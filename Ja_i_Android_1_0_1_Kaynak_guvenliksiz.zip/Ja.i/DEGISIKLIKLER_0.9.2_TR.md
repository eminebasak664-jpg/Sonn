# Ja.i 0.9.2 — Dosya ve web bağlamı entegrasyonu

## Dosya okuma ve arşivler
- `FileManager` artık `ToolRegistry` içinde `file_inspect` aracı olarak kayıtlıdır. Kullanıcı tarafından seçilen ve ek metnine dönüştürülen içeriği Flash/Think araç seçimi üzerinden yanıt bağlamına aktarır. Keyfî URI açmaz.
- Eski 8 MiB metin dosyası okuma kotası kaldırıldı. Tekil metin/GZIP tamponları telefonun mevcut uygulama heap'ine göre dinamik hesaplanır; sıkıştırılmış NBT için eski 64 MiB açılım eşiği de dinamik tampon bütçesine geçirildi.
- ZIP/TAR toplam açılmış içerik için sabit 128 MiB kotası kaldırıldı; toplam yalnızca raporlanır. Tek bir içerik byte[] olarak çözümlenmek zorundaysa tekil tampon dinamik heap bütçesine tabidir; TAR/TGZ girdileri akıştan tek tek okunur.
- Tekil ZIP/TAR girdilerinde sabit 16 MiB kotası kaldırıldı; tek tampon boyutu anlık heap ve kopyalama maliyetine göre belirlenir.
- ZIP iç içe derinlik 3 sınırı kaldırıldı. İç içe ZIP akışları özyinelemeli çağrı yerine açık yığınla işlenir; sabit derinlik kesmesi yoktur. 10.000 girdi sayısı, yol geçişi reddi ve yalnızca bellekte tutulan iç içe arşivler için dinamik bellek bütçesi korunur. TAR için de işlemci yükünü sınırlayan 10.000 girdi sınırı vardır. NBT ayrıştırıcısında 64 yapısal katman ve 1 milyon düğüm koruması saldırgan/bozuk NBT yapısına karşı kalır; bunlar ZIP iç içe derinlik sınırı değildir.
- TAR ve `.tar.gz`/`.tgz` artık tüm arşivi tek byte dizisine yüklemez; girdileri akıştan birer birer okur. ZIP'te de tüm arşiv toplam açılımı sabit kotayla kesilmez; iç içe ZIP katmanlarının aynı anda bellekte tuttuğu baytlar dinamik heap bütçesine tabidir.
- TAR sabit 128 MiB toplam ve 16 MiB tek-girdi eşikleri kaldırıldı; akış tabanlı okuma ve dinamik tek-girdi/rapor bütçesine geçti.
- Çoklu eklerin 8.000.000 karakter sabit toplam sınırı kaldırıldı. Birleştirme, kullanılabilir uygulama belleğine göre yapılır; yer kalmazsa kısmi içerik uyarısı eklenir.

## Web araştırması
- Ara açıkken araştırma, BrainEngine yanıtından önce çalışır. Kaynak başlıkları, tarihleri, alan adları, sayfa durumu, alıntılar ve URL'ler Flash/Think bağlamına aktarılır.
- Think görevinde web kanıtı `supplemental_context` alanına kaydedilir; görev devam ettirildiğinde aynı kanıt bağlamı korunur.
- Web araştırması başarısız olursa yerel yanıt yine üretilir; hata ayrıca raporlanır.
- Ara kapalıyken web isteği başlatılmaz.
- Araştırma kontrolsüz sonsuz sorguya dönüşmez: Hızlı/Orta/Maksimum/Derin modlarında 4/7/12/16 arama isteği, 8/14/24/32 sayfa açma ve 60/90/150/180 saniye üst bütçesi vardır. Bütçe dolarsa toplanmış kaynaklar yine yanıt bağlamına aktarılır.

## Doğruluk ve güvenlik notları
- Sabit dosya boyutu eşikleri tamamen sınırsız okuma anlamına gelmez. Büyük veri ancak Android uygulamasının o anki heap'i yeterliyse okunur; aksi durumda işlem bellek hatası verir veya çoklu ek bağlamı açıkça kısaltır.
- Web sayfalarının okunması iddiaları bağımsız doğrulanmış yapmaz.
- Haricî AI API'si veya indirilen LLM eklenmedi.
