# Ja.i 1.0.0 — DEVAM NOTU

## Bu sürümde yapılanlar

- 0.9.8 kaynak yapısı korundu; proje Android Java/Gradle olarak kaldı.
- `ModelEngine` sınıflandırıcısından ayrı olarak kullanıcı tarafından Colab'da sıfırdan eğitilecek GRU sohbet modeli eklendi.
- `ByteTokenizer` UTF-8 bayt biçimini eğitim notebook'u ile eşleştirir.
- `LocalOnnxLanguageModel` ONNX Runtime ile cihazda yerel çıkarım yapar; model ZIP'ini güvenli klasör/uzantı/byte sınırlarıyla içe aktarır.
- Zekâ ayarı penceresine model durumu ve **Colab modelini yükle** eylemi eklendi.
- Colab notebook'u 5.000 çok turlu CC BY 4.0 diyalog ve yaklaşık 51.900 Apache-2.0 talimat-cevap örneği seçeneğini yükleyebilir; kullanıcı JSONL verisi de ekleyebilir.
- Eğitim/doğrulama/test kümeleri kayıt düzeyinde ayrı tutulur. Her asistan turu EOS ile biter ve loss yalnızca asistan yanıtlarına uygulanır.
- Üretilen metin için ek yerel güvenlik filtresi eklendi.
- Android derleme hedefi API 36, AGP 8.13.2, Gradle 8.13 ve Java 17 olarak güncellendi; Android 15/16 sistem çubuğu inset yönetimi eklendi.

## Bilinen gerçek sınırlar

- Colab eğitimi bu ortamda çalıştırılmadı; eğitim yalnızca kullanıcı Google Colab'da çalıştırdığında gerçekleşir.
- Varsayılan 5.000 sentetik diyalog veri kümesi bir genel amaçlı LLM değildir. Model küçük bir GRU'dur; cevap kalitesi sınırlı olabilir.
- Bu ortamda Android SDK/Gradle dağıtımı indirilmediği için APK derlemesi ve gerçek cihaz testi yapılmadı.
- ONNX model import/inference gerçek cihazda doğrulanmadı.
- Web araştırması, dosya araçları ve diğer mevcut özellikler kaynakta korunmuştur; bütün Android uçtan uca akışları bu ortamda çalıştırılmadı.

## Telefondan sonraki kullanıcı adımı

1. Kaynak ZIP'i çıkar.
2. Colab notebook'unu Google Colab'da açıp veriyi ve eğitimi çalıştır.
3. `jai-chat-model.zip` paketini indir.
4. Ja.i 1.0.0'da Zekâ ayarı → Colab modelini yükle yoluyla aktar.
5. APK'yi GitHub Actions veya Android IDE ile derle; gerçek cihaz denemesinde hata kaydını incele.
