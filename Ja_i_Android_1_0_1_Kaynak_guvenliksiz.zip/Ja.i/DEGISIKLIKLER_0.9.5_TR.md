# Ja.i 0.9.5 — Yerel görsel ve Minecraft Bedrock paket üretimi

## Yerel görsel üretimi
- `ProceduralImageGenerator.java` eklendi. Haricî görsel modeli, model indirme, API veya ağ isteği kullanmaz.
- Şekil, çizgi, elips, poligon, renk paleti, katman ve deterministik piksel dokusu ile sahne kurar; PNG dosyasını Java koduyla doğrudan kodlar.
- Ejderha, kedi, ağaç, ev, dağ manzarası, kristal, çiçek, balık, robot, mantar, roket ve soyut kompozisyon için yerel sahne tarifleri vardır.
- Varsayılan çıktı 256×256 PNG'dir. 16–512 piksel aralığı desteklenir. Minecraft modeli için ayrıca 64×64 bölümlü UV doku atlası üretilir.
- Bu yöntem prosedürel/rule-based çizimdir; diffusion modeli veya serbest biçimli üretken görsel zekâ değildir. İstekler desteklenen sahne tariflerine eşlenir.

## Minecraft Bedrock paket üretimi
- `MinecraftPackGenerator.java` eklendi.
- Tek kaynak paketi isteği `.mcpack`; tek davranış paketi isteği `.mcpack`; birlikte istenen kaynak + davranış paketi `.mcaddon` olarak çıkar.
- Kaynak paketinde manifest, vanilla dirt doku değiştirme PNG'si, eşya atlası, dil dosyaları ve tam add-on modunda custom mob doku/geometry/client entity dosyaları bulunur.
- Davranış paketinde manifest, işlenmiş golden apple tarifi, loot table ve çağrılabilir `functions/jai_info.mcfunction` bulunur.
- Birleşik add-on'a özel pasif yaratık (entity JSON, spawn rule, loot), `jai:moonstone` özel bloğu, `jai:moon_crystal` özel eşyası, bunların dokuları, terrain texture kaydı, tarifler ve loot tabloları eklenir.
- Behavior Pack manifesti Resource Pack UUID bağımlılığını taşır. Manifest/header/module UUID'leri ayrı oluşturulur.
- `ProjectArchiveWriter.createZipBinary` PNG gibi ikili dosyaları değiştirmeden ZIP/MCAddon içine yazar. Güvensiz yol reddi ve 128 dosya/16 MiB sınırı vardır.

## Android arayüzü
- Kod Laboratuvarı görsel çıktıyı PNG önizlemesiyle gösterir.
- PNG, MCPACK, MCADDON ve mevcut çok dosyalı web ZIP çıktıları Android Storage Access Framework üzerinden kaydedilebilir.
- Sohbet içinden görsel/paket üretim isteği algılanır ve Kod Laboratuvarı'na yönlendirme açıklaması döner; ikili dosyanın kendisi sohbet metnine gömülmez.
- Orijinal sohbet arayüzü ve mevcut proje üretim akışı korunmuştur.

## Sınırlar
- Serbest biçimli metinden her tür foto-gerçekçi görsel üretimi yoktur; bu sürümde tarif tabanlı çizim ve piksel kompozisyonu vardır.
- Üretilen yaratık şimdilik ortak basit geometri/UV şablonu kullanır; özel animasyon, karmaşık model rig'i, ses, script API ve isteğe bağlı her oyun mekaniği henüz yoktur.
- `.mcworld` gerçek LevelDB dünya veritabanı gerektirdiğinden bu sürümde üretilmez. `.jar` derlemek için JVM sınıf üretimi/derleme hattı henüz yoktur.
- Minecraft JSON yapısı statik olarak üretilir; Bedrock'ın farklı sürümlerinde import/oyun testi yapılmadı. Hedeflenen minimum paket motoru 1.20.80, özel blok JSON formatı 1.21.50'dir.
- Tam Android Gradle/APK derlemesi ve gerçek telefonda UI testi bu geliştirme ortamında yapılamadı (Android SDK/android.jar ve Gradle 8.9 dağıtımı yok).

## Sürüm
- `versionCode`: 16
- `versionName`: 0.9.5
