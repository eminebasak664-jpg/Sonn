# Ja.i 0.9.6 — 720p görsel öğrenme, video ve gelişmiş Bedrock üretimi

## Görsel üretimi ve yerel öğrenme
- Görsel üretiminde varsayılan çıktı 1280×720 PNG'dir. Kullanıcı 16×16–512×512 gibi küçük kare boyut veya 720×1280 dikey boyut belirtebilir.
- "piksel piksel", "pixel art" ve "8 bit" isteklerinde 720p hedefe düşük çözünürlüklü piksel ızgarası en yakın-komşu ölçekleme ile büyütülür; pikseller bulanıklaştırılmaz.
- `VisualLearningEngine`: sıfırdan yazılmış 12→32→3 küçük MLP; etiketli kullanıcı görsellerinde geri yayılım (backpropagation) ile eğitim, ağırlıkları yerel dosyaya kaydetme ve yeniden yükleme içerir.
- Kullanıcının daha önce verdiği **Altın Ağ Küresi Amblemi** görseli tek başlangıç örneği olarak paketlendi. Başlangıç ağırlıkları bu görselde eğitildi; ilk açılışta örnek de yerel görsel belleğine eklenir.
- Kullanıcı Kod Laboratuvarı'nda etiket yazıp kendi görselini seçerek aynı ağı eğitebilir. Etikete eşleşen görsel örneği oran korunarak 720p'ye dönüştürülür; pixel-art isteğinde nearest-neighbor kullanılır. En fazla dört örnek/etiket tutulur.
- Bu, bağımsız bir yerel öğrenme bileşenidir; genel amaçlı diffusion/text-to-image modeli değildir. Bir örnekten ilgisiz kavramları (ör. logo örneğinden televizyon) öğrenmiş gibi davranmaz. TV gibi tanımlı sahneler ayrıca yerel raster tarifleriyle çizilebilir; yeni kavramlar için kullanıcı örneği gerekir.

## Video
- `AndroidVideoGenerator` Android `MediaCodec` / H.264 / `MediaMuxer` ile 1280×720, 24 FPS, 4 saniyelik MP4 üretim hattı içerir.
- Mevcut sürüm oluşturulmuş 720p görsele pan/zoom ve parçacık hareketi ekleyen kısa kliptir; tam metinden sinema kalitesinde video sentezi değildir. Bu MP4 yolunun gerçek Android cihazda donanımsal kodlayıcı testi henüz yapılmadı. Ses kanalı eklenmez.

## Minecraft Bedrock
- Ayrı kaynak paketi (`.mcpack`), davranış paketi (`.mcpack`), ikisini içeren `.mcaddon` ve kaynak/davranış paketleri gömülü `.mcworld` kapsayıcısı üretilir.
- `.mcaddon` dış ZIP'i iki iç `.mcpack` taşır; her paketin `manifest.json` dosyası kendi arşivinin kökündedir.
- Kaynak paketi: PNG blok/eşya/varlık dokuları, dil kayıtları, geometri, render controller, ses tanımları ve OGG sesleri.
- Davranış paketi: özel yaratık, spawn kuralı, özel blok/eşya, tarifler, loot tabloları, `.mcfunction` komut dosyaları ve `@minecraft/server` Script API başlangıcı.
- Yedi kemik tabanlı animasyon ve geçiş denetleyicisi: idle, walk, run, attack, hurt, jump, sit.
- `.mcworld` çıktısı `level.dat`, `levelname.txt`, paket bağlantıları, `db/` başlangıç dizini ve paketleri taşır. `db/` içinde Minecraft LevelDB kayıtları üretilmediği için bu hâli tam oynanabilir dünya olarak garanti edilmez; Minecraft ilk açılışta veri tabanını oluşturmalı ve gerçek içe aktarma testi yapılmalıdır.

## Java JAR
- `SourceJarGenerator` küçük, çalıştırılabilir Java 8 bytecode içeren genel amaçlı JAR ve kaynak/manifest üretir. Bu genel Java JAR'ıdır; Fabric/Forge Minecraft modu veya istenen herhangi bir Java uygulamasını doğal dilden eksiksiz derleyen bir derleyici değildir.

## Android
- Görsel eğitim örneği seçicisi iptal edilirse bekleyen etiket temizlenir.
- Video üretim hataları arka plan iş parçacığını düşürmek yerine Kod Laboratuvarı'nda gösterilir.
- Orijinal yerel sohbet arayüzü ve haricî AI API/model kullanmama kuralı korunur.

## Sürüm
- `versionCode`: 17
- `versionName`: 0.9.6
