# Ja.i 0.9.6 test raporu

## Çalıştırılan doğrulamalar
- 7 saf Java üretim sınıfı JDK ile derlendi: `ProjectArchiveWriter`, `ProceduralImageGenerator`, `VisualLearningEngine`, `MinecraftSoundAssets`, `SourceJarGenerator`, `BedrockWorldArchiveGenerator`, `MinecraftPackGenerator`.
- Görsel, öğrenme ve Minecraft için 13 test metodu yerel JUnit-uyumlu test adaptörüyle geçti (6 görsel üretim, 2 öğrenme, 5 Minecraft/paket testi). Bu, Gradle/JUnit Android projesi testi değildir.
- Varsayılan görsel üretimi 1280×720 PNG verdi. Piksel-art 720p ve dikey 720×1280 üretim kontrolleri geçti.
- Başlangıç sinir ağı model dosyası 2.117 bayt olarak üretildi ve görsel etiketi `altin ag kuresi emblemi` ile yükleme/üretim kontrolü yapıldı. Örnek görselden 720p çıktı üretildi ve görsel olarak açıldı.
- Yeni etiketli görsel eğitimi, backpropagation, ağırlıkların kaydı/yüklenmesi ve etiket eşleştirme testleri geçti.
- `.mcaddon` dış ZIP içinde iki `.mcpack` bulundu. Her iki iç arşiv CRC kontrolünden geçti; içindeki tüm JSON dosyaları ayrıştırıldı. Kaynak ve davranış paketlerinde manifest, UUID modülleri, bağımlılık, geometri, 7 animasyon, controller, Script API, özel blok/eşya/tarif/loot dosyaları doğrulandı. Ayrı istenen `.mcpack` kaynak ve davranış çıktılarının da aynı gelişmiş varlık/animasyon ve davranış dosyalarını taşıdığı test edildi.
- Üç OGG dosyası `OggS` başlığıyla kontrol edildi. Animasyon adları ve script dosyası arşiv içinde bulundu; script `node --check` ile sözdizimi kontrolünden geçti.
- `.mcworld` ZIP CRC, `level.dat` v10 başlığı/payload uzunluğu, `db/`, `levelname.txt` ve dünya paket bağlantısı dosyaları kontrol edildi. Bu doğrulama Minecraft oyun içi açılış testi değildir.
- Üretilen JAR `java -jar` ile başlatıldı ve konsola çıktı verdi.
- Eski çok dosyalı web üretimi ve yapılandırılmış JavaScript sentezi dosyaları projede korundu; Android tarafı tam derlenemedi.

## Bu ortamda yapılamayan testler
- Tam Android Gradle derlemesi/JUnit görevi ve APK üretimi: Android SDK/`android.jar` yok; Gradle 8.9 dağıtımı bu ortamda indirilemedi. Bu nedenle APK hazır değildir.
- `AndroidVideoGenerator` Android MediaCodec kodu statik olarak eklendi ancak gerçek telefonda H.264 kodlayıcısı ve MP4 oynatma testi yapılmadı.
- Minecraft Bedrock içinde `.mcpack`, `.mcaddon`, `.mcworld` içe aktarma, Script API çalışma zamanı, animasyon görünümü, ses çalma ve paket uyumluluğu gerçek cihazda test edilmedi.
- `.mcworld` içinde LevelDB verileri üretilmedi. Arşiv iskeleti hazırlanıyor; açılabilir dünya garantisi verilmez.

## Telefon manuel test planı
1. GitHub Actions ile APK'yı derle; `Ja.i-debug-apk` artifact'ini indirip telefona kur.
2. Kod Laboratuvarı → `televizyon resmi yap` → Üret: varsayılan 1280×720 PNG önizlemesini ve Kaydet akışını kontrol et.
3. `televizyon piksel piksel çiz 720p` ile bloklu piksel çıktısını kontrol et.
4. Başlangıç örneği için `altın ağ küresi amblemi 720p çiz` üret; örneğin oranının korunduğunu gör.
5. Kod Laboratuvarı'na yeni bir etiket yaz (ör. `televizyon`), örnek görsel seç ve Ja.i'ye öğret. Aynı etiketi içeren isteği yeniden üret.
6. `Minecraft için özel yaratık, animasyon, ses ve script içeren tam mcaddon yap` komutuyla paket üret; Minecraft'a aktar ve kaynak/davranış paketlerini dünyada etkinleştir.
7. `720p video yap` ile MP4 üretmeyi dene; cihazda codec desteklenmiyorsa hata metnini kaydet.
8. `.mcworld` arşivini ve JAR'ı hedef uygulamalarında ayrıca test et. JAR genel Java JAR'ıdır, Minecraft mod JAR'ı değildir.
