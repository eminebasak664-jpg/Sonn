# Ja.i 1.0.0 — Telefonda APK derleme kılavuzu

Bu arşiv **Android kaynak projesidir; içinde hazır APK yoktur**. Bilgisayar kullanmadan APK üretmek için GitHub Actions akışı dahildir.

## 1. GitHub deposunu hazırla

1. GitHub'da Ja.i için kullandığın depoyu aç.
2. `Ja.i_Android_1.0.0_Tam_Kaynak_Colab.zip` dosyasını deponun kök dizinine yükle ve `main` dalına commit et.
3. İlk kurulumda ZIP'in içindeki `.github/workflows/android.yml` dosyasını ayrıca GitHub deposunun **gerçek kök dizininde** `.github/workflows/android.yml` yoluna koy. GitHub, ZIP'in içine gömülü bir workflow'u kendiliğinden etkinleştirmez.
4. Kaydet ve `main` dalına commit et.

## 2. APK çıktısını al

1. Depoda **Actions** sekmesine gir.
2. `Ja.i Android APK` iş akışını aç.
3. Son çalışmanın başarıyla tamamlanmasını bekle ve çalışma kaydını aç.
4. **Artifacts → Ja.i-debug-apk** öğesini indir.
5. İnen artifact ZIP'ini telefonda çıkar; içindeki `app-debug.apk` dosyasını Android'in dosya yöneticisiyle açıp yükle.

İş akışı JDK 21, Gradle 8.13, Android API 36 ve Build Tools 36.0.0 kullanır. Uygulama kaynakları Java 17 hedefiyle derlenir. Başarılı Actions çalışması gerçek bulut derlemesidir; yalnızca kaynak ZIP'i yüklenmiş olması APK üretildiği anlamına gelmez.

## 3. Colab'da sohbet modelini eğit

1. ZIP'ten `colab/Ja.i_1.0.0_Sifirdan_Sohbet_Modeli_Egitimi.ipynb` dosyasını telefona çıkar.
2. Google Colab'da notebook'u aç.
3. Çalışma zamanı türünü mümkünse GPU seç; GPU ücretsiz kullanımda garanti değildir.
4. Hücreleri sırayla çalıştır. Varsayılan veri seçenekleri 5.000 çok turlu Türkçe diyalog ve yaklaşık 51.900 talimat-cevap örneğidir. İstersen kendi hakkın olan JSONL verisini de yükle.
5. Eğitim ve ONNX doğrulama tamamlanınca `jai-chat-model.zip` dosyası indirilir.
6. Ja.i 1.0.0 APK'sini aç → **Zekâ ayarı → Colab modelini yükle** → `jai-chat-model.zip` dosyasını seç.
7. Durum mesajı modelin yerel ONNX oturumunun açıldığını doğrulamalı. Daha sonra interneti kapatıp sohbet ederek ağsız çalışma kontrolü yap.

## Gerçekçi sınırlar

- Notebook hazır bir model veya hazır ağırlık kullanmaz; GRU ağı rastgele başlatılır ve seçilen metin verisiyle Colab'da eğitilir.
- Bu küçük model genel amaçlı büyük dil modeli değildir. 5 bin diyalog ve 51.9 bin talimat örneği başlangıç/prototip ölçeğindedir; doğal, geniş kapsamlı ve güvenilir sohbet kalitesi garanti edilmez.
- Veri kaynaklarının cevapları hatalı/eskimiş olabilir. Lisans/atıf koşullarını koru; özel konuşma, kişisel bilgi veya eğitim hakkın olmayan veriyi yükleme.
- Colab GPU, oturum süresi, RAM ve kota garantisi vermez. Eğitim tamamlanmadan kesilirse model ZIP'i oluşmaz.
- Uygulama, Colab'da eğitilen ONNX modelini telefonda yerel çalıştırır. Harici sohbet API'si kullanmaz. Web araştırması sadece `Ara` açık olduğunda etkinleşir.

## Derleme başarısız olursa

GitHub Actions çalışma kaydındaki ilk `FAILED` adımının hata metnini kaydet. Sadece son satır yerine hatanın başladığı bölüm de gereklidir. Debug APK, Play Store için imzalı release APK/AAB değildir.
