# Ja.i 0.9.3 — Yerel zekâ karar katmanı

## Yeni bileşen
- `app/src/main/java/com/jai/assistant/engine/LocalIntelligenceEngine.java`
  - İstek sınıflandırmasını görev türüne dönüştürür.
  - Kavram kelimelerini ayıklar.
  - Güncel bilgi gereksinimini işaretler.
  - Karşılaştırma, kod ve özet isteklerinde dar kapsamlı eksik-parametre kontrolü yapar.
  - İstek karmaşıklığını 1–5 arası sezgisel ölçer.

## Var olan zekâ bileşenleri geliştirildi
- `ModelEngine.java`: 11 niyet; araştırma/dosya/özet/karşılaştırma kategorileri; bilinen kelime sayısı, sözlük kapsaması ve sezgisel kanıt gücü.
- `LocalLanguageEngine.java`: hafıza adayları alaka puanına göre sıralanır; `KnowledgeAssessment` eşleşen sorgu terimlerini, kanıt sayısını ve kapsama oranını verir.
- `TaskPlanner.java`: istek profili, yerel bilgi yeterliliği ve güncel bilgi ihtiyacı plan adımlarına eklenir.
- `BrainEngine.java`: Think kontrol noktaları niyet kanıtı, görev türü, karmaşıklık ve bilgi yeterliliğini saklar. `zeka durumu` komutu eklendi.
- Testler: sınıflandırıcı sinyal metrikleri ve yeni istek anlama kuralları için regresyon testleri eklendi.

## Yerel kullanım
- `zeka durumu`: mevcut yerel karar altyapısının kabiliyetlerini ve sınırlarını gösterir.
- `öğret-intent:arastirma|son güvenlik gelişmelerini kaynaklarıyla araştır`: yeni bir sınıflandırma örneği kaydeder; bu genel dil üretimini eğitmez.
- Eksik karşılaştırma isteği (`bunu karşılaştır`) netleştirme sorusu üretir; iki konu birlikte yazıldığında istek karşılaştırma olarak sınıflandırılır.

## Tasarım sınırı
Bu sistem yerel ve deterministik bir karar/arama/planlama katmanıdır; üretken büyük dil modeli değildir. Kelime kapsaması anlamsal doğruluk ölçmez. Harici AI API'si veya indirilen dil modeli eklenmedi.

## Derleme durumu
JDK 21 mevcut; bu ortamda Gradle 8.9 dağıtımı ve Android SDK bulunmadığı için Android unit testleri/APK derlemesi çalıştırılamadı.
