# Ja.i — Android / Java yerel asistan

**Sürüm:** 1.0.1  
**Paket:** `com.jai.assistant`  
**APK durumu:** Bu ZIP kaynak kodudur; hazır APK değildir.

Ja.i, Android üzerinde Java ile çalışan, çevrimdışı yerel araçlar ve kullanıcı tarafından eğitilen küçük sohbet modeli altyapısı içeren asistandır. Orijinal koyu mor/turkuaz arayüz çizgisi korunmuştur. Harici sohbet AI API'si ve hazır dil modeli ağırlığı kullanılmaz. Üretken sohbet modeli, Colab notebook'unda sıfırdan eğitilip uygulamaya içe aktarılmadan hazır sayılmaz.

## 1.0.1 — Kaynak uyumlu MP4 üretimi ve dosya aktarımı

- Video profili cihazın mantıksal CPU çekirdeği, okunabilirse kısa süreli /proc/stat CPU yük örneklemi, düşük-RAM sınıfı bilgisi, anlık kullanılabilir sistem RAM'i, uygulama heap'i ve cache alanına göre seçilir: 1280×720/24 FPS, 960×540/20 FPS veya 640×360/15 FPS.
- Kaynaklar yetersizse kalite kademeli düşürülür; en hafif profil için bile yeterli RAM/depolama yoksa işlem başlamadan anlaşılır hata verilir. Süre istenen 1–60 saniye aralığında korunur.
- MP4 artık tümüyle byte[] olarak belleğe kopyalanmaz. Codec verisi cache dosyasına aktarılır; kullanıcı dışa aktarırken 64 KiB tamponla arka plan iş parçacığında seçtiği konuma akış halinde kopyalanır.
- Video çizim döngüsünde Matrix yeniden kullanılır; parçacık sayısı seçilen profile göre azaltılır. Eski geçici MP4 dosyaları yedi günden sonra temizlenir.
- Kaynak durumu ekranı işlemci çekirdeği, uygulama belleği, sistem RAM'i ve boş veri alanını raporlar.
- Örnek JSONL dosya adı yalnızca ASCII karakterlerle yeniden adlandırıldı; içeriği değiştirilmedi.
- Yeni birim testleri kaynak profili seçimini, kalite düşürmeyi ve yetersiz RAM/depolama durumlarını kontrol eder (7 test).
- Güncellenmiş Colab eğitimi kaynak gruplarına göre örnekleme dengesi uygular; epoch/erken durdurma, en iyi checkpoint ve ONNX karşılaştırmasını içerir.

## 1.0.0 — Sıfırdan eğitilen sohbet modeli ve yerel ONNX çıkarımı

- `ByteTokenizer` eğitim ve Android tarafında aynı UTF-8 bayt/special-token biçimini kullanır. Önceki asistan cevapları geçmişte EOS ile sonlandırılır.
- `LocalOnnxLanguageModel`, kullanıcı tarafından Colab'da rastgele ağırlıklardan eğitilen GRU modelini ONNX Runtime ile cihazda çalıştırır. Harici sohbet API'si veya önceden eğitilmiş model ağırlığı indirmez.
- Zekâ ayarlarına **Colab modelini yükle** eylemi eklendi. Uygulama yalnızca doğruladığı model paketini uygulamanın özel depolamasına alır; ZIP dosya yolu, içerik adı, yinelenen kayıt ve boyut sınırları denetlenir.
- Colab notebook'u iki açık Türkçe veri seçeneği kullanır: 5.000 çok turlu günlük diyalog (CC BY 4.0) ve yaklaşık 51.900 talimat-cevap örneği (Apache-2.0). Basit, korumacı veri filtresi uygulanır; veri doğruluğu garanti edilmez.
- Eğitim/doğrulama/test kayıtları ayrı tutulur. Her asistan cevabı EOS ile biter; eğitim kaybı yalnızca asistan cevabı ve EOS hedeflerine uygulanır, kullanıcı metni hedef olarak öğretilmez.
- Eğitim sonrası ONNX model doğrulaması ve Android'e aktarılacak tek `jai-chat-model.zip` paketi oluşturulur.
- Gerçek sınır: Bu küçük GRU prototipi geniş bilgi ve insan seviyesinde sohbet kabiliyeti garanti etmez. 5K/51.9K veri kümeleri büyük genel amaçlı model eğitimi için yeterli değildir. Kalite, veri ve eğitim sonuçlarına bağlıdır.
- Model yüklenmemişse uygulama bunu bildirir ve mevcut yerel araç/hafıza davranışına döner; eğitilmiş model varmış gibi davranmaz.
- Android hedefi API 36, AGP 8.13.2, Gradle 8.13 ve Java 17 uygulama bytecode'u; CI başlangıç aracı JDK 21 ister.

### 1.0.0 Colab ve APK adımları

- Güncel eğitim: `colab/Ja.i_1.0.1_Sifirdan_Sohbet_Modeli_Egitimi.ipynb` (Ja.i 1.0.1 ile uyumlu, 2.1 eğitim akışı)
- Eski 1.0.0 notebook: geçmiş sürüm karşılaştırması için korunur.
- Eğitim kodu/testleri: `training/`
- Telefonda APK: `APK_OLUSTUR_TELEFON_1.0.0_TR.md`
- Değişiklik listesi ve doğrulama: `DEGISIKLIKLER_1.0.0_TR.md`, `TEST_RAPORU_1.0.0_TR.md`

## 0.9.8 — Web görsel örnekleri ve yerel piksel öğrenmesi
- Ara açıkken görsel istekleri web görsel aramasına yönlendirilir; en fazla dört güvenli HTTPS raster görseli indirilir, 256×256 sınırına küçültülerek etiketli yerel örneklere dönüştürülür. Ham görseller saklanmaz.
- Aynı nesne için en fazla beş referans görseli saklanır. Yerel 16→128→64→3 ağın piksel renk tahminleri, bu örneklerin pikselleriyle birleştirilerek yeni raster PNG üretilir.
- Üretilen eski prosedürel çizimler otomatik eğitim örneği yapılmaz. Uygulama, eğitilmemiş nesneyi geometrik şablonla biliyormuş gibi çizmez.
- Sınır: Bu hâlâ küçük bir yerel MLP ve örnek pikseli bileşimidir; genel nesne tanıma/diffusion modeli veya fotogerçekçi görsel zekâ değildir. Canlı web araması ve APK için Android cihaz/SDK testi gerekir.

## 0.9.7 — Araştırma destekli üretim, 60 saniye çok sahneli video ve kişiselleştirilmiş Bedrock modları
- Görsel ağ 16→128→64→3 mimarisine yükseltildi: 10.627 eğitilebilir parametre; 0.9.6'daki 12→32→3 ağa göre yaklaşık 20,6 kat. Eski v1 ağırlıkları okunup yeni mimariye taşınır.
- Ara açıkken sohbet ve Kod Laboratuvarı görsel/video/Minecraft üretim isteğini üretimden önce web'de araştırır; kaynak raporunu yerel öğrenme belleğine kaydeder. Görsel/video metinsel tasarım ipuçlarını sahne kompozisyonuna katar; Minecraft teknik kaynakları üretim notlarına eklenir. Ara kapalıysa bu üretim yolları web isteği göndermez.
- Yerel görsel kompozisyon motoru 1280×720 PNG ve keskin piksel-art üretir. Araştırma açıklamasından örnek kompozisyon oluşturabilir ve bu kompozisyondan bir başlangıç eğitim turu yapabilir; kullanıcı seçtiği görseli etiketleyerek de ağı eğitir.
- Video süresi 1–60 saniye; varsayılan 10 saniye. Video planlayıcı dört kadraj (açılış, yakın plan, aksiyon, final) oluşturur; güncel kaynak yönetimi profiline göre sahneler 720p, 540p veya 360p çizilir ve H.264 MP4 içinde geçiş, kamera hareketi, parallax ve parçacıklarla birleştirilir.
- Bedrock istemci profili 1.21.132.1; paket `min_engine_version` 1.21.132. Script API bağımlılığı `@minecraft/server` 2.4.0 olarak ayarlanır.
- İstemden yaratık adı çıkarımı (ejderha, zombi, iskelet, kedi, kurt, yılan, örümcek, golem, robot) kaynak/davranış paketi yolları, kimlikleri, script ve dil anahtarlarına uygulanır. Ejderha için ayrı kanat-kuyruk geometrisi, kanat çırpma animasyonları ve uçuş AI bileşenleri üretilir. Birden fazla dekoratif/yardımcı özel eşya ve tarif üretilebilir.
- 999 gibi miktarlar tek yığın olarak yazılmaz: 15×64 + 39 gibi geçerli yığın komutlarıyla toplam miktarı veren `.mcfunction` üretilir. Bedrock'ın standart eşya yığın sınırı 64'tür.
- `BedrockPackRepairEngine` JSON son virgüllerini ve 64 üstü stack değerlerini güvenli mekanik kurallarla düzeltir; bilinmeyen JSON/şema hatasında paketi başarılıymış gibi sunmak yerine üretimi durdurur.
- Video sahne planlayıcısı, 999 eşya bölme, özel ejderha/eşya kimlikleri, araştırma notu, yerel MLP ve onarım yolları için testler eklendi.
- Bu sürümde haricî AI modeli/API'si kullanılmaz. Yerel sahne çizimi, araştırılmış metin ipuçları ve kullanıcı örnekleriyle gelişir; foto-gerçekçi diffusion/video üretici değildir. Donanımsal MP4 üretimi gerçek Android cihazda ayrıca test edilmelidir.

## 0.9.6 — 720p görsel öğrenme, video ve gelişmiş Minecraft üretimi (önceki sürüm)
- Varsayılan PNG 1280×720; pixel-art düşük çözünürlüklü ızgaradan nearest-neighbor ile 720p'ye büyütülür.
- 12→32→3 yerel MLP, etiketli kullanıcı görselleriyle backpropagation eğitimi ve yerel örnek görsel belleği kullanır. Başlangıç örneği Altın Ağ Küresi Amblemi'dir.
- Android MediaCodec H.264 ile 720p MP4 üretim kodu eklendi (24 FPS/4 saniye pan-zoom/partikül); cihaz testi yok.
- Bedrock `.mcpack`, iç mcpack'li `.mcaddon`, `.mcworld` kapsayıcısı, yedi kemik animasyonu, OGG ses, Script API, blok/eşya/tarif/loot dosyaları üretir.
- Genel Java çalıştırılabilir `.jar` üretimi eklendi; Fabric/Forge modu değildir. `.mcworld` LevelDB'si henüz boş ve gerçek dünya açılışı doğrulanmamıştır.
- Bu yerel MLP genel amaçlı foto-gerçekçi diffusion modeli değildir; yeni kavramlar için etiketli örnek gerekir.

## 0.9.5 — Prosedürel PNG ve Minecraft Bedrock üretimi
- `ProceduralImageGenerator`, haricî görsel modeli/API indirmeden kurallı sahne tarifleri, şekiller, renk paletleri ve piksel dokularından PNG üretir. Ejderha, kedi, ağaç, ev, dağ, kristal, çiçek, balık, robot, mantar, roket ve soyut sahne türleri desteklenir. Bu bir diffusion modeli değildir.
- `MinecraftPackGenerator` kaynak paketi (`.mcpack`), davranış paketi (`.mcpack`) ve birlikte `.mcaddon` üretir. Birleşik pakete örnek pasif yaratık, spawn/loot kuralları, özel blok, özel eşya, tarifler ve görsel dokular eklenir.
- Minecraft paketleri Bedrock `manifest.json`/UUID/bağımlılık düzeniyle oluşturulur; binary ZIP yazıcısı PNG baytlarını korur.
- Kod Laboratuvarı PNG önizlemesi verir ve PNG/MCPACK/MCADDON çıktılarını Android dosya seçicisiyle kaydeder. Sohbet istekleri doğru araca yönlendirir.
- Sınır: görseller prosedürel çizimdir; gerçek foto-gerçekçi serbest üretim değildir. Minecraft paketleri gerçek oyunda henüz test edilmemiştir. `.mcworld` ve `.jar` bu sürümde üretilmez.

## 0.9.4 — Gerçek çok dosyalı kaynak üretimi
- `ProjectCodeGenerator` eklendi: doğal dildeki proje tarifini desteklenen işlevlere ayırır, özellikleri birleştirir ve `index.html`, `styles.css`, `app.js`, `README.md` dosyalarını ayrı ayrı sentezler. Bu, sabit bir sayfa şablonu seçmekten farklı olarak sayaç, görev, not, hesaplama ve oyun davranışlarını aynı kaynak dosyasında birleştirir.
- Tek istekte görev listesi, kalıcı notlar, sayaç, hesap makinesi ve kronometre gibi modüller birleştirilebilir. Oyun üretimi tıklama, hafıza kartı, refleks testi, bilgi yarışması ve X-O türlerini destekler.
- Proje başlığı ve birkaç görünüm tercihi (ör. turkuaz/mavi/yeşil vurgu) tariften çıkarılır. Metin HTML olarak kaçırılır; kullanıcı metni kaynak kod içine doğrudan HTML olarak yerleştirilmez.
- Oluşturulan projeler haricî CDN/kütüphane/API kullanmadan çevrimdışı çalışacak şekilde hazırlanır; görev/not/sayaç verisi tarayıcı `localStorage` alanında saklanır.
- `ProjectCodeValidator`, HTML ana dosya bağlantılarını ve CSS/JavaScript ayraçlarını statik olarak denetler. Bu doğrulama gerçek tarayıcı çalıştırması değildir.
- Kod Laboratuvarı'ndan üretilen çok dosyalı kaynaklar Android Storage Access Framework üzerinden ZIP olarak kaydedilebilir. Sohbet içinde de her dosyanın kaynak metni gösterilebilir.
- `ProjectArchiveWriter` dört dosyayı UTF-8 ZIP olarak paketler; en fazla 64 dosya ve 2 MiB kaynak toplamı kabul edilir, güvensiz arşiv yolları reddedilir.
- Kod Laboratuvarı'na çok dosyalı proje ZIP dışa aktarma düğmesi eklendi. ZIP, Android Storage Access Framework üzerinden kullanıcı tarafından seçilen konuma yazılır.
- Sohbet komutuyla kod isteği gönderildiğinde desteklenen proje dosyaları ayrı kod bloklarıyla yanıtlanır. Desteklenmeyen 3D/Android gibi istekler hazırmış gibi gösterilmez.
- `ModelEngine` kod üretim niyetini tanımak için uygulama, web projesi ve oyun istekleriyle yeni eğitim örnekleri aldı.
- Haricî AI API'si veya indirilen dil modeli eklenmedi. Bu sürüm hâlâ yerel kural/özellik tabanlı üretimdir; serbest doğal dilde sınırsız kodlama yapan LLM değildir.

## 0.9.3 — Yerel zekâ karar katmanı
- `LocalIntelligenceEngine` eklendi: istek türü, kavramlar, karmaşıklık, güncel bilgi ihtiyacı ve eksik parametre analizi.
- Naive Bayes sınıflandırıcısına araştırma, dosya, özet ve karşılaştırma niyetleri eklendi (toplam 11 niyet).
- Sınıflandırmaya bilinen kelime sayısı, sözlük kapsaması ve sezgisel kanıt gücü eklendi. Bunlar kalibre edilmiş doğruluk olasılığı değildir.
- Yerel hafıza adayları güncellikten önce alaka puanına göre sıralanır; `KnowledgeAssessment` sorgu kelimelerinin ne kadarının kayıtlarda eşleştiğini raporlar.
- Think planı istek profili, bilgi yeterliliği, güncel bilgi gereksinimi ve sınıflandırma kanıtını kaydeder.
- `zeka durumu` komutu yerel zekâ yeteneklerini ve sınırlarını açıklar.
- Harici AI API'si veya indirilen dil modeli eklenmedi. Bu sürüm genel amaçlı üretken LLM değildir.

## 0.9.2 — Dosya aracı ve web kanıtı entegrasyonu
- `FileManager`, `ToolRegistry` içine `file_inspect` genel aracı olarak kaydedildi; kullanıcı tarafından seçilip okunmuş ek içerik Flash ve Think işlem hattına girer.
- Eski 8 MiB metin, ZIP/TAR için 128 MiB toplam açılım, 16 MiB tek girdi ve üç ZIP iç içe geçiş sınırları kaldırıldı. ZIP/TAR toplam açılmış veri için sabit kota yoktur; TAR ve TGZ akıştan okunur. Tekil girdiler ve aynı anda bellekte tutulan iç içe ZIP katmanları telefonun anlık heap bütçesine tabidir. İç içe ZIP'lerde sabit derinlik kesmesi yoktur.
- Çoklu dosya eklerinde 8.000.000 karakter sabit toplam sınırı kaldırıldı. İçerik o anki boş uygulama belleği ölçüsünde bağlama alınır; yetmiyorsa kısmi olduğu açıkça bildirilir.
- ZIP/TAR başına 10.000 girdi üst sınırı ve güvensiz arşiv yolu reddi korunur. Bunlar dosya boyutu/depth kotası değil; arşiv girdisi fırtınası ve yol geçişine karşı CPU/güvenlik kontrolleridir. NBT içinde ayrı bir yapısal derinlik/düğüm koruması bulunur.
- Ara açıkken web araştırması BrainEngine yanıtından önce yapılır; kaynak başlığı, URL, alan adı, tarih, sayfa durumu ve içerik parçaları Flash/Think bağlamına aktarılır. Think kontrol noktası bu kanıt bağlamını saklar.
- Web araştırması Hızlı/Orta/Maksimum/Derin için sırasıyla 4/7/12/16 arama isteği, 8/14/24/32 sayfa açma ve 60/90/150/180 saniyelik üst bütçeler kullanır. Ara kapalıyken ağ isteği gönderilmez.
- Bu sürüm hâlâ haricî AI API'si veya genel dil modeli eklemez. Yerel motor dosya/web metninden ilişkili cümleleri seçer; yeni olgular üretmez.

## 0.9.1 — Zekâ altyapısı ve görev orkestrasyonu

### İstek analizi ve araç seçimi
- `ModelEngine.classifyDetailed` istek türüyle birlikte normalize edilmiş göreli sınıflandırma puanlarını ve ilk iki etiket arasındaki farkı döndürür. Bu değerler kalibre edilmiş olasılık veya genel dil modeli güveni değildir.
- `ToolRegistry`, her araca istek eşleştiricisi ve girdi çıkarıcısı ekleyebilir. Uygun araçlar puanlanır ve en yüksek eşleşme seçilir; eşleşme yoksa sistem sahte araç sonucu üretmez.
- Hesap makinesi, hafıza arama, cihaz kaynakları ve statik kod ön kontrolü otomatik yönlendirmeye bağlandı.
- Kodla ilgili bir kelimenin (ör. “Java”) tek başına kod üretim isteği sayılması engellendi. Kod tarif menüsü açık kod üretme niyetinde gösterilir.

### Bağlam, plan ve yürütme
- Think işlem sırası bağımlılıklara göre düzenlendi: analiz → yerel bağlam → plan → yürütme → doğrulama.
- Getirilen yerel hafıza bağlamı artık yanıt üretim yoluna parametre olarak aktarılır; yanıtın sonuna bağımsız bir ek olarak iliştirilmez.
- `TaskPlanner.ExecutionPlan`, hedefi, sınıflandırılmış isteği, seçilen aracı, bağlam/denetim gereksinimlerini ve uygulanabilir adımları saklar. Plan aşamasında seçilen araç yürütme aşamasında gerçekten çağrılır.
- Doğrulama yalnızca yürütmeden sonra yapılır. Kod için basit statik ayraç/XML ön kontrolü uygulanır; bu kontrol derleme veya çalıştırma değildir. Düz metinde yalnızca boş çıktı kontrolü yapılır; olgusal doğruluk iddia edilmez.

### Kalıcı Think görevleri
- Her Think isteği SQLite görev kaydı alır. Efor, seçilen aşamalar, bağlam, araç seçimi, ara çıktı ve sonraki aşama JSON kontrol noktası olarak saklanır; özgün kullanıcı girdisi ayrı `brain_task_payloads` tablosunda tutulur. Büyük ek metni her checkpoint güncellemesinde tekrar yazılmaz. Veritabanı sürümü 3’e yükseltilmiş, eski sürüm 2 verisi için geçiş eklenmiştir.
- Her tamamlanan adımın ardından kontrol noktası yazılır. Kayıt başarısızsa görev sessizce tamamlanmış gösterilmez.
- Uygulama kapanır veya bir adım hata verirse `görev devam: ID` komutuyla ilk tamamlanmamış aşamadan devam edilebilir. Tamamlanmış aşamalar tekrar çalıştırılmaz. `görevleri göster` Think ve öğrenme kayıtlarını birlikte listeler.
- Think görevleri WebResearch WorkManager işinden ayrıdır; MainActivity bunları yanlışlıkla araştırma işçisine göndermez.

### Efor/aşama davranışı
- Akıllı Hızlı: analiz + yürütme; Orta: analiz + bağlam + plan + yürütme; Maksimum/Derin: beş farklı aşamanın tamamı.
- Manuel 1–115 değeri üst sınır olarak saklanır. Gerçekten mevcut beş farklı aşamadan fazlası uydurulmaz; 5 üzerindeki istek, tekrar döngüsü açmadan açıklamayla sonlanır.
- Manuel 1 doğrudan yürütme, 2 analiz+yürütme, 3 analiz+bağlam+yürütme, 4 planlamayı da ekler, 5 doğrulamayı yürütmeden sonra ekler.

### Bilinçli sınırlar
- `ModelEngine` hâlâ küçük bir Naive Bayes sınıflandırıcısıdır; sınıflandırma puanı dil anlama veya metin üretme kabiliyeti değildir.
- `LocalLanguageEngine` kayıtlı metinden bağlam seçer; serbest ve yeni genel bilgi üreten bir LLM değildir.
- Think aşamaları yerel işlemlerdir, art arda model çıkarımı değildir. Haricî AI API'si veya gizlice indirilen genel model eklenmemiştir.

## 0.9.0 — Geniş dosya okuyucu ve uyarlanabilir web araştırması

### Dosya araçları
- Dosya seçici artık `*/*` üzerinden tüm dosya türlerini gösterebilir; çoklu seçimde 5 dosyalık yapay bir adet sınırı kaldırıldı.
- Dosya uzantısı tanınmasa bile UTF-8/UTF-16 metin içeriği algılanır. TXT, Markdown, Java, Kotlin, Python, HTML, CSS, JS, JSON, XML, YAML, CSV, SQL, Gradle, shell ve benzeri metinler ortak okuyucudan geçer.
- ZIP tabanlı paketler içerik imzasıyla tanınır. ZIP, JAR, APK/AAB, MCPACK/MCADDON/MCWORLD, DOCX/XLSX/PPTX, ODT/ODS/ODP, EPUB ve CBZ paketlerinin metin/XML girdileri arşiv diske çıkarılmadan okunur. İç içe ZIP paketleri de incelenir.
- ZIP içindeki `.nbt` ve `.mcstructure` girdileri için Java big-endian ve Bedrock little-endian Minecraft NBT okuyucusu eklendi. JAR içindeki `.class` dosyalarında kaynak kod geri üretilmez; yalnızca okunabilir sabit dizeler çıkarılır.
- TAR ve GZIP/TGZ arşivleri okunur. PDF ve fotoğraf analizi mevcut PDFBox/ML Kit altyapısını kullanır. Ses/video dosyalarında başlık/sanatçı/süre gibi meta veriler okunur; transkripsiyon yapılmaz.
- Bilinmeyen ikili dosyalarda güvenli okunabilir metin dizeleri çıkarılır. RAR/7z arşivleri bu sürümde açılmaz; tam içerik çözümlenmiş gibi gösterilmez.

### Web araştırması
- Ara açıkken `researchAdaptive` kullanılır; kaynaklar Flash/Think cevap çalıştırılmadan önce toplanır ve kanıt bağlamı olarak BrainEngine’e aktarılır. Ara kapalıyken MainActivity ve kalıcı görev işçisi web isteği başlatmaz.
- “Hızlı/Orta/Maksimum/Derin” seçimi başlangıç sorgularının genişliğini ve takip sorgularında kullanılacak metin miktarını değiştirir.
- Yeni bulunan kaynaklardan takip sorguları türetilir; URL'ler tekilleştirilir. Telefon/ağ kaynaklarını korumak için efor seviyesine göre arama, sayfa ve süre bütçeleri uygulanır.
- DuckDuckGo HTML sayfalamasında ilk yanıtın `vqd` belirteci alınır; sonraki sayfalar form POST akışıyla çağrılır. Bu akış güncel SearXNG uygulama kaynağıyla karşılaştırılarak düzenlendi; canlı cihaz/ağ entegrasyon testi henüz yapılmadı.
- HTTPS kaynak sayfaları okunur; localhost/yerel IP hedefleri reddedilir ve yönlendirmeler takip edilmez. Sayfada yayın tarihi metaverisi bulunursa rapora eklenir; yoksa “çıkarılamadı” olarak belirtilir.
- Araştırma motoru efor seviyesine göre arama, sayfa açma ve süre bütçesi uygular; yeni URL ve kaynak doygunluğu araştırmayı daha erken sonlandırabilir. DuckDuckGo erişimi kendi bot koruması ve hız sınırlamalarına tabi olabilir.

## 0.6.0 sürümünde eklenenler (0.8.1 sürümünde korunur)

### PDF ve fotoğraf analizi
- PDF'nin seçilebilir metin katmanı PDFBox Android ile okunur. Telefon belleğini korumak için PDF 20 MiB, metin çıkarımı ilk 20 sayfa ile sınırlıdır.
- Taranmış PDF'de metin azsa ilk en fazla 5 sayfa Android `PdfRenderer` ile görüntülenir ve cihaz içi ML Kit OCR denenir.
- Fotoğrafta metin OCR ile çıkarılır; ayrıca sınırlı yerel etiketleyici en fazla 8 kategori etiketi gösterebilir.
- Fotoğraf boyutu işleme öncesi küçültülür; 20 MiB üzerindeki dosyalar reddedilir.
- **Sınır:** Bu özellik ChatGPT benzeri sahne/kişi/bağlam muhakemesi değildir. OCR ve sınıflandırma sonuçları hata yapabilir. Kimlik tanıma yapılmaz.

### Kod laboratuvarı
- Çevrimdışı kod üretiminde iki yol vardır: (1) değişken/fonksiyon/ifade/koşul/döngü/atama/çıktı komutlarını içeren yapılandırılmış mini dil tanımından yeni JavaScript sentezi, (2) mevcut başlangıç örnekleri/tarifleri. Mini dil genel amaçlı doğal dil kod üreticisi değildir.
- Mini dil biçiminde olmayan istekler mevcut başlangıç tarifleriyle eşleşmiyorsa desteklenmiyor olarak bildirilir. Örneğin 3D Minecraft benzeri oyun motoru bu sürümde oluşturulmaz.
- JavaScript, Rhino runtime yorumlayıcısında sınırlı süre, kaynak uzunluğu ve çıktı sınırıyla çalıştırılır. Java/Android sınıflarına doğrudan erişim kapatılmıştır.
- HTML, Java, Python, XML ve JSON kaynakları kaydedilebilir; bunlar bu sürümde uygulama içinde çalıştırılmaz/derlenmez. HTML önizlemesi ve Android APK üretimi uygulamanın içinde yoktur.

### Uzun görevleri sürdürme
- Araştırma görevleri SQLite görev kaydı + Android WorkManager ile adımlara ayrılır: hazırlık, ağ araştırması, kaynak notlarını kaydetme, yerel cümle seçici özet ve tamamlandı durumu.
- Uygulama kapanınca WorkManager işi sistem kuyruğunda kalabilir. İnternet gerektiren adım ağ koşuluyla sıraya alınır.
- Ara daha sonra kapatılırsa arka plan işçisi ağ isteği göndermez; görev beklemede kalır. Yeniden sürdürmek için Ara'yı açıp `görev devam: ID` yazılır.
- Android arka plan/Doze/üretici politikaları işin ne zaman çalışacağını geciktirebilir. 7/24 çalışma garantisi yoktur.

### Yerel dil motoru
- Türkçe kelime ayıklama, kayıtlı hafızadan ilgili cümleleri puanlama, tekrarları azaltma ve yerel özet cümleleri seçme geliştirildi.
- Motor yalnızca cihazdaki kayıtlı bilgiye ve tanımlı araçlara dayanır.
- **Sınır:** Bu bir büyük dil modeli değildir; serbest biçimde yeni bilgi icat etmez ve ChatGPT düzeyinde genel amaçlı dil üretimi yapamaz. Hafızada yeterli bilgi yoksa bunu söyler.

### Gerçek cihazlar arası mesajlaşma altyapısı
- `server/` klasöründe FastAPI + SQLite mesaj sunucusu; Android tarafında HTTPS istemcisi bulunur.
- Kullanıcı adı/parola ile kayıt ve giriş, parola için PBKDF2-HMAC-SHA256, sunucuda token özeti saklama, Android cihazında token'ı Keystore AES-GCM ile koruma vardır.
- Mesaj gönderme, gelen kutusu eşitleme, teslim ve okundu makbuzları sunucudaki gerçek kayıtları temel alır.
- Gelen kutusu eşitleme “teslim edildi” durumunu oluşturur. Mesajı okundu işaretlemek kullanıcı tarafından ayrıca yapılır.
- **Gerçek kullanım için:** Sunucu internette HTTPS ile barındırılmalı, kalıcı disk `/data` konumuna bağlanmalı, Android'de Sunucu bölümüne bu adres girilmeli ve iki cihazda ayrı hesap açılmalıdır.
- **Henüz yok:** Sunucu bu ZIP ile internete dağıtılmış değildir; canlı uçtan uca cihaz testi yapılmamıştır. Anlık push bildirimi/WebSocket yoktur; gelen kutusu kullanıcı tarafından eşitlenir. Uçtan uca şifreleme yoktur; mesaj metni sunucu veritabanında okunabilir şekilde saklanır. Hassas bilgi göndermeyin.

## Önceden bulunan işlevler
- Yerel sohbet ve SQLite konuşma/hafıza kayıtları.
- `hatırla: ...`, `hafızada ara ...`, hafıza arşivleme/silme komutları.
- Yerel dört işlem ayrıştırıcısı ve sınırlı istek türü sınıflandırıcısı.
- Ara açıkken DuckDuckGo araması ve sınırlı HTTPS sayfası çıkarımı. Ara kapalıyken web istekleri engellenir.
- Kaynak notları URL üzerinden tekilleştirilir ve `verified=0` olarak kaydedilir; bu model eğitimi veya bağımsız doğrulama değildir.
- ZIP tabanlı arşivlerin metin/XML girdilerini diske çıkarmadan okuma; JAR/MCPACK/Office/EPUB ve iç içe ZIP desteği.
- Açılışta ayarlı sunucu adresine tek uyandırma/sağlık isteği. Sürekli ping döngüsü yoktur.

## Kurulum ve doğrulama

### Android kaynak projesi
- Android Studio/Gradle projesi `Ja.i/` klasöründedir.
- `minSdk 26`, `compileSdk/targetSdk 36`, Java 17 uygulama kaynak uyumluluğu ve Gradle 8.13 kullanılır. Paket içindeki küçük Gradle başlatıcısı JDK 21 gerektirir; GitHub Actions da JDK 21 ile çalışır.
- `./gradlew validateAndroidResources testDebugUnitTest` kaynak doğrulama ve birim testlerini çalıştırır.
- `./gradlew assembleDebug` APK üretir. Bu aşamada APK oluşturulmamıştır.

### GitHub Actions (telefon üzerinden)
Ayrıntılı güncel adımlar: `APK_OLUSTUR_TELEFON_1.0.0_TR.md`.
- Bu sürümün kaynaklarını GitHub deposuna yüklerken ZIP dosyasını tek başına depo köküne koymak yeterli değildir. ZIP'i çıkar; `app/`, `gradle/`, `build.gradle`, `settings.gradle` ve `.github/workflows/android.yml` dosyaları depo kökünde görünmelidir.
- `main` dalına bu kaynakları yüklediğinde Actions Android kaynaklarını kontrol eder, birim testlerini çalıştırır ve `assembleDebug` ile APK üretir.
- İstersen **Actions → Ja.i Android APK → Run workflow** ile aynı işlemi elle de başlatabilirsin.
- Başarılı derlemenin `Ja.i-debug-apk` adlı artifact'ini Actions çalışmasının içinden indir. Artifact 14 gün saklanır.
- Otomatik derleme açık olması sorun değildir; her yeni kaynak ZIP'i yüklemesinde yeni APK üretilir. Bu işlem bulut derlemesidir ve telefonunda Android SDK kurmanı gerektirmez.

### Mesaj sunucusu
Ayrıntılı adımlar `SERVER_KURULUM_TR.md` dosyasındadır. Ücretsiz barındırma hizmetlerinin kart koşulu, uyku politikası, disk kalıcılığı ve kullanım sınırları hizmete göre değişir; ücretsiz/7x24 süreklilik garanti değildir.

## Veri ve gizlilik
- Sohbetler, hafıza ve görevler cihazda SQLite veritabanındadır.
- Sunucu adresi ve oturum anahtarları Android Keystore/uygulama ayarlarında korunur; mesajlaşma parolası cihazda saklanmaz.
- Web araştırması etkinleştirilirse sorgu DuckDuckGo'ya ve okuma isteği seçilen web sitelerine gönderilir. Hassas bilgiyle Ara'yı açmayın.
- Mesajlaşma sunucusu mesaj metinlerini şimdilik şifrelenmemiş biçimde saklar; uçtan uca şifreleme yoktur.
- Haricî sohbet AI API'si veya hazır genel dil modeli ağırlığı kullanılmaz. Kullanıcı Colab notebook'unda sıfırdan eğittiği GRU modelini ONNX ZIP olarak içe aktarır; model cihazda yerel çalışır. ML Kit OCR ve görsel etiketleme modelleri görsel/metin yardımcı araçlarıdır, sohbet dil modeli değildir.

## 0.8.1 — Think aşama hattı ve yapılandırılmış kaynak sentezi

- Yeni **Zekâ ayarı** ekranında Akıllı (otomatik) veya Manuel mod seçilebilir.
- Manuel aşama sayısı 1–115 aralığında girilebilir; tercih SharedPreferences içinde saklanır.
- Think akışı, `TaskStageEngine` ile isteğe bağlı analiz, yerel bağlam, plan, görev yürütme ve çıktı kontrolü adımlarına ayrılır. Gerçek ilerleme göstergesi her adımı izler.
- Manuel 1–115 ayarı bağımsız yerel adımlar için üst sınırdır; mevcut en fazla beş aşama bulunur. Fazladan tekrar veya model çağrısı uydurulmaz. Eğitilmiş 65M dil modeli ve ardışık model çıkarım döngüsü henüz yoktur.
- `StructuredProgramCompiler`, tanımlı komutlardan yeni JavaScript sentezler; 16.384 karakter, 100 komut, 256 ifade belirteci ve 10.000 döngü adımı üst sınırı bulunur. Bu, genel doğal dil üretimi değildir.
- Özgün kod üretimi, Colab model eğitimi ve gerçek çok aşamalı model çevrimi için ayrıntılı gereksinimler `JA_I_YENI_GEREKSINIMLER_0.8.0_TR.md` dosyasındadır.

## 0.7.0 — Yerel dil ve kod tarif motoru

### Yerel dil motoru iyileştirmeleri
- Türkçe karakter normalleştirme, yaygın ek kırpma ve sınırlı eş anlamlı genişletme eklendi.
- Sınıflandırıcı da aynı metin işlemeyi kullanır; kullanıcıdan gelen etiketli örnekler yeniden sınıflandırıcı eğitimine katılır.
- Hafıza sorgusu birden fazla kök/sinonimle denenir; sonuçlar cümle düzeyinde sıralanır, tekrarlar azaltılır ve web kaynak kayıtları URL olarak gösterilir.
- Özetleme ilk cümleleri körlemesine kesmek yerine cümleleri anahtar sözcük yoğunluğuna göre sıralar.
- Bu motor hâlâ bir büyük dil modeli değildir. Dilbilgisel ek ayrıştırması yaklaşık, sinonim sözlüğü küçük ve bilgi alanı yerel hafızayla sınırlıdır.

### Genişletilmiş kod üretimi
- Şablonlar sayaç, hesap makinesi, Fibonacci, asal sayı, yapılacaklar listesi, metin araçları, dizi araçları, HTML başlangıç/portfolyo sayfası, tıklama oyunu, bilgi yarışması ve X-O oyununu kapsar.
- Java ve Python için başlangıç kaynakları üretilebilir ancak bu diller uygulama içinde derlenmez/çalıştırılmaz.
- Her çıktı `supported`, `templateId` ve `runnableInLab` alanlarıyla işaretlenir. Eşleşmeyen istek artık sahte bir örnek kod üretmek yerine boş kaynakla açıkça reddedilir.
- JavaScript şablonları Rhino sandbox'ta denenebilir; HTML çıktıları tarayıcı önizlemesi desteklenene kadar dosya/kaynak metni olarak kalır.

### GitHub APK otomasyonu
- GitHub deposunun köküne `Ja.i_Android_0.9.1_Zeka_Altyapisi.zip` eklendiğinde `main` dalındaki `push` olayı APK derlemesini otomatik başlatır.
- Actions ayrıca elle `workflow_dispatch` ile de çalıştırılabilir. `build_apk` seçeneği kaldırıldı; derleme işi artık varsayılan olarak APK üretir.
- Başarılı derleme `Ja.i-debug-apk` artifact'i olarak yüklenir. Bu, imzalı Play Store paketi değil, test amaçlı debug APK'dır.

### Bilinen sınırlar
- Bu çalışma ortamında Android SDK/Gradle dağıtımına erişilemediği için APK'nın derlendiği iddia edilmez.
- Bu oturumda 0.8.1 ZIP GitHub'a yüklenmedi. Depoya eklendikten sonra Actions derlemesi başlayabilir; sonucu Actions ekranında doğrulanmalıdır.


## 0.8.1 geliştirme notu

Think akışına `TaskStageEngine` eklendi. Manuel/akıllı aşama seçimi gerçek yerel işlem hattını yönetir; yerel bağlam aşaması puanlanmış kayıt cümleleri seçer. Ayrıca `StructuredProgramCompiler` yapılandırılmış satırlardan yeni JavaScript üretir ve `CodeGenerator` içinde ilk yol olarak kullanılır. Kod çıktısı için statik ön kontrol yapılır. Bunlar eğitilmiş dil modeli çıkarımı veya serbest doğal dilde genel amaçlı kod üretimi değildir.
