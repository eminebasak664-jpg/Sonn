# Ja.i 0.9.0 — Test Raporu

## Kapsam
Yalnızca dosya ve web araştırma araçları geliştirildi. APK üretilmedi. Orijinal ekran tasarımında görsel değişiklik yapılmadı.

## Derleme kontrolleri
- `ResearchSource`, `ResearchReport`, `WebResearchEngine`, `ZipArchiveInspector`, `TarArchiveInspector`, `NbtInspector`: JDK 17 `javac` derlemesi başarılı.
- `FileManager`: Android `Context`, `ContentResolver`, `Uri`, `Cursor`, `OpenableColumns`, `MediaMetadataRetriever` ve `DocumentImageAnalyzer` için geçici test stub'larıyla `javac` derlemesi başarılı. Gerçek Android SDK/Android framework derlemesi değildir.
- `MainActivity` ve `DurableTaskWorker` kaynak bağlantıları kontrol edildi; tam Android build ile doğrulanmadı.

## Otomatikleştirilmiş kontroller
14 JUnit uyumlu test metodu geçti:
1. ZIP içindeki Java/metin dosyasının içeriği okunuyor.
2. İç içe `.mcpack`/ZIP manifest içeriği okunuyor.
3. `../` yol geçişi reddediliyor.
4. Java big-endian NBT string alanı okunuyor.
5. Bedrock little-endian NBT string alanı okunuyor.
6. TAR içindeki text içeriği okunuyor.
7. ResearchReport okunabilen sayfa/farklı alan adı sayısını ayrı tutuyor.
8. Yayın tarihi metaverisi raporda gösteriliyor.
9. Web kaynağı içeriği kesin doğru diye etiketlenmiyor.
10. Boş web sorgusunda ağ isteği yapılmıyor.
11. DuckDuckGo başlangıç arama URL’sinde sorgu parametresi doğru oluşturuluyor.
12. DuckDuckGo HTML içindeki `vqd` devam belirteci ayıklanıyor.
13. Uzantısı bilinmeyen dosya adıyla gelen UTF-8 metin okunuyor.
14. Uzantısı bilinmeyen dosyanın ZIP imzası algılanıp içeriği okunuyor.

Ek Java smoke testi: ZIP metni, nested paket, path traversal koruması, TAR okuması, Java/Bedrock NBT ve boş adaptive sorgu kontrolü geçti.

## Henüz doğrulanmayanlar
- Gradle `testDebugUnitTest`, Android `assembleDebug` ve tam Android kaynak derlemesi bu ortamda çalıştırılmadı; Android SDK/Gradle dağıtımı bulunmuyor.
- Gerçek Android cihazda SAF belge sağlayıcısı, çoklu dosya seçimi, PDF/fotoğraf/medya işlemleri test edilmedi.
- Canlı DuckDuckGo sorgusu ve sonraki sayfanın `vqd` form POST isteği gerçek ağda test edilmedi. Kod akışı güncel SearXNG DuckDuckGo adaptöründe belgelenen vqd/POST parametrelerine göre yazıldı.
- Web sayfalarında meta yayın tarihi her sitede bulunmaz; boşsa `sayfadan çıkarılamadı` gösterilir.
- RAR/7z arşivleri açılmaz; eski OLE DOC/XLS/PPT ve birçok özel ikili biçim tam ayrıştırılmaz. JAR içindeki `.class` kaynak koda decompile edilmez; okunabilir string'ler çıkarılır.
- Ses/video meta verisi çıkarılır; konuşma transkripsiyonu yapılmaz.

## Telefon kaynakları ve içerik sınırları
- Düz metin okuma: 8 MiB/dosya.
- ZIP: 10.000 girdi, girdi başına 16 MiB, toplam açılmış veri 128 MiB, nested depth 3, rapor metni 8 MiB.
- TAR/GZIP: açılmış veri 128 MiB; TAR girdi başına 16 MiB.
- Sohbet mesajına birleşik ek metni: 8 MiB. Üzerindeki dosyalar yine teker teker okunur fakat tam içerikleri tek mesaja eklenmeyebilir.
- Mevcut PDF/görsel analyzer sınırları korunur: PDF 20 MiB ve ilk 20 sayfa, taranmış PDF OCR ilk 5 sayfa, görsel 20 MiB ve küçültülmüş çözünürlük.

Bu sınırlar format kısıtlaması değil; Android belleğini, işlem süresini ve arşiv bombalarına karşı güvenliği korumak içindir.
