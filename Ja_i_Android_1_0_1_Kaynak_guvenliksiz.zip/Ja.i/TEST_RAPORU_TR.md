# Ja.i 0.7.0 — Geliştirme Test Raporu

Tarih: 1 Kasım 2026

## Bu turda gerçekten çalıştırılan kontroller

| Kontrol | Sonuç | Kapsam |
|---|---:|---|
| Türkçe metin ve kod üretim saf-Java testleri | 17/17 geçti | Normalleştirme, ek kırpma, sinonim, sayaç, HTML oyun/quiz, Java/Python başlangıç, dinamik Fibonacci/asal sayı parametreleri, desteklenmeyen talepler |
| Yerel hafıza dil motoru harness'i | 3/3 geçti | Stub SQLite kaynağı üzerinde arama/URL gösterme, bilgi yoksa reddetme, cümle puanlı özet |
| Naive Bayes sınıflandırıcı harness'i | 1 senaryo geçti | Kod/hafıza etiketleri ve kullanıcı örneğiyle güncelleme |
| JavaScript şablon statik ayraç kontrolü | 8/8 geçti | CodeLabEngine'in basit ayraç ön kontrolü |
| HTML yapı kontrolü | 5/5 geçti | Python HTMLParser ile etiket açma/kapatma dengesi ve parser hatası kontrolü |
| Android kaynak XML kontrolü | 5/5 dosya ayrıştırıldı | Python XML parser ile iyi biçimlenmiş XML kontrolü |

## Testlerin kapsam sınırı
- Yerel dil motoru için kullanılan `MemoryDatabase` testte bir Java stub'ıydı; gerçek Android SQLite veritabanı üzerinde cihaz testi değildir.
- JavaScript kontrolü derleme/çalıştırma değil, yalnızca basit ayraç ön kontrolüdür. Rhino runtime üzerinde cihaz içi yürütme bu turda çalıştırılmadı.
- HTMLParser kontrolü HTML5 tarayıcı uyumluluğunu veya görsel davranışı kanıtlamaz.
- Tam Gradle komutu `./gradlew --no-daemon validateAndroidResources testDebugUnitTest` denendi; özel Gradle başlatıcısı `services.gradle.org` üzerinden dağıtımı indirme aşamasında tamamlanamadı. Ortamda `ANDROID_HOME` ve `ANDROID_SDK_ROOT` yok.
- APK oluşturulmadı; iki gerçek Android cihazda test yapılmadı.

## Yeni 0.7.0 işlevleri
- `TurkishTextProcessor`: Türkçe karakter normalleştirme, sınırlı suffix/stem işlemi, stopword temizleme, küçük sinonim haritası.
- `LocalLanguageEngine`: birden fazla hafıza sorgusu, cümle relevans sıralama, tekrar azaltma, kaynak URL gösterimi ve anahtar sözcük puanlı özet.
- `CodeGenerator`: 15 kod tarifi; sayaç, hesap makinesi, Fibonacci, asal sayılar, yapılacaklar, metin/dizi araçları, JavaScript başlangıç, Java/Python başlangıç, HTML başlangıç/portfolyo, tıklama oyunu, quiz ve X-O.
- Bilinmeyen istekler `supported=false` ve boş kaynakla sonuçlanır; destek varmış gibi davranılmaz.
- GitHub Actions yeni `Ja.i_Android_*.zip` dosyasını main'e ekleyince otomatik `assembleDebug` yapacak şekilde yapılandırıldı.

## Açık kalanlar
- Genel amaçlı LLM düzeyinde kod veya doğal dil üretimi yok.
- Python/Java derleyicisi, HTML uygulama içi önizleme, tam çoklu-dosya proje sentezi yok.
- APK'nın GitHub Actions üzerinde başarılı build olduğunun doğrulanması bekliyor.
- GitHub deposunda şu anda 0.1.1 ZIP'i var; 0.7.0 ZIP'i kullanıcı tarafından repo köküne eklendikten sonra yeni workflow çalışacak.
