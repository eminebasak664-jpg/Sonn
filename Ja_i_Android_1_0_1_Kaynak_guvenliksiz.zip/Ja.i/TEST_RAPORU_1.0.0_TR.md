# Ja.i 1.0.0 — Test Raporu

Tarih: 4 Kasım 2026

## Geçen testler

| Test | Sonuç | Kapsam |
|---|---|---|
| Python birim testleri | GEÇTİ (7/7) | UTF-8 tokenizer, özel işaretler, asistan turu EOS, kullanıcı/asistan loss maskesi, konuşma ayrımı, sabit dizi parçaları, JSONL ve GRU çıktı şekli |
| Python eğitim smoke testi | GEÇTİ | Demo verisiyle 3 CPU adımı, doğrulama kaybı hesaplaması, kontrollü çıkış |
| Java çekirdek derlemesi | GEÇTİ | ChatMessage, TurkishTextProcessor, ByteTokenizer, SafetyPolicyEngine |
| Java ONNX adapter sözdizim/bağlantı derlemesi | GEÇTİ (stub API ile) | LocalOnnxLanguageModel Java sözdizimi ve beklenen çağrı biçimleri; gerçek ONNX runtime testi değildir |
| Java tokenizer/güvenlik smoke testi | GEÇTİ | Geçmiş işaretleri, mevcut prompt'un tekrarlanmaması, tarih sorusunun engellenmemesi, uygulamalı zarar isteğinin ön kapıda durması |
| Colab notebook JSON | GEÇTİ | 13 hücre, geçerli notebook JSON |
| Notebook Python hücreleri | GEÇTİ (söz dizimi) | Notebook magic satırları ayrıldıktan sonra Python AST kontrolü |
| Notebook ile eğitim script eşitliği | GEÇTİ | `%%writefile` hücresindeki script, `training/train_jai_from_scratch.py` ile aynı |
| Android XML | GEÇTİ | Kaynak XML dosyaları XML parser ile okunabildi |
| GitHub Actions YAML | GEÇTİ | YAML sözdizimi çözümlendi |
| ZIP bütünlüğü | GEÇTİ | Son arşiv `unzip -t` ile kontrol edildi; beklenen ana dosyalar arşivde bulundu |

## Yakalanıp düzeltilen hatalar

1. Test modülü proje kökünden çalıştırılınca eğitim modülünü bulamıyordu. Göreli/yerel import fallback'i eklendi.
2. Çok turlu kayıtlarda asistan cevabı yalnızca tüm konuşmanın sonunda bitiyordu. Her asistan cevabına EOS eklendi.
3. Model kullanıcı metnini de hedef olarak öğreniyordu. Loss maskesi yalnızca asistan yanıtı ve EOS tokenlerine uygulandı.
4. Android istem bağlamını her bayt için ayrı ONNX çağrısıyla işliyordu. Değişken uzunluklu giriş ve tek çağrıda bağlam işleme eklendi.
5. Colab notebook'undaki eğitim kodu ana kaynak dosyadan ayrışabiliyordu. Notebook `%%writefile` hücresi güncel script ile birebir eşitlendi.
6. Özel Gradle bootstrap JDK 21 bytecode'u istediği hâlde CI JDK 17 kuruyordu. CI JDK 21 olarak düzeltildi; Android Build Tools 36.0.0 ayarlandı.
7. İlk kaynak taraması Java text block sözdizimini normal çok satırlı string gibi algıladı; denetleyici Java 17 text block biçimine göre yeniden çalıştırıldı. 89 Java dosyasında leksik kontrol sıfır hata verdi.
8. Araştırma/dosya bağlamı olduğunda eski bağlam yanıtlayıcısına doğrudan geçiliyordu. Eğitilmiş model varsa bu bağlam artık sohbet modeline aktarılır; model yoksa eski yerel yanıtlayıcı yedek olur.

## Bu ortamda çalıştırılamayanlar

- `./gradlew assembleDebug`: Gradle 8.13 dağıtımı henüz yerel önbellekte yok; indirme denemesi bu ortamın DNS/ağ erişiminde başarısız oldu. Android SDK/`android.jar` da kurulu değil.
- ONNX dışa aktarma/runtime: bu ortamda `onnx` ve `onnxruntime` Python paketleri kurulu değil. Colab hücreleri notebook'ta hazırlandı ama Google Colab üzerinde yürütülmedi.
- Gerçek Android cihaz testi: APK üretilemediği için yapılmadı.
- Canlı Hugging Face veri indirme: notebook kodu statik olarak kontrol edildi; bu oturumda veri kümesi çekilmedi.

## Sonuç

Son kaynak değişikliklerinden sonra Python testleri yeniden çalıştırıldı: 7/7 geçti. 3 adımlı CPU eğitim smoke testi yeniden geçti. Java tokenizer/güvenlik smoke testi yeniden geçti. Java dosyalarının 89/89 leksik taraması sıfır hata verdi. Notebook içindeki script, `training/train_jai_from_scratch.py` ile birebir eşleşiyor.


Kaynak, eğitim kodu, tokenizer/safety çekirdeği, notebook ve ZIP paket yapısı statik/yerel testlerden geçti. Ancak bu rapor **APK'nın derlendiğini, Colab eğitimini tamamladığını veya eğitilmiş modelin telefonda çalıştığını iddia etmez**. Bunlar için GitHub Actions ve Google Colab'ın gerçek çalışma sonuçları gerekir.
