# Ja.i 0.9.1 — Zekâ altyapısı

Bu sürüm temel zekâ orkestrasyonunu geliştirir. Dosya/web araçları için 0.9.0'daki kod korunur; arayüz tasarımı değiştirilmedi.

## Değişen dosyalar
- `app/src/main/java/com/jai/assistant/engine/BrainEngine.java`
- `app/src/main/java/com/jai/assistant/engine/ModelEngine.java`
- `app/src/main/java/com/jai/assistant/engine/ToolRegistry.java`
- `app/src/main/java/com/jai/assistant/engine/TaskPlanner.java`
- `app/src/main/java/com/jai/assistant/engine/TaskStageEngine.java`
- `app/src/main/java/com/jai/assistant/engine/TaskPersistence.java`
- `app/src/main/java/com/jai/assistant/data/MemoryDatabase.java`
- `app/src/main/java/com/jai/assistant/engine/LocalLanguageEngine.java`
- `app/src/main/java/com/jai/assistant/MainActivity.java`
- `app/build.gradle`
- `app/src/test/java/com/jai/assistant/engine/ModelEngineTest.java`
- `app/src/test/java/com/jai/assistant/engine/TaskPlannerExecutionTest.java`
- `app/src/test/java/com/jai/assistant/engine/TaskStageEngineTest.java`
- `app/src/test/java/com/jai/assistant/engine/ToolRegistryTest.java`
- `README_TR.md`, `DEVAM_NOTU_TR.md`, `DEGISIKLIKLER_0.9.1_TR.md`, `TEST_RAPORU_0.9.1_TR.md`

## Davranış değişiklikleri
- Naive Bayes sınıflandırması göreli puan dağılımıyla raporlanır; puanlar kalibre edilmiş güven değildir.
- ToolRegistry en iyi eşleşen aracı skoruna göre seçer. Hesaplama, hafıza arama, cihaz kaynakları ve statik kod ön kontrolü yönlendirmesi eklendi.
- TaskPlanner uygulanabilir plan üretir ve plan aşamasında seçilen araç yürütme aşamasında çağrılır.
- Think işlem sırası artık analiz → bağlam → plan → yürütme → doğrulama. Önceki hatalı doğrulama-önce-yürütme sıralaması bulunmuyor.
- Yerel hafıza bağlamı doğrudan yanıt seçimine aktarılır; yanıtın sonuna sonradan iliştirilmez.
- Think görevleri JSON durumuyla `tasks` tablosuna kaydedilir. Özgün istek, `brain_task_payloads` tablosunda ayrı tutulur; checkpoint JSON içine büyük girdi kopyalanmaz. SQLite veritabanı şeması v3’e yükseltilir.
- Görev listesi Think ve öğrenme görevlerini birlikte gösterir.
- `görev devam: ID` `brain` görevini `next_stage` alanından sürdürür; tamamlanan aşamalar tekrarlanmaz.
- MainActivity, yerel Think görevini yanlışlıkla web araştırma WorkManager işçisiyle başlatmaz.
- Kod üretim menüsü artık sadece sınıflandırıcı etiketi `kod` diye geldiği için açılmaz; açık üretim niyeti aranır.
- Sürüm `0.9.1` / versionCode `12` oldu.

## Kapsam dışında bırakılanlar
- Serbest doğal dilde genel amaçlı LLM üretimi.
- Gerçek model eğitimi veya model ağırlıkları.
- Java/Python derleme ve genel proje test çalıştırıcısı.
- Web araştırmasının BrainEngine'e tam kanıt bağlamı olarak aktarılması; mevcut MainActivity web akışı korunmuştur.
