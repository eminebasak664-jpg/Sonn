# Ja.i 0.9.8 — Web görsel örneği ve yerel piksel öğrenmesi

## Görsel araştırması
- `Ara` açıkken görsel isteklerinde genel metin araştırması yerine DuckDuckGo Görseller araması yapılır.
- En fazla 4 HTTPS görsel örneği indirilir. Her indirme en fazla 1,5 MB; bağlantı zaman aşımı ve yönlendirme sayısı sınırlıdır.
- Yalnızca Android `BitmapFactory` tarafından desteklenen raster biçimler kabul edilir (JPEG, PNG, WebP, GIF, BMP). SVG/HTML kabul edilmez.
- Yerel ağa aktarılmadan önce görüntüler en fazla 256×256 boyutuna düşürülür. Ham indirme dosyaları saklanmaz; yalnızca etiketli piksel örnekleri uygulamanın özel alanında tutulur.
- Ara kapalıysa bu web görsel arama/indirme yolu çağrılmaz. Kod Laboratuvarı ve sohbet görsel görevleri aynı davranışı kullanır.

## Yerel görsel öğrenmesi
- `VisualLearningEngine` bir etiket için birden çok `.jaimg` örneği tutabilir; üst sınır etiket başına 5 örnektir. Eski tek-örnek dosyası biçimi de okunur.
- Üretim, düşük çözünürlükteki yerel 16→128→64→3 ağının piksel renk tahminleri ve etiketli örnek piksellerinden oluşturulmuş bileşimiyle raster PNG üretir.
- Üretilmiş prosedürel resim artık kendiliğinden eğitim örneğine dönüştürülmez. Kendi hatalı çıktısını öğrenerek pekiştiren döngü kaldırıldı.
- Uygulama içindeki üretici, eğitilmiş örneği bulunmayan nesnede eski geometrik çiziciye sessizce düşmez; örnek gerektiğini açıkça bildirir.
- `MainActivity` görsel isteğinde sadece görsel araştırma sonucunu bağlama ekler; diğer web araştırma istekleri mevcut metin araştırma yolunu korur.

## Değişen dosyalar
- `app/src/main/java/com/jai/assistant/tools/WebImageResearchEngine.java` (yeni)
- `app/src/main/java/com/jai/assistant/engine/VisualLearningEngine.java`
- `app/src/main/java/com/jai/assistant/engine/ProceduralImageGenerator.java`
- `app/src/main/java/com/jai/assistant/MainActivity.java`
- `app/src/test/java/com/jai/assistant/tools/WebImageResearchEngineTest.java` (yeni)
- `app/src/test/java/com/jai/assistant/engine/VisualLearningEngineTest.java`
- `app/src/test/java/com/jai/assistant/engine/ProceduralImageGeneratorTest.java`
- `app/build.gradle` (`versionCode 20`, `versionName 0.9.8`)

## Bilinen sınırlar
- DuckDuckGo `i.js` uç noktası resmî, kararlı bir geliştirici API'si değildir; değişebilir veya istekleri engelleyebilir.
- Arama sonucu görseller yalnızca sorgu etiketiyle eşleştirilir. Bu sürüm her görselde zürafa vb. nesnenin gerçekten bulunduğunu bağımsız bir görüntü sınıflandırıcısıyla doğrulamıyor.
- 10.627 parametreli küçük MLP bir diffusion/generative vision modeli veya genel amaçlı nesne tanıma sistemi değildir. Az sayıda örnekle yüksek kaliteli, serbest biçimli ve fotogerçekçi resim garantisi vermez. Bu sürüm gerçek piksel örnekleri ve yerel ağı birleştiren ilk aşama öğrenme/üretim altyapısıdır.
- Web araması bu geliştirme ortamında DNS/ağ erişimi olmadığı için canlı olarak doğrulanamadı. Android cihazında internet ve `Ara` açıkken denenmelidir.
- Android Gradle/APK derlemesi bu ortamda yapılmadı: Android SDK/`android.jar` yok ve Gradle Wrapper 8.9 dağıtımını indirmek için gerekli ağ erişimi bulunmuyor.
