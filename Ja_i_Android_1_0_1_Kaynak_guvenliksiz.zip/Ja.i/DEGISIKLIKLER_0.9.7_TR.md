# Ja.i 0.9.7 — Araştırma destekli yaratıcı üretim

## 1. Yerel görsel ağı
- Mimari 16→128→64→3, 10.627 eğitilebilir parametreye yükseltildi (önceki 12→32→3 ağdan ~20,6 kat fazla).
- Eski sürümün v1 model dosyası okunur; eski katman ağırlıkları yeni modele taşınır ve yeni biçimde saklanır.
- Başlangıç görseli için yalnızca etiket kaydı kontrol edilmez; gerçek `.jaimg` piksel örneğinin varlığı kontrol edilir. Eski modelde etiket olup örnek dosyası yoksa paketlenmiş örnek tekrar eğitilir.
- Kullanıcı kendi görselini seçip etiketleyebilir. Ağırlıklar ve örnek pikselleri uygulamanın özel dosyalarında kalır.
- Web araştırmasından gelen yazılı görsel açıklamasıyla sahne kompozisyonu oluşturulabilir. Bu, internetten haricî bir görsel modeli indirmek değildir; yerel çizim motoruna tasarım verisi sağlar ve üretilen örnek üzerinde tek başlangıç öğrenme turu yapar.

## 2. Çok sahneli 720p video
- 1280×720, 24 FPS H.264 MP4; 1–60 saniye. Varsayılan 10 saniye.
- `VideoScenePlanner`, genel fikirden dört kadraj üretir: açılış, yakın plan, aksiyon, final. `Sahne 1: ... Sahne 2: ...` gibi açık tarifler ayrıştırılır.
- Her kadraj ayrı yerel kompozisyon olarak çizilir. Kodlayıcı kareleri yumuşak geçiş, kamera pan/zoom, parallax, parçacık ve ışık katmanlarıyla birleştirir.
- Tek bir durağan görseli bir dakikaya uzatma yolu kaldırıldı. Buna rağmen tam metinden fotogerçekçi video, fiziksel hareket simülasyonu ve seslendirme bu sürümün kapsamı değildir.
- Kodlayıcı gerçek cihazda çalışır; bu geliştirme ortamında Android `MediaCodec` donanımı bulunmadığından MP4 cihaz testi yapılamadı.

## 3. Bedrock 1.21.132 hedefi
- Hedef istemci profili 1.21.132.1; `min_engine_version`: `[1,21,132]`.
- Script API bağımlılığı `@minecraft/server` 2.4.0. Mojang'ın 1.21.130 sürüm notlarında kararlı 2.4.0 API'si duyurulmuştur; 1.21.132 hotfix hedefi için bu kararlı profil kullanılır.
- Yaratık isteğine göre ortak kimlik, dosya adları, geometri/animasyon referansları, ses yolları, script referansları ve dil anahtarı kişiselleştirilir. Ejderha için ayrı kanatlı geometri, kuyruk ve kanat uçuş anahtar kareleri; davranış paketinde `movement.fly`, `navigation.fly` ve `behavior.random_fly` eklenir. Diğer desteklenen yaratık adları: zombi, iskelet, kedi, kurt, yılan, örümcek, golem, robot. Gerçek oyunda davranış/animasyon uygunluğu ayrıca test edilmelidir.
- Öğe adları `itemler: Ateş Kılıcı, Buz Yayı` gibi tariften çıkarılabilir; kaynak dokusu, eşya tanımı, tarif ve dil dosyası oluşturulur.
- `999 tutalım` talebi toplam 999 öğe verecek fonksiyon oluşturur: `give` komutlarına 64'ten büyük miktar yazılmaz. Örnek: 15 yığın ×64 + 39.
- `BedrockPackRepairEngine` JSON sözdizimini doğrular, son virgül/BOM ve stack sınırını güvenli şekilde onarır. Şema veya oyun içi semantik hataları otomatik düzelttiğini iddia etmez. Eşya üretiminde tehlikeli ekipman türündeki istekler reddedilir; dekoratif ve yardımcı öğeler desteklenir.

## 4. Ara / araştırma
- Kod Laboratuvarı'nda Ara seçiliyse, isteğe özel teknik arama ve kaynak okuma üretimden önce çalışır.
- Kaynak raporu yerel öğrenme notlarına kaydedilir; Minecraft için 1.21.132.1, max stack, manifest ve Script API; görsel/video için nesne anatomisi, malzeme, kompozisyon ve tasarım terimleri aranır.
- Ara kapalıysa bu CodeLab yolunda web çağrısı yapılmaz. Ara açık olsa da web'den bir görsel model veya başka AI modeli indirilmez.

## 5. Test ve doğrulama
- Saf Java çekirdeği `javac` ile derlendi.
- Bedrock paket üretimi: iki iç `.mcpack`, dış `.mcaddon`, 999 adedin 16 geçerli yığına bölünmesi, max 64, 1.21.132 min engine ve 2.4.0 Script API bağımlılığı kontrol edildi.
- Üretilen örnek Add-on'un kaynak ve davranış paketlerinde toplam 25 JSON dosyası ayrıştırıldı; ejderha kanat/kuyruk kemikleri, animasyon referansları ve uçuş bileşenleri ayrıca kontrol edildi; güvensiz dosya yolları reddedildi.
- MLP 10.627 parametre, örnek eğitimi, ağırlık kaydet/yükle ve 1280×720 PNG testi geçti.
- Video sahne planlayıcısı: otomatik dört kadraj ve kullanıcı tarafından yazılan açık sahne bölümleri test edildi. Süre parser: 1 dakika=60 saniye, 90 saniye=60 saniye üst sınırı, varsayılan=10 saniye.
- Onarım testi: JSON son virgülü düzeltme, metin içindeki virgülü koruma, max stack 999→64.
- Android Gradle/APK testi yapılamadı: bu çalışma ortamında Android SDK/`android.jar` bulunmuyor ve Gradle Wrapper 8.9 dağıtımını başlatamadı. Minecraft Bedrock gerçek cihaz içe aktarma/oynanış testi de yapılmadı.

## 6. Bilinçli sınırlar
- 10.627 parametreli MLP küçük ve yerel bir öğrenme bileşenidir; genel görsel dil modeli değildir. Eğitim örneklerinin etiketleri/renk-konum örüntülerini öğrenir; tek başına her nesnenin semantiğini anında öğrenmez.
- Araştırma metni sahne kompozisyonuna bağlam sağlar; web sayfası metni tek başına binlerce etiketli resim ve kapsamlı görsel eğitim veri kümesinin yerini tutmaz.
- Video, dört ayrı yerel sahne çizimini hareket ve geçişlerle birleştirir; bir video diffusion modeli değildir. 60 saniye video; işlemci, kullanılabilir RAM ve depolama kaynaklarına göre çözünürlük/FPS seçerek oluşturulur.
- Minecraft'ın standart item yığın boyutu 64'tür. Ja.i 999 isteğini komutla birden fazla yığına böler; tek envanter slotunda 999 oluşturduğunu iddia etmez.
- Paket doğrulaması JSON ve dosya yapısı doğrulamasıdır. Minecraft oyun motorunun bütün şema kurallarını veya her animasyon/Script API davranışını simüle etmez.
