# Ja.i 1.0.1 — DEVAM NOTU

## Bu pakette değişenler
- Video üretimi artık cihaz işlemci çekirdek sayısı, kısa CPU yük örneklemi, düşük-RAM cihaz işareti, sistem RAM'i, uygulama heap'i ve cache depolamasına göre 720p/24, 540p/20 veya 360p/15 profilini seçer.
- MP4 byte[] yerine cache dosyası olarak üretilir ve 64 KiB tamponla arka plan iş parçacığında SAF konumuna aktarılır.
- Kaynak durumu CPU/RAM/depolama bilgisini gösterir.
- ZIP/TAR kaynak sınırları işlemci yükü ve RAM kullanımını açıklar.
- JSONL örnek dosya adı UTF-8/ZIP araçlarında sorun çıkarmayacak ASCII ada taşındı.
- Colab eğitim notebooku 2.1 olarak eklendi: kaynak dengeli örnekleme, 12 epoch üst sınırı, 3 epoch sabırla erken durdurma, kaynak bazlı veri/pencere raporu ve eski checkpoint temizliği.

## Henüz gerçek cihazda doğrulanması gerekenler
1. 10 saniye ve 60 saniye MP4 üretimini gerçek Android cihazda dene.
2. Üretim sırasında Android Geliştirici Seçenekleri/Profil GPU Rendering değil, sistem bellek ekranından uygulama RAM değişimini gözlemle; uygulama kaynak durumunda sistem RAM/cache alanını raporlar.
3. Cache alanı azaldığında 720p'den 540p/360p profiline indiğini test et.
4. MP4'ü Dosyalar uygulamasına kaydet, dosyanın açıldığını doğrula.
5. Colab'da `colab/Ja.i_1.0.1_Sifirdan_Sohbet_Modeli_Egitimi.ipynb` notebook'unu ayrıca çalıştır; bu kaynak ZIP'inde sohbet ONNX ağırlığı yoktur.

## Bilinen doğrulama sınırı
Bu çalışma ortamında Android SDK/Gradle dağıtımı bulunmadığından APK derlemesi ve donanımsal MediaCodec testi doğrulanmadı.
