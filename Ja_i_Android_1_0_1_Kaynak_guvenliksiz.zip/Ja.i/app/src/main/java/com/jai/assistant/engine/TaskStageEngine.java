package com.jai.assistant.engine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Think modunun gerçek ve birbirinden farklı yerel işlem adımlarını seçer. */
public final class TaskStageEngine {
    public enum Stage {
        ANALYZE_REQUEST("İstek analizi"),
        RETRIEVE_CONTEXT("Yerel bağlam arama"),
        BUILD_PLAN("Görev planlama"),
        EXECUTE_TASK("Görevi/araçları çalıştırma"),
        VERIFY_RESULT("Çıktı doğrulama");

        public final String displayName;
        Stage(String displayName) { this.displayName = displayName; }
    }

    public static final class Plan {
        public final boolean automatic;
        public final int requestedStageLimit;
        public final List<Stage> stages;
        public final String stopReason;

        private Plan(boolean automatic, int requestedStageLimit, List<Stage> stages, String stopReason) {
            this.automatic = automatic;
            this.requestedStageLimit = requestedStageLimit;
            this.stages = Collections.unmodifiableList(new ArrayList<>(stages));
            this.stopReason = stopReason;
        }
    }

    private TaskStageEngine() { }

    public static Plan restorePlan(boolean automatic, int requestedStageLimit, List<Stage> stages, String stopReason) {
        if (stages == null || stages.isEmpty() || !stages.contains(Stage.EXECUTE_TASK)) {
            throw new IllegalArgumentException("Kaydedilmiş görev planı geçersiz.");
        }
        return new Plan(automatic, Math.max(1, Math.min(115, requestedStageLimit)), stages,
                stopReason == null ? "" : stopReason);
    }

    public static Plan createPlan(String prompt, String effort, boolean autoMode, int manualCount) {
        int requested = autoMode ? automaticLimit(effort) : Math.max(1, Math.min(115, manualCount));
        List<Stage> selected = new ArrayList<>();
        if (requested <= 1) {
            selected.add(Stage.EXECUTE_TASK);
        } else {
            selected.add(Stage.ANALYZE_REQUEST);
            if (requested >= 3) selected.add(Stage.RETRIEVE_CONTEXT);
            if (requested >= 4) selected.add(Stage.BUILD_PLAN);
            selected.add(Stage.EXECUTE_TASK);
            if (requested >= 5) selected.add(Stage.VERIFY_RESULT);
        }

        String stopReason = "";
        if (!autoMode && requested > 5) {
            stopReason = "İstenen " + requested + " aşama sınırına rağmen yalnızca 5 farklı yerel işlem yapılabilir; sahte tekrarlar çalıştırılmadı.";
        }
        if (autoMode) stopReason = "Efor seviyesine uygun bağımsız yerel aşamalar tamamlanınca durulur.";
        return new Plan(autoMode, requested, selected, stopReason);
    }

    private static int automaticLimit(String effort) {
        if ("Hızlı".equalsIgnoreCase(effort)) return 2;
        if ("Orta".equalsIgnoreCase(effort)) return 4;
        return 5;
    }
}
