package com.jai.assistant.media;

/**
 * Video üretim profilini işlemci çekirdeği, kullanılabilir RAM, uygulama heap'i ve
 * geçici depolama alanına göre seçer. Sabit tek bir 720p/24 FPS ayarı dayatmaz.
 */
public final class VideoResourcePolicy {
    private static final long MIB = 1024L * 1024L;

    public static final class Profile {
        public final int width;
        public final int height;
        public final int fps;
        public final int bitRate;
        public final int particleCount;
        public final String qualityName;

        private Profile(int width, int height, int fps, int bitRate, int particleCount, String qualityName) {
            this.width = width;
            this.height = height;
            this.fps = fps;
            this.bitRate = bitRate;
            this.particleCount = particleCount;
            this.qualityName = qualityName;
        }

        public long estimateOutputBytes(int durationSeconds) {
            return ((long) bitRate * Math.max(1, durationSeconds)) / 8L + 1536L * 1024L;
        }

        public long estimateWorkingMemoryBytes(int sceneCount) {
            long pixels = (long) width * height;
            // Sahne bitmap'leri + üretim sırasında çözümlenen bir geçici bitmap + pay.
            return pixels * 4L * (Math.max(1, sceneCount) + 2L) + 8L * MIB;
        }

        public long requiredStorageBytes(int durationSeconds) {
            return estimateOutputBytes(durationSeconds) + 4L * MIB;
        }
    }

    private static final Profile HIGH = new Profile(1280, 720, 24, 1_800_000, 36, "Yüksek");
    private static final Profile MEDIUM = new Profile(960, 540, 20, 1_200_000, 24, "Orta");
    private static final Profile LOW = new Profile(640, 360, 15, 650_000, 14, "Hafif");

    private VideoResourcePolicy() { }

    public static Profile choose(boolean lowRamDevice, int cpuCores, int cpuLoadPercent,
                                 long availableSystemRamBytes, long availableAppHeapBytes,
                                 long availableStorageBytes, int durationSeconds, int sceneCount) {
        int duration = Math.max(1, Math.min(60, durationSeconds));
        Profile preferred;
        if (!lowRamDevice && cpuCores >= 6
                && availableSystemRamBytes >= 640L * MIB
                && availableAppHeapBytes >= 64L * MIB) {
            preferred = HIGH;
        } else if (cpuCores >= 4
                && availableSystemRamBytes >= 320L * MIB
                && availableAppHeapBytes >= 32L * MIB) {
            preferred = MEDIUM;
        } else if (cpuCores >= 2
                && availableSystemRamBytes >= 160L * MIB
                && availableAppHeapBytes >= 16L * MIB) {
            preferred = LOW;
        } else {
            throw new IllegalStateException("Video üretimi için şu anda yeterli işlemci/RAM kaynağı yok. Diğer uygulamaları kapatıp yeniden dene.");
        }

        // Anlık sistem işlemci yükü okunabildiyse profil bir kademe hafifletilebilir.
        if (cpuLoadPercent >= 85) {
            preferred = LOW;
        } else if (cpuLoadPercent >= 65 && preferred == HIGH) {
            preferred = MEDIUM;
        } else if (cpuLoadPercent >= 65 && preferred == MEDIUM) {
            preferred = LOW;
        }

        Profile[] candidates = {HIGH, MEDIUM, LOW};
        int start = preferred == HIGH ? 0 : preferred == MEDIUM ? 1 : 2;
        for (int i = start; i < candidates.length; i++) {
            Profile candidate = candidates[i];
            if (availableAppHeapBytes >= candidate.estimateWorkingMemoryBytes(sceneCount)
                    && availableStorageBytes >= candidate.requiredStorageBytes(duration)) {
                return candidate;
            }
        }
        throw new IllegalStateException("Video için yeterli boş depolama veya uygulama belleği yok. En az "
                + formatMiB(LOW.requiredStorageBytes(duration))
                + " MiB boş uygulama alanı ve yaklaşık "
                + formatMiB(LOW.estimateWorkingMemoryBytes(sceneCount))
                + " MiB kullanılabilir uygulama belleği gerekiyor.");
    }

    private static String formatMiB(long bytes) {
        return String.valueOf(Math.max(1L, (bytes + MIB - 1L) / MIB));
    }
}
