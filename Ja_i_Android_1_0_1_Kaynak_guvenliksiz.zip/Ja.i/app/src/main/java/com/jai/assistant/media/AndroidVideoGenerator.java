package com.jai.assistant.media;

import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.view.Surface;

import com.jai.assistant.engine.ProceduralImageGenerator;
import com.jai.assistant.engine.VisualLearningEngine;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;

/** Cihaz kaynaklarına göre çözünürlük/FPS seçerek H.264 MP4 üretir. */
public final class AndroidVideoGenerator {
    private static final int DEFAULT_DURATION_SECONDS = 10;
    private static final int MAX_DURATION_SECONDS = 60;
    private static final long OLD_VIDEO_RETENTION_MS = 7L * 24L * 60L * 60L * 1000L;

    public static boolean isVideoRequest(String prompt) {
        String q = normalize(prompt);
        boolean video = q.matches(".*\\b(video|mp4|animasyonlu video|klip|film)\\b.*");
        boolean action = q.matches(".*\\b(yap|uret|olustur|hazirla|tasarla)\\b.*");
        return video && action;
    }

    public static final class Result {
        /** MP4 dosyası cache içinde tutulur; tüm video byte[] olarak RAM'e alınmaz. */
        public final File mp4File;
        public final String fileName;
        public final String description;
        Result(File file, String name, String description) {
            this.mp4File = file;
            this.fileName = name;
            this.description = description;
        }
    }

    private final Context context;
    private final VisualLearningEngine learningEngine;

    public AndroidVideoGenerator(Context context, VisualLearningEngine learningEngine) {
        this.context = context.getApplicationContext();
        this.learningEngine = learningEngine;
    }

    public Result generate(String prompt) throws Exception { return generate(prompt, ""); }

    public Result generate(String prompt, String researchContext) throws Exception {
        int durationSeconds = requestedDurationSeconds(prompt);
        List<String> scenePrompts = com.jai.assistant.engine.VideoScenePlanner.plan(prompt, researchContext);
        if (scenePrompts.isEmpty()) throw new IOException("Video sahne planı boş.");
        cleanupOldVideoFiles();

        VideoResourcePolicy.Profile profile = chooseProfile(durationSeconds, scenePrompts.size());
        int width = profile.width;
        int height = profile.height;
        int fps = profile.fps;
        List<Bitmap> sceneBitmaps = new ArrayList<>();
        ProceduralImageGenerator imageGenerator = new ProceduralImageGenerator();
        File output = null;
        boolean completed = false;
        MuxerState muxerState = new MuxerState();
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        Surface inputSurface = null;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();

        try {
            for (int sceneNumber = 0; sceneNumber < scenePrompts.size(); sceneNumber++) {
                String scenePrompt = scenePrompts.get(sceneNumber);
                VisualLearningEngine sceneLearning = sceneNumber == 0 ? learningEngine : null;
                ProceduralImageGenerator.Result frame = imageGenerator.generate(
                        scenePrompt + " " + width + "x" + height,
                        width, height, sceneLearning, researchContext);
                Bitmap sceneBitmap = BitmapFactory.decodeByteArray(frame.pngBytes, 0, frame.pngBytes.length);
                if (sceneBitmap == null) {
                    throw new IOException("Video sahnesi için " + width + "x" + height + " görsel çözümlenemedi.");
                }
                sceneBitmaps.add(sceneBitmap);
            }

            output = File.createTempFile("jai-video-", ".mp4", context.getCacheDir());
            MediaFormat format = MediaFormat.createVideoFormat("video/avc", width, height);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            format.setInteger(MediaFormat.KEY_BIT_RATE, profile.bitRate);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            encoder = MediaCodec.createEncoderByType("video/avc");
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            inputSurface = encoder.createInputSurface();
            muxer = new MediaMuxer(output.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            encoder.start();

            Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
            Paint fadePaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
            Paint particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            particlePaint.setColor(Color.argb(120, 255, 240, 180));
            Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            Matrix matrix = new Matrix();
            int frameCount = fps * durationSeconds;
            int framesPerScene = Math.max(1, (int) Math.ceil(frameCount / (double) sceneBitmaps.size()));
            int transitionFrames = Math.min(fps * 2, Math.max(1, framesPerScene / 3));

            for (int i = 0; i < frameCount; i++) {
                Canvas canvas = inputSurface.lockCanvas(null);
                try {
                    canvas.drawColor(Color.rgb(8, 12, 25));
                    float phase = (float) (i / (double) Math.max(1, frameCount - 1));
                    float zoom = 1.0f + 0.055f * (float) Math.sin(phase * Math.PI * 2.0 * 3.0);
                    float panX = (float) Math.sin(phase * Math.PI * 2.0 * 2.0) * (width * 0.018f);
                    float panY = (float) Math.cos(phase * Math.PI * 2.0 * 1.5) * (height * 0.019f);
                    int sceneIndex = Math.min(sceneBitmaps.size() - 1, i / framesPerScene);
                    int nextSceneIndex = Math.min(sceneBitmaps.size() - 1, sceneIndex + 1);
                    int localFrame = i - sceneIndex * framesPerScene;
                    matrix.reset();
                    matrix.setScale(zoom, zoom, width / 2f, height / 2f);
                    matrix.postTranslate(panX, panY);
                    canvas.drawBitmap(sceneBitmaps.get(sceneIndex), matrix, paint);
                    if (nextSceneIndex != sceneIndex && localFrame >= framesPerScene - transitionFrames) {
                        float transition = (localFrame - (framesPerScene - transitionFrames)) / (float) transitionFrames;
                        fadePaint.setAlpha(Math.max(0, Math.min(255, Math.round(transition * 255f))));
                        canvas.drawBitmap(sceneBitmaps.get(nextSceneIndex), matrix, fadePaint);
                        fadePaint.setAlpha(255);
                    }
                    for (int particle = 0; particle < profile.particleCount; particle++) {
                        float speed = 0.35f + (particle % 7) * 0.11f;
                        float x = (particle * 59 + i * speed * (2 + particle % 3)) % width;
                        float y = (particle * 31 + i * speed * (1 + particle % 2)) % height;
                        float radius = 1.2f + (particle % 4) * 0.7f;
                        canvas.drawCircle(x, y, radius, particlePaint);
                    }
                    float pulse = (float) (0.025 + 0.025 * (0.5 + 0.5 * Math.sin(phase * Math.PI * 2.0 * 6.0)));
                    glowPaint.setColor(Color.argb((int) (pulse * 255), 120, 110, 255));
                    canvas.drawRect(0, 0, width, height, glowPaint);
                } finally {
                    inputSurface.unlockCanvasAndPost(canvas);
                }

                drainAvailable(encoder, muxer, info, muxerState, false);
                Thread.sleep(Math.max(1L, 1000L / fps));
            }

            encoder.signalEndOfInputStream();
            long deadline = System.currentTimeMillis() + 15000L;
            boolean eos = false;
            while (!eos && System.currentTimeMillis() < deadline) {
                eos = drainAvailable(encoder, muxer, info, muxerState, true);
            }
            if (!eos) throw new IOException("Video kodlayıcısı bitiş karesini zamanında tamamlayamadı.");
            if (!muxerState.started) throw new IOException("Cihazın video kodlayıcısı MP4 akışını başlatamadı.");
            if (output.length() < 1024L) throw new IOException("Üretilen MP4 dosyası beklenenden küçük.");

            String base = normalize(prompt).replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
            if (base.isEmpty()) base = "jai-klip";
            if (base.length() > 32) base = base.substring(0, 32);
            String description = "Ja.i cihazdaki H.264 kodlayıcıyla " + width + "×" + height + ", "
                    + fps + " FPS, " + durationSeconds + " saniyelik MP4 üretti. Kaynak profili: "
                    + profile.qualityName + " (" + profile.bitRate / 1000 + " kbit/s). "
                    + sceneBitmaps.size() + " yerel sahne, geçişli kurgu, kamera hareketi, parallax, parçacık ve ışık efektleri uygulandı. "
                    + "Sahne taslağı istem ve Ara açıksa araştırma metniyle oluşturuldu; bağımsız fotogerçekçi video modeli veya seslendirme bu sürümde yoktur.";
            completed = true;
            return new Result(output, base + "-" + width + "x" + height + ".mp4", description);
        } finally {
            for (Bitmap sceneBitmap : sceneBitmaps) {
                if (sceneBitmap != null && !sceneBitmap.isRecycled()) sceneBitmap.recycle();
            }
            if (encoder != null) {
                try { encoder.stop(); } catch (Exception ignored) { }
                try { encoder.release(); } catch (Exception ignored) { }
            }
            if (inputSurface != null) {
                try { inputSurface.release(); } catch (Exception ignored) { }
            }
            if (muxer != null) {
                try { muxer.stop(); } catch (Exception ignored) { }
                try { muxer.release(); } catch (Exception ignored) { }
            }
            if (!completed && output != null) output.delete();
        }
    }

    private VideoResourcePolicy.Profile chooseProfile(int durationSeconds, int sceneCount) throws IOException {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memory = new ActivityManager.MemoryInfo();
        if (manager != null) manager.getMemoryInfo(memory);
        Runtime runtime = Runtime.getRuntime();
        long usedHeap = runtime.totalMemory() - runtime.freeMemory();
        long availableHeap = Math.max(0L, runtime.maxMemory() - usedHeap);
        long availableStorage = context.getCacheDir().getUsableSpace();
        boolean lowRam = manager != null && manager.isLowRamDevice();
        int cores = Math.max(1, runtime.availableProcessors());
        int cpuLoadPercent = readCpuLoadPercent();
        try {
            return VideoResourcePolicy.choose(lowRam, cores, cpuLoadPercent, memory.availMem,
                    availableHeap, availableStorage, durationSeconds, sceneCount);
        } catch (IllegalStateException error) {
            throw new IOException(error.getMessage(), error);
        }
    }

    /** /proc/stat okunabiliyorsa kısa bir örneklemle sistemin anlık CPU yükünü tahmin eder. */
    private int readCpuLoadPercent() {
        long[] first = readCpuCounters();
        if (first == null) return -1;
        try { Thread.sleep(120L); }
        catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            return -1;
        }
        long[] second = readCpuCounters();
        if (second == null) return -1;
        long totalDelta = second[0] - first[0];
        long idleDelta = second[1] - first[1];
        if (totalDelta <= 0L || idleDelta < 0L) return -1;
        long busy = Math.max(0L, totalDelta - idleDelta);
        return (int) Math.max(0L, Math.min(100L, busy * 100L / totalDelta));
    }

    private long[] readCpuCounters() {
        try (RandomAccessFile stat = new RandomAccessFile("/proc/stat", "r")) {
            String line = stat.readLine();
            if (line == null || !line.startsWith("cpu ")) return null;
            String[] parts = line.trim().split("\\s+");
            if (parts.length < 5) return null;
            long total = 0L;
            for (int i = 1; i < parts.length; i++) total += Long.parseLong(parts[i]);
            long idle = Long.parseLong(parts[4]);
            if (parts.length > 5) idle += Long.parseLong(parts[5]);
            return new long[]{total, idle};
        } catch (Exception ignored) {
            return null;
        }
    }

    private static final class MuxerState {
        boolean started;
        int track = -1;
    }

    /** Codec çıktılarını küçük arabelleklerle doğrudan MP4 dosyasına aktarır. */
    private boolean drainAvailable(MediaCodec codec, MediaMuxer muxer, MediaCodec.BufferInfo info,
                                    MuxerState state, boolean waitForEndOfStream) throws IOException {
        while (true) {
            int index = codec.dequeueOutputBuffer(info, waitForEndOfStream ? 10000 : 0);
            if (index == MediaCodec.INFO_TRY_AGAIN_LATER) return false;
            if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (state.started) throw new IOException("Video kodlayıcısı birden fazla çıktı biçimi bildirdi.");
                state.track = muxer.addTrack(codec.getOutputFormat());
                muxer.start();
                state.started = true;
                continue;
            }
            if (index < 0) continue;
            ByteBuffer buffer = codec.getOutputBuffer(index);
            if (buffer != null && info.size > 0) {
                if (!state.started || state.track < 0) {
                    codec.releaseOutputBuffer(index, false);
                    throw new IOException("MP4 muxer henüz başlatılmadı.");
                }
                buffer.position(info.offset);
                buffer.limit(info.offset + info.size);
                muxer.writeSampleData(state.track, buffer, info);
            }
            boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
            codec.releaseOutputBuffer(index, false);
            if (eos) return true;
        }
    }

    private void cleanupOldVideoFiles() {
        File cache = context.getCacheDir();
        File[] files = cache.listFiles((dir, name) -> name.startsWith("jai-video-") && name.endsWith(".mp4"));
        if (files == null) return;
        long cutoff = System.currentTimeMillis() - OLD_VIDEO_RETENTION_MS;
        for (File file : files) {
            if (file.isFile() && file.lastModified() < cutoff) file.delete();
        }
    }

    public static int requestedDurationSeconds(String prompt) {
        String q = normalize(prompt);
        java.util.regex.Matcher minutes = java.util.regex.Pattern.compile("\\b(\\d{1,2})\\s*(?:dk|dakika)\\b").matcher(q);
        if (minutes.find()) return clampDuration(Integer.parseInt(minutes.group(1)) * 60);
        java.util.regex.Matcher seconds = java.util.regex.Pattern.compile("\\b(\\d{1,3})\\s*(?:sn|saniye|sec|seconds?)\\b").matcher(q);
        if (seconds.find()) return clampDuration(Integer.parseInt(seconds.group(1)));
        if (q.matches(".*\\b1\\s*dk\\b.*") || q.contains("bir dakika")) return 60;
        return DEFAULT_DURATION_SECONDS;
    }

    private static int clampDuration(int value) { return Math.max(1, Math.min(MAX_DURATION_SECONDS, value)); }

    private static String normalize(String text) {
        String q = text == null ? "" : text.toLowerCase(Locale.ROOT);
        return q.replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c');
    }
}
