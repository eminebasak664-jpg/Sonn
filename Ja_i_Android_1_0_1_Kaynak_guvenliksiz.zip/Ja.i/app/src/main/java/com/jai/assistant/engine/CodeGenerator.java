package com.jai.assistant.engine;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Çevrimdışı üretim yönlendiricisi: yapılandırılmış JavaScript sentezi, modüler çok dosyalı
 * web projeleri ve açık başlangıç örnekleri. Serbest biçimli genel amaçlı LLM değildir.
 */
public final class CodeGenerator {
    public static final class GeneratedCode {
        public final boolean supported;
        public final boolean runnableInLab;
        public final String templateId;
        public final String title;
        public final String language;
        public final String source;
        public final String explanation;
        public final Map<String, String> projectFiles;
        public final boolean project;
        public final byte[] artifactBytes;
        public final File artifactFile;
        public final String artifactFileName;
        public final String artifactMimeType;

        public boolean hasArtifact() { return (artifactBytes != null && artifactBytes.length > 0)
                || (artifactFile != null && artifactFile.isFile() && artifactFile.length() > 0L); }

        GeneratedCode(boolean supported, boolean runnableInLab, String templateId,
                      String title, String language, String source, String explanation) {
            this(supported, runnableInLab, templateId, title, language, source, explanation, Collections.emptyMap(), (byte[]) null, null, null);
        }

        GeneratedCode(boolean supported, boolean runnableInLab, String templateId,
                      String title, String language, String source, String explanation, Map<String, String> projectFiles) {
            this(supported, runnableInLab, templateId, title, language, source, explanation, projectFiles, null, null, null, null);
        }

        GeneratedCode(boolean supported, boolean runnableInLab, String templateId,
                      String title, String language, String source, String explanation, Map<String, String> projectFiles,
                      byte[] artifactBytes, String artifactFileName, String artifactMimeType) {
            this(supported, runnableInLab, templateId, title, language, source, explanation, projectFiles,
                    artifactBytes, null, artifactFileName, artifactMimeType);
        }

        GeneratedCode(boolean supported, boolean runnableInLab, String templateId,
                      String title, String language, String source, String explanation, Map<String, String> projectFiles,
                      File artifactFile, String artifactFileName, String artifactMimeType) {
            this(supported, runnableInLab, templateId, title, language, source, explanation, projectFiles,
                    null, artifactFile, artifactFileName, artifactMimeType);
        }

        private GeneratedCode(boolean supported, boolean runnableInLab, String templateId,
                      String title, String language, String source, String explanation, Map<String, String> projectFiles,
                      byte[] artifactBytes, File artifactFile, String artifactFileName, String artifactMimeType) {
            this.supported = supported;
            this.runnableInLab = runnableInLab;
            this.templateId = templateId;
            this.title = title;
            this.language = language;
            this.source = source;
            this.explanation = explanation;
            this.projectFiles = projectFiles == null ? Collections.emptyMap() : Collections.unmodifiableMap(new java.util.LinkedHashMap<>(projectFiles));
            this.project = !this.projectFiles.isEmpty();
            this.artifactBytes = artifactBytes == null ? null : artifactBytes.clone();
            this.artifactFile = artifactFile;
            this.artifactFileName = artifactFileName;
            this.artifactMimeType = artifactMimeType;
        }
    }

    private final ProjectCodeGenerator projectGenerator = new ProjectCodeGenerator();
    private final MinecraftPackGenerator minecraftPackGenerator = new MinecraftPackGenerator();
    private final ProceduralImageGenerator imageGenerator = new ProceduralImageGenerator();
    private final VisualLearningEngine visualLearningEngine;
    private final android.content.Context androidContext;

    public CodeGenerator() { this(null, null); }
    public CodeGenerator(VisualLearningEngine visualLearningEngine) { this(visualLearningEngine, null); }
    public CodeGenerator(VisualLearningEngine visualLearningEngine, android.content.Context androidContext) {
        this.visualLearningEngine = visualLearningEngine;
        this.androidContext = androidContext == null ? null : androidContext.getApplicationContext();
    }

    private static final List<String> TEMPLATE_IDS = Collections.unmodifiableList(Arrays.asList(
            "js-counter", "js-calculator", "js-fibonacci", "js-prime", "js-todo",
            "js-string-tools", "js-array-tools", "js-starter", "html-starter", "html-landing",
            "html-clicker", "html-quiz", "html-tic-tac-toe", "java-starter", "python-starter"));

    public List<String> supportedTemplates() { return TEMPLATE_IDS; }

    /** Sohbetin doğrudan PNG veya Bedrock dosyası üretme isteklerini Kod Laboratuvarı'na yönlendirmesi için. */
    public boolean isArtifactRequest(String prompt) {
        return minecraftPackGenerator.isMinecraftPackRequest(prompt) || imageGenerator.isImageRequest(prompt)
                || com.jai.assistant.media.AndroidVideoGenerator.isVideoRequest(prompt);
    }

    public GeneratedCode generate(String prompt) {
        return generate(prompt, "");
    }

    /** Ara açıksa toplanan güncel teknik kaynakları üretici modüle aktarır; AI API çağrısı yapmaz. */
    public GeneratedCode generate(String prompt, String researchContext) {
        String q = TurkishTextProcessor.normalize(prompt);
        if (q.isEmpty()) return unsupported("Bir kod isteği yaz. Örneğin: kod üret: tıklama sayacı");

        try {
            if (com.jai.assistant.media.AndroidVideoGenerator.isVideoRequest(prompt)) {
                if (androidContext == null) return unsupported("MP4 üretimi Android MediaCodec gerektirir; uygulama içinden başlatılmalı.");
                com.jai.assistant.media.AndroidVideoGenerator.Result video =
                        new com.jai.assistant.media.AndroidVideoGenerator(androidContext, visualLearningEngine).generate(prompt, researchContext);
                return new GeneratedCode(true, false, "android-h264-video", "Yerel MP4 video", "MP4",
                        video.description, video.description, Collections.emptyMap(), video.mp4File, video.fileName, "video/mp4");
            }
            if (minecraftPackGenerator.isMinecraftPackRequest(prompt)) {
                MinecraftPackGenerator.Result pack = minecraftPackGenerator.generate(prompt, researchContext);
                return new GeneratedCode(true, false, "minecraft-bedrock-pack", "Minecraft Bedrock paketi", "JSON",
                        pack.description, pack.description, Collections.emptyMap(), pack.archiveBytes,
                        pack.fileName, pack.mimeType);
            }
            if (imageGenerator.isImageRequest(prompt)) {
                ProceduralImageGenerator.Result image = imageGenerator.generate(prompt, visualLearningEngine, researchContext);
                return new GeneratedCode(true, false, "procedural-png-image", "Yerel PNG görseli", "PNG",
                        image.description, image.description, Collections.emptyMap(), image.pngBytes,
                        "jai-" + image.subject.replaceAll("[^a-zA-Z0-9_-]", "-") + "-" + image.width + "x" + image.height + ".png",
                        "image/png");
            }
        } catch (Exception exception) {
            return unsupported("Yerel üretim tamamlanamadı: " + (exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage()));
        }

        StructuredProgramCompiler.Result synthesis = new StructuredProgramCompiler().compile(prompt);
        if (synthesis.recognized) {
            if (!synthesis.supported) {
                return unsupported("Yapılandırılmış kaynak sentezi durdu: " + synthesis.message
                        + "\nHer satıra bir komut yaz. Örnek: değişken puan = 0 | fonksiyon ekle(x) = puan + x | yazdır ekle(3).");
            }
            return source("structured-js-compiler", "JavaScript", "Özgün JavaScript kaynak sentezi", synthesis.source,
                    synthesis.message + " Desteklenen yapılar: değişken, fonksiyon, eğer/ise, döngü, ata ve yazdır."
                            + " Çıktı JavaScript sandbox içinde denenebilir; bu doğal dilde genel amaçlı model üretimi değildir.", true);
        }

        ProjectCodeGenerator.Project project = projectGenerator.generate(prompt);
        if (project != null) {
            return new GeneratedCode(true, false, "generated-web-project", project.title, "HTML",
                    project.files.get("index.html"), project.explanation, project.files);
        }

        if (contains(q, "tic tac toe", "x o oyunu", "xox", "uc tas", "üç taş")) return html("html-tic-tac-toe", "X-O oyunu", ticTacToeHtml(), "İki kişilik X-O oyunu. Kazanan kontrolü ve beraberlik kontrolü tarayıcıda yapılır.");
        if (contains(q, "bilgi yarismasi", "bilgi yarışması", "quiz", "sinav oyunu", "soru oyunu")) return html("html-quiz", "Bilgi yarışması", quizHtml(), "Soruları düzenleyebileceğin basit, çevrimdışı quiz sayfası.");
        if (contains(q, "tiklama oyunu", "tıklama oyunu", "clicker", "tiklayarak puan", "tıklayarak puan")) return html("html-clicker", "Tıklama oyunu", clickerHtml(), "Puanı tıklamayla artıran basit tarayıcı oyunu. Skor cihazda kalıcı değildir.");
        if (contains(q, "kronometre", "stopwatch")) return js("js-counter", "Kronometre", stopwatchJs(), "Başlat/durdur/sıfırla mantığını içeren JavaScript kodu. Kod Laboratuvarı zamanlayıcı API'si sunmadığından otomatik akan saat değildir; tarayıcı arayüzüne aktarılmalıdır.", false);
        if (contains(q, "sayaç", "sayac", "counter", "tıklama say")) return js("js-counter", "Sayaç", counterJs(), "Sayaç değeri artırılır, azaltılır ve sıfırlanır. JavaScript sandbox içinde çalıştırılabilir.", true);
        if (contains(q, "hesap makinesi", "hesaplama", "toplama makinesi", "calculator")) return js("js-calculator", "Hesap makinesi", calculatorJs(), "Dört işlem ve sıfıra bölme kontrolü. JavaScript sandbox içinde çalıştırılabilir.", true);
        if (contains(q, "fibonacci", "fibonaci")) return js("js-fibonacci", "Fibonacci", fibonacciJs(extractNumber(q, 10, 1, 45)), "İlk n Fibonacci sayısını üretir; telefon kaynaklarını korumak için n 0–45 aralığıyla sınırlıdır.", true);
        if (contains(q, "asal sayı", "asal sayi", "prime")) return js("js-prime", "Asal sayı denetleyici", primeJs(extractNumber(q, 100, 2, 10000)), "Verilen üst sınıra kadar asal sayıları bulur. Sandbox içinde çalıştırılabilir.", true);
        if (contains(q, "yapılacak", "yapilacak", "görev listesi", "gorev listesi", "todo", "liste uygulaması")) return js("js-todo", "Yapılacaklar listesi", todoJs(), "Bellek içi yapılacaklar listesi. Uygulama kapatıldığında veriyi saklamaz; kalıcılık ayrıca eklenmelidir.", true);
        if (contains(q, "metin araç", "metin arac", "kelime say", "karakter say", "metin analiz")) return js("js-string-tools", "Metin araçları", stringToolsJs(), "Kelime, karakter ve satır sayısını hesaplar.", true);
        if (contains(q, "dizi işle", "dizi islem", "array", "en büyük sayı", "en buyuk sayi")) return js("js-array-tools", "Dizi araçları", arrayToolsJs(), "Sayı dizisinde toplam, ortalama, en küçük ve en büyük değerleri hesaplar.", true);
        if (contains(q, "javascript", "js kod", "js program")) return js("js-starter", "JavaScript başlangıç kodu", "const name = 'Ja.i';\nfunction greet(value) { return 'Merhaba, ' + value + '!'; }\nprint(greet(name));", "JavaScript başlangıç kodu üretildi ve yerel JavaScript sandbox'ında çalıştırılabilir.", true);
        if (contains(q, "java", "android sınıf", "android sinif")) return source("java-starter", "Java", "Java başlangıç sınıfı", "public class Main {\n    public static void main(String[] args) {\n        System.out.println(\"Merhaba Ja.i\");\n    }\n}", "Java başlangıç sınıfı üretildi. Bu uygulama Java kodunu derlemez veya çalıştırmaz; yalnızca kaynak metni üretir.", false);
        if (contains(q, "python", "py kod")) return source("python-starter", "Python", "Python başlangıç programı", "def main():\n    print(\"Merhaba Ja.i\")\n\nif __name__ == \"__main__\":\n    main()", "Python kaynak kodu üretildi. Bu uygulama Python yorumlayıcısı içermez; kodu burada çalıştıramaz.", false);
        if (contains(q, "anasayfa", "web sitesi", "web sayfası", "web sayfasi", "html", "internet sitesi", "landing page", "portfolyo", "tanitim sitesi", "tanitim sayfasi")) {
            if (contains(q, "tanitim", "tanıtım", "landing", "portfolyo", "portfolio")) return html("html-landing", "Tanıtım sayfası", landingHtml(), "Mobil uyumlu, koyu temalı tanıtım/portfolyo sayfası. Metinleri HTML içinden değiştirebilirsin.");
            return html("html-starter", "HTML web sayfası", htmlStarter(), "Başlık, açıklama, çalışan düğme ve mobil uyumlu stil içeren HTML sayfası.");
        }

        return unsupported("Bu istek desteklenen yerel kod üretim kurallarıyla eşleşmedi; yapılandırılmış JavaScript dili, modüler çevrimdışı web proje bileşenleri veya başlangıç tarifleriyle güvenilir biçimde üretilemiyor."
                + " Desteklenen proje modüllerini birlikte isteyebilirsin: görev listesi, notlar, sayaç, hesap makinesi, kronometre, hafıza kartı, refleks, quiz ve X-O."
                + " Desteklenmeyen özellikler için sahte kod üretmem; genel amaçlı kodlama modeli değilim.");
    }

    private GeneratedCode js(String id, String title, String source, String explanation, boolean runnable) {
        return new GeneratedCode(true, runnable, id, title, "JavaScript", "// " + title + "\n" + source, explanation);
    }

    private GeneratedCode html(String id, String title, String source, String explanation) {
        return new GeneratedCode(true, false, id, title, "HTML", source, explanation + " Bu sürümde HTML önizleme penceresi henüz yok.");
    }

    private GeneratedCode source(String id, String language, String title, String source, String explanation, boolean runnable) {
        return new GeneratedCode(true, runnable, id, title, language, source, explanation);
    }

    private GeneratedCode unsupported(String explanation) {
        return new GeneratedCode(false, false, "unsupported", "Desteklenmeyen kod isteği", "Metin", "", explanation);
    }

    private String counterJs() {
        return "let count = 0;\n"
                + "function increase() { count += 1; return count; }\n"
                + "function decrease() { count -= 1; return count; }\n"
                + "function reset() { count = 0; return count; }\n"
                + "print('Artır:', increase());\nprint('Artır:', increase());\n"
                + "print('Azalt:', decrease());\nprint('Sıfırla:', reset());";
    }

    private String calculatorJs() {
        return "function calculate(a, operator, b) {\n"
                + "  if (typeof a !== 'number' || typeof b !== 'number') throw new Error('İki sayı gerekli');\n"
                + "  if (operator === '+') return a + b;\n"
                + "  if (operator === '-') return a - b;\n"
                + "  if (operator === '*') return a * b;\n"
                + "  if (operator === '/') { if (b === 0) throw new Error('Sıfıra bölme yapılamaz'); return a / b; }\n"
                + "  throw new Error('Desteklenmeyen işlem');\n}\n"
                + "print('12 + 8 =', calculate(12, '+', 8));\n"
                + "print('12 × 8 =', calculate(12, '*', 8));\n"
                + "print('12 / 3 =', calculate(12, '/', 3));";
    }

    private String fibonacciJs(int requestedCount) {
        return "function fibonacci(n) {\n"
                + "  if (!Number.isInteger(n) || n < 0 || n > 45) throw new Error('n 0 ile 45 arasında tam sayı olmalı');\n"
                + "  const values = [];\n"
                + "  for (let i = 0; i < n; i++) values.push(i < 2 ? i : values[i - 1] + values[i - 2]);\n"
                + "  return values;\n}\nprint(fibonacci(" + requestedCount + ").join(', '));";
    }

    private String primeJs(int upperLimit) {
        return "function isPrime(n) {\n"
                + "  if (!Number.isInteger(n) || n < 2) return false;\n"
                + "  for (let i = 2; i * i <= n; i++) if (n % i === 0) return false;\n"
                + "  return true;\n}\n"
                + "const primes = [];\nfor (let n = 2; n <= " + upperLimit + "; n++) if (isPrime(n)) primes.push(n);\n"
                + "print(primes.join(', '));";
    }

    private String todoJs() {
        return "const tasks = [];\n"
                + "function addTask(text) { if (!text || !text.trim()) return false; tasks.push({text:text.trim(), done:false}); return true; }\n"
                + "function completeTask(index) { if (index < 0 || index >= tasks.length) return false; tasks[index].done = true; return true; }\n"
                + "function removeTask(index) { if (index < 0 || index >= tasks.length) return false; tasks.splice(index, 1); return true; }\n"
                + "addTask('Ja.i kod motorunu test et'); addTask('Yeni proje fikrini yaz'); completeTask(0);\n"
                + "print(JSON.stringify(tasks));";
    }

    private String stringToolsJs() {
        return "function analyzeText(text) {\n"
                + "  const words = text.trim() ? text.trim().split(/\\s+/).length : 0;\n"
                + "  return {characters:text.length, words:words, lines:text.length ? text.split(/\\r?\\n/).length : 0};\n}\n"
                + "print(JSON.stringify(analyzeText('Ja.i yerel kod motoru')));";
    }

    private String arrayToolsJs() {
        return "function analyzeNumbers(values) {\n"
                + "  if (!Array.isArray(values) || values.length === 0) throw new Error('Boş olmayan sayı dizisi gerekli');\n"
                + "  const total = values.reduce((sum, value) => sum + value, 0);\n"
                + "  return {total:total, average:total / values.length, min:Math.min.apply(null, values), max:Math.max.apply(null, values)};\n}\n"
                + "print(JSON.stringify(analyzeNumbers([4, 8, 2, 10, 6])));";
    }

    private String stopwatchJs() {
        return "let startedAt = 0;\nlet elapsed = 0;\nlet running = false;\n"
                + "function start(now) { if (!running) { startedAt = now; running = true; } }\n"
                + "function stop(now) { if (running) { elapsed += Math.max(0, now - startedAt); running = false; } return elapsed; }\n"
                + "function reset() { startedAt = 0; elapsed = 0; running = false; return elapsed; }\n"
                + "start(1000); print('Örnek geçen süre (ms):', stop(4500));";
    }

    private String htmlStarter() {
        return "<!doctype html>\n<html lang=\"tr\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
                + "<title>Ja.i sayfam</title>\n<style>\n:root{color-scheme:dark}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b1020;color:#f5f7ff;font:16px system-ui;padding:24px;box-sizing:border-box}.card{max-width:560px;width:100%;padding:28px;border:1px solid #28334a;border-radius:22px;background:#141d2f}button{background:#7c5cff;color:white;border:0;border-radius:12px;padding:12px 18px;font-size:16px}#result{color:#2dd4bf}</style>\n</head>\n<body><main class=\"card\"><h1>Merhaba!</h1><p>Bu sayfa Ja.i'nin yerel kod şablonundan üretildi.</p><button id=\"action\">Tıkla</button><p id=\"result\" aria-live=\"polite\"></p></main>\n"
                + "<script>document.getElementById('action').addEventListener('click',function(){document.getElementById('result').textContent='Düğme çalışıyor!';});</script>\n</body>\n</html>";
    }

    private String landingHtml() {
        return "<!doctype html>\n<html lang=\"tr\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Tanıtım Sayfası</title>\n"
                + "<style>body{margin:0;background:#0b1020;color:#f5f7ff;font:16px system-ui}header,main,footer{max-width:900px;margin:auto;padding:24px}nav{display:flex;justify-content:space-between;align-items:center}a{color:#2dd4bf}.hero{padding:70px 24px}.hero h1{font-size:clamp(2rem,8vw,4rem);margin:0 0 16px}.tag{color:#2dd4bf}.button{display:inline-block;background:#7c5cff;color:#fff;padding:12px 18px;border-radius:12px;text-decoration:none}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px}.tile{background:#141d2f;border:1px solid #28334a;border-radius:16px;padding:18px}</style></head>\n"
                + "<body><header><nav><strong>Marka Adı</strong><a href=\"#iletisim\">İletişim</a></nav></header><main><section class=\"hero\"><p class=\"tag\">MERHABA, BEN ...</p><h1>Fikrini burada anlat.</h1><p>Bu alanı kendini, projenı veya hizmetini tanıtmak için düzenle.</p><a class=\"button\" href=\"#hakkinda\">Keşfet</a></section><section id=\"hakkinda\" class=\"grid\"><article class=\"tile\"><h2>Hakkımda</h2><p>Kısa açıklamanı yaz.</p></article><article class=\"tile\"><h2>Projeler</h2><p>Çalışmalarını tanıt.</p></article><article class=\"tile\"><h2>Yetenekler</h2><p>Yeteneklerini listele.</p></article></section></main><footer id=\"iletisim\">İletişim: e-posta adresini buraya ekle.</footer></body></html>";
    }

    private String clickerHtml() {
        return "<!doctype html><html lang=\"tr\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Tıklama Oyunu</title>\n"
                + "<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b1020;color:white;font:18px system-ui;text-align:center}.wrap{padding:28px;background:#141d2f;border-radius:22px;width:min(90vw,420px)}button{border:0;border-radius:50%;width:190px;height:190px;background:#7c5cff;color:white;font-size:24px;font-weight:700;touch-action:manipulation}strong{color:#2dd4bf;font-size:30px}</style></head>\n"
                + "<body><main class=\"wrap\"><h1>Tıkla ve puan kazan</h1><p>Puan: <strong id=\"score\">0</strong></p><button id=\"tap\">TIKLA</button><p id=\"message\">Başlamak için dokun.</p></main><script>let score=0;document.getElementById('tap').addEventListener('click',()=>{score++;document.getElementById('score').textContent=score;document.getElementById('message').textContent='Harika! '+score+' puan.';});</script></body></html>";
    }

    private String quizHtml() {
        return "<!doctype html><html lang=\"tr\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Mini Quiz</title>\n"
                + "<style>body{font:17px system-ui;background:#0b1020;color:#fff;padding:20px}.box{max-width:620px;margin:5vh auto;background:#141d2f;padding:24px;border-radius:20px}button{display:block;width:100%;margin:9px 0;padding:13px;border:1px solid #38415a;background:#202c43;color:white;border-radius:12px;text-align:left}#feedback{color:#2dd4bf}</style></head>\n"
                + "<body><main class=\"box\"><h1>Mini Quiz</h1><h2 id=\"question\"></h2><div id=\"answers\"></div><p id=\"feedback\"></p><p id=\"score\"></p><button id=\"next\">Sonraki soru</button></main><script>const items=[{q:'HTML ne için kullanılır?',a:['Web sayfası yapısı','Veritabanı','İşletim sistemi'],c:0},{q:'JavaScript ne ekler?',a:['Etkileşim','Ekran kartı','Pil'],c:0}];let index=0,score=0;function draw(){let item=items[index];document.getElementById('question').textContent=item.q;let root=document.getElementById('answers');root.innerHTML='';item.a.forEach((answer,i)=>{let b=document.createElement('button');b.textContent=answer;b.onclick=()=>{if(i===item.c){score++;document.getElementById('feedback').textContent='Doğru!';}else{document.getElementById('feedback').textContent='Doğru cevap: '+item.a[item.c];}document.getElementById('score').textContent='Puan: '+score;Array.from(root.children).forEach(x=>x.disabled=true);};root.appendChild(b);});}document.getElementById('next').onclick=()=>{index=(index+1)%items.length;document.getElementById('feedback').textContent='';draw();};draw();</script></body></html>";
    }

    private String ticTacToeHtml() {
        return "<!doctype html><html lang=\"tr\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>X-O</title>\n"
                + "<style>body{font:18px system-ui;background:#0b1020;color:#fff;text-align:center;padding:20px}.board{display:grid;grid-template-columns:repeat(3, min(25vw,100px));gap:8px;justify-content:center}button.cell{height:min(25vw,100px);border:0;border-radius:14px;background:#141d2f;color:#2dd4bf;font-size:42px;font-weight:700}button#reset{margin:18px;padding:12px 18px;background:#7c5cff;color:white;border:0;border-radius:12px}</style></head>\n"
                + "<body><h1>X-O Oyunu</h1><p id=\"status\">Sıra: X</p><div class=\"board\" id=\"board\"></div><button id=\"reset\">Yeniden başlat</button><script>let cells=Array(9).fill(''),turn='X',done=false;const wins=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];const board=document.getElementById('board');function draw(){board.innerHTML='';cells.forEach((v,i)=>{let b=document.createElement('button');b.className='cell';b.textContent=v;b.onclick=()=>play(i);board.appendChild(b);});}function play(i){if(done||cells[i])return;cells[i]=turn;let won=wins.some(w=>w.every(n=>cells[n]===turn));if(won){done=true;document.getElementById('status').textContent=turn+' kazandı!';}else if(cells.every(Boolean)){done=true;document.getElementById('status').textContent='Berabere!';}else{turn=turn==='X'?'O':'X';document.getElementById('status').textContent='Sıra: '+turn;}draw();}document.getElementById('reset').onclick=()=>{cells=Array(9).fill('');turn='X';done=false;document.getElementById('status').textContent='Sıra: X';draw();};draw();</script></body></html>";
    }

    private int extractNumber(String normalizedPrompt, int fallback, int min, int max) {
        Matcher matcher = Pattern.compile("\\b(\\d{1,5})\\b").matcher(normalizedPrompt);
        if (!matcher.find()) return fallback;
        try {
            int value = Integer.parseInt(matcher.group(1));
            return Math.max(min, Math.min(max, value));
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private boolean contains(String text, String... words) {
        for (String word : words) if (text.contains(TurkishTextProcessor.normalize(word))) return true;
        return false;
    }
}
