package com.jai.assistant.data;

public final class ChatMessage {
    public final long id;
    public final String role;
    public final String content;
    public final long createdAt;

    public ChatMessage(long id, String role, String content, long createdAt) {
        this.id = id;
        this.role = role;
        this.content = content;
        this.createdAt = createdAt;
    }
}
