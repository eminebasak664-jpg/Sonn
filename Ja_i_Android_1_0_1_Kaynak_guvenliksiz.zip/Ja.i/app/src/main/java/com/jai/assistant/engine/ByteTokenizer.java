package com.jai.assistant.engine;

import com.jai.assistant.data.ChatMessage;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Ja.i'nin sıfırdan eğitilen dil modeli için modelle birlikte tanımlanmış UTF-8 byte tokenizer'ı.
 * 0..255 byte değerleri, 256..261 arası kontrol token'larıdır.
 */
public final class ByteTokenizer {
    public static final int PAD = 256;
    public static final int BOS = 257;
    public static final int USER = 258;
    public static final int ASSISTANT = 259;
    public static final int EOS = 260;
    public static final int SYSTEM = 261;
    public static final int VOCAB_SIZE = 262;

    private ByteTokenizer() { }

    public static int[] encodeText(String text) {
        byte[] bytes = (text == null ? "" : text).getBytes(StandardCharsets.UTF_8);
        int[] tokens = new int[bytes.length];
        for (int i = 0; i < bytes.length; i++) tokens[i] = bytes[i] & 0xff;
        return tokens;
    }

    public static String decodeBytes(List<Integer> tokens) {
        if (tokens == null || tokens.isEmpty()) return "";
        byte[] bytes = new byte[tokens.size()];
        int count = 0;
        for (Integer token : tokens) {
            if (token == null || token < 0 || token > 255) continue;
            bytes[count++] = (byte) (int) token;
        }
        return new String(bytes, 0, count, StandardCharsets.UTF_8);
    }

    /** Sohbet geçmişini modelin eğitim biçimiyle eşleşen tek token dizisine dönüştürür. */
    public static int[] buildConversation(List<ChatMessage> history, String currentPrompt,
                                          String context, int maxTokens) {
        int safeMax = Math.max(64, Math.min(2048, maxTokens));
        List<Integer> all = new ArrayList<>();
        all.add(BOS);
        all.add(SYSTEM);
        appendText(all, "Sen Ja.i'sin. Türkçe konuş. Yardımcı, açık ve dürüst ol. Bilmediğin bilgiyi uydurma.\n");

        String rawPrompt = currentPrompt == null ? "" : currentPrompt.trim();
        String contextualPrompt = rawPrompt;
        String safeContext = context == null ? "" : context.trim();
        if (safeContext.length() > 1800) safeContext = safeContext.substring(0, 1800);
        if (!safeContext.isEmpty()) {
            contextualPrompt = "Kaynak/işlem bağlamı:\n" + safeContext
                    + "\n\nKullanıcının isteği:\n" + rawPrompt;
        }

        boolean currentAlreadyInHistory = false;
        List<ChatMessage> safeHistory = history == null ? new ArrayList<>() : history;
        int start = Math.max(0, safeHistory.size() - 8);
        for (int i = start; i < safeHistory.size(); i++) {
            ChatMessage message = safeHistory.get(i);
            if (message == null || message.content == null) continue;
            boolean user = "user".equalsIgnoreCase(message.role);
            boolean assistant = "assistant".equalsIgnoreCase(message.role);
            if (!user && !assistant) continue;
            if (user && i == safeHistory.size() - 1 && message.content.trim().equals(rawPrompt)) {
                currentAlreadyInHistory = true;
            }
            all.add(user ? USER : ASSISTANT);
            appendText(all, message.content);
            if (assistant) all.add(EOS);
        }
        if (!currentAlreadyInHistory) {
            all.add(USER);
            appendText(all, contextualPrompt);
        } else if (!safeContext.isEmpty()) {
            // Son kullanıcı iletisi geçmişte zaten bulunur; isteği tekrarlamadan bağlamı ekle.
            all.add(USER);
            appendText(all, "Ek kaynak/işlem bağlamı:\n" + safeContext);
        }
        all.add(ASSISTANT);

        if (all.size() > safeMax) {
            // BOS ve SYSTEM yönergesini koru; yalnızca eski konuşma gövdesini kırp.
            int prefixLength = 2 + encodeText("Sen Ja.i'sin. Türkçe konuş. Yardımcı, açık ve dürüst ol. Bilmediğin bilgiyi uydurma.\n").length;
            if (prefixLength >= safeMax - 1) {
                all = new ArrayList<>(all.subList(all.size() - (safeMax - 1), all.size()));
                all.add(0, BOS);
            } else {
                List<Integer> prefix = new ArrayList<>(all.subList(0, prefixLength));
                int remaining = safeMax - prefixLength;
                List<Integer> tail = new ArrayList<>(all.subList(Math.max(prefixLength, all.size() - remaining), all.size()));
                all.clear();
                all.addAll(prefix);
                all.addAll(tail);
            }
        }
        int[] result = new int[all.size()];
        for (int i = 0; i < all.size(); i++) result[i] = all.get(i);
        return result;
    }

    private static void appendText(List<Integer> target, String text) {
        int[] encoded = encodeText(text);
        for (int token : encoded) target.add(token);
    }

    public static int[] toFixedInput(int[] tokens, int maxTokens) {
        int length = Math.max(1, Math.min(maxTokens, tokens == null ? 0 : tokens.length));
        int[] result = new int[maxTokens];
        Arrays.fill(result, PAD);
        if (tokens != null) System.arraycopy(tokens, Math.max(0, tokens.length - length), result, 0, length);
        return result;
    }
}
