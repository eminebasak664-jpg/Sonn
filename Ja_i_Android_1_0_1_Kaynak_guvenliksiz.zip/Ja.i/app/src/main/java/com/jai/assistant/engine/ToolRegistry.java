package com.jai.assistant.engine;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Gerçek yerel işlevleri ve hangi isteklerde kullanılabileceklerini kaydeder. */
public final class ToolRegistry {
    public interface Tool {
        String execute(String input) throws Exception;
    }

    public interface Matcher {
        int score(String request);
    }

    public interface InputExtractor {
        String extract(String request);
    }

    public static final class Selection {
        public final String name;
        public final String input;
        public final int score;

        private Selection(String name, String input, int score) {
            this.name = name;
            this.input = input;
            this.score = score;
        }
    }

    private static final class Entry {
        final Tool tool;
        final Matcher matcher;
        final InputExtractor extractor;
        Entry(Tool tool, Matcher matcher, InputExtractor extractor) {
            this.tool = tool;
            this.matcher = matcher;
            this.extractor = extractor;
        }
    }

    private final Map<String, Entry> entries = new LinkedHashMap<>();

    /** Yalnızca açıkça çağrılan araçlar için geriye dönük kayıt yöntemi. */
    public synchronized void register(String name, Tool tool) {
        register(name, tool, null, null);
    }

    /** Matcher puanı sıfırdan büyükse araç adaydır; en yüksek puan kazanır. */
    public synchronized void register(String name, Tool tool, Matcher matcher, InputExtractor extractor) {
        if (name == null || name.trim().isEmpty() || tool == null) {
            throw new IllegalArgumentException("Araç adı ve işlevi zorunludur.");
        }
        if ((matcher == null) != (extractor == null)) {
            throw new IllegalArgumentException("Otomatik yönlendirme için matcher ve input extractor birlikte verilmelidir.");
        }
        entries.put(name, new Entry(tool, matcher, extractor));
    }

    public synchronized boolean contains(String name) {
        return entries.containsKey(name);
    }

    public synchronized String execute(String name, String input) throws Exception {
        Entry entry = entries.get(name);
        if (entry == null) throw new IllegalArgumentException("Kayıtlı olmayan araç: " + name);
        return entry.tool.execute(input == null ? "" : input);
    }

    public synchronized Selection selectBest(String request) {
        String safeRequest = request == null ? "" : request;
        String selectedName = null;
        String selectedInput = "";
        int selectedScore = 0;
        for (Map.Entry<String, Entry> item : entries.entrySet()) {
            Entry entry = item.getValue();
            if (entry.matcher == null) continue;
            int score = Math.max(0, entry.matcher.score(safeRequest));
            if (score > selectedScore) {
                selectedName = item.getKey();
                selectedInput = entry.extractor.extract(safeRequest);
                selectedScore = score;
            }
        }
        return selectedName == null ? null : new Selection(selectedName, selectedInput, selectedScore);
    }

    public String execute(Selection selection) throws Exception {
        if (selection == null) throw new IllegalArgumentException("Araç seçimi boş.");
        return execute(selection.name, selection.input);
    }

    public synchronized Map<String, Tool> registeredTools() {
        Map<String, Tool> copy = new LinkedHashMap<>();
        for (Map.Entry<String, Entry> entry : entries.entrySet()) copy.put(entry.getKey(), entry.getValue().tool);
        return Collections.unmodifiableMap(copy);
    }
}
