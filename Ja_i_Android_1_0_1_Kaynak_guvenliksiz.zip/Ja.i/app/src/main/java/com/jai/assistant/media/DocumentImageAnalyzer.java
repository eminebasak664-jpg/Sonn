package com.jai.assistant.media;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.graphics.pdf.PdfRenderer;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.defaults.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * Yerel belge/görsel analizi. PDFBox metin katmanını okur; taranmış PDF sayfalarını
 * PdfRenderer + cihaz içi ML Kit OCR ile sınırlı sayıda işler. Fotoğraflarda OCR ve
 * hafif nesne/konu etiketleri çıkarır. Genel görsel muhakeme veya LLM değildir.
 */
public final class DocumentImageAnalyzer {
    private static final int MAX_PDF_BYTES = 20 * 1024 * 1024;
    private static final int MAX_PDF_PAGES = 20;
    private static final int MAX_OCR_PDF_PAGES = 5;
    private static final int MAX_IMAGE_DIMENSION = 2048;
    private static final long TASK_TIMEOUT_SECONDS = 35;

    private final Context context;

    public DocumentImageAnalyzer(Context context) {
        this.context = context.getApplicationContext();
    }

    public String analyze(Context ignored, Uri uri, String displayName) throws Exception {
        if (uri == null) throw new IllegalArgumentException("Dosya seçilmedi.");
        String name = displayName == null ? "" : displayName.toLowerCase(Locale.ROOT);
        String mime = context.getContentResolver().getType(uri);
        if (name.endsWith(".pdf") || "application/pdf".equalsIgnoreCase(mime)) {
            return analyzePdf(uri);
        }
        if ((mime != null && mime.startsWith("image/")) || name.matches(".*\\.(jpg|jpeg|png|webp|bmp|heic)$")) {
            return analyzeImage(uri);
        }
        throw new IllegalArgumentException("Bu dosya PDF veya desteklenen bir görsel değil.");
    }

    private String analyzePdf(Uri uri) throws Exception {
        File temp = copyPdfToCache(uri);
        StringBuilder output = new StringBuilder("PDF ANALİZİ\n");
        int pageCount;
        int extractedTextCharacters = 0;
        try {
            PDFBoxResourceLoader.init(context);
            try (PDDocument document = PDDocument.load(temp)) {
                pageCount = document.getNumberOfPages();
                if (pageCount <= 0) throw new IllegalArgumentException("PDF içinde sayfa bulunamadı.");
                output.append("Sayfa sayısı: ").append(pageCount).append("\n");
                int end = Math.min(pageCount, MAX_PDF_PAGES);
                PDFTextStripper stripper = new PDFTextStripper();
                stripper.setStartPage(1);
                stripper.setEndPage(end);
                String text = stripper.getText(document);
                text = clean(text);
                extractedTextCharacters = countUsefulCharacters(text);
                if (!text.isEmpty()) {
                    output.append("\nMETİN KATMANI (ilk ").append(end).append(" sayfa):\n");
                    output.append(limit(text, 18000));
                } else {
                    output.append("\nPDF'nin seçilebilir metin katmanı bulunamadı; taranmış sayfalarda OCR deneniyor.\n");
                }
            }

            if (extractedTextCharacters < 80) {
                String scanned = ocrPdfPages(temp, Math.min(pageCount, MAX_OCR_PDF_PAGES));
                if (!scanned.trim().isEmpty()) {
                    output.append("\n\nTARANMIŞ SAYFA OCR SONUCU (en fazla ")
                            .append(Math.min(pageCount, MAX_OCR_PDF_PAGES)).append(" sayfa):\n")
                            .append(limit(scanned, 9000));
                } else {
                    output.append("\nOCR okunabilir metin bulamadı. Sayfa görüntüleri bu sürümde semantik olarak yorumlanmıyor.");
                }
            }
            if (pageCount > MAX_PDF_PAGES) {
                output.append("\n\nNot: Güvenlik ve telefon belleği için yalnızca ilk ")
                        .append(MAX_PDF_PAGES).append(" sayfa metni işlendi.");
            }
            return output.toString();
        } finally {
            // Android PdfRenderer dosya tanıtıcıları kapandıktan sonra geçici dosya silinir.
            // Dosya kilitli kalırsa cache temizliği sonraki uygulama başlatmalarına bırakılır.
            if (temp.exists()) temp.delete();
        }
    }

    private File copyPdfToCache(Uri uri) throws Exception {
        File target = new File(context.getCacheDir(), "jai_pdf_" + System.nanoTime() + ".pdf");
        try (InputStream input = context.getContentResolver().openInputStream(uri);
             FileOutputStream output = new FileOutputStream(target)) {
            if (input == null) throw new IllegalStateException("PDF okunamadı.");
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > MAX_PDF_BYTES) throw new IllegalArgumentException("PDF 20 MiB sınırını aşıyor.");
                output.write(buffer, 0, read);
            }
            output.flush();
        } catch (Exception ex) {
            target.delete();
            throw ex;
        }
        return target;
    }

    private String ocrPdfPages(File file, int pages) throws Exception {
        StringBuilder output = new StringBuilder();
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        try (ParcelFileDescriptor pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer = new PdfRenderer(pfd)) {
            int count = Math.min(pages, renderer.getPageCount());
            for (int i = 0; i < count; i++) {
                try (PdfRenderer.Page page = renderer.openPage(i)) {
                    float scale = Math.min(2.0f, MAX_IMAGE_DIMENSION / (float) Math.max(page.getWidth(), page.getHeight()));
                    int width = Math.max(1, Math.round(page.getWidth() * scale));
                    int height = Math.max(1, Math.round(page.getHeight() * scale));
                    Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    try {
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        Text result = Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0)),
                                TASK_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                        String text = clean(result.getText());
                        if (!text.isEmpty()) output.append("\n[Sayfa ").append(i + 1).append("]\n").append(text).append("\n");
                    } finally {
                        bitmap.recycle();
                    }
                }
            }
        } finally {
            recognizer.close();
        }
        return output.toString();
    }

    private String analyzeImage(Uri uri) throws Exception {
        long fileSize = getSize(uri);
        if (fileSize > MAX_PDF_BYTES) throw new IllegalArgumentException("Fotoğraf dosyası 20 MiB sınırını aşıyor.");
        Bitmap bitmap = decodeDownsampled(uri);
        if (bitmap == null) throw new IllegalArgumentException("Fotoğraf çözümlenemedi.");
        try {
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            StringBuilder output = new StringBuilder("FOTOĞRAF ANALİZİ\n");
            output.append("Görüntü boyutu: ").append(bitmap.getWidth()).append(" × ").append(bitmap.getHeight())
                    .append(" piksel (telefon belleği için küçültülmüş olabilir)\n");

            TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            try {
                Text text = Tasks.await(recognizer.process(image), TASK_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                String recognized = clean(text.getText());
                output.append("\nGÖRSELDEKİ YAZILAR:\n");
                output.append(recognized.isEmpty() ? "Okunabilir yazı tespit edilmedi." : limit(recognized, 12000));
            } finally {
                recognizer.close();
            }

            ImageLabeler labeler = ImageLabeling.getClient(new ImageLabelerOptions.Builder()
                    .setConfidenceThreshold(0.55f).build());
            try {
                List<ImageLabel> labels = Tasks.await(labeler.process(image), TASK_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                output.append("\n\nGÖRSEL ETİKETLERİ (yerel sınıflandırma):\n");
                if (labels.isEmpty()) output.append("Belirgin bir etiket bulunamadı.");
                else {
                    int count = 0;
                    for (ImageLabel label : labels) {
                        if (count++ >= 8) break;
                        output.append("• ").append(label.getText()).append(" (")
                                .append(String.format(Locale.ROOT, "%.0f%%", label.getConfidence() * 100f))
                                .append(")\n");
                    }
                }
            } finally {
                labeler.close();
            }
            output.append("\nNot: Etiketler olasılıksal tahmindir; fotoğrafın tüm bağlamını veya kişilerin kimliğini belirlemez.");
            return output.toString();
        } finally {
            bitmap.recycle();
        }
    }

    private Bitmap decodeDownsampled(Uri uri) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream input = context.getContentResolver().openInputStream(uri)) {
            if (input == null) throw new IllegalArgumentException("Fotoğraf okunamadı.");
            BitmapFactory.decodeStream(input, null, bounds);
        }
        int sample = 1;
        while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > MAX_IMAGE_DIMENSION) sample *= 2;
        BitmapFactory.Options decode = new BitmapFactory.Options();
        decode.inSampleSize = Math.max(1, sample);
        decode.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try (InputStream input = context.getContentResolver().openInputStream(uri)) {
            if (input == null) throw new IllegalArgumentException("Fotoğraf okunamadı.");
            return BitmapFactory.decodeStream(input, null, decode);
        }
    }

    private long getSize(Uri uri) {
        try (android.database.Cursor cursor = context.getContentResolver().query(uri,
                new String[]{android.provider.OpenableColumns.SIZE}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst() && !cursor.isNull(0)) return cursor.getLong(0);
        } catch (Exception ignored) { }
        return 0L;
    }

    private int countUsefulCharacters(String value) {
        int count = 0;
        for (int i = 0; i < value.length(); i++) if (Character.isLetterOrDigit(value.charAt(i))) count++;
        return count;
    }

    private String clean(String value) {
        if (value == null) return "";
        return value.replace('\u0000', ' ').replaceAll("[\\t\\x0B\\f\\r]+", " ")
                .replaceAll("[ ]{2,}", " ").trim();
    }

    private String limit(String value, int max) {
        return value.length() <= max ? value : value.substring(0, max) + "\n… (çıktı telefon belleği için kısaltıldı)";
    }
}
