package com.jai.assistant.engine;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Generated Bedrock content is checked before packaging. Safe mechanical issues
 * (BOM, trailing commas, impossible stack sizes and unsafe paths) are repaired;
 * unknown/schema errors stop generation rather than being hidden.
 */
public final class BedrockPackRepairEngine {
    public static final class Result {
        public final Map<String, byte[]> files;
        public final int repairedFiles;
        public final String report;
        Result(Map<String, byte[]> files, int repairedFiles, String report) {
            this.files = files;
            this.repairedFiles = repairedFiles;
            this.report = report;
        }
    }

    public Result validateAndRepair(Map<String, byte[]> source) throws IOException {
        if (source == null || source.isEmpty()) throw new IOException("Bedrock paketi boş oluşturuldu.");
        Map<String, byte[]> output = new LinkedHashMap<>();
        int repaired = 0;
        int jsonCount = 0;
        for (Map.Entry<String, byte[]> entry : source.entrySet()) {
            String path = entry.getKey();
            validatePath(path);
            byte[] bytes = entry.getValue() == null ? new byte[0] : entry.getValue().clone();
            if (path.toLowerCase(java.util.Locale.ROOT).endsWith(".json")) {
                jsonCount++;
                String text = new String(bytes, StandardCharsets.UTF_8);
                String fixed = repairJsonText(text);
                if (!fixed.equals(text)) repaired++;
                if (fixed.contains("\"minecraft:max_stack_size\"")) {
                    String stackFixed = clampStackSizes(fixed);
                    if (!stackFixed.equals(fixed)) repaired++;
                    fixed = stackFixed;
                }
                try {
                    new JsonParser(fixed).parse();
                } catch (IllegalArgumentException error) {
                    throw new IOException("Kendi kendine onarım JSON hatasını çözemedi: " + path + " · " + error.getMessage());
                }
                bytes = fixed.getBytes(StandardCharsets.UTF_8);
            }
            output.put(path, bytes);
        }
        if (!output.containsKey("manifest.json")) throw new IOException("Paket manifest.json dosyası eksik.");
        String manifest = new String(output.get("manifest.json"), StandardCharsets.UTF_8);
        if (!manifest.contains("\"uuid\"")) throw new IOException("manifest.json içinde paket UUID'si yok.");
        validateManifest(manifest, output);
        return new Result(output, repaired, "Otomatik doğrulama: " + jsonCount + " JSON dosyası ayrıştırıldı; "
                + repaired + " mekanik düzeltme uygulandı; güvensiz dosya yolu bulunmadı.");
    }


    private void validateManifest(String manifest, Map<String, byte[]> files) throws IOException {
        Matcher uuids = Pattern.compile("\"uuid\"\\s*:\\s*\"([0-9a-fA-F-]{36})\"").matcher(manifest);
        Set<String> unique = new HashSet<>();
        int found = 0;
        while (uuids.find()) {
            String value = uuids.group(1).toLowerCase(java.util.Locale.ROOT);
            try {
                if (!UUID.fromString(value).toString().equals(value)) throw new IllegalArgumentException("canonical");
            } catch (IllegalArgumentException invalid) {
                throw new IOException("manifest.json içinde geçersiz UUID: " + value);
            }
            if (!unique.add(value)) throw new IOException("manifest.json içinde yinelenen UUID: " + value);
            found++;
        }
        if (found < 2) throw new IOException("manifest.json header ve module UUID alanlarını içermeli.");
        if (manifest.contains("\"type\": \"script\"")) {
            Matcher entry = Pattern.compile("\"entry\"\\s*:\\s*\"([^\"]+)\"").matcher(manifest);
            boolean hasEntry = entry.find();
            if (!hasEntry || !files.containsKey(entry.group(1))) {
                throw new IOException("Script modülü entry dosyasını bulamadı: " + (hasEntry ? entry.group(1) : "entry"));
            }
            if (manifest.contains("@minecraft/server") && !manifest.contains("\"version\": \"2.4.0\"")) {
                throw new IOException("Bedrock 1.21.132 hedefinde @minecraft/server bağımlılık sürümü doğrulanmadı.");
            }
        }
    }

    private String repairJsonText(String text) {
        String fixed = text == null ? "" : text;
        if (!fixed.isEmpty() && fixed.charAt(0) == '\uFEFF') fixed = fixed.substring(1);
        // JSON nesne/array sonundaki yaygın üretim hatasını yalnızca string dışındayken temizle.
        StringBuilder out = new StringBuilder(fixed.length());
        boolean inString = false, escaped = false;
        for (int i = 0; i < fixed.length(); i++) {
            char c = fixed.charAt(i);
            if (inString) {
                out.append(c);
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '\"') inString = false;
                continue;
            }
            if (c == '\"') { inString = true; out.append(c); continue; }
            if (c == ',') {
                int j = i + 1;
                while (j < fixed.length() && Character.isWhitespace(fixed.charAt(j))) j++;
                if (j < fixed.length() && (fixed.charAt(j) == '}' || fixed.charAt(j) == ']')) continue;
            }
            out.append(c);
        }
        return out.toString();
    }

    private String clampStackSizes(String json) {
        Matcher matcher = Pattern.compile("(\\\"minecraft:max_stack_size\\\"\\s*:\\s*)(\\d+)").matcher(json);
        StringBuffer result = new StringBuffer();
        while (matcher.find()) {
            int requested;
            try { requested = Integer.parseInt(matcher.group(2)); }
            catch (NumberFormatException ex) { requested = 64; }
            int safe = Math.max(1, Math.min(64, requested));
            matcher.appendReplacement(result, Matcher.quoteReplacement(matcher.group(1) + safe));
        }
        matcher.appendTail(result);
        return result.toString();
    }

    private void validatePath(String path) throws IOException {
        if (path == null || path.trim().isEmpty() || path.startsWith("/") || path.startsWith("\\")
                || path.contains("..") || path.indexOf('\\') >= 0 || path.matches("^[A-Za-z]:.*")) {
            throw new IOException("Güvensiz Bedrock paket yolu: " + path);
        }
    }

    /** Küçük bağımlılıksız JSON ayrıştırıcısı; Android/Gradle JSON kitaplığına bağlı değildir. */
    static final class JsonParser {
        private final String text;
        private int index;
        JsonParser(String text) { this.text = text == null ? "" : text; }
        void parse() {
            skipWhitespace();
            value();
            skipWhitespace();
            if (index != text.length()) fail("fazladan karakter");
        }
        private void value() {
            skipWhitespace();
            if (index >= text.length()) fail("değer bekleniyordu");
            char c = text.charAt(index);
            if (c == '{') object();
            else if (c == '[') array();
            else if (c == '"') string();
            else if (c == 't') literal("true");
            else if (c == 'f') literal("false");
            else if (c == 'n') literal("null");
            else number();
        }
        private void object() {
            index++; skipWhitespace();
            if (take('}')) return;
            while (true) {
                skipWhitespace();
                if (index >= text.length() || text.charAt(index) != '"') fail("nesne anahtarı metin olmalı");
                string(); skipWhitespace(); expect(':'); value(); skipWhitespace();
                if (take('}')) return;
                expect(',');
            }
        }
        private void array() {
            index++; skipWhitespace();
            if (take(']')) return;
            while (true) {
                value(); skipWhitespace();
                if (take(']')) return;
                expect(',');
            }
        }
        private void string() {
            expect('"');
            while (index < text.length()) {
                char c = text.charAt(index++);
                if (c == '"') return;
                if (c < 0x20) fail("metin içinde kontrol karakteri");
                if (c == '\\') {
                    if (index >= text.length()) fail("yarım kaçış dizisi");
                    char e = text.charAt(index++);
                    if (e == 'u') {
                        for (int i = 0; i < 4; i++) {
                            if (index >= text.length() || Character.digit(text.charAt(index++), 16) < 0) fail("geçersiz Unicode kaçışı");
                        }
                    } else if (e != '"' && e != '\\' && e != '/' && e != 'b' && e != 'f' && e != 'n' && e != 'r' && e != 't') {
                        fail("geçersiz metin kaçışı");
                    }
                }
            }
            fail("kapanmamış metin");
        }
        private void number() {
            int start = index;
            if (take('-')) { }
            if (take('0')) { }
            else {
                if (index >= text.length() || !Character.isDigit(text.charAt(index))) fail("sayı bekleniyordu");
                while (index < text.length() && Character.isDigit(text.charAt(index))) index++;
            }
            if (take('.')) {
                if (index >= text.length() || !Character.isDigit(text.charAt(index))) fail("ondalık basamak eksik");
                while (index < text.length() && Character.isDigit(text.charAt(index))) index++;
            }
            if (take('e') || take('E')) {
                if (!take('+')) take('-');
                if (index >= text.length() || !Character.isDigit(text.charAt(index))) fail("üs değeri eksik");
                while (index < text.length() && Character.isDigit(text.charAt(index))) index++;
            }
            if (start == index) fail("geçersiz sayı");
        }
        private void literal(String expected) {
            if (!text.regionMatches(index, expected, 0, expected.length())) fail("geçersiz değer");
            index += expected.length();
        }
        private void skipWhitespace() {
            while (index < text.length()) {
                char c = text.charAt(index);
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t') index++; else break;
            }
        }
        private boolean take(char c) { if (index < text.length() && text.charAt(index) == c) { index++; return true; } return false; }
        private void expect(char c) { if (!take(c)) fail("'" + c + "' bekleniyordu"); }
        private void fail(String message) { throw new IllegalArgumentException(message + " (konum " + index + ")"); }
    }
}
