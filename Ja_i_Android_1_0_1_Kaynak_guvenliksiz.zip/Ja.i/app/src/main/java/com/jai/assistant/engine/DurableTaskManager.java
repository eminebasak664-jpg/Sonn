package com.jai.assistant.engine;

import android.content.Context;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import com.jai.assistant.data.MemoryDatabase;
import com.jai.assistant.data.TaskRecord;

import java.util.concurrent.TimeUnit;

/** WorkManager tabanlı, uygulama kapanınca da kalıcı kalan görev orkestratörü. */
public final class DurableTaskManager {
    private final Context context;
    private final MemoryDatabase database;

    public DurableTaskManager(Context context, MemoryDatabase database) {
        this.context = context.getApplicationContext();
        this.database = database;
    }

    public boolean scheduleExistingTask(long taskId) {
        TaskRecord task = database.getTask(taskId);
        if (task == null || "Duraklatıldı".equals(task.status) || "Tamamlandı".equals(task.status)) return false;
        int step = DurableTaskWorker.readStep(task.details);
        enqueueStep(taskId, step);
        return true;
    }

    public void pause(long taskId) {
        WorkManager.getInstance(context).cancelAllWorkByTag(tag(taskId));
        TaskRecord task = database.getTask(taskId);
        if (task != null) database.updateTask(taskId, "Duraklatıldı", task.details);
    }

    void enqueueStep(long taskId, int step) {
        Constraints.Builder constraints = new Constraints.Builder();
        // Sadece web araştırma adımı internet ister. Diğer adımlar çevrimdışı çalışır.
        if (step == 1) constraints.setRequiredNetworkType(NetworkType.CONNECTED);
        Data input = new Data.Builder().putLong("task_id", taskId).putInt("step", step).build();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(DurableTaskWorker.class)
                .setInputData(input)
                .addTag(tag(taskId))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
                .setConstraints(constraints.build())
                .build();
        WorkManager.getInstance(context).enqueueUniqueWork(workName(taskId, step), ExistingWorkPolicy.KEEP, request);
    }

    static String workName(long taskId, int step) { return "jai-task-" + taskId + "-step-" + step; }
    static String tag(long taskId) { return "jai-task-" + taskId; }
}
