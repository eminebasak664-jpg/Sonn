package com.jai.assistant.server;

/** Sunucu bağlantı ayarları. Erişim anahtarı yalnızca bellekte çözülmüş olarak tutulur. */
public final class ServerConfig {
    public final String baseUrl;
    public final String healthPath;
    public final String bearerToken;

    public ServerConfig(String baseUrl, String healthPath, String bearerToken) {
        this.baseUrl = baseUrl;
        this.healthPath = healthPath;
        this.bearerToken = bearerToken == null ? "" : bearerToken;
    }

    public boolean isConfigured() {
        return baseUrl != null && !baseUrl.trim().isEmpty();
    }

    public String getHealthUrl() {
        return baseUrl + (healthPath.startsWith("/") ? healthPath : "/" + healthPath);
    }
}
