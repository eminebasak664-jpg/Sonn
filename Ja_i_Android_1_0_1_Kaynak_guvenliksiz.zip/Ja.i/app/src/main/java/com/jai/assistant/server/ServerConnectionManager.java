package com.jai.assistant.server;

import java.io.InputStream;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;

/** Sunucuya tek HTTP isteği gönderir. Kendi başına zamanlayıcı veya arka plan döngüsü başlatmaz. */
public final class ServerConnectionManager {
    public Result sendSingleWakeRequest(ServerConfig config) {
        if (config == null || !config.isConfigured()) return new Result(false, 0, "Sunucu adresi ayarlanmamış.");
        HttpsURLConnection connection = null;
        try {
            URL url = new URL(config.getHealthUrl());
            java.net.URLConnection rawConnection = url.openConnection();
            if (!(rawConnection instanceof HttpsURLConnection)) return new Result(false, 0, "Yalnızca güvenli HTTPS bağlantısı desteklenir.");
            connection = (HttpsURLConnection) rawConnection;
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Accept", "application/json, text/plain, */*");
            connection.setRequestProperty("User-Agent", "Ja.i-Android/0.6");
            if (config.bearerToken != null && !config.bearerToken.isEmpty()) {
                connection.setRequestProperty("Authorization", "Bearer " + config.bearerToken);
            }
            int code = connection.getResponseCode();
            if (code >= 200 && code < 300) {
                try (InputStream stream = connection.getInputStream()) {
                    byte[] buffer = new byte[512];
                    int total = 0;
                    int read;
                    while ((read = stream.read(buffer)) != -1 && total < 4096) total += read;
                } catch (Exception ignored) { }
                return new Result(true, code, "Sunucu yanıt verdi (HTTP " + code + ").");
            }
            if (code >= 300 && code < 400) return new Result(false, code, "Sunucu yönlendirme döndürdü (HTTP " + code + "). Güvenlik için yönlendirme izlenmedi.");
            return new Result(false, code, "Sunucu isteğe HTTP " + code + " yanıtı verdi. Hizmet hazır olmayabilir veya yol/erişim bilgisi yanlış olabilir.");
        } catch (Exception exception) {
            String message = exception.getMessage();
            if (message == null || message.trim().isEmpty()) message = exception.getClass().getSimpleName();
            return new Result(false, 0, "Sunucuya ulaşılamadı: " + message);
        } finally {
            if (connection != null) {
                try { InputStream stream = connection.getErrorStream(); if (stream != null) stream.close(); } catch (Exception ignored) { }
                connection.disconnect();
            }
        }
    }

    public static final class Result {
        public final boolean reachable;
        public final int httpCode;
        public final String message;
        Result(boolean reachable, int httpCode, String message) {
            this.reachable = reachable; this.httpCode = httpCode; this.message = message;
        }
    }
}
