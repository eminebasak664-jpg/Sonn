package com.jai.assistant.engine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** İsteği uygulanabilir bir yerel işlem planına dönüştürür. */
public final class TaskPlanner {
    public static final class ExecutionPlan {
        public final String objective;
        public final String intent;
        public final String selectedTool;
        public final boolean retrieveContext;
        public final boolean verifyOutput;
        public final String requestKind;
        public final String evidenceStatus;
        public final double evidenceCoverage;
        public final List<String> steps;

        private ExecutionPlan(String objective, String intent, String selectedTool,
                              boolean retrieveContext, boolean verifyOutput, String requestKind,
                              String evidenceStatus, double evidenceCoverage, List<String> steps) {
            this.objective = objective;
            this.intent = intent;
            this.selectedTool = selectedTool;
            this.retrieveContext = retrieveContext;
            this.verifyOutput = verifyOutput;
            this.requestKind = requestKind == null ? "general" : requestKind;
            this.evidenceStatus = evidenceStatus == null ? "değerlendirilmedi" : evidenceStatus;
            this.evidenceCoverage = Math.max(0.0, Math.min(1.0, evidenceCoverage));
            this.steps = Collections.unmodifiableList(new ArrayList<>(steps));
        }
    }

    public ExecutionPlan createExecutionPlan(String prompt, String effort, String intent,
                                             ToolRegistry.Selection selection) {
        String safePrompt = prompt == null ? "" : prompt.trim();
        String text = safePrompt.toLowerCase(Locale.forLanguageTag("tr-TR"));
        boolean retrieve = safePrompt.length() >= 3 && !startsWithCommand(text, "hatırla:", "hatirla:");
        boolean verify = !"Hızlı".equalsIgnoreCase(effort)
                || containsAny(text, "kod", "java", "javascript", "html", "python", "proje", "oyun", "hesapla");
        String tool = selection == null ? "" : selection.name;
        List<String> steps = new ArrayList<>();
        steps.add("İsteği sınıflandır ve hedef çıktıyı belirle: " + (intent == null ? "genel" : intent));
        if (retrieve) steps.add("Soruya uygun yerel hafıza bağlamını getir ve kaynağın doğrulama durumunu koru.");
        if (!tool.isEmpty()) steps.add("Uygun kayıtlı aracı seç: " + tool + ".");
        else steps.add("İstek için uygun bir yerel araç olup olmadığını denetle; yoksa destek sınırını belirt.");
        steps.add("Görevi bir kez çalıştır ve ara sonucu kaydet.");
        if (verify) steps.add("Çıktıyı uygun statik/biçim kontrolünden geçir; yapılmayan testi yapılmış gösterme.");
        steps.add("Sonucu, kullanılan yerel bağlamı ve doğrulanamayan noktaları raporla.");
        return new ExecutionPlan(safePrompt, intent, tool, retrieve, verify,
                "general", "değerlendirilmedi", 0.0, steps);
    }

    /** İstek profilini ve bilgi yeterliliği ölçümünü kullanarak açıklanabilir plan oluşturur. */
    public ExecutionPlan createExecutionPlan(String prompt, String effort, String intent,
                                             ToolRegistry.Selection selection,
                                             LocalIntelligenceEngine.Analysis analysis,
                                             LocalLanguageEngine.KnowledgeAssessment knowledge) {
        ExecutionPlan base = createExecutionPlan(prompt, effort, intent, selection);
        List<String> steps = new ArrayList<>(base.steps);
        String requestKind = analysis == null ? "general" : analysis.taskKind.name().toLowerCase(Locale.ROOT);
        String evidenceStatus = knowledge == null ? "değerlendirilmedi" : knowledge.statusLabel();
        double coverage = knowledge == null ? 0.0 : knowledge.termCoverage;
        steps.add(0, "İstek profili çıkarıldı: " + requestKind + "; kavramlar: "
                + (analysis == null || analysis.concepts.isEmpty() ? "belirgin kavram yok" : String.join(", ", analysis.concepts)) + ".");
        if (knowledge != null) {
            steps.add("Yerel bilgi yeterliliğini ölç: " + evidenceStatus + " (kelime eşleşmesi "
                    + Math.round(coverage * 100.0) + "%; bu oran doğruluk puanı değildir).");
        }
        if (analysis != null && analysis.requiresFreshInformation) {
            steps.add("İstek güncel bilgi gerektiriyor; Ara etkinse web kanıtlarını cevap öncesi değerlendir.");
        }
        if (analysis != null && analysis.needsClarification) {
            steps.add("İstek eksik/çok anlamlı; araç çalıştırmadan önce netleştirme sorusu sor.");
        }
        if (analysis != null) {
            steps.add("Sınıflandırma kanıtını denetle: " + analysis.knownTokenCount + "/"
                    + analysis.tokenCount + " sorgu kelimesi eğitim sözlüğüyle eşleşti.");
        }
        return new ExecutionPlan(base.objective, base.intent, base.selectedTool, base.retrieveContext,
                base.verifyOutput, requestKind, evidenceStatus, coverage, steps);
    }

    /** Eski rapor ve testler için metinsel plan API'si korunur. */
    public List<String> createPlan(String prompt, String effort) {
        String text = prompt == null ? "" : prompt.toLowerCase(Locale.forLanguageTag("tr-TR"));
        List<String> plan = new ArrayList<>();
        plan.add("İsteği ve beklenen çıktıyı sınıflandır.");
        if (containsAny(text, "hatırla", "hafıza", "hafiza", "kaydet", "önceki", "onceki")) {
            plan.add("İlgili yerel hafızayı ara ve kayıtların doğrulama durumunu koru.");
        } else if (containsAny(text, "araştır", "arastir", "güncel", "kaynak", "haber", "bugün", "karsilastir", "karşılaştır")) {
            plan.add("Yerel kayıtları kontrol et; Ara açıksa web sonuçlarını ayrıca değerlendir.");
        } else if (containsAny(text, "kod", "java", "javascript", "oyun", "uygulama", "apk", "proje", "html")) {
            plan.add("Kod/proje gereksinimlerini belirle ve mevcut yerel araçları seç.");
        } else {
            plan.add("Yerel bağlamı ve kullanılabilir araçları kontrol et.");
        }
        int extra = effortCount(effort);
        if (extra >= 2) plan.add("Alt işlemleri sırala ve uygun aracı seç.");
        if (extra >= 3 && containsAny(text, "kod", "java", "javascript", "html", "python")) {
            plan.add("Statik kontrolleri uygula; derleme yapılmadıysa bunu ayrıca belirt.");
        }
        if (extra >= 3 && containsAny(text, "araştır", "arastir", "kaynak", "güncel")) {
            plan.add("Kaynak bağlantılarını ve kanıt sınırlarını kaydet.");
        }
        if (extra >= 4) plan.add("Eksik bilgi, çelişki ve hata olasılığını denetle.");
        plan.add("Yanıtı doğrulama düzeyi ve kalan eksiklerle sun.");
        return plan;
    }

    private int effortCount(String effort) {
        if ("Hızlı".equalsIgnoreCase(effort)) return 1;
        if ("Orta".equalsIgnoreCase(effort)) return 2;
        if ("Maksimum".equalsIgnoreCase(effort)) return 3;
        return 4;
    }

    private boolean startsWithCommand(String text, String... prefixes) {
        for (String prefix : prefixes) if (text.startsWith(prefix)) return true;
        return false;
    }

    private boolean containsAny(String text, String... needles) {
        for (String needle : needles) if (text.contains(needle)) return true;
        return false;
    }
}
