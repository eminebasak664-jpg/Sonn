package com.jai.assistant.tools;

/**
 * Dosya/arşiv işlemleri için sabit dosya boyutu kotaları yerine anlık Android uygulama heap'ine
 * göre hesaplanan tampon bütçesi. Değerler her çağrıda yeniden hesaplanır; RAM rezerve etmez.
 */
public final class ResourceAwareBudget {
    private ResourceAwareBudget() { }

    /** Tek seferde bellekte tutulacak tampon için yaklaşık güvenli üst sınır. */
    public static long currentSafeBufferBytes() {
        Runtime runtime = Runtime.getRuntime();
        long maxHeap = runtime.maxMemory();
        long usedHeap = runtime.totalMemory() - runtime.freeMemory();
        long freeHeap = Math.max(0L, maxHeap - usedHeap);
        // Hem toplam uygulama heap'inin hem de şu anda boş olan kısmın bir bölümünü kullan.
        long heapShare = maxHeap / 2L;
        long freeShare = freeHeap / 3L;
        return Math.max(0L, Math.min(heapShare, freeShare));
    }

    /** Aynı anda bellekte tutulan iç içe ZIP katmanları için dinamik heap bütçesi. */
    public static long currentSafeExpansionBytes() {
        return currentSafeBufferBytes();
    }

    /** StringBuilder/mesaj birleştirmesi için yaklaşık UTF-16 karakter bütçesi. */
    public static int currentSafeTextCharacters() {
        long chars = currentSafeBufferBytes() / 2L;
        return (int) Math.min((long) Integer.MAX_VALUE - 8L, chars);
    }

    public static int currentSafeArrayBytes() {
        // ByteArrayOutputStream.toByteArray(), metin çözme ve rapor üretimi sırasında kopyalar oluşur.
        // Her tekil girdi için toplam boş heap'in küçük bir bölümünü ayır.
        return (int) Math.min((long) Integer.MAX_VALUE - 8L, currentSafeBufferBytes() / 6L);
    }
}
