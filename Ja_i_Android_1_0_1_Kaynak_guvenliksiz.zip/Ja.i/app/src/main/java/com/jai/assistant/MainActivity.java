package com.jai.assistant;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.view.WindowInsets;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;

import com.jai.assistant.data.ChatMessage;
import com.jai.assistant.data.ConversationManager;
import com.jai.assistant.data.MemoryDatabase;
import com.jai.assistant.data.SettingsManager;
import com.jai.assistant.engine.BrainEngine;
import com.jai.assistant.engine.LearningEngine;
import com.jai.assistant.engine.DurableTaskManager;
import com.jai.assistant.engine.CodeGenerator;
import com.jai.assistant.engine.CodeLabEngine;
import com.jai.assistant.engine.JavaScriptSandbox;
import com.jai.assistant.engine.ProjectArchiveWriter;
import com.jai.assistant.engine.MinecraftPackGenerator;
import com.jai.assistant.engine.VisualLearningEngine;
import com.jai.assistant.messaging.MessagingClient;
import com.jai.assistant.messaging.MessagingSessionStore;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import com.jai.assistant.tools.FileManager;
import com.jai.assistant.tools.ResourceAwareBudget;
import com.jai.assistant.tools.WebResearchEngine;
import com.jai.assistant.tools.WebImageResearchEngine;
import com.jai.assistant.tools.ResearchReport;
import com.jai.assistant.server.ServerConfig;
import com.jai.assistant.server.ServerSettingsManager;
import com.jai.assistant.server.ServerConnectionManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;

/** Android yerel sohbet arayüzü. Ağ işlemleri ana UI iş parçacığında yapılmaz. */
public final class MainActivity extends Activity {
    private static final int REQUEST_OPEN_TEXT_FILE = 4101;
    private static final int REQUEST_EXPORT_CHAT = 4102;
    private static final int REQUEST_EXPORT_CODE = 4103;
    private static final int REQUEST_EXPORT_PROJECT = 4104;
    private static final int REQUEST_IMPORT_VISUAL_EXAMPLE = 4105;
    private static final int REQUEST_IMPORT_LANGUAGE_MODEL = 4106;
    private static final int MAX_RENDERED_MESSAGES = 250;

    private MemoryDatabase database;
    private ConversationManager conversations;
    private SettingsManager settings;
    private BrainEngine brain;
    private WebResearchEngine webResearch;
    private WebImageResearchEngine webImageResearch;
    private LearningEngine learningEngine;
    private VisualLearningEngine visualLearning;
    private String pendingVisualLabel;
    private FileManager fileManager;
    private ServerSettingsManager serverSettings;
    private ServerConnectionManager serverConnection;
    private DurableTaskManager durableTasks;
    private MessagingSessionStore messagingSession;
    private ExecutorService serverExecutor;
    private ExecutorService worker;

    private TextView subtitleText;
    private TextView statusText;
    private LinearLayout chatContainer;
    private ScrollView chatScroll;
    private EditText messageInput;
    private Button sendButton;
    private Spinner modeSpinner;
    private Spinner effortSpinner;
    private CheckBox webCheckBox;
    private Button serverButton;
    private Button codeLabButton;
    private Button messagesButton;
    private Button processingSettingsButton;
    private ProgressBar processingProgress;
    private volatile String serverStatus = "Sunucu ayarlanmadı";
    private final AtomicBoolean serverRequestInFlight = new AtomicBoolean(false);

    private String attachedText;
    private String attachedName;
    private volatile boolean attachmentReadInProgress;
    private String pendingCodeExport;
    private volatile byte[] pendingProjectExport;
    private volatile File pendingProjectExportFile;
    private volatile boolean activityDestroyed;
    private volatile boolean backgroundTaskRunning;
    private final AtomicBoolean databaseClosed = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configureSystemBarInsets();

        database = new MemoryDatabase(this);
        conversations = new ConversationManager(database);
        settings = new SettingsManager(this);
        fileManager = new FileManager();
        webResearch = new WebResearchEngine();
        webImageResearch = new WebImageResearchEngine();
        learningEngine = new LearningEngine(database);
        File visualModelFile = new File(getFilesDir(), "visual-model-jaiv.bin");
        if (!visualModelFile.exists()) {
            try (InputStream input = getAssets().open("visual-model-jaiv.bin");
                 FileOutputStream output = new FileOutputStream(visualModelFile)) {
                byte[] buffer = new byte[4096];
                int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                output.flush();
            } catch (IOException seedModelError) {
                android.util.Log.w("Ja.i", "Başlangıç görsel ağırlığı kopyalanamadı; ağ kullanıcı örnekleriyle eğitilebilir.", seedModelError);
            }
        }
        visualLearning = new VisualLearningEngine(visualModelFile);
        visualLearning.load();
        brain = new BrainEngine(this, database, fileManager, visualLearning);
        serverSettings = new ServerSettingsManager(this);
        serverConnection = new ServerConnectionManager();
        durableTasks = new DurableTaskManager(this, database);
        messagingSession = new MessagingSessionStore(this);
        serverExecutor = Executors.newSingleThreadExecutor();
        worker = Executors.newSingleThreadExecutor();
        // Önceden içe aktarılmış sohbet modelini ve görsel örneğini UI iş parçacığını kilitlemeden yükle.
        worker.execute(() -> brain.initializeLanguageModel());
        worker.execute(this::seedBundledVisualExample);

        bindViews();
        configureSpinners();
        restoreSettings();
        configureActions();

        if (database.countMessages() == 0) {
            conversations.add("assistant", "Merhaba, ben Ja.i. Yerel hafıza, dosya araçları, isteğe bağlı web araştırması, kod/proje üretimi, piksel tabanlı görsel ve video taslağı, Minecraft Bedrock paketleri ve güvenli mesajlaşma araçlarım var. Serbest sohbet için Ja.i'nin kendi dil modelini Colab'da sıfırdan eğitip 'Zekâ ayarı' bölümünden içe aktarabilirsin. Model yüklenmediyse bunu açıkça söylerim; haricî sohbet API'si kullanmam.");
        }
        reloadChat();
        updateConnectionLabel();
        wakeServerOnceOnLaunch();
    }

    /** Android 15/16 edge-to-edge davranışında içerik sistem çubuklarının altında kalmaz. */
    private void configureSystemBarInsets() {
        if (Build.VERSION.SDK_INT < 26) return;
        android.view.View root = findViewById(R.id.rootLayout);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        } else {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
                return insets.consumeSystemWindowInsets();
            });
        }
        root.requestApplyInsets();
    }

    private void seedBundledVisualExample() {
        final String label = "altın ağ küresi amblemi";
        if (visualLearning == null || visualLearning.hasReferenceImage(label)) return;
        try (InputStream input = getAssets().open("visual_examples/altin-ag-kuresi-amblemi.png")) {
            android.graphics.Bitmap bitmap = BitmapFactory.decodeStream(input);
            if (bitmap == null) return;
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            int[] pixels = new int[width * height];
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
            bitmap.recycle();
            String training = visualLearning.trainFromImage(label, width, height, pixels, 1);
            android.util.Log.i("Ja.i", "Başlangıç görsel örneği eğitildi: " + training);
        } catch (IOException error) {
            android.util.Log.w("Ja.i", "Başlangıç görsel örneği yüklenemedi; kullanıcı yeni örnek ekleyebilir.", error);
        }
    }

    private void bindViews() {
        subtitleText = findViewById(R.id.subtitleText);
        statusText = findViewById(R.id.statusText);
        chatContainer = findViewById(R.id.chatContainer);
        chatScroll = findViewById(R.id.chatScroll);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);
        modeSpinner = findViewById(R.id.modeSpinner);
        effortSpinner = findViewById(R.id.effortSpinner);
        webCheckBox = findViewById(R.id.webCheckBox);
        serverButton = findViewById(R.id.serverButton);
        codeLabButton = findViewById(R.id.codeLabButton);
        messagesButton = findViewById(R.id.messagesButton);
        processingSettingsButton = findViewById(R.id.processingSettingsButton);
        processingProgress = findViewById(R.id.processingProgress);
    }

    private void configureSpinners() {
        ArrayAdapter<String> modeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[]{"Flash", "Think"});
        modeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        modeSpinner.setAdapter(modeAdapter);

        ArrayAdapter<String> effortAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[]{"Hızlı", "Orta", "Maksimum", "Derin"});
        effortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        effortSpinner.setAdapter(effortAdapter);
    }

    private void restoreSettings() {
        setSpinnerSelection(modeSpinner, settings.getMode());
        setSpinnerSelection(effortSpinner, settings.getEffort());
        webCheckBox.setChecked(settings.isWebResearchEnabled());
    }

    private void setSpinnerSelection(Spinner spinner, String wanted) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (String.valueOf(spinner.getItemAtPosition(i)).equals(wanted)) {
                spinner.setSelection(i);
                return;
            }
        }
    }

    private void configureActions() {
        sendButton.setOnClickListener(view -> submitMessage());
        findViewById(R.id.attachButton).setOnClickListener(view -> openTextPicker());
        findViewById(R.id.exportButton).setOnClickListener(view -> exportChat());
        serverButton.setOnClickListener(view -> showServerSettings());
        codeLabButton.setOnClickListener(view -> showCodeLabDialog());
        messagesButton.setOnClickListener(view -> showMessagingDialog());
        processingSettingsButton.setOnClickListener(view -> showProcessingSettings());

        modeSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(value -> settings.setMode(value)));
        effortSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(value -> settings.setEffort(value)));
        webCheckBox.setOnCheckedChangeListener((buttonView, checked) -> {
            settings.setWebResearchEnabled(checked);
            statusText.setText(checked
                    ? "Ara açık: web isteği yalnızca mesaj gönderdiğinde ve uygunsa yapılır."
                    : "Ara kapalı: web araştırması başlatılmaz.");
        });

        messageInput.setOnEditorActionListener((view, actionId, event) -> {
            boolean send = actionId == EditorInfo.IME_ACTION_SEND
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP);
            if (send) {
                submitMessage();
                return true;
            }
            return false;
        });
    }

    private void submitMessage() {
        String typed = messageInput.getText().toString().trim();
        if (attachmentReadInProgress) {
            Toast.makeText(this, "Dosya analizi sürüyor; bitince tekrar Gönder'e bas.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (typed.isEmpty() && TextUtils.isEmpty(attachedText)) {
            Toast.makeText(this, "Önce bir mesaj yaz veya dosya ekle.", Toast.LENGTH_SHORT).show();
            return;
        }

        String query = typed;
        if (!TextUtils.isEmpty(attachedText)) {
            String attachmentBlock = "\n\n[Metin eki: " + attachedName + "]\n" + attachedText;
            query = query + attachmentBlock;
        }
        messageInput.setText("");
        attachedText = null;
        attachedName = null;
        hideKeyboard();

        conversations.add("user", query);
        reloadChat();
        sendButton.setEnabled(false);
        String selectedMode = String.valueOf(modeSpinner.getSelectedItem());
        String selectedEffort = String.valueOf(effortSpinner.getSelectedItem());
        boolean webEnabled = webCheckBox.isChecked();
        statusText.setText("İşlem başlatılıyor…");
        processingProgress.setVisibility(android.view.View.VISIBLE);
        processingProgress.setProgress(5);

        final String finalQuery = query;
        final boolean explicitLearningRequest = isLearningRequest(typed);
        final boolean artifactGenerationRequest = new CodeGenerator(visualLearning, this).isArtifactRequest(typed);
        final String researchQuery = explicitLearningRequest ? extractLearningTopic(typed) : buildResearchQuery(typed);
        final boolean researchNeeded = webEnabled && !explicitLearningRequest
                && (brain.shouldResearch(typed) || artifactGenerationRequest);
        backgroundTaskRunning = true;
        try {
            worker.execute(() -> {
                String answer;
                boolean networkAvailable = false;
                int savedResearchCount = 0;
                String imageResearchStatus = "";
                ResearchReport researchReport = null;
                String researchContext = "";
                String researchFailure = "";
                try {
                    // Ara açıksa kaynakları yanıt üretiminden ÖNCE topla ve Think bağlamına ver.
                    if (researchNeeded) {
                        updateProgressFromWorker(8, "Web araştırması hazırlanıyor");
                        networkAvailable = isNetworkAvailable();
                        if (networkAvailable) {
                            try {
                                boolean imageTask = new com.jai.assistant.engine.ProceduralImageGenerator().isImageRequest(finalQuery);
                                if (imageTask) {
                                    updateProgressFromWorker(13, "Nesnenin web görsel örnekleri aranıyor ve indiriliyor");
                                    imageResearchStatus = learnVisualReferences(finalQuery);
                                    researchContext = "[JA.I WEB GÖRSEL ÖRNEKLERİ]\n" + imageResearchStatus;
                                } else {
                                    updateProgressFromWorker(13, "Web kaynakları aranıyor ve okunuyor");
                                    researchReport = webResearch.researchAdaptive(researchQuery, selectedEffort);
                                    savedResearchCount = learningEngine.rememberResearch(researchReport);
                                    researchContext = "[JA.I WEB ARAŞTIRMA BAĞLAMI]\n" + researchReport.toDisplayText();
                                }
                                updateProgressFromWorker(17, "Web kanıtları Think/Flash bağlamına eklendi");
                            } catch (Exception researchException) {
                                researchFailure = safeMessage(researchException);
                                researchReport = null;
                                researchContext = "";
                            }
                        }
                    }

                    answer = brain.answer(finalQuery, selectedMode, selectedEffort,
                            settings.isAutoStageMode(), settings.getManualStageCount(),
                            (completedStages, totalStages, stageLabel) -> {
                                int progress = 18 + (int) (52f * completedStages / Math.max(1, totalStages));
                                updateProgressFromWorker(progress, stageLabel + " · " + completedStages + "/" + totalStages);
                            }, researchContext);
                    updateProgressFromWorker(76, "Yerel yanıt ve kaynak bağlamı işlendi");

                    if (explicitLearningRequest && webEnabled && !researchQuery.isEmpty()) {
                        long taskId = database.getLatestTaskId(researchQuery, "öğrenme");
                        boolean queued = taskId > 0 && durableTasks.scheduleExistingTask(taskId);
                        answer += queued
                                ? "\n\nKalıcı görev #" + taskId + " Android görev kuyruğuna alındı. İnternet bulunduğunda kaynakları araştırıp adım adım yerel hafızaya kaydedecek; uygulama kapansa da kuyruk korunur. Android güç yönetimi başlama zamanını geciktirebilir."
                                : "\n\nKalıcı görev kuyruğa alınamadı; görev yalnızca yerel kayıtta kalmış olabilir.";
                    }
                    if (startsCommand(finalQuery, "görev devam:", "gorev devam:")) {
                        long resumeId = trailingId(finalQuery);
                        // Think görevleri BrainEngine tarafından SQLite kontrol noktasından devam ettirildi.
                        // Sadece öğrenme/web kuyruğu görevleri WorkManager'a verilir.
                        if (!brain.isPersistentBrainTask(resumeId)) {
                            if (webEnabled && resumeId > 0 && durableTasks.scheduleExistingTask(resumeId)) {
                                answer += "\n\nGörev #" + resumeId + " kalıcı arka plan kuyruğuna tekrar alındı.";
                            } else if (!webEnabled) {
                                answer += "\n\nGörevi internet araştırmasıyla sürdürmek için Ara'yı açıp tekrar 'görev devam: " + resumeId + "' yaz.";
                            }
                        }
                    } else if (startsCommand(finalQuery, "görev duraklat:", "gorev duraklat:")) {
                        long pauseId = trailingId(finalQuery);
                        if (pauseId > 0) durableTasks.pause(pauseId);
                    }

                    if (researchNeeded) {
                        if (!imageResearchStatus.isEmpty()) {
                            answer += "\n\nGörsel araştırması: " + imageResearchStatus;
                            if (visualLearning != null && visualLearning.canGenerate(finalQuery)) {
                                answer += " Ja.i bu nesne için yerel görsel örneklerini artık kullanabilir.";
                            }
                        } else if (researchReport != null) {
                            answer += "\n\nWeb araştırması tamamlandı: " + researchReport.getSources().size()
                                    + " kaynak, " + researchReport.getReadPageCount() + " okunabilen sayfa, "
                                    + researchReport.getDistinctDomainCount() + " farklı alan adı.";
                            if (savedResearchCount > 0) {
                                answer += " " + savedResearchCount + " metin kaynak notu yerel hafızaya kaydedildi; bu işlem genel dil modelini eğitmez.";
                            } else {
                                answer += " Yeni metin kaynak notu yerel hafızaya kaydedilemedi.";
                            }
                        } else if (!networkAvailable) {
                            answer += "\n\nAra açık ancak bu cihazda kullanılabilir internet bağlantısı görünmüyor. Web araştırması yapılmadı; yerel yanıt kullanıldı.";
                        } else {
                            answer += "\n\nWeb araştırması tamamlanamadı: " + researchFailure
                                    + ". Yerel yanıt üretimi yine de tamamlandı.";
                        }
                    }
                } catch (Exception exception) {
                    answer = "İşlem sırasında hata oluştu: " + safeMessage(exception)
                            + "\n\nMesajın tamamı Ja.i tarafından başarıyla işlenmiş sayılmaz.";
                }

                updateProgressFromWorker(96, "Yanıt ve sohbet kaydı tamamlanıyor");
                try {
                    conversations.add("assistant", answer);
                } catch (Exception persistenceException) {
                    answer += "\n\nUyarı: Yanıt sohbet veritabanına kaydedilemedi ("
                            + safeMessage(persistenceException) + ").";
                } finally {
                    backgroundTaskRunning = false;
                    if (activityDestroyed) closeDatabaseIfNeeded();
                }

                if (!activityDestroyed) {
                    final boolean finalNetworkAvailable = networkAvailable;
                    final int finalSavedResearchCount = savedResearchCount;
                    runOnUiThread(() -> {
                        if (activityDestroyed) return;
                        reloadChat();
                        processingProgress.setProgress(100);
                        sendButton.setEnabled(true);
                        updateConnectionLabel();
                        if (explicitLearningRequest && webEnabled) {
                            statusText.setText("Öğrenme görevi kalıcı arka plan kuyruğunda");
                        } else if (researchNeeded) {
                            statusText.setText(finalNetworkAvailable
                                    ? (finalSavedResearchCount > 0
                                        ? "Araştırma tamamlandı · " + finalSavedResearchCount + " kaynak yerel hafızaya kaydedildi"
                                        : "Araştırma denendi · kaydedilebilir kaynak bulunamadı")
                                    : "İşlem tamamlandı · çevrimdışı");
                        } else {
                            statusText.setText("İşlem tamamlandı · yerel yanıt");
                        }
                    });
                }
            });
        } catch (RejectedExecutionException exception) {
            backgroundTaskRunning = false;
            sendButton.setEnabled(true);
            statusText.setText("Görev kuyruğu kapalı olduğu için mesaj başlatılamadı.");
        }
    }

    /** Ara açıkken bulunan gerçek web görsellerini sınırlı boyutta indirip yerel piksel ağına öğretir. */
    private String learnVisualReferences(String prompt) {
        if (webImageResearch == null || visualLearning == null) return "Görsel öğrenme motoru hazır değil.";
        String label = new com.jai.assistant.engine.ProceduralImageGenerator().learningLabelForPrompt(prompt);
        if (label == null || label.trim().length() < 2 || "özel nesne".equalsIgnoreCase(label.trim()))
            return "İstekten belirli bir nesne etiketi çıkarılamadı; genel görsel araması yapılmadı.";
        WebImageResearchEngine.Result result = webImageResearch.searchAndDownload(label + " real photo", 4);
        int learned = 0;
        List<String> sources = new ArrayList<>();
        for (WebImageResearchEngine.DownloadedImage reference : result.images) {
            android.graphics.Bitmap bitmap = null;
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(reference.bytes, 0, reference.bytes.length, bounds);
                if (bounds.outWidth < 8 || bounds.outHeight < 8) continue;
                int sample = 1;
                while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > 256) sample *= 2;
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = Math.max(1, sample);
                options.inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888;
                bitmap = BitmapFactory.decodeByteArray(reference.bytes, 0, reference.bytes.length, options);
                if (bitmap == null || bitmap.getWidth() < 8 || bitmap.getHeight() < 8
                        || (long) bitmap.getWidth() * bitmap.getHeight() > 65536L) continue;
                int width = bitmap.getWidth(), height = bitmap.getHeight();
                int[] pixels = new int[width * height];
                bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
                String training = visualLearning.trainFromImage(label, width, height, pixels, 1);
                learned++;
                if (!reference.title.isEmpty()) sources.add(reference.title
                        + (reference.sourceUrl == null || reference.sourceUrl.isEmpty() ? "" : " (" + reference.sourceUrl + ")"));
                android.util.Log.i("Ja.i", "Web görsel örneği yerel ağa öğretildi: " + training);
            } catch (Exception trainingError) {
                android.util.Log.w("Ja.i", "Web görsel örneği işlenemedi.", trainingError);
            } finally {
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        }
        if (learned == 0) return result.note + " Bu nesne için yeni eğitim örneği eklenmedi.";
        return learned + " gerçek görsel örneği '" + label + "' etiketiyle yerel belleğe ve piksel ağına eklendi. "
                + "Başlık örnekleri: " + String.join("; ", sources)
                + ". Kaynak görsellerin ham dosyaları saklanmadı; en fazla 256×256 piksel örnekleri cihazda tutuldu. "
                + "Bu, genel nesne tanıma modeli değil; etiketli görsel örüntüsü öğrenmesidir.";
    }

    private void updateProgressFromWorker(int progress, String label) {
        if (activityDestroyed) return;
        runOnUiThread(() -> {
            if (activityDestroyed || processingProgress == null) return;
            processingProgress.setVisibility(android.view.View.VISIBLE);
            processingProgress.setProgress(Math.max(0, Math.min(100, progress)));
            statusText.setText(label);
        });
    }

    private void showProcessingSettings() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (18 * getResources().getDisplayMetrics().density);
        content.setPadding(pad, pad, pad, pad);

        TextView intro = new TextView(this);
        intro.setText("Think modunun gerçek yerel işlem aşamalarını ayarla. Ayrıca Colab'da Ja.i için sıfırdan eğitilmiş sohbet modelini buradan içe aktarabilirsin. Model dosyası cihazda kalır ve çevrimdışı çalışır.");
        intro.setTextColor(getResources().getColor(R.color.jai_text));
        content.addView(intro);

        RadioGroup modeGroup = new RadioGroup(this);
        modeGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton automatic = new RadioButton(this);
        automatic.setId(android.view.View.generateViewId());
        automatic.setText("Akıllı (otomatik sayı)");
        automatic.setTextColor(getResources().getColor(R.color.jai_text));
        RadioButton manual = new RadioButton(this);
        manual.setId(android.view.View.generateViewId());
        manual.setText("Manuel aşama sayısı");
        manual.setTextColor(getResources().getColor(R.color.jai_text));
        modeGroup.addView(automatic);
        modeGroup.addView(manual);
        modeGroup.check(settings.isAutoStageMode() ? automatic.getId() : manual.getId());
        content.addView(modeGroup);

        EditText countInput = new EditText(this);
        countInput.setSingleLine(true);
        countInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        countInput.setHint("1–115 (ör. 8 veya 115)");
        countInput.setText(String.valueOf(settings.getManualStageCount()));
        countInput.setTextColor(getResources().getColor(R.color.jai_text));
        countInput.setHintTextColor(getResources().getColor(R.color.jai_muted));
        content.addView(countInput);

        TextView limitNote = new TextView(this);
        limitNote.setText("Manuel değer 1–115 arasındadır. 1 yalnızca görevi çalıştırır; daha yüksek değerler analiz, bağlam ve plan adımlarını ekler. Bağımsız aşamalar bittiğinde motor tekrar üretmeden durur.");
        limitNote.setTextColor(getResources().getColor(R.color.jai_muted));
        limitNote.setTextSize(12);
        content.addView(limitNote);

        TextView availabilityNote = new TextView(this);
        availabilityNote.setText("Sohbet modeli durumu: " + brain.getLanguageModelStatus()
                + "\nThink aşaması görev akışını düzenler; modelin eğitimini veya kalitesini tek başına değiştirmez.");
        availabilityNote.setTextColor(getResources().getColor(R.color.jai_turquoise));
        availabilityNote.setTextSize(12);
        availabilityNote.setPadding(0, pad / 2, 0, 0);
        content.addView(availabilityNote);

        modeGroup.setOnCheckedChangeListener((group, checkedId) -> {
            countInput.setEnabled(checkedId == manual.getId());
            countInput.setAlpha(checkedId == manual.getId() ? 1.0f : 0.55f);
        });
        countInput.setEnabled(!settings.isAutoStageMode());
        countInput.setAlpha(settings.isAutoStageMode() ? 0.55f : 1.0f);

        new AlertDialog.Builder(this)
                .setTitle("Ja.i · Zekâ işleme ayarları")
                .setView(content)
                .setNeutralButton("Colab modelini yükle", (dialog, which) -> openLanguageModelPicker())
                .setNegativeButton("Vazgeç", null)
                .setPositiveButton("Kaydet", (dialog, which) -> {
                    boolean auto = modeGroup.getCheckedRadioButtonId() == automatic.getId();
                    int count;
                    try {
                        count = Integer.parseInt(countInput.getText().toString().trim());
                    } catch (NumberFormatException exception) {
                        Toast.makeText(this, "1 ile 115 arasında bir sayı gir.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (count < 1 || count > 115) {
                        Toast.makeText(this, "Aşama sayısı 1 ile 115 arasında olmalı.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    settings.setAutoStageMode(auto);
                    settings.setManualStageCount(count);
                    Toast.makeText(this, auto
                            ? "Akıllı aşama modu kaydedildi."
                            : "Manuel aşama sayısı kaydedildi: " + count, Toast.LENGTH_LONG).show();
                })
                .show();
    }

    private boolean isLearningRequest(String text) {
        if (text == null) return false;
        String lower = text.trim().toLowerCase(java.util.Locale.forLanguageTag("tr-TR"));
        return lower.startsWith("öğren:") || lower.startsWith("ogren:")
                || lower.startsWith("öğren ") || lower.startsWith("ogren ");
    }

    private String extractLearningTopic(String text) {
        if (text == null) return "";
        return text.trim().replaceFirst("(?i)^(öğren|ogren)\\s*:?\\s*", "").trim();
    }

    /** Ara açıkken üretim isteklerini doğru teknik/biçim referanslarıyla genişletir. */
    private String buildResearchQuery(String prompt) {
        String base = prompt == null ? "" : prompt.trim();
        if (new MinecraftPackGenerator().isMinecraftPackRequest(base)) {
            return base + " Minecraft Bedrock 1.21.132.1 official creator documentation manifest resource pack behavior pack entity geometry animation controller script API item components recipes loot tables compatibility validation";
        }
        if (com.jai.assistant.media.AndroidVideoGenerator.isVideoRequest(base)) {
            return base + " visual reference details scene composition storyboard camera movement materials lighting color palette animation timing adaptive MP4 rendering";
        }
        if (new com.jai.assistant.engine.ProceduralImageGenerator().isImageRequest(base)) {
            return base + " visual reference object anatomy parts proportions materials surface details shape lighting palette composition illustration";
        }
        return base;
    }

    private void openLanguageModelPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        startActivityForResult(intent, REQUEST_IMPORT_LANGUAGE_MODEL);
    }

    private void openTextPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, REQUEST_OPEN_TEXT_FILE);
    }

    private void exportChat() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "ja-i-sohbet.txt");
        startActivityForResult(intent, REQUEST_EXPORT_CHAT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) {
            if (requestCode == REQUEST_EXPORT_PROJECT) {
                pendingProjectExport = null;
                pendingProjectExportFile = null;
            }
            if (requestCode == REQUEST_EXPORT_CODE) pendingCodeExport = null;
            if (requestCode == REQUEST_IMPORT_VISUAL_EXAMPLE) pendingVisualLabel = null;
            return;
        }

        if (requestCode == REQUEST_OPEN_TEXT_FILE) {
            List<Uri> selectedUris = new ArrayList<>();
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) {
                    Uri selected = clip.getItemAt(i).getUri();
                    if (selected != null) selectedUris.add(selected);
                }
            } else if (data.getData() != null) {
                selectedUris.add(data.getData());
            }
            if (!selectedUris.isEmpty()) analyzeAttachmentsAsync(selectedUris);
            return;
        }

        if (requestCode == REQUEST_IMPORT_LANGUAGE_MODEL && data.getData() != null) {
            Uri modelPackageUri = data.getData();
            statusText.setText("Colab modeli güvenli biçimde içe aktarılıyor…");
            try {
                worker.execute(() -> {
                    String result;
                    try (InputStream input = getContentResolver().openInputStream(modelPackageUri)) {
                        if (input == null) throw new IOException("Seçilen ZIP dosyası okunamadı.");
                        result = brain.importLanguageModel(input);
                    } catch (Exception error) {
                        result = "Model içe aktarılamadı: " + safeMessage(error);
                    }
                    final String finalResult = result;
                    if (!activityDestroyed) runOnUiThread(() -> {
                        if (activityDestroyed) return;
                        statusText.setText(brain.getLanguageModelStatus());
                        Toast.makeText(this, finalResult, Toast.LENGTH_LONG).show();
                    });
                });
            } catch (RejectedExecutionException error) {
                statusText.setText("Model içe aktarma kuyruğu kapalı.");
                Toast.makeText(this, "Model yükleme başlatılamadı.", Toast.LENGTH_LONG).show();
            }
            return;
        }

        Uri uri = data.getData();
        if (requestCode == REQUEST_IMPORT_VISUAL_EXAMPLE && uri != null) {
            final String label = pendingVisualLabel == null ? "" : pendingVisualLabel;
            pendingVisualLabel = null;
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("Görsel dosyası açılamadı.");
                    BitmapFactory.decodeStream(in, null, bounds);
                }
                if (bounds.outWidth < 8 || bounds.outHeight < 8) throw new IOException("Seçilen dosya geçerli bir görsel değil.");
                int sample = 1;
                while (bounds.outWidth / sample > 256 || bounds.outHeight / sample > 256) sample *= 2;
                BitmapFactory.Options decode = new BitmapFactory.Options();
                decode.inSampleSize = sample;
                Bitmap bitmap;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("Görsel dosyası yeniden açılamadı.");
                    bitmap = BitmapFactory.decodeStream(in, null, decode);
                }
                if (bitmap == null) throw new IOException("Görsel belleğe alınamadı.");
                Bitmap scaled = Bitmap.createScaledBitmap(bitmap, Math.min(256, bitmap.getWidth()), Math.min(256, bitmap.getHeight()), true);
                if (scaled != bitmap) bitmap.recycle();
                int width = scaled.getWidth(), height = scaled.getHeight();
                int[] pixels = new int[width * height];
                scaled.getPixels(pixels, 0, width, 0, 0, width, height);
                scaled.recycle();
                worker.execute(() -> {
                    try {
                        String report = visualLearning.trainFromImage(label, width, height, pixels, 18);
                        runOnUiThread(() -> Toast.makeText(this, report, Toast.LENGTH_LONG).show());
                    } catch (Exception ex) {
                        runOnUiThread(() -> Toast.makeText(this, "Görsel eğitimi başarısız: " + safeMessage(ex), Toast.LENGTH_LONG).show());
                    }
                });
                Toast.makeText(this, "Örnek alındı; Ja.i yerel sinir ağı eğitiliyor…", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(this, "Örnek görsel okunamadı: " + safeMessage(ex), Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode == REQUEST_EXPORT_CHAT && uri != null) {
            try {
                fileManager.writeText(getContentResolver(), uri, conversations.exportPlainText());
                Toast.makeText(this, "Sohbet seçtiğin konuma aktarıldı.", Toast.LENGTH_LONG).show();
            } catch (IOException exception) {
                Toast.makeText(this, "Dışa aktarma başarısız: " + exception.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_EXPORT_CODE && uri != null && pendingCodeExport != null) {
            try {
                fileManager.writeText(getContentResolver(), uri, pendingCodeExport);
                Toast.makeText(this, "Kod dosyası kaydedildi.", Toast.LENGTH_LONG).show();
            } catch (IOException exception) {
                Toast.makeText(this, "Kod kaydedilemedi: " + safeMessage(exception), Toast.LENGTH_LONG).show();
            } finally { pendingCodeExport = null; }
        } else if (requestCode == REQUEST_EXPORT_PROJECT && uri != null
                && (pendingProjectExport != null || pendingProjectExportFile != null)) {
            final File sourceFile = pendingProjectExportFile;
            final byte[] sourceBytes = pendingProjectExport;
            final android.content.ContentResolver exportResolver = getContentResolver();
            final FileManager exportManager = fileManager;
            pendingProjectExport = null;
            pendingProjectExportFile = null;
            try {
                worker.execute(() -> {
                    String message;
                    try {
                        if (sourceFile != null) {
                            exportManager.writeFile(exportResolver, uri, sourceFile);
                        } else if (sourceBytes != null) {
                            exportManager.writeBytes(exportResolver, uri, sourceBytes);
                        } else {
                            throw new IOException("Dışa aktarılacak çıktı artık bulunamıyor.");
                        }
                        message = "Üretilen dosya kaydedildi.";
                    } catch (Exception exception) {
                        message = "Dosya kaydedilemedi: " + safeMessage(exception);
                    }
                    final String resultMessage = message;
                    if (!activityDestroyed) runOnUiThread(() ->
                            Toast.makeText(this, resultMessage, Toast.LENGTH_LONG).show());
                });
            } catch (RejectedExecutionException exception) {
                Toast.makeText(this, "Dosya aktarım kuyruğu şu anda dolu.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void analyzeAttachmentsAsync(List<Uri> uris) {
        attachmentReadInProgress = true;
        statusText.setText("Dosyalar arka planda analiz ediliyor…");
        try {
            worker.execute(() -> {
                StringBuilder combined = new StringBuilder();
                StringBuilder names = new StringBuilder();
                int success = 0;
                for (Uri uri : uris) {
                    try {
                        String name = fileManager.getDisplayName(this, uri);
                        String content = fileManager.readAttachment(this, uri);
                        String header = "\n\n[Dosya eki: " + name + "]\n";
                        int remainingChars = Math.max(0, ResourceAwareBudget.currentSafeTextCharacters() - combined.length() - header.length());
                        if (content.length() > remainingChars) {
                            if (remainingChars > 0) {
                                combined.append(header).append(content, 0, remainingChars);
                                combined.append("\n[Bu dosyanın devamı, telefonun o anki boş uygulama belleği nedeniyle aynı mesaj bağlamına eklenemedi. Sabit 8 milyon karakter kotası kullanılmıyor.]\n");
                            } else {
                                combined.append("\n\n[Dosya analiz edildi ancak mevcut boş RAM, içeriği sohbet bağlamına kopyalamaya yetmedi: ")
                                        .append(name).append("]\n");
                            }
                        } else {
                            combined.append(header).append(content);
                        }
                        if (names.length() > 0) names.append(", ");
                        names.append(name);
                        success++;
                    } catch (Exception exception) {
                        combined.append("\n\n[Dosya analizi başarısız: ").append(fileManager.getDisplayName(this, uri))
                                .append("] ").append(safeMessage(exception));
                    }
                }
                final String result = combined.toString().trim();
                final String resultNames = names.toString();
                final int count = success;
                attachedText = result.isEmpty() ? null : result;
                attachedName = resultNames;
                attachmentReadInProgress = false;
                if (!activityDestroyed) runOnUiThread(() -> {
                    if (activityDestroyed) return;
                    statusText.setText(count + " dosya incelendi. Metin, ZIP/JAR/MCPACK paketleri, PDF ve fotoğraf içerikleri hazır.");
                    Toast.makeText(this, count + " dosya işlendi.", Toast.LENGTH_LONG).show();
                });
            });
        } catch (RejectedExecutionException ex) {
            attachmentReadInProgress = false;
            statusText.setText("Dosya analiz kuyruğu kapalı.");
        }
    }

    private void reloadChat() {
        chatContainer.removeAllViews();
        List<ChatMessage> messages = conversations.recent(MAX_RENDERED_MESSAGES);
        for (ChatMessage message : messages) addMessageBubble(message.role, message.content);
        chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void addMessageBubble(String role, String content) {
        boolean user = "user".equals(role);
        TextView bubble = new TextView(this);
        bubble.setText(content);
        bubble.setTextColor(getResources().getColor(R.color.jai_text));
        bubble.setTextSize(15);
        bubble.setLineSpacing(dp(2), 1.0f);
        bubble.setTextIsSelectable(true);
        bubble.setAutoLinkMask(android.text.util.Linkify.WEB_URLS);
        bubble.setMovementMethod(LinkMovementMethod.getInstance());
        bubble.setPadding(dp(13), dp(10), dp(13), dp(10));

        GradientDrawable background = new GradientDrawable();
        background.setColor(getResources().getColor(user ? R.color.jai_user_bubble : R.color.jai_ai_bubble));
        background.setCornerRadius(dp(15));
        if (!user) background.setStroke(dp(1), getResources().getColor(R.color.jai_border));
        bubble.setBackground(background);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                Math.min((int) (getResources().getDisplayMetrics().widthPixels * 0.86f), dp(520)),
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.gravity = user ? Gravity.END : Gravity.START;
        params.setMargins(dp(4), dp(4), dp(4), dp(6));
        chatContainer.addView(bubble, params);
    }

    /** Uygulama açılışında ayarlı sunucuya yalnızca bir istek gönderir; zamanlayıcı kurmaz. */
    private void wakeServerOnceOnLaunch() {
        if (!serverSettings.isConfigured()) return;
        wakeServer("Uygulama açıldı: sunucuya tek uyandırma isteği gönderiliyor…");
    }

    private boolean startsCommand(String text, String... prefixes) {
        String lower = text == null ? "" : text.trim().toLowerCase(java.util.Locale.forLanguageTag("tr-TR"));
        for (String prefix : prefixes) if (lower.startsWith(prefix)) return true;
        return false;
    }

    private long trailingId(String text) {
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("(\\d+)\\s*$").matcher(text == null ? "" : text.trim());
        if (!matcher.find()) return -1L;
        try { return Long.parseLong(matcher.group(1)); } catch (NumberFormatException ignored) { return -1L; }
    }

    private void showCodeLabDialog() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padding = dp(14);
        content.setPadding(padding, dp(6), padding, dp(6));

        EditText prompt = new EditText(this);
        prompt.setSingleLine(false);
        prompt.setMinLines(2);
        prompt.setMaxLines(5);
        prompt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        prompt.setHint("Örn: televizyon çiz 720p piksel piksel; video yap; Minecraft için tam mcaddon üret; Java JAR oluştur; mcworld dünya yap");
        content.addView(prompt);

        TextView synthesisHelp = new TextView(this);
        synthesisHelp.setText("Ja.i yerel kodla PNG çizer; 720p (1280×720) ve piksel-art ölçekleme destekler. Örnek görsel seçip etiket vererek cihazdaki küçük sinir ağını eğitebilirsin. MP4 video üretimi telefonun MediaCodec kodlayıcısını kullanır; işlemci, RAM ve boş depolamaya göre çözünürlük/FPS otomatik düşürülebilir.\nMinecraft Bedrock: kaynak paketi, davranış paketi, iç içe mcpack dosyaları taşıyan mcaddon, mcworld, özel blok/eşya/yaratık, geometri, 7 keyframe animasyonu, OGG ses ve Script API.\nÖrn: televizyon çiz 720p piksel piksel | mor ejderha için tam mcaddon yap | mcworld dünya paketi üret | Java JAR yap.\nÖzgün JavaScript: değişken puan = 0 | fonksiyon ekle(x) = puan + x | yazdır ekle(3)");
        synthesisHelp.setTextColor(getResources().getColor(R.color.jai_muted));
        synthesisHelp.setTextSize(11);
        synthesisHelp.setPadding(0, dp(4), 0, dp(8));
        content.addView(synthesisHelp);

        Spinner language = new Spinner(this);
        String[] languages = {"JavaScript", "HTML", "Java", "Python", "XML", "JSON", "PNG"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, languages);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        language.setAdapter(adapter);
        content.addView(language);

        EditText source = new EditText(this);
        source.setGravity(Gravity.TOP | Gravity.START);
        source.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        source.setTypeface(android.graphics.Typeface.MONOSPACE);
        source.setMinLines(9);
        source.setMaxLines(15);
        source.setHint("Kod burada oluşturulur veya düzenlenir…");
        content.addView(source, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220)));

        TextView output = new TextView(this);
        output.setTextColor(getResources().getColor(R.color.jai_turquoise));
        output.setTextSize(12);
        output.setPadding(0, dp(8), 0, dp(4));
        output.setText("Ja.i pikselleri yerel Java raster motoruyla işler. Varsayılan çıktı 1280×720 PNG; piksel-art modunda ızgara 720p'ye keskin ölçeklenir. Görsel ağı 16→128→64→3 ve 10.627 parametrelidir; senin Altın Ağ Küresi örneğinle başlar, yeni görselleri etiketleyip cihazda öğretebilirsin. Ara açıksa görsel/video/Minecraft isteği için web kaynaklarını önce araştırır ve yerel hafızaya kaydeder. Android donanımsal kodlayıcısıyla dört sahne taslağına kadar 1–60 saniyelik MP4; işlemci/RAM/depolama durumuna göre 1280×720/24 FPS, 960×540/20 FPS veya 640×360/15 FPS seçilir; Bedrock 1.21.132 hedefli kaynak/davranış paketi üretimi desteklenir. Haricî AI modeli/API yoktur.");
        content.addView(output);
        ImageView imagePreview = new ImageView(this);
        imagePreview.setAdjustViewBounds(true);
        imagePreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imagePreview.setVisibility(android.view.View.GONE);
        content.addView(imagePreview, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(210)));
        Button trainVisual = new Button(this);
        trainVisual.setText("Örnek görseli seç ve Ja.i'ye öğret");
        trainVisual.setAllCaps(false);
        content.addView(trainVisual, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)));
        trainVisual.setOnClickListener(v -> {
            String label = prompt.getText().toString().trim();
            if (label.isEmpty()) {
                Toast.makeText(this, "Önce örneğin ne olduğunu yaz. Örn: televizyon", Toast.LENGTH_LONG).show();
                return;
            }
            pendingVisualLabel = label;
            Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            picker.addCategory(Intent.CATEGORY_OPENABLE);
            picker.setType("image/*");
            startActivityForResult(picker, REQUEST_IMPORT_VISUAL_EXAMPLE);
        });
        output.append("\n\n" + visualLearning.status() + "\nÖrnek öğretmek için konu adını yazıp örnek görsel seçebilirsin.");

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);
        Button generate = new Button(this); generate.setText("Üret"); generate.setAllCaps(false);
        Button check = new Button(this); check.setText("Kontrol"); check.setAllCaps(false);
        Button run = new Button(this); run.setText("Çalıştır"); run.setAllCaps(false);
        Button save = new Button(this); save.setText("Kaydet"); save.setAllCaps(false);
        buttons.addView(generate, new LinearLayout.LayoutParams(0, dp(44), 1));
        buttons.addView(check, new LinearLayout.LayoutParams(0, dp(44), 1));
        buttons.addView(run, new LinearLayout.LayoutParams(0, dp(44), 1));
        buttons.addView(save, new LinearLayout.LayoutParams(0, dp(44), 1));
        content.addView(buttons);
        Button exportProject = new Button(this);
        exportProject.setText("Çok dosyalı projeyi ZIP olarak kaydet");
        exportProject.setAllCaps(false);
        exportProject.setEnabled(false);
        content.addView(exportProject, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)));
        final CodeGenerator.GeneratedCode[] currentGeneration = new CodeGenerator.GeneratedCode[1];

        generate.setOnClickListener(v -> {
            String requestText = prompt.getText().toString().trim();
            if (requestText.isEmpty()) {
                output.setText("Önce ne üretileceğini yaz.");
                return;
            }
            generate.setEnabled(false);
            boolean researchEnabled = webCheckBox != null && webCheckBox.isChecked();
            String effort = effortSpinner == null ? "Orta" : String.valueOf(effortSpinner.getSelectedItem());
            output.setText(researchEnabled
                    ? "Ara açık: teknik kaynaklar aranıyor; sonra yerel üretim, doğrulama ve düzeltme çalışacak…"
                    : "Yerel üretim, doğrulama ve otomatik düzeltme çalışıyor…");
            try {
                worker.execute(() -> {
                    String researchContext = "";
                    String researchStatus = "";
                    boolean isMinecraft = new MinecraftPackGenerator().isMinecraftPackRequest(requestText);
                    if (researchEnabled) {
                        if (!isNetworkAvailable()) {
                            researchStatus = "Ara açık fakat internet bağlantısı bulunamadı; mevcut yerel bilgiyle devam edildi.";
                        } else {
                            try {
                                boolean isImageTask = new com.jai.assistant.engine.ProceduralImageGenerator().isImageRequest(requestText);
                                if (isImageTask) {
                                    String visualStatus = learnVisualReferences(requestText);
                                    researchContext = "[JA.I CODE LAB GÖRSEL ARAŞTIRMASI]\n" + visualStatus;
                                    researchStatus = "Görsel araştırması: " + visualStatus;
                                } else {
                                String researchQuery = requestText;
                                boolean isVideoTask = com.jai.assistant.media.AndroidVideoGenerator.isVideoRequest(requestText);
                                if (isMinecraft) {
                                    researchQuery += " Minecraft Bedrock 1.21.132.1 official add-on documentation resource behavior packs custom items max stack size manifest format version animations script API";
                                } else if (isVideoTask) {
                                    researchQuery += " visual reference descriptions object anatomy parts structure shape materials color composition design";
                                } else {
                                    researchQuery += " official technical documentation implementation examples compatibility troubleshooting";
                                }
                                com.jai.assistant.tools.ResearchReport report = webResearch.researchAdaptive(researchQuery, effort);
                                int saved = learningEngine.rememberResearch(report);
                                researchContext = "[JA.I CODE LAB WEB ARAŞTIRMA RAPORU]\n" + report.toDisplayText();
                                researchStatus = "Araştırma tamamlandı: " + report.getSources().size() + " kaynak sonucu, "
                                        + report.getReadPageCount() + " okunmuş sayfa; " + saved + " not yerel hafızaya kaydedildi.";
                                }
                            } catch (Exception researchError) {
                                researchStatus = "Web araştırması başarısız: " + safeMessage(researchError)
                                        + ". Yerel üretim yine de denendi.";
                            }
                        }
                    }
                    CodeGenerator.GeneratedCode generated = new CodeGenerator(visualLearning, this)
                            .generate(requestText, researchContext);
                    String finalResearchStatus = researchStatus;
                    if (!activityDestroyed) runOnUiThread(() -> {
                        generate.setEnabled(true);
                        currentGeneration[0] = generated;
                        source.setText(generated.source);
                        for (int i = 0; i < language.getCount(); i++) {
                            if (String.valueOf(language.getItemAtPosition(i)).equalsIgnoreCase(generated.language)) language.setSelection(i);
                        }
                        exportProject.setEnabled(generated.project || generated.hasArtifact());
                        check.setEnabled(!generated.hasArtifact());
                        run.setEnabled(!generated.hasArtifact());
                        save.setEnabled(!generated.hasArtifact());
                        if (generated.hasArtifact()) {
                            exportProject.setText("Üretilen dosyayı kaydet");
                            output.setText(generated.explanation + "\n\nDosya dışa aktarılmaya hazır.");
                            if ("image/png".equalsIgnoreCase(generated.artifactMimeType)) {
                                android.graphics.Bitmap bitmap = BitmapFactory.decodeByteArray(generated.artifactBytes, 0, generated.artifactBytes.length);
                                if (bitmap != null) {
                                    imagePreview.setImageBitmap(bitmap);
                                    imagePreview.setVisibility(android.view.View.VISIBLE);
                                } else {
                                    imagePreview.setVisibility(android.view.View.GONE);
                                    output.append("\nPNG önizlemesi açılamadı; dosya yine de kaydedilebilir.");
                                }
                            } else {
                                imagePreview.setImageDrawable(null);
                                imagePreview.setVisibility(android.view.View.GONE);
                            }
                        } else if (generated.project) {
                            imagePreview.setImageDrawable(null);
                            imagePreview.setVisibility(android.view.View.GONE);
                            exportProject.setText("Çok dosyalı projeyi ZIP olarak kaydet");
                            output.setText(generated.explanation + "\n\nZIP dışa aktarımı için alttaki düğmeyi kullan. Açık dosya önizlemesi index.html'dir.");
                        } else {
                            imagePreview.setImageDrawable(null);
                            imagePreview.setVisibility(android.view.View.GONE);
                            exportProject.setText("Çok dosyalı projeyi ZIP olarak kaydet");
                            exportProject.setEnabled(false);
                            output.setText(generated.explanation);
                        }
                        if (!finalResearchStatus.isEmpty()) output.append("\n\n" + finalResearchStatus);
                    });
                });
            } catch (RejectedExecutionException ex) {
                generate.setEnabled(true);
                output.setText("Üretim kuyruğu şu anda dolu. Önce devam eden görevin bitmesini bekle.");
            }
        });
        exportProject.setOnClickListener(v -> {
            CodeGenerator.GeneratedCode generated = currentGeneration[0];
            if (generated == null || (!generated.project && !generated.hasArtifact())) {
                output.setText("Önce desteklenen bir çıktı üret.");
                return;
            }
            try {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                if (generated.hasArtifact()) {
                    if (generated.artifactFile != null) {
                        pendingProjectExportFile = generated.artifactFile;
                        pendingProjectExport = null;
                    } else {
                        pendingProjectExport = generated.artifactBytes == null ? null : generated.artifactBytes.clone();
                        pendingProjectExportFile = null;
                    }
                    intent.setType(generated.artifactMimeType == null ? "application/octet-stream" : generated.artifactMimeType);
                    intent.putExtra(Intent.EXTRA_TITLE, generated.artifactFileName == null ? "jai-output.bin" : generated.artifactFileName);
                } else {
                    java.util.Map<String, String> exportFiles = new java.util.LinkedHashMap<>(generated.projectFiles);
                    exportFiles.put("index.html", source.getText().toString());
                    pendingProjectExport = new ProjectArchiveWriter().createZip(exportFiles);
                    pendingProjectExportFile = null;
                    String safeName = generated.title.toLowerCase(java.util.Locale.ROOT)
                            .replaceAll("[^\\p{L}\\p{N}]+", "-").replaceAll("^-|-$", "");
                    if (safeName.isEmpty()) safeName = "jai-proje";
                    intent.setType("application/zip");
                    intent.putExtra(Intent.EXTRA_TITLE, safeName + ".zip");
                }
                startActivityForResult(intent, REQUEST_EXPORT_PROJECT);
            } catch (IOException exception) {
                pendingProjectExport = null;
                pendingProjectExportFile = null;
                output.setText("Dosya oluşturulamadı: " + safeMessage(exception));
            }
        });
        check.setOnClickListener(v -> {
            CodeGenerator.GeneratedCode generated = currentGeneration[0];
            if (generated != null && generated.project) {
                java.util.Map<String, String> currentFiles = new java.util.LinkedHashMap<>(generated.projectFiles);
                currentFiles.put("index.html", source.getText().toString());
                output.setText(new com.jai.assistant.engine.ProjectCodeValidator().validate(currentFiles).report);
                return;
            }
            String selected = String.valueOf(language.getSelectedItem());
            output.setText(new CodeLabEngine().analyze(source.getText().toString(), selected));
        });
        run.setOnClickListener(v -> {
            CodeGenerator.GeneratedCode generated = currentGeneration[0];
            if (generated != null && generated.project) {
                output.setText("Bu çok dosyalı web projesidir. Önce ZIP olarak kaydet, arşivi çıkar ve index.html dosyasını tarayıcıda aç. Kod Laboratuvarı sandbox'ı DOM/tarayıcı arayüzü sağlamaz.");
                return;
            }
            String selected = String.valueOf(language.getSelectedItem());
            if (!"JavaScript".equalsIgnoreCase(selected)) {
                output.setText("Bu sürümde yalnızca JavaScript yerel sandbox içinde çalıştırılabilir. Diğer diller yalnızca statik kontrol edilebilir.");
                return;
            }
            run.setEnabled(false);
            output.setText("JavaScript yerel sandbox içinde çalışıyor…");
            String code = source.getText().toString();
            try {
                worker.execute(() -> {
                    String result = new JavaScriptSandbox().execute(code, 1500L);
                    if (!activityDestroyed) runOnUiThread(() -> {
                        run.setEnabled(true);
                        output.setText(result);
                    });
                });
            } catch (RejectedExecutionException ex) {
                run.setEnabled(true);
                output.setText("Kod yürütme kuyruğu kullanılamıyor.");
            }
        });
        save.setOnClickListener(v -> {
            String selected = String.valueOf(language.getSelectedItem()).toLowerCase(java.util.Locale.ROOT);
            String extension = "javascript".equals(selected) ? "js" : selected;
            pendingCodeExport = source.getText().toString();
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TITLE, "jai-kod." + extension);
            startActivityForResult(intent, REQUEST_EXPORT_CODE);
        });

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        new AlertDialog.Builder(this).setTitle("Ja.i · Kod laboratuvarı")
                .setView(scroll).setPositiveButton("Kapat", null).show();
    }

    private void showMessagingDialog() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padding = dp(16);
        content.setPadding(padding, dp(4), padding, dp(4));

        TextView server = new TextView(this);
        String baseUrl = "";
        try { baseUrl = serverSettings.get().baseUrl; } catch (Exception ignored) { }
        server.setText(baseUrl.isEmpty() ? "Önce Sunucu bölümünden HTTPS adresi gir." : "Mesaj sunucusu: " + baseUrl);
        server.setTextColor(getResources().getColor(R.color.jai_turquoise));
        server.setTextSize(12);
        content.addView(server);

        EditText username = new EditText(this); username.setSingleLine(true); username.setHint("Kullanıcı adı (3-24 harf/rakam/_)");
        try { username.setText(messagingSession.getUsername()); } catch (Exception ignored) { }
        EditText password = new EditText(this); password.setSingleLine(true); password.setHint("Parola (en az 10 karakter)");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText recipient = new EditText(this); recipient.setSingleLine(true); recipient.setHint("Alıcının Ja.i kullanıcı adı");
        EditText message = new EditText(this); message.setMinLines(2); message.setMaxLines(4); message.setHint("Mesajını yaz…");
        EditText incomingId = new EditText(this); incomingId.setSingleLine(true); incomingId.setInputType(InputType.TYPE_CLASS_NUMBER); incomingId.setHint("Okundu işaretlenecek gelen mesaj numarası");
        content.addView(username); content.addView(password); content.addView(recipient); content.addView(message); content.addView(incomingId);

        TextView result = new TextView(this);
        result.setTextColor(getResources().getColor(R.color.jai_text));
        result.setTextSize(12);
        result.setPadding(0, dp(8), 0, dp(4));
        result.setText("Teslim durumu gerçek sunucu kayıtlarıyla gösterilir: gönderildi, teslim edildi, okundu.");
        content.addView(result);

        TextView privacy = new TextView(this);
        privacy.setText("Gizlilik uyarısı: Bu geliştirme sunucusu mesaj metnini veritabanında okunabilir biçimde saklar. Uçtan uca şifreleme henüz eklenmedi; özel veya hassas bilgi gönderme.");
        privacy.setTextColor(getResources().getColor(R.color.jai_muted));
        privacy.setTextSize(11);
        content.addView(privacy);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button register = new Button(this); register.setText("Kayıt"); register.setAllCaps(false);
        Button login = new Button(this); login.setText("Giriş"); login.setAllCaps(false);
        Button send = new Button(this); send.setText("Gönder"); send.setAllCaps(false);
        Button sync = new Button(this); sync.setText("Gelen kutusu"); sync.setAllCaps(false);
        actions.addView(register, new LinearLayout.LayoutParams(0, dp(44), 1));
        actions.addView(login, new LinearLayout.LayoutParams(0, dp(44), 1));
        actions.addView(send, new LinearLayout.LayoutParams(0, dp(44), 1));
        actions.addView(sync, new LinearLayout.LayoutParams(0, dp(44), 1));
        content.addView(actions);
        Button readButton = new Button(this); readButton.setText("Seçilen mesajı okundu işaretle"); readButton.setAllCaps(false);
        content.addView(readButton);
        Button statusButton = new Button(this); statusButton.setText("Son gönderdiğim mesajın durumunu denetle"); statusButton.setAllCaps(false);
        content.addView(statusButton);

        final String finalBaseUrl = baseUrl;
        register.setOnClickListener(v -> performMessagingAction(result, () -> {
            JSONObject response = new MessagingClient().register(finalBaseUrl, username.getText().toString().trim(), password.getText().toString());
            messagingSession.save(response.getString("username"), response.getString("token"));
            return "Hesap oluşturuldu: " + response.getString("username") + ". Oturum bu cihazda şifreli saklandı.";
        }));
        login.setOnClickListener(v -> performMessagingAction(result, () -> {
            JSONObject response = new MessagingClient().login(finalBaseUrl, username.getText().toString().trim(), password.getText().toString());
            messagingSession.save(response.getString("username"), response.getString("token"));
            return "Giriş başarılı: " + response.getString("username");
        }));
        send.setOnClickListener(v -> performMessagingAction(result, () -> {
            String token = messagingSession.getToken();
            JSONObject response = new MessagingClient().send(finalBaseUrl, token, recipient.getText().toString().trim(), message.getText().toString());
            messagingSession.setLastSentId(response.getLong("id"));
            return "Mesaj #" + response.getLong("id") + " sunucu tarafından kabul edildi (gönderildi). Teslim/okundu durumu alıcı Ja.i gelen kutusunu eşitlediğinde değişir.";
        }));
        sync.setOnClickListener(v -> performMessagingAction(result, () -> {
            String token = messagingSession.getToken();
            JSONArray items = new MessagingClient().inbox(finalBaseUrl, token, messagingSession.getLastMessageId());
            StringBuilder text = new StringBuilder(items.length()).append(" yeni mesaj alındı.\n");
            long highest = messagingSession.getLastMessageId();
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.getJSONObject(i);
                long id = item.getLong("id");
                text.append("\n#").append(id).append(" · ").append(item.optString("sender"))
                        .append("\n").append(item.optString("text")).append("\n");
                highest = Math.max(highest, id);
            }
            messagingSession.setLastMessageId(highest);
            return text.toString();
        }));
        readButton.setOnClickListener(v -> performMessagingAction(result, () -> {
            String token = messagingSession.getToken();
            long id;
            try { id = Long.parseLong(incomingId.getText().toString().trim()); }
            catch (NumberFormatException invalid) { return "Önce gelen kutusundaki mesaj numarasını yaz."; }
            JSONObject response = new MessagingClient().markRead(finalBaseUrl, token, id);
            return "Mesaj #" + response.getLong("id") + " sunucu kayıtlarına göre okundu olarak işaretlendi.";
        }));
        statusButton.setOnClickListener(v -> performMessagingAction(result, () -> {
            String token = messagingSession.getToken();
            long id = messagingSession.getLastSentId();
            if (id <= 0) return "Henüz bu cihazdan gönderilmiş mesaj yok.";
            JSONObject state = new MessagingClient().status(finalBaseUrl, token, id);
            String value = state.optString("status", "unknown");
            String turkish = "read".equals(value) ? "okundu" : "delivered".equals(value) ? "teslim edildi" : "sent".equals(value) ? "gönderildi" : value;
            return "Mesaj #" + id + " durumu: " + turkish + ". Durum sunucudaki alıcı kayıtlarına göre geldi.";
        }));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        new AlertDialog.Builder(this).setTitle("Ja.i · Gerçek mesajlaşma")
                .setView(scroll).setPositiveButton("Kapat", null).show();
    }

    private void performMessagingAction(TextView output, MessagingAction action) {
        if (worker == null || worker.isShutdown()) {
            output.setText("İş kuyruğu kapalı.");
            return;
        }
        output.setText("Sunucuyla iletişim kuruluyor…");
        try {
            worker.execute(() -> {
                String message;
                try { message = action.run(); }
                catch (Exception exception) { message = "Mesajlaşma işlemi başarısız: " + safeMessage(exception); }
                final String result = message;
                if (!activityDestroyed) runOnUiThread(() -> { if (!activityDestroyed) output.setText(result); });
            });
        } catch (RejectedExecutionException exception) {
            output.setText("İş kuyruğu bu isteği kabul etmedi.");
        }
    }

    private interface MessagingAction { String run() throws Exception; }

    private void showServerSettings() {
        final EditText addressInput = new EditText(this);
        addressInput.setSingleLine(true);
        addressInput.setHint("https://sunucu-adresin.example");
        addressInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);

        final EditText pathInput = new EditText(this);
        pathInput.setSingleLine(true);
        pathInput.setHint("/health");
        pathInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);

        final EditText tokenInput = new EditText(this);
        tokenInput.setSingleLine(true);
        tokenInput.setHint("Erişim anahtarı (isteğe bağlı)");
        tokenInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        try {
            ServerConfig current = serverSettings.get();
            addressInput.setText(current.baseUrl);
            pathInput.setText(current.healthPath);
            tokenInput.setText(current.bearerToken);
        } catch (Exception exception) {
            Toast.makeText(this, "Kayıtlı sunucu anahtarı okunamadı. Yeni anahtar girmen gerekebilir.", Toast.LENGTH_LONG).show();
        }

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        content.setPadding(pad, dp(8), pad, dp(4));

        TextView explanation = new TextView(this);
        explanation.setText("Ja.i açıldığında bu adrese bir kez GET isteği gönderir. Arka planda sürekli kontrol veya boş istek döngüsü yoktur. Uygulamayı kapatınca yeni istek gönderilmez. Sunucunun bu yolu desteklemesi gerekir.");
        explanation.setTextColor(getResources().getColor(R.color.jai_muted));
        explanation.setTextSize(13);
        content.addView(explanation);
        addLabeledField(content, "Sunucu HTTPS adresi", addressInput);
        addLabeledField(content, "Uyandırma / sağlık yolu", pathInput);
        addLabeledField(content, "Erişim anahtarı", tokenInput);

        TextView note = new TextView(this);
        note.setText("Erişim anahtarı Android Keystore ile şifrelenir. Kart veya ödeme bilgisi bu ekranda istenmez. Sunucunun gerçekten uyanması, seçilen barındırma hizmetinin HTTP isteğiyle başlatmayı desteklemesine bağlıdır.");
        note.setTextColor(getResources().getColor(R.color.jai_muted));
        note.setTextSize(12);
        note.setPadding(0, dp(10), 0, 0);
        content.addView(note);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        Button saveAndWake = new Button(this);
        saveAndWake.setText("Kaydet ve bağlan");
        saveAndWake.setAllCaps(false);
        Button disconnect = new Button(this);
        disconnect.setText("Sunucu ayarlarını sil");
        disconnect.setAllCaps(false);
        actions.addView(saveAndWake);
        actions.addView(disconnect);
        content.addView(actions);

        ScrollView scroller = new ScrollView(this);
        scroller.addView(content);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Ja.i · Sunucu")
                .setView(scroller)
                .setPositiveButton("Kapat", null)
                .create();

        saveAndWake.setOnClickListener(view -> {
            try {
                serverSettings.save(addressInput.getText().toString(), pathInput.getText().toString(), tokenInput.getText().toString());
                dialog.dismiss();
                wakeServer("Sunucuya tek bağlantı isteği gönderiliyor…");
            } catch (Exception exception) {
                Toast.makeText(this, "Ayarlar kaydedilemedi: " + safeMessage(exception), Toast.LENGTH_LONG).show();
            }
        });
        disconnect.setOnClickListener(view -> {
            serverSettings.clear();
            serverStatus = "Sunucu ayarları silindi";
            statusText.setText(serverStatus + " · otomatik uyandırma kapalı");
            Toast.makeText(this, "Sunucu ayarları silindi. Sunucuya istek gönderilmeyecek.", Toast.LENGTH_LONG).show();
            dialog.dismiss();
        });
        dialog.show();
    }

    private void addLabeledField(LinearLayout parent, String label, EditText field) {
        TextView caption = new TextView(this);
        caption.setText(label);
        caption.setTextColor(getResources().getColor(R.color.jai_text));
        caption.setTextSize(13);
        caption.setPadding(0, dp(12), 0, 0);
        parent.addView(caption);
        parent.addView(field, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void wakeServer(String startingMessage) {
        if (serverExecutor == null || serverExecutor.isShutdown()) return;
        if (!serverRequestInFlight.compareAndSet(false, true)) {
            Toast.makeText(this, "Sunucu isteği zaten sürüyor.", Toast.LENGTH_SHORT).show();
            return;
        }
        statusText.setText(startingMessage);
        try {
            serverExecutor.execute(() -> {
                String message;
                boolean reachable = false;
                try {
                    ServerConfig config = serverSettings.get();
                    if (!config.isConfigured()) {
                        message = "Sunucu ayarlanmamış.";
                    } else {
                        ServerConnectionManager.Result result = serverConnection.sendSingleWakeRequest(config);
                        message = result.message;
                        reachable = result.reachable;
                    }
                } catch (Exception exception) {
                    message = "Sunucu ayarları okunamadı: " + safeMessage(exception);
                } finally {
                    serverRequestInFlight.set(false);
                }
                if (activityDestroyed) return;
                final String finalMessage = message;
                final boolean finalReachable = reachable;
                runOnUiThread(() -> {
                    if (activityDestroyed) return;
                    serverStatus = finalMessage;
                    statusText.setText("Sunucu: " + finalMessage);
                    subtitleText.setText(finalReachable ? "Yerel asistan · sunucu erişilebilir" : "Yerel asistan · sunucu yanıtı yok");
                });
            });
        } catch (RejectedExecutionException exception) {
            serverRequestInFlight.set(false);
            serverStatus = "Sunucu isteği başlatılamadı.";
            statusText.setText(serverStatus);
        }
    }

    private void updateConnectionLabel() {
        boolean connected = isNetworkAvailable();
        subtitleText.setText(connected ? "Yerel asistan · ağ var" : "Yerel asistan · çevrimdışı");
        if (!webCheckBox.isChecked()) {
            statusText.setText(connected ? "Yerel sohbet hazır · Ara kapalı" : "Çevrimdışı yerel sohbet hazır");
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) return false;
        Network network = manager.getActiveNetwork();
        if (network == null) return false;
        NetworkCapabilities capabilities = manager.getNetworkCapabilities(network);
        return capabilities != null
                && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
    }

    private String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.trim().isEmpty()
                ? exception.getClass().getSimpleName() : message;
    }

    private void closeDatabaseIfNeeded() {
        if (database != null && databaseClosed.compareAndSet(false, true)) {
            database.close();
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (manager != null) manager.hideSoftInputFromWindow(messageInput.getWindowToken(), 0);
        } catch (Exception ignored) {
            // Klavye görünmüyorsa mesaj gönderimi yine de sürer.
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        activityDestroyed = true;
        if (worker != null) {
            // Kapanış, kuyruktaki mevcut yanıt/aktarımı bitirdikten sonra çalışır.
            if (brain != null) {
                try { worker.execute(() -> brain.close()); }
                catch (RejectedExecutionException ignored) { /* süreç kapanırken native kaynaklar işletim sistemince temizlenir. */ }
            }
            worker.shutdown();
        }
        if (serverExecutor != null) serverExecutor.shutdownNow();
        if (!backgroundTaskRunning) closeDatabaseIfNeeded();
        super.onDestroy();
    }
}
