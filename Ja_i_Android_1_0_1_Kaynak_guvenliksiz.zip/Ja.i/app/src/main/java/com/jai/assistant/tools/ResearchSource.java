package com.jai.assistant.tools;

/** Tek bir web kaynağının arama, sayfa-okuma ve sayfadan çıkarılan yayın tarihi bilgisi. */
public final class ResearchSource {
    public final String title;
    public final String url;
    public final String domain;
    public final String excerpt;
    public final boolean pageRead;
    public final String publishedDate;

    public ResearchSource(String title, String url, String domain, String excerpt, boolean pageRead) {
        this(title, url, domain, excerpt, pageRead, "");
    }

    public ResearchSource(String title, String url, String domain, String excerpt,
                          boolean pageRead, String publishedDate) {
        this.title = clean(title);
        this.url = clean(url);
        this.domain = clean(domain);
        this.excerpt = clean(excerpt);
        this.pageRead = pageRead;
        this.publishedDate = clean(publishedDate);
    }

    private static String clean(String value) { return value == null ? "" : value.trim(); }
}
