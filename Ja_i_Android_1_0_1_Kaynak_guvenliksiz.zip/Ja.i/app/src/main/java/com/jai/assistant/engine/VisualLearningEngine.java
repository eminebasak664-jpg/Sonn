package com.jai.assistant.engine;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Random;

/**
 * Ja.i yerel görsel öğrenme ağı.
 * Yeni mimari: 16 -> 128 -> 64 -> 3 (10.000'den fazla eğitilebilir parametre).
 * Kullanıcının etiketlediği görsellerden konum/renk örüntüsü öğrenir; ağ ve örnekler
 * cihazda tutulur. Haricî AI modeli, API veya ağ ağırlığı indirilmez.
 */
public final class VisualLearningEngine {
    private static final int INPUTS = 16;
    private static final int HIDDEN_1 = 128;
    private static final int HIDDEN_2 = 64;
    private static final int OUTPUTS = 3;
    private static final int MAGIC = 0x4A414956; // JAIV
    private static final int SAMPLE_MAGIC = 0x4A414953; // JAIS
    private static final int VERSION = 2;
    private static final int LEGACY_VERSION = 1;
    private static final int LEGACY_INPUTS = 12;
    private static final int LEGACY_HIDDEN = 32;
    private static final int MAX_TRAINING_PIXELS = 512;
    private static final int MAX_REFERENCE_SAMPLES_PER_LABEL = 5;
    private static final int MAX_GENERATION_PIXELS = 9216;
    private static final long PARAMETER_COUNT = (long) INPUTS * HIDDEN_1 + (long) HIDDEN_1 * HIDDEN_2
            + (long) HIDDEN_2 * OUTPUTS + HIDDEN_1 + HIDDEN_2 + OUTPUTS;

    private final File modelFile;
    private final float[][] w1 = new float[HIDDEN_1][INPUTS];
    private final float[] b1 = new float[HIDDEN_1];
    private final float[][] w2 = new float[HIDDEN_2][HIDDEN_1];
    private final float[] b2 = new float[HIDDEN_2];
    private final float[][] w3 = new float[OUTPUTS][HIDDEN_2];
    private final float[] b3 = new float[OUTPUTS];
    private final LinkedHashSet<String> labels = new LinkedHashSet<>();
    private final Random random = new Random(0x4A414956L ^ 0x09612864L);
    private long trainedPixels;
    private int trainedExamples;
    private boolean migratedLegacy;

    public VisualLearningEngine(File modelFile) {
        this.modelFile = modelFile;
        initializeWeights();
    }

    private void initializeWeights() {
        float scale1 = (float) Math.sqrt(2.0 / (INPUTS + HIDDEN_1));
        float scale2 = (float) Math.sqrt(2.0 / (HIDDEN_1 + HIDDEN_2));
        float scale3 = (float) Math.sqrt(2.0 / (HIDDEN_2 + OUTPUTS));
        for (int h = 0; h < HIDDEN_1; h++) {
            for (int i = 0; i < INPUTS; i++) w1[h][i] = (random.nextFloat() * 2f - 1f) * scale1;
        }
        for (int h = 0; h < HIDDEN_2; h++) {
            for (int i = 0; i < HIDDEN_1; i++) w2[h][i] = (random.nextFloat() * 2f - 1f) * scale2;
        }
        for (int o = 0; o < OUTPUTS; o++) {
            for (int h = 0; h < HIDDEN_2; h++) w3[o][h] = (random.nextFloat() * 2f - 1f) * scale3;
        }
    }

    public synchronized void load() {
        if (modelFile == null || !modelFile.isFile()) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(modelFile)))) {
            int magic = in.readInt();
            int version = in.readInt();
            if (magic != MAGIC) return;
            if (version == VERSION) {
                int inputs = in.readInt();
                int hidden1 = in.readInt();
                int hidden2 = in.readInt();
                if (inputs != INPUTS || hidden1 != HIDDEN_1 || hidden2 != HIDDEN_2) return;
                trainedPixels = in.readLong();
                trainedExamples = in.readInt();
                readLabels(in);
                readNewWeights(in);
            } else if (version == LEGACY_VERSION) {
                int inputs = in.readInt();
                int hidden = in.readInt();
                if (inputs != LEGACY_INPUTS || hidden != LEGACY_HIDDEN) return;
                trainedPixels = in.readLong();
                trainedExamples = in.readInt();
                int count = in.readInt();
                if (count < 0 || count > 256) return;
                labels.clear();
                for (int i = 0; i < count; i++) labels.add(in.readUTF());
                float[][] oldW1 = new float[LEGACY_HIDDEN][LEGACY_INPUTS];
                float[] oldB1 = new float[LEGACY_HIDDEN];
                float[][] oldW2 = new float[OUTPUTS][LEGACY_HIDDEN];
                float[] oldB2 = new float[OUTPUTS];
                for (int h = 0; h < LEGACY_HIDDEN; h++) {
                    for (int i = 0; i < LEGACY_INPUTS; i++) oldW1[h][i] = in.readFloat();
                    oldB1[h] = in.readFloat();
                }
                for (int o = 0; o < OUTPUTS; o++) {
                    for (int h = 0; h < LEGACY_HIDDEN; h++) oldW2[o][h] = in.readFloat();
                    oldB2[o] = in.readFloat();
                }
                migrateLegacyWeights(oldW1, oldB1, oldW2, oldB2);
                migratedLegacy = true;
                save();
            }
        } catch (IOException | RuntimeException ignored) {
            initializeWeights();
            labels.clear();
            trainedPixels = 0;
            trainedExamples = 0;
        }
    }

    private void readLabels(DataInputStream in) throws IOException {
        int count = in.readInt();
        if (count < 0 || count > 256) throw new IOException("Görsel etiket sayısı geçersiz.");
        labels.clear();
        for (int i = 0; i < count; i++) labels.add(in.readUTF());
    }

    private void readNewWeights(DataInputStream in) throws IOException {
        for (int h = 0; h < HIDDEN_1; h++) {
            for (int i = 0; i < INPUTS; i++) w1[h][i] = finite(in.readFloat());
            b1[h] = finite(in.readFloat());
        }
        for (int h = 0; h < HIDDEN_2; h++) {
            for (int i = 0; i < HIDDEN_1; i++) w2[h][i] = finite(in.readFloat());
            b2[h] = finite(in.readFloat());
        }
        for (int o = 0; o < OUTPUTS; o++) {
            for (int h = 0; h < HIDDEN_2; h++) w3[o][h] = finite(in.readFloat());
            b3[o] = finite(in.readFloat());
        }
    }

    private void migrateLegacyWeights(float[][] oldW1, float[] oldB1, float[][] oldW2, float[] oldB2) {
        // Eski 32 düğümlü ara katman ilk 32 yeni düğüme taşınır; ikinci katmana
        // yaklaşık kimlik geçişi kurularak eski çıktının davranışı olabildiğince korunur.
        for (int h = 0; h < LEGACY_HIDDEN; h++) {
            System.arraycopy(oldW1[h], 0, w1[h], 0, LEGACY_INPUTS);
            w1[h][12] = 0.0f; w1[h][13] = 0.0f; w1[h][14] = 0.0f; w1[h][15] = 0.0f;
            b1[h] = oldB1[h];
            w2[h][h] = 1.0f;
        }
        for (int o = 0; o < OUTPUTS; o++) {
            System.arraycopy(oldW2[o], 0, w3[o], 0, LEGACY_HIDDEN);
            b3[o] = oldB2[o];
        }
    }

    private static float finite(float value) throws IOException {
        if (Float.isNaN(value) || Float.isInfinite(value) || Math.abs(value) > 1000f) {
            throw new IOException("Görsel modelinde geçersiz ağırlık bulundu.");
        }
        return value;
    }

    public synchronized void save() throws IOException {
        if (modelFile == null) throw new IOException("Model dosya yolu ayarlanmamış.");
        File parent = modelFile.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Görsel model klasörü oluşturulamadı.");
        File temp = new File(modelFile.getPath() + ".tmp");
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(temp)))) {
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(INPUTS); out.writeInt(HIDDEN_1); out.writeInt(HIDDEN_2);
            out.writeLong(trainedPixels); out.writeInt(trainedExamples); out.writeInt(labels.size());
            for (String label : labels) out.writeUTF(label);
            for (int h = 0; h < HIDDEN_1; h++) {
                for (int i = 0; i < INPUTS; i++) out.writeFloat(w1[h][i]);
                out.writeFloat(b1[h]);
            }
            for (int h = 0; h < HIDDEN_2; h++) {
                for (int i = 0; i < HIDDEN_1; i++) out.writeFloat(w2[h][i]);
                out.writeFloat(b2[h]);
            }
            for (int o = 0; o < OUTPUTS; o++) {
                for (int h = 0; h < HIDDEN_2; h++) out.writeFloat(w3[o][h]);
                out.writeFloat(b3[o]);
            }
            out.flush();
        }
        if (modelFile.exists() && !modelFile.delete()) { temp.delete(); throw new IOException("Eski görsel model dosyası değiştirilemedi."); }
        if (!temp.renameTo(modelFile)) { temp.delete(); throw new IOException("Eğitilmiş görsel model kaydedilemedi."); }
    }

    /** Etiketli örnek görselden geri yayılım ile öğrenir. */
    public synchronized String trainFromImage(String label, int width, int height, int[] argb, int epochs) throws IOException {
        String cleanLabel = normalize(label);
        if (cleanLabel.length() < 2) throw new IllegalArgumentException("Örnek görsele açıklama yaz; ör. televizyon.");
        if (width < 8 || height < 8 || argb == null || argb.length != width * height) throw new IllegalArgumentException("Görsel verisi geçersiz.");
        if (width > 512 || height > 512 || (long) width * height > 262144L) throw new IllegalArgumentException("Eğitim örneği en fazla 512×512 olmalı.");
        int safeEpochs = Math.max(1, Math.min(24, epochs));
        labels.add(cleanLabel);
        float[] input = new float[INPUTS];
        float[] hidden1 = new float[HIDDEN_1];
        float[] hidden2 = new float[HIDDEN_2];
        float[] output = new float[OUTPUTS];
        float[] delta1 = new float[HIDDEN_1];
        float[] delta2 = new float[HIDDEN_2];
        int samples = Math.min(MAX_TRAINING_PIXELS, Math.max(256, width * height / 128));
        Random sampleRandom = new Random(((long) cleanLabel.hashCode() << 32) ^ trainedPixels ^ width ^ height);
        final float learningRate = 0.0045f;
        for (int epoch = 0; epoch < safeEpochs; epoch++) {
            for (int sample = 0; sample < samples; sample++) {
                int x = sampleRandom.nextInt(width);
                int y = sampleRandom.nextInt(height);
                int color = argb[y * width + x];
                makeInput(cleanLabel, x / (float) Math.max(1, width - 1), y / (float) Math.max(1, height - 1), input);
                forward(input, hidden1, hidden2, output);
                float[] target = {((color >>> 16) & 255) / 255f, ((color >>> 8) & 255) / 255f, (color & 255) / 255f};
                for (int h = 0; h < HIDDEN_2; h++) {
                    float sum = 0f;
                    for (int o = 0; o < OUTPUTS; o++) sum += (output[o] - target[o]) * output[o] * (1f - output[o]) * w3[o][h];
                    delta2[h] = sum * (1f - hidden2[h] * hidden2[h]);
                }
                for (int h = 0; h < HIDDEN_1; h++) {
                    float sum = 0f;
                    for (int j = 0; j < HIDDEN_2; j++) sum += delta2[j] * w2[j][h];
                    delta1[h] = sum * (1f - hidden1[h] * hidden1[h]);
                }
                for (int o = 0; o < OUTPUTS; o++) {
                    float delta = (output[o] - target[o]) * output[o] * (1f - output[o]);
                    for (int h = 0; h < HIDDEN_2; h++) w3[o][h] -= learningRate * delta * hidden2[h];
                    b3[o] -= learningRate * delta;
                }
                for (int h = 0; h < HIDDEN_2; h++) {
                    for (int j = 0; j < HIDDEN_1; j++) w2[h][j] -= learningRate * delta2[h] * hidden1[j];
                    b2[h] -= learningRate * delta2[h];
                }
                for (int h = 0; h < HIDDEN_1; h++) {
                    for (int i = 0; i < INPUTS; i++) w1[h][i] -= learningRate * delta1[h] * input[i];
                    b1[h] -= learningRate * delta1[h];
                }
                trainedPixels++;
            }
        }
        trainedExamples++;
        storeReferenceImage(cleanLabel, width, height, argb);
        save();
        return "Öğrenme tamamlandı. Mimari 16→128→64→3; " + PARAMETER_COUNT
                + " eğitilebilir parametre. Etiket: " + cleanLabel + ", örnek: " + trainedExamples
                + ", eğitim pikseli: " + trainedPixels + ". Ağırlıklar ve görsel örneği cihazda saklandı.";
    }

    public synchronized boolean canGenerate(String prompt) {
        String label = matchingLabel(prompt);
        return label != null && !findSamples(label).isEmpty();
    }

    /** Etikete bağlı örnek piksellerini oranı koruyarak hedef boyuta dönüştürür. */
    public synchronized int[] generateReferenceImage(String prompt, int width, int height, boolean pixelArt) throws IOException {
        String label = matchingLabel(prompt);
        if (label == null) return null;
        List<File> samples = findSamples(label);
        if (samples.isEmpty()) return null;
        ImageSample sample = readSample(samples.get(samples.size() - 1));
        return fitSample(sample, width, height, pixelArt);
    }

    /** Bir etikete ait birden fazla web/kullanıcı görselini piksel piksel harmanlar. */
    private int[] generateReferenceComposite(String label, int width, int height, boolean pixelArt) throws IOException {
        List<File> files = findSamples(label);
        if (files.isEmpty()) return null;
        long[] red = new long[width * height];
        long[] green = new long[width * height];
        long[] blue = new long[width * height];
        short[] counts = new short[width * height];
        int used = 0;
        for (File file : files) {
            ImageSample sample = readSample(file);
            if (sample == null) continue;
            int[] fitted = fitSample(sample, width, height, pixelArt);
            for (int i = 0; i < fitted.length; i++) {
                int color = fitted[i];
                if ((color >>> 24) == 0) continue;
                red[i] += (color >>> 16) & 255;
                green[i] += (color >>> 8) & 255;
                blue[i] += color & 255;
                if (counts[i] < Short.MAX_VALUE) counts[i]++;
            }
            used++;
        }
        if (used == 0) return null;
        int[] combined = new int[width * height];
        for (int i = 0; i < combined.length; i++) {
            if (counts[i] == 0) {
                combined[i] = 0x00000000;
            } else {
                int count = counts[i];
                combined[i] = 0xff000000 | ((int) (red[i] / count) << 16)
                        | ((int) (green[i] / count) << 8) | (int) (blue[i] / count);
            }
        }
        return combined;
    }

    private static int[] fitSample(ImageSample sample, int width, int height, boolean pixelArt) {
        int[] output = new int[width * height];
        float scale = Math.min(width / (float) sample.width, height / (float) sample.height);
        int drawWidth = Math.max(1, Math.min(width, Math.round(sample.width * scale)));
        int drawHeight = Math.max(1, Math.min(height, Math.round(sample.height * scale)));
        int offsetX = (width - drawWidth) / 2, offsetY = (height - drawHeight) / 2;
        for (int y = 0; y < drawHeight; y++) {
            float sy = ((y + 0.5f) * sample.height / drawHeight) - 0.5f;
            for (int x = 0; x < drawWidth; x++) {
                float sx = ((x + 0.5f) * sample.width / drawWidth) - 0.5f;
                output[(offsetY + y) * width + offsetX + x] = pixelArt
                        ? sampleNearest(sample.pixels, sample.width, sample.height, sx, sy)
                        : sampleBilinear(sample.pixels, sample.width, sample.height, sx, sy);
            }
        }
        return output;
    }

    private ImageSample readSample(File sample) throws IOException {
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(sample)))) {
            if (in.readInt() != SAMPLE_MAGIC) throw new IOException("Görsel örnek başlığı geçersiz.");
            int width = in.readInt(), height = in.readInt();
            if (width < 8 || height < 8 || width > 512 || height > 512
                    || (long) width * height > 262144L) throw new IOException("Görsel örnek boyutu geçersiz.");
            int[] pixels = new int[width * height];
            for (int i = 0; i < pixels.length; i++) pixels[i] = in.readInt();
            if (in.read() != -1) throw new IOException("Görsel örneğinde beklenmeyen ek veri var.");
            return new ImageSample(width, height, pixels);
        }
    }

    public synchronized boolean hasReferenceImage(String label) { return !findSamples(normalize(label)).isEmpty(); }

    /** Örnekleri ayrı dosyalarda saklar; aynı etikete ait yeni görsel eski örneği ezmez. */
    public synchronized void storeReferenceImage(String label, int width, int height, int[] argb) throws IOException {
        String cleanLabel = normalize(label);
        if (cleanLabel.length() < 2 || width < 8 || height < 8 || argb == null || argb.length != width * height
                || width > 512 || height > 512 || (long) width * height > 262144L) throw new IllegalArgumentException("Örnek görsel sınırları geçersiz.");
        if (modelFile == null || modelFile.getParentFile() == null) throw new IOException("Örnek görsel klasörü için model yolu ayarlanmamış.");
        File directory = new File(modelFile.getParentFile(), "visual_examples");
        if (!directory.exists() && !directory.mkdirs()) throw new IOException("Örnek görsel klasörü oluşturulamadı.");
        String slug = cleanLabel.replaceAll("[^\\p{L}\\p{N}]+", "-").replaceAll("^-|-$", "");
        if (slug.length() > 48) slug = slug.substring(0, 48);
        List<File> previous = findSamples(cleanLabel);
        int sequence = previous.size() + 1;
        File target = new File(directory, slug + "-" + String.format(Locale.ROOT, "%02d", sequence) + ".jaimg");
        while (target.exists()) {
            sequence++;
            target = new File(directory, slug + "-" + String.format(Locale.ROOT, "%02d", sequence) + ".jaimg");
        }
        File temp = new File(target.getPath() + ".tmp");
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(temp)))) {
            out.writeInt(SAMPLE_MAGIC); out.writeInt(width); out.writeInt(height);
            for (int color : argb) out.writeInt(color);
            out.flush();
        }
        if (!temp.renameTo(target)) { temp.delete(); throw new IOException("Örnek görsel kaydedilemedi."); }
        List<File> all = findSamples(cleanLabel);
        while (all.size() > MAX_REFERENCE_SAMPLES_PER_LABEL) {
            File oldest = all.remove(0);
            if (!oldest.equals(target)) oldest.delete();
        }
    }

    private List<File> findSamples(String label) {
        List<File> samples = new ArrayList<>();
        if (modelFile == null || modelFile.getParentFile() == null) return samples;
        File directory = new File(modelFile.getParentFile(), "visual_examples");
        if (!directory.isDirectory()) return samples;
        String slug = normalize(label).replaceAll("[^\\p{L}\\p{N}]+", "-").replaceAll("^-|-$", "");
        if (slug.length() > 48) slug = slug.substring(0, 48);
        File legacy = new File(directory, slug + ".jaimg");
        if (legacy.isFile()) samples.add(legacy);
        final String samplePrefix = slug + "-";
        File[] newer = directory.listFiles((dir, name) -> name.startsWith(samplePrefix) && name.endsWith(".jaimg"));
        if (newer != null) {
            Arrays.sort(newer, (a, b) -> {
                int byTime = Long.compare(a.lastModified(), b.lastModified());
                return byTime != 0 ? byTime : a.getName().compareTo(b.getName());
            });
            samples.addAll(Arrays.asList(newer));
        }
        return samples;
    }

    private static final class ImageSample {
        final int width, height;
        final int[] pixels;
        ImageSample(int width, int height, int[] pixels) {
            this.width = width; this.height = height; this.pixels = pixels;
        }
    }

    private String matchingLabel(String prompt) {
        String q = normalize(prompt);
        String best = null;
        int bestScore = 0;
        for (String label : labels) {
            int score = 0;
            if (q.contains(label)) score = label.length() + 100;
            else if (synonymMatch(q, label)) score = label.length() + 60;
            else {
                for (String token : label.split("\\s+")) if (token.length() > 2 && q.contains(token)) score += token.length();
            }
            if (score > bestScore) { bestScore = score; best = label; }
        }
        return bestScore >= 4 ? best : null;
    }

    private File findLatestSample(String label) {
        if (modelFile == null || modelFile.getParentFile() == null) return null;
        File directory = new File(modelFile.getParentFile(), "visual_examples");
        if (!directory.isDirectory()) return null;
        String slug = normalize(label).replaceAll("[^\\p{L}\\p{N}]+", "-").replaceAll("^-|-$", "");
        if (slug.length() > 48) slug = slug.substring(0, 48);
        File result = new File(directory, slug + ".jaimg");
        return result.isFile() ? result : null;
    }

    private int[] generateNetwork(String prompt, int width, int height) {
        int[] result = new int[width * height];
        float[] input = new float[INPUTS];
        float[] hidden1 = new float[HIDDEN_1];
        float[] hidden2 = new float[HIDDEN_2];
        float[] output = new float[OUTPUTS];
        for (int y = 0; y < height; y++) {
            float ny = y / (float) Math.max(1, height - 1);
            for (int x = 0; x < width; x++) {
                makeInput(prompt, x / (float) Math.max(1, width - 1), ny, input);
                forward(input, hidden1, hidden2, output);
                int r = clamp(Math.round(output[0] * 255));
                int g = clamp(Math.round(output[1] * 255));
                int b = clamp(Math.round(output[2] * 255));
                result[y * width + x] = 0xff000000 | (r << 16) | (g << 8) | b;
            }
        }
        return result;
    }

    public synchronized int[] generate(String prompt, int width, int height) {
        if (!canGenerate(prompt)) throw new IllegalStateException("Bu konu için eğitilmiş görsel örneği yok.");
        if (width < 1 || height < 1 || (long) width * height > MAX_GENERATION_PIXELS) throw new IllegalArgumentException("Yerel ağ önizlemesi en fazla 96×96 piksel olmalı.");
        return generateNetwork(prompt, width, height);
    }

    /** Ağın her piksel için ürettiği rengi çoklu referans pikselleriyle harmanlar. */
    public synchronized int[] generateLearnedImage(String prompt, int width, int height, boolean pixelArt) throws IOException {
        String label = matchingLabel(prompt);
        if (label == null) return null;
        float scale = Math.min(1f, (float) Math.sqrt(MAX_GENERATION_PIXELS / (double) ((long) width * height)));
        int baseWidth = Math.max(8, Math.round(width * scale));
        int baseHeight = Math.max(8, Math.round(height * scale));
        while ((long) baseWidth * baseHeight > MAX_GENERATION_PIXELS) {
            if (baseWidth >= baseHeight) baseWidth--; else baseHeight--;
        }
        int[] reference = generateReferenceComposite(label, baseWidth, baseHeight, pixelArt);
        if (reference == null) return null;
        // Eğitimdeki sınıf etiketiyle aynı girdiyi kullan; kullanıcı cümlesindeki fiiller ağı bozmasın.
        int[] learned = generateNetwork(label, baseWidth, baseHeight);
        int[] composed = new int[reference.length];
        float networkBlend = containsStyle(prompt, "serbest", "varyasyon", "yeniden yorumla", "farkli yorum", "stil")
                ? 0.48f : 0.30f;
        Random variation = new Random(((long) normalize(prompt).hashCode() << 32) ^ trainedPixels ^ trainedExamples);
        for (int i = 0; i < composed.length; i++) {
            int a = reference[i], b = learned[i];
            if ((a >>> 24) == 0) a = b;
            int noise = variation.nextInt(5) - 2;
            int r = clamp(Math.round(((a >>> 16) & 255) * (1f - networkBlend) + ((b >>> 16) & 255) * networkBlend) + noise);
            int g = clamp(Math.round(((a >>> 8) & 255) * (1f - networkBlend) + ((b >>> 8) & 255) * networkBlend) + noise);
            int bl = clamp(Math.round((a & 255) * (1f - networkBlend) + (b & 255) * networkBlend) + noise);
            composed[i] = 0xff000000 | (r << 16) | (g << 8) | bl;
        }
        return pixelArt ? nearestScale(composed, baseWidth, baseHeight, width, height)
                : bilinearScale(composed, baseWidth, baseHeight, width, height);
    }

    private static int[] bilinearScale(int[] source, int sw, int sh, int width, int height) {
        int[] output = new int[width * height];
        for (int y = 0; y < height; y++) {
            float sy = ((y + 0.5f) * sh / height) - 0.5f;
            for (int x = 0; x < width; x++) {
                float sx = ((x + 0.5f) * sw / width) - 0.5f;
                output[y * width + x] = sampleBilinear(source, sw, sh, sx, sy);
            }
        }
        return output;
    }

    public synchronized String status() {
        return "Yerel görsel sinir ağı: 16→128→64→3 · parametre=" + PARAMETER_COUNT
                + " · " + (trainedExamples > 0 ? "eğitildi" : "henüz kullanıcı örneğiyle eğitilmedi")
                + " · eğitim kaydı=" + trainedExamples + " · öğrenilen piksel=" + trainedPixels
                + " · etiket=" + labels + " · çoklu referans örneği=" + totalReferenceSampleCount()
                + (migratedLegacy ? " · eski 12→32→3 model taşındı" : "");
    }

    private synchronized int totalReferenceSampleCount() {
        int count = 0;
        for (String label : labels) count += findSamples(label).size();
        return count;
    }

    public synchronized int referenceSampleCount(String label) { return findSamples(normalize(label)).size(); }

    public long parameterCount() { return PARAMETER_COUNT; }

    private void forward(float[] input, float[] hidden1, float[] hidden2, float[] output) {
        for (int h = 0; h < HIDDEN_1; h++) {
            float sum = b1[h];
            for (int i = 0; i < INPUTS; i++) sum += w1[h][i] * input[i];
            hidden1[h] = (float) Math.tanh(sum);
        }
        for (int h = 0; h < HIDDEN_2; h++) {
            float sum = b2[h];
            for (int j = 0; j < HIDDEN_1; j++) sum += w2[h][j] * hidden1[j];
            hidden2[h] = (float) Math.tanh(sum);
        }
        for (int o = 0; o < OUTPUTS; o++) {
            float sum = b3[o];
            for (int h = 0; h < HIDDEN_2; h++) sum += w3[o][h] * hidden2[h];
            output[o] = 1f / (1f + (float) Math.exp(-sum));
        }
    }

    private static void makeInput(String prompt, float x, float y, float[] input) {
        input[0] = x; input[1] = y;
        input[2] = (float) Math.sin(x * Math.PI * 2); input[3] = (float) Math.cos(x * Math.PI * 2);
        input[4] = (float) Math.sin(x * Math.PI * 8); input[5] = (float) Math.cos(x * Math.PI * 8);
        input[6] = (float) Math.sin(y * Math.PI * 2); input[7] = (float) Math.cos(y * Math.PI * 2);
        input[8] = (float) Math.sin(y * Math.PI * 8); input[9] = (float) Math.cos(y * Math.PI * 8);
        input[10] = (float) Math.sin((x + y) * Math.PI * 4);
        input[11] = (float) Math.cos((x - y) * Math.PI * 4);
        String[] words = normalize(prompt).split("\\s+");
        for (int i = 12; i < INPUTS; i++) input[i] = 0f;
        int count = 0;
        for (String word : words) {
            if (word.isEmpty() || isPromptControlWord(word)) continue;
            int hash = word.hashCode();
            for (int i = 0; i < 4; i++) {
                int bits = (hash >>> (i * 7)) & 127;
                input[12 + i] += (bits / 63.5f) - 1f;
            }
            count++;
        }
        float divisor = Math.max(1, count);
        for (int i = 12; i < INPUTS; i++) input[i] /= divisor;
    }

    private static int sampleNearest(int[] pixels, int width, int height, float x, float y) {
        int sx = Math.max(0, Math.min(width - 1, Math.round(x)));
        int sy = Math.max(0, Math.min(height - 1, Math.round(y)));
        return pixels[sy * width + sx];
    }

    private static int sampleBilinear(int[] pixels, int width, int height, float x, float y) {
        float cx = Math.max(0, Math.min(width - 1, x));
        float cy = Math.max(0, Math.min(height - 1, y));
        int x0 = (int) Math.floor(cx), y0 = (int) Math.floor(cy);
        int x1 = Math.min(width - 1, x0 + 1), y1 = Math.min(height - 1, y0 + 1);
        float fx = cx - x0, fy = cy - y0;
        int c00 = pixels[y0 * width + x0], c10 = pixels[y0 * width + x1];
        int c01 = pixels[y1 * width + x0], c11 = pixels[y1 * width + x1];
        int a = mixChannel((c00 >>> 24) & 255, (c10 >>> 24) & 255, (c01 >>> 24) & 255, (c11 >>> 24) & 255, fx, fy);
        int r = mixChannel((c00 >>> 16) & 255, (c10 >>> 16) & 255, (c01 >>> 16) & 255, (c11 >>> 16) & 255, fx, fy);
        int g = mixChannel((c00 >>> 8) & 255, (c10 >>> 8) & 255, (c01 >>> 8) & 255, (c11 >>> 8) & 255, fx, fy);
        int b = mixChannel(c00 & 255, c10 & 255, c01 & 255, c11 & 255, fx, fy);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int mixChannel(int c00, int c10, int c01, int c11, float fx, float fy) {
        float top = c00 + (c10 - c00) * fx;
        float bottom = c01 + (c11 - c01) * fx;
        return clamp(Math.round(top + (bottom - top) * fy));
    }

    private static int[] nearestScale(int[] source, int sw, int sh, int width, int height) {
        int[] output = new int[width * height];
        for (int y = 0; y < height; y++) {
            int sy = Math.min(sh - 1, (int) ((long) y * sh / height));
            for (int x = 0; x < width; x++) {
                int sx = Math.min(sw - 1, (int) ((long) x * sw / width));
                output[y * width + x] = source[sy * sw + sx];
            }
        }
        return output;
    }

    private static String normalize(String text) {
        String q = text == null ? "" : text.toLowerCase(Locale.ROOT).trim();
        q = q.replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c');
        return q.replaceAll("\\s+", " ");
    }

    private static boolean synonymMatch(String query, String label) {
        if ("televizyon".equals(label)) return query.contains(" tv ") || query.contains("ekran");
        if ("kopek".equals(label)) return query.contains("dog");
        if ("araba".equals(label)) return query.contains("otomobil") || query.contains("car");
        return false;
    }

    private static boolean containsStyle(String query, String... words) {
        String q = normalize(query);
        for (String word : words) if (q.contains(normalize(word))) return true;
        return false;
    }

    private static boolean isPromptControlWord(String word) {
        return word.matches("(ciz|cizim|uret|olustur|yap|hazirla|tasarla|png|jpg|jpeg|resim|gorsel|video|mp4|720p|hd|piksel|sanat|kalite|cozunurluk|16|32|64|128|256|512|720|1080|1280|x|ve|icin|bir|ile)");
    }

    private static int clamp(int value) { return Math.max(0, Math.min(255, value)); }
}
