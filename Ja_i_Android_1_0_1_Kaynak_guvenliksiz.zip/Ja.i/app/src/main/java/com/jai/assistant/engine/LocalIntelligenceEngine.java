package com.jai.assistant.engine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Genel amaçlı bir dil modeli değildir. Yerel motorların etrafında çalışan,
 * isteği anlamlandıran, görev biçimini çıkaran ve belirsizlik sinyali üreten
 * deterministik karar katmanıdır. Harici ağ veya model kullanmaz.
 */
public final class LocalIntelligenceEngine {
    public enum TaskKind {
        GREETING, CALCULATION, MEMORY, CODE, LEARNING, RESEARCH,
        FILE_ANALYSIS, SUMMARY, COMPARISON, PROCEDURE, EXPLANATION, GENERAL
    }

    public static final class Analysis {
        public final String intent;
        public final TaskKind taskKind;
        public final double posteriorConfidence;
        public final double evidenceStrength;
        public final int knownTokenCount;
        public final int tokenCount;
        public final List<String> concepts;
        public final boolean requiresFreshInformation;
        public final boolean needsClarification;
        public final String clarificationQuestion;
        public final int complexity;

        private Analysis(String intent, TaskKind taskKind, double posteriorConfidence,
                         double evidenceStrength, int knownTokenCount, int tokenCount,
                         List<String> concepts, boolean requiresFreshInformation,
                         boolean needsClarification, String clarificationQuestion, int complexity) {
            this.intent = intent;
            this.taskKind = taskKind;
            this.posteriorConfidence = clamp(posteriorConfidence);
            this.evidenceStrength = clamp(evidenceStrength);
            this.knownTokenCount = Math.max(0, knownTokenCount);
            this.tokenCount = Math.max(0, tokenCount);
            this.concepts = Collections.unmodifiableList(new ArrayList<>(concepts));
            this.requiresFreshInformation = requiresFreshInformation;
            this.needsClarification = needsClarification;
            this.clarificationQuestion = clarificationQuestion == null ? "" : clarificationQuestion;
            this.complexity = Math.max(1, Math.min(5, complexity));
        }

        public String describe() {
            return "İstek türü: " + taskKind.name().toLowerCase(Locale.ROOT)
                    + " · niyet: " + intent
                    + " · sözlük kanıtı: " + knownTokenCount + "/" + tokenCount
                    + " · kanıt gücü: " + Math.round(evidenceStrength * 100) + "%"
                    + " · karmaşıklık: " + complexity + "/5"
                    + (requiresFreshInformation ? " · güncel bilgi gerekli" : "");
        }
    }

    private static final Set<String> GENERIC_CONCEPTS = new LinkedHashSet<>();
    static {
        Collections.addAll(GENERIC_CONCEPTS, "yap", "et", "ver", "bul", "anlat", "acikla", "kod", "program", "yaz", "nedir",
                "nasil", "neden", "lutfen", "bana", "bunu", "bunun", "icin", "hakkinda", "mi", "mu",
                "olan", "olarak", "daha", "bir", "ile", "ve", "veya", "icin", "istiyorum", "isterim",
                "karsilastir", "ozetle", "yaz", "olustur", "uret", "incele", "bak", "goster", "eder");
    }

    private LocalIntelligenceEngine() { }

    /**
     * Sınıflandırıcı çıktısını daha geniş istek profiline dönüştürür.
     * confidence tek başına karar sayılmaz; sözlükteki bilinen kelimeler de hesaba katılır.
     */
    public static Analysis analyze(String prompt, ModelEngine.Classification classification) {
        if (classification == null) return analyze(prompt, "genel", 0.0, 0.0, 0, 0);
        return analyze(prompt, classification.label, classification.confidence,
                classification.evidenceStrength, classification.knownTokenCount, classification.tokenCount);
    }

    /** Android/SQLite gerektirmeyen saf analiz girişi; birim testlerinde de kullanılır. */
    public static Analysis analyze(String prompt, String intent, double posteriorConfidence,
                                   double evidenceStrength, int knownTokenCount, int tokenCount) {
        String fullText = prompt == null ? "" : prompt.trim();
        int attachmentIndex = firstAttachmentMarker(fullText);
        String text = attachmentIndex >= 0 ? fullText.substring(0, attachmentIndex).trim() : fullText;
        if (text.isEmpty()) text = fullText;
        int attachmentCount = countAttachmentMarkers(fullText);
        String normalized = TurkishTextProcessor.normalize(text);
        List<String> tokens = TurkishTextProcessor.tokens(text);
        String safeIntent = intent == null ? "genel" : intent;
        double posterior = posteriorConfidence;
        double strength = evidenceStrength;
        int known = knownTokenCount;
        if (tokenCount < 0) tokenCount = tokens.size();

        TaskKind kind = detectTaskKind(normalized, safeIntent);
        List<String> concepts = extractConcepts(tokens);
        boolean localClockRequest = "zaman".equals(intent)
                || containsAny(normalized, "saat kac", "su an saat", "bugun tarih", "bugunun tarihi", "tarih nedir");
        boolean fresh = !localClockRequest && containsAny(normalized, "guncel", "bugun", "simdi", "su an", "son gelisme",
                "en son", "latest", "2026", "fiyat", "kur", "hava durumu", "haber", "mevcut surum");
        String clarification = clarificationFor(kind, normalized, concepts, text, attachmentCount);
        int complexity = estimateComplexity(text, tokens, kind);
        return new Analysis(safeIntent, kind, posterior, strength, known, tokenCount, concepts,
                fresh, !clarification.isEmpty(), clarification, complexity);
    }

    private static TaskKind detectTaskKind(String text, String intent) {
        if (containsAny(text, "merhaba", "selam", "gunaydin", "iyi aksamlar", "nasilsin", "naber")) return TaskKind.GREETING;
        if (containsAny(text, "hesapla", "kac eder", "kactir") || looksLikeArithmetic(text)) return TaskKind.CALCULATION;
        if (containsAny(text, "hafizada ara", "ne hatirliyorsun", "hatirla:", "hafizadan sil", "arsivle:", "arsivden cikar")) return TaskKind.MEMORY;
        if (containsAny(text, "kod yaz", "kod uret", "program yaz", "oyun yap", "uygulama yap", "script yaz", "fonksiyon yaz")) return TaskKind.CODE;
        if (containsAny(text, "ogren:", "ogren ", "ogret-intent", "konuyu ogren")) return TaskKind.LEARNING;
        if (containsAny(text, "dosya", "ekli belge", "pdf", "zip", "belgeyi oku", "dosyayi oku", "dosyayi incele")) return TaskKind.FILE_ANALYSIS;
        if (containsAny(text, "internette ara", "webde ara", "web arastir", "internetten", "kaynaklari arastir", "haberleri ara",
                "guncel surum", "son surum", "son gelisme", "hava durumu", "fiyatlari", "doviz kuru")
                || "arastirma".equals(intent)) return TaskKind.RESEARCH;
        if (containsAny(text, "ozetle", "ozet cikar", "ana fikir", "kisaca", "kisa ozet") || "ozet".equals(intent)) return TaskKind.SUMMARY;
        if (containsAny(text, "karsilastir", "arasindaki fark", "hangisi daha iyi", "benzerlikleri") || "karsilastirma".equals(intent)) return TaskKind.COMPARISON;
        if (containsAny(text, "adim adim", "nasil yapilir", "nasil yaparim", "kurulum", "yapmam gerekiyor")) return TaskKind.PROCEDURE;
        if (containsAny(text, "nedir", "ne demek", "neden", "nasil calisir", "acikla", "anlat")) return TaskKind.EXPLANATION;
        if ("matematik".equals(intent)) return TaskKind.CALCULATION;
        if ("hafiza".equals(intent)) return TaskKind.MEMORY;
        if ("kod".equals(intent)) return TaskKind.CODE;
        if ("ogrenme".equals(intent)) return TaskKind.LEARNING;
        if ("dosya".equals(intent)) return TaskKind.FILE_ANALYSIS;
        if ("zaman".equals(intent)) return TaskKind.GENERAL;
        return TaskKind.GENERAL;
    }

    private static List<String> extractConcepts(List<String> tokens) {
        List<String> result = new ArrayList<>();
        for (String token : tokens) {
            if (token.length() < 3 || GENERIC_CONCEPTS.contains(token)) continue;
            if (!result.contains(token)) result.add(token);
            if (result.size() >= 8) break;
        }
        return result;
    }

    private static String clarificationFor(TaskKind kind, String normalized, List<String> concepts,
                                           String requestText, int attachmentCount) {
        if (kind == TaskKind.COMPARISON && concepts.size() < 2 && attachmentCount < 2) {
            return "Hangi iki şeyi karşılaştırmamı istiyorsun? İkisini de yazabilir veya iki dosya ekleyebilirsin.";
        }
        if (kind == TaskKind.CODE && concepts.isEmpty()) {
            return "Ne tür bir kod veya program oluşturmamı istiyorsun? Amacını ve kullanacağımız dili belirtir misin?";
        }
        if (kind == TaskKind.SUMMARY && concepts.isEmpty() && requestText.indexOf('\n') < 0
                && requestText.length() < 35 && attachmentCount == 0) {
            return "Özetlememi istediğin metni veya dosyayı ekler misin?";
        }
        if (kind == TaskKind.FILE_ANALYSIS && !containsAny(normalized, "ekli", "dosya", "pdf", "zip", "belge")
                && attachmentCount == 0) {
            return "Hangi dosyayı incelememi istiyorsun?";
        }
        return "";
    }

    private static int firstAttachmentMarker(String text) {
        if (text == null || text.isEmpty()) return -1;
        int textMarker = text.indexOf("[Metin eki:");
        int fileMarker = text.indexOf("[Dosya eki:");
        if (textMarker < 0) return fileMarker;
        if (fileMarker < 0) return textMarker;
        return Math.min(textMarker, fileMarker);
    }

    private static int countAttachmentMarkers(String text) {
        if (text == null || text.isEmpty()) return 0;
        int count = 0;
        int from = 0;
        while (true) {
            int marker = firstAttachmentMarkerFrom(text, from);
            if (marker < 0) return count;
            count++;
            from = marker + 1;
        }
    }

    private static int firstAttachmentMarkerFrom(String text, int from) {
        int textMarker = text.indexOf("[Metin eki:", from);
        int fileMarker = text.indexOf("[Dosya eki:", from);
        if (textMarker < 0) return fileMarker;
        if (fileMarker < 0) return textMarker;
        return Math.min(textMarker, fileMarker);
    }

    private static int estimateComplexity(String text, List<String> tokens, TaskKind kind) {
        int score = 1;
        if (tokens.size() >= 8) score++;
        if (tokens.size() >= 16 || text.length() > 500) score++;
        if (containsAny(TurkishTextProcessor.normalize(text), "ve", "ayrica", "sonra", "ardindan", "karsilastir", "analiz et")) score++;
        if (kind == TaskKind.CODE || kind == TaskKind.RESEARCH || kind == TaskKind.FILE_ANALYSIS) score++;
        return Math.min(5, score);
    }

    private static boolean looksLikeArithmetic(String text) {
        return text.matches(".*\\d+\\s*[+*/-]\\s*\\d+.*");
    }

    private static boolean containsAny(String text, String... values) {
        for (String value : values) if (text.contains(value)) return true;
        return false;
    }

    private static double clamp(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }
}
