package com.jai.assistant.server;

import java.net.URI;

/** Sunucu adreslerini uygulama açılmadan önce doğrulayan saf Java kuralları. */
public final class ServerUrlRules {
    private ServerUrlRules() { }

    public static String normalizeBaseUrl(String input) throws Exception {
        if (input == null || input.trim().isEmpty()) throw new IllegalArgumentException("Sunucu adresini gir.");
        URI uri = new URI(input.trim());
        if (!"https".equalsIgnoreCase(uri.getScheme())) throw new IllegalArgumentException("Güvenlik için sunucu adresi https:// ile başlamalı.");
        if (uri.getHost() == null || uri.getUserInfo() != null || uri.getQuery() != null || uri.getFragment() != null) {
            throw new IllegalArgumentException("Geçerli, kullanıcı bilgisi içermeyen bir HTTPS sunucu adresi gir.");
        }
        String path = uri.getRawPath();
        if (path != null && !path.isEmpty() && !"/".equals(path)) throw new IllegalArgumentException("Sunucu adresine yol ekleme; yolu aşağıdaki ayrı alana yaz.");
        return "https://" + uri.getRawAuthority();
    }

    public static String normalizeHealthPath(String input) {
        String path = input == null || input.trim().isEmpty() ? "/health" : input.trim();
        if (!path.startsWith("/")) path = "/" + path;
        if (path.length() > 120 || path.contains("..") || path.contains("?") || path.contains("#") || path.contains("\\")) {
            throw new IllegalArgumentException("Bağlantı yolu geçersiz. Örnek: /health");
        }
        return path;
    }
}
