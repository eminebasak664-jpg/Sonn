package com.jai.assistant.engine;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Bedrock için kaynak paketi, davranış paketi ve iki paketi birleştiren add-on üreticisi. */
public final class MinecraftPackGenerator {
    public static final class Result {
        public final byte[] archiveBytes;
        public final String fileName;
        public final String mimeType;
        public final String description;
        public final String packType;
        public final int fileCount;
        Result(byte[] bytes, String fileName, String mime, String description, String packType, int fileCount) {
            this.archiveBytes=bytes; this.fileName=fileName; this.mimeType=mime;
            this.description=description; this.packType=packType; this.fileCount=fileCount;
        }
    }

    private static final String TARGET_CLIENT_VERSION = "1.21.132.1";
    private static final int[] TARGET_ENGINE_VERSION = {1, 21, 132};
    private final ProjectArchiveWriter archiveWriter = new ProjectArchiveWriter();
    private final ProceduralImageGenerator imageGenerator = new ProceduralImageGenerator();
    private final BedrockPackRepairEngine repairEngine = new BedrockPackRepairEngine();

    public boolean isMinecraftPackRequest(String prompt) {
        String q=normalize(prompt);
        boolean packageTerm=contains(q,"mcpack","mcaddon","mcworld",".jar","java jar","jar dosyasi","jar yap","jar olustur","jar uret","addon","add-on","davranis paketi","behavior pack","behaviour pack",
                "kaynak paketi","resource pack","texture pack","texturepack","minecraft add-on","minecraft addon","minecraft icin addon",
                "minecraft eklentisi","minecraft icin paket","minecraft paketi","minecraft dunyasi","minecraft world");
        boolean create=contains(q,"yap","olustur","uret","hazirla","tasarla","kodla","ekle");
        boolean minecraftCreation=q.contains("minecraft") && create && !contains(q,"minecraft benzeri oyun motoru","minecraft benzeri oyun yap");
        return (packageTerm || minecraftCreation) && create;
    }

    public Result generate(String prompt) throws IOException { return generate(prompt, ""); }

    /** Web araştırma kanıtı varsa paketin teknik notlarına ekler; üretici yine yerel kodla çalışır. */
    public Result generate(String prompt, String researchContext) throws IOException {
        String q=normalize(prompt);
        java.util.List<ItemSpec> itemSpecs = parseItemSpecs(prompt);
        CreatureSpec creatureSpec = parseCreatureSpec(prompt);
        int bulkCount = parseBulkCount(prompt);
        String projectNotes = projectNotes(prompt, researchContext, itemSpecs, bulkCount);
        if (contains(q,".jar","java jar","jar dosyasi","jar yap","jar olustur","jar uret")) return new SourceJarGenerator().generate(prompt);
        String displayName=extractName(prompt);
        String slug=slug(displayName);
        String bpUuid=UUID.randomUUID().toString();
        String bpModuleUuid=UUID.randomUUID().toString();
        String rpUuid=UUID.randomUUID().toString();
        String rpModuleUuid=UUID.randomUUID().toString();
        if (contains(q,"mcworld","minecraft dunyasi","dunya paketi","world export")) {
            Map<String,byte[]> resourceFiles = new LinkedHashMap<>();
            Map<String,byte[]> behaviorFiles = new LinkedHashMap<>();
            addResourcePack(resourceFiles, "", displayName + " Kaynak", rpUuid, rpModuleUuid, prompt, true);
            addBehaviorPack(behaviorFiles, "", displayName + " Davranış", bpUuid, bpModuleUuid, rpUuid, prompt, true);
            addDynamicItemResources(resourceFiles, itemSpecs, prompt);
            addDynamicItemsAndBulkFunction(behaviorFiles, itemSpecs, bulkCount);
            customizeCreatureFiles(resourceFiles, creatureSpec);
            customizeCreatureFiles(behaviorFiles, creatureSpec);
            put(resourceFiles, "JAI_PROJE_NOTLARI_TR.md", projectNotes);
            put(behaviorFiles, "JAI_PROJE_NOTLARI_TR.md", projectNotes);
            String validationSummary = repairInPlace(resourceFiles) + " " + repairInPlace(behaviorFiles);
            long seed = new Random(prompt == null ? System.nanoTime() : prompt.hashCode()).nextLong();
            byte[] world = new BedrockWorldArchiveGenerator().create(displayName, seed, rpUuid, bpUuid, resourceFiles, behaviorFiles);
            return new Result(world, slug.isEmpty() ? "jai-dunya.mcworld" : slug + ".mcworld", "application/zip",
                    "Bedrock .mcworld kapsayıcısı oluşturuldu: level.dat, dünya ayarları, kaynak/davranış paketleri, dinamik eşya tanımları, animasyon, ses, script ve proje notları içerir. Hedef istemci: " + TARGET_CLIENT_VERSION + ". " + validationSummary + " db/ klasörü Minecraft tarafından ilk açılışta başlatılmak üzere bırakıldı; gerçek Minecraft içe aktarma/açma testi yapılmalıdır.", "mcworld", resourceFiles.size() + behaviorFiles.size() + 5);
        }
        boolean wantsResource=contains(q,"kaynak","resource","texture","doku");
        boolean wantsBehavior=contains(q,"davranis","behavior","behaviour");
        boolean combined=contains(q,"mcaddon","addon","add-on","eklenti","tam paket")
                || (!wantsResource && !wantsBehavior)
                || (wantsResource && wantsBehavior)
                || contains(q,"yaratik","mob","ejderha","kedi","canavar","blok ve esya","esya ve blok");
        boolean resourceOnly=wantsResource && !wantsBehavior && !combined;
        boolean behaviorOnly=wantsBehavior && !wantsResource && !combined;

        Map<String,byte[]> files=new LinkedHashMap<>();
        int generatedFileCount;
        String validationSummary;
        if(resourceOnly) {
            addResourcePack(files, "", displayName, rpUuid, rpModuleUuid, prompt, true);
            addDynamicItemResources(files, itemSpecs, prompt);
            customizeCreatureFiles(files, creatureSpec);
            put(files, "JAI_PROJE_NOTLARI_TR.md", projectNotes);
            validationSummary = repairInPlace(files);
            generatedFileCount = files.size();
        } else if(behaviorOnly) {
            addBehaviorPack(files, "", displayName, bpUuid, bpModuleUuid, null, prompt, true);
            addDynamicItemsAndBulkFunction(files, itemSpecs, bulkCount);
            customizeCreatureFiles(files, creatureSpec);
            put(files, "JAI_PROJE_NOTLARI_TR.md", projectNotes);
            validationSummary = repairInPlace(files);
            generatedFileCount = files.size();
        } else {
            Map<String, byte[]> resourcePackFiles = new LinkedHashMap<>();
            Map<String, byte[]> behaviorPackFiles = new LinkedHashMap<>();
            addResourcePack(resourcePackFiles, "", displayName + " Kaynak", rpUuid, rpModuleUuid, prompt, true);
            addBehaviorPack(behaviorPackFiles, "", displayName + " Davranış", bpUuid, bpModuleUuid, rpUuid, prompt, true);
            addDynamicItemResources(resourcePackFiles, itemSpecs, prompt);
            addDynamicItemsAndBulkFunction(behaviorPackFiles, itemSpecs, bulkCount);
            customizeCreatureFiles(resourcePackFiles, creatureSpec);
            customizeCreatureFiles(behaviorPackFiles, creatureSpec);
            put(resourcePackFiles, "JAI_PROJE_NOTLARI_TR.md", projectNotes);
            put(behaviorPackFiles, "JAI_PROJE_NOTLARI_TR.md", projectNotes);
            validationSummary = repairInPlace(resourcePackFiles) + " " + repairInPlace(behaviorPackFiles);
            // Microsoft .mcaddon biçimi: dış ZIP içinde ayrı .mcpack paketleri bulunur.
            files.put(slug + "-kaynak.mcpack", archiveWriter.createZipBinary(resourcePackFiles));
            files.put(slug + "-davranis.mcpack", archiveWriter.createZipBinary(behaviorPackFiles));
            put(files, "JAI_PROJE_NOTLARI_TR.md", projectNotes);
            generatedFileCount = resourcePackFiles.size() + behaviorPackFiles.size();
        }

        byte[] archive=archiveWriter.createZipBinary(files);
        String extension=resourceOnly?"mcpack":behaviorOnly?"mcpack":"mcaddon";
        String base=slug.isEmpty()?"jai-minecraft":slug;
        String description;
        if(resourceOnly) description="Bedrock kaynak/texture paketi oluşturuldu. PNG blok/eşya/yaratık dokuları, geometri, 7 animasyon, animasyon denetleyicisi, ses tanımları ve OGG dosyaları, eşya atlası, dil dosyaları ve manifest içerir.";
        else if(behaviorOnly) description="Bedrock davranış paketi oluşturuldu. Özel yaratık ve davranışları, spawn kuralları, özel blok/eşya/tarifler, loot tabloları, mcfunction, Script API başlangıcı ve manifest içerir.";
        else description="Bedrock tam add-on oluşturuldu: dış .mcaddon içinde iki ayrı iç .mcpack (kaynak + davranış); özel yaratık, spawn/loot, blok/eşya/tarif, 7 animasyon, durum denetleyicisi, render controller, OGG sesler, Script API ve PNG dokuları.";
        if (contains(q, "itemler", "esya", "eşya") && itemSpecs.isEmpty()) {
            description += " İstenen eşya adlarından uygun olmayanlar elendi; zararsız dekoratif/yardımcı bir varsayılan eşya kullanıldı. ";
        }
        description += " Hedef Android istemci profili: " + TARGET_CLIENT_VERSION + " (Bedrock içerik minimum motor sürümü 1.21.132). "
                + "Özel eşya sayısı: " + itemSpecs.size() + "; istenen toplu adet: " + bulkCount + ". Bedrock tek yığın sınırı nedeniyle her yığın en fazla 64 olacak; give fonksiyonu istenen toplamı yasal yığınlara böler. "
                + "Paket içeriğindeki dosyalar: " + generatedFileCount + ". " + validationSummary
                + " Gerçek Minecraft uygulamasında içe aktarma/oynanış testi bu ortamda yapılamadı.";
        return new Result(archive, base+"."+extension, "application/zip", description,
                resourceOnly?"resource_pack":behaviorOnly?"behavior_pack":"mcaddon", generatedFileCount);
    }

    private void addResourcePack(Map<String,byte[]> files, String prefix, String name,
                                 String headerUuid, String moduleUuid, String prompt, boolean addon) throws IOException {
        put(files,prefix+"manifest.json",resourceManifest(name,headerUuid,moduleUuid));
        ProceduralImageGenerator.Result block = imageGenerator.generateMinecraftTexture(prompt+" yeşil taşlı minecraft blok dokusu",64);
        ProceduralImageGenerator.Result item = imageGenerator.generate(prompt+" mor kristal minecraft eşya ikonu",64,64);
        put(files,prefix+"textures/blocks/dirt.png",block.pngBytes);
        put(files,prefix+"textures/items/jai_crystal.png",item.pngBytes);
        if (addon) {
            put(files,prefix+"textures/blocks/jai_moonstone.png",block.pngBytes);
            put(files,prefix+"textures/terrain_texture.json",terrainTextureJson(name));
        }
        put(files,prefix+"textures/item_texture.json", "{\n  \"resource_pack_name\": \""+json(name)+"\",\n  \"texture_name\": \"atlas.items\",\n  \"texture_data\": {\n    \"jai_crystal\": {\"textures\": \"textures/items/jai_crystal\"}\n  }\n}\n");
        put(files,prefix+"texts/languages.json","[\"en_US\",\"tr_TR\"]\n");
        put(files,prefix+"texts/en_US.lang","item.jai:moon_crystal.name=Moon Crystal\ntile.jai:moonstone.name=Moonstone\n");
        put(files,prefix+"texts/tr_TR.lang","item.jai:moon_crystal.name=Ay Kristali\ntile.jai:moonstone.name=Ay Taşı\n");
        if(addon) {
            ProceduralImageGenerator.Result mobTexture=imageGenerator.generateMinecraftTexture(prompt,64);
            put(files,prefix+"textures/entity/jai_companion.png",mobTexture.pngBytes);
            boolean dragon = isDragonPrompt(prompt);
            put(files,prefix+"models/entity/jai_companion.geo.json",dragon ? dragonGeometryJson() : geometryJson());
            put(files,prefix+"entity/jai_companion.entity.json",clientEntityJson());
            put(files,prefix+"animations/jai_companion.animation.json",dragon ? dragonAnimationJson() : animationJson());
            put(files,prefix+"animation_controllers/jai_companion.controller.json",animationControllerJson());
            put(files,prefix+"render_controllers/jai_companion.render_controllers.json",renderControllerJson());
            put(files,prefix+"sounds/sound_definitions.json",soundDefinitionsJson());
            put(files,prefix+"sounds/mob/jai_companion/idle.ogg",MinecraftSoundAssets.idle());
            put(files,prefix+"sounds/mob/jai_companion/walk.ogg",MinecraftSoundAssets.walk());
            put(files,prefix+"sounds/mob/jai_companion/attack.ogg",MinecraftSoundAssets.attack());
        }
    }

    private void addBehaviorPack(Map<String,byte[]> files, String prefix, String name,
                                 String headerUuid, String moduleUuid, String dependencyUuid,
                                 String prompt, boolean addon) {
        String scriptModuleUuid = UUID.randomUUID().toString();
        put(files,prefix+"manifest.json",behaviorManifest(name,headerUuid,moduleUuid,dependencyUuid,scriptModuleUuid));
        put(files,prefix+"recipes/jai_golden_apple.json",goldenAppleRecipe());
        put(files,prefix+"loot_tables/chests/jai_bonus.json",lootTable());
        put(files,prefix+"functions/jai_info.mcfunction","say Ja.i yerel paketinin işlev dosyası çalıştı!\n");
        put(files,prefix+"functions/jai_summon.mcfunction","summon jai:forest_companion ~ ~ ~\n");
        put(files,prefix+"functions/jai_effect.mcfunction","particle minecraft:basic_crit_particle ~ ~1 ~\n");
        put(files,prefix+"scripts/main.js",scriptSource());
        if(addon) {
            put(files,prefix+"entities/jai_companion.json",behaviorEntity(prompt));
            put(files,prefix+"spawn_rules/jai_companion.json",spawnRules(prompt));
            put(files,prefix+"loot_tables/entities/jai_companion.json",entityLoot());
            put(files,prefix+"items/jai_moon_crystal.json",customItem());
            put(files,prefix+"recipes/jai_moon_crystal.json",crystalRecipe());
            put(files,prefix+"blocks/jai_moonstone.json",customBlock());
            put(files,prefix+"recipes/jai_moonstone.json",blockRecipe());
            put(files,prefix+"loot_tables/blocks/jai_moonstone.json",blockLoot());
        }
    }

    private String resourceManifest(String name,String header,String module) {
        return "{\n  \"format_version\": 2,\n  \"header\": {\n    \"name\": \""+json(name)+"\",\n    \"description\": \"Ja.i tarafından çevrimdışı oluşturulan Bedrock kaynak paketi\",\n    \"uuid\": \""+header+"\",\n    \"version\": [1, 0, 0],\n    \"min_engine_version\": [1, 21, 132]\n  },\n  \"modules\": [{\n    \"type\": \"resources\",\n    \"uuid\": \""+module+"\",\n    \"version\": [1, 0, 0]\n  }]\n}\n";
    }

    private String behaviorManifest(String name,String header,String module,String dependency,String scriptModule) {
        String dep=dependency==null?"":",\n    {\n      \"uuid\": \""+dependency+"\",\n      \"version\": [1, 0, 0]\n    }";
        return "{\n  \"format_version\": 2,\n  \"header\": {\n    \"name\": \""+json(name)+"\",\n    \"description\": \"Ja.i tarafından çevrimdışı oluşturulan Bedrock davranış paketi\",\n    \"uuid\": \""+header+"\",\n    \"version\": [1, 0, 0],\n    \"min_engine_version\": [1, 21, 132]\n  },\n  \"modules\": [{\n    \"type\": \"data\",\n    \"uuid\": \""+module+"\",\n    \"version\": [1, 0, 0]\n  }, {\n    \"type\": \"script\",\n    \"language\": \"javascript\",\n    \"uuid\": \""+scriptModule+"\",\n    \"version\": [1, 0, 0],\n    \"entry\": \"scripts/main.js\"\n  }],\n  \"dependencies\": [{\n    \"module_name\": \"@minecraft/server\",\n    \"version\": \"2.4.0\"\n  }"+dep+"]\n}\n";
    }

    private String behaviorEntity(String prompt) {
        String q = normalize(prompt);
        boolean dragon = isDragonPrompt(prompt);
        int health = contains(q, "canli", "tank gibi", "dayanikli", "guclu") ? 50 : (dragon ? 200 : 24);
        double speed = contains(q, "hizli", "suratli") ? 0.32 : (dragon ? 0.30 : 0.22);
        boolean peaceful = contains(q, "pasif", "dost", "evcil", "bariscil", "friendly");
        boolean aggressive = contains(q, "saldirgan", "agresif", "dusman", "dusmanca") || (dragon && !peaceful);
        String movementComponents = dragon
                ? "\"minecraft:movement.fly\": {},\n      \"minecraft:navigation.fly\": {\"can_path_over_water\": true},"
                : "\"minecraft:movement.basic\": {},\n      \"minecraft:navigation.walk\": {\"can_path_over_water\": true, \"avoid_water\": false},\n      \"minecraft:jump.static\": {},";
        String collision = dragon ? "{\"width\": 2.4, \"height\": 3.2}" : "{\"width\": 0.8, \"height\": 1.4}";
        String family = dragon ? "[\"jai_companion\", \"mob\", \"monster\", \"flying\"]" : "[\"jai_companion\", \"mob\"]";
        String behaviors = aggressive
                ? "\"minecraft:behavior.nearest_attackable_target\": {\"priority\": 1, \"must_see\": true, \"entity_types\": [{\"filters\": {\"test\": \"is_family\", \"subject\": \"other\", \"value\": \"player\"}, \"max_dist\": 24}]},\n      \"minecraft:behavior.melee_attack\": {\"priority\": 2, \"speed_multiplier\": 1.2, \"track_target\": true},\n      \"minecraft:behavior.hurt_by_target\": {\"priority\": 3}"
                : "\"minecraft:behavior.look_at_player\": {\"priority\": 7, \"look_distance\": 8},\n      \"minecraft:behavior.random_look_around\": {\"priority\": 8}";
        String movementBehavior = dragon ? "\"minecraft:behavior.random_fly\": {\"priority\": 3, \"xz_dist\": 12, \"y_dist\": 6, \"y_offset\": 1, \"speed_multiplier\": 1.0, \"avoid_damage_blocks\": true}," : "\"minecraft:behavior.random_stroll\": {\"priority\": 6, \"speed_multiplier\": 1.0},";
        return "{\n  \"format_version\": \"1.20.80\",\n  \"minecraft:entity\": {\n    \"description\": {\n      \"identifier\": \"jai:forest_companion\",\n      \"is_spawnable\": true,\n      \"is_summonable\": true,\n      \"is_experimental\": false\n    },\n    \"components\": {\n      \"minecraft:type_family\": {\"family\": "+family+"},\n      \"minecraft:health\": {\"value\": "+health+", \"max\": "+health+"},\n      \"minecraft:movement\": {\"value\": "+speed+"},\n      \"minecraft:collision_box\": "+collision+",\n      \"minecraft:physics\": {},\n      "+movementComponents+"\n      \"minecraft:pushable\": {\"is_pushable\": true, \"is_pushable_by_piston\": true},\n      \"minecraft:loot\": {\"table\": \"loot_tables/entities/jai_companion.json\"},\n      \"minecraft:behavior.float\": {\"priority\": 0},\n      "+movementBehavior+"\n      \"minecraft:ambient_sound_interval\": {\"event_name\": \"ambient\", \"value\": 8, \"range\": 16},\n      "+behaviors+"\n    },\n    \"events\": {\n      \"minecraft:on_hurt\": {\"play_sound\": {\"sound\": \"jai:companion.hurt\"}},\n      \"minecraft:on_target_acquired\": {\"play_sound\": {\"sound\": \"jai:companion.attack\"}}\n    }\n  }\n}\n";
    }

    private boolean isDragonPrompt(String prompt) {
        return contains(normalize(prompt), "ejderha", "dragon");
    }

    private String clientEntityJson() {
        return """
                {
                  "format_version": "1.10.0",
                  "minecraft:client_entity": {
                    "description": {
                      "identifier": "jai:forest_companion",
                      "materials": {"default": "entity_alphatest"},
                      "textures": {"default": "textures/entity/jai_companion"},
                      "geometry": {"default": "geometry.jai_companion"},
                      "animations": {
                        "idle": "animation.jai_companion.idle",
                        "walk": "animation.jai_companion.walk",
                        "run": "animation.jai_companion.run",
                        "attack": "animation.jai_companion.attack",
                        "hurt": "animation.jai_companion.hurt",
                        "jump": "animation.jai_companion.jump",
                        "sit": "animation.jai_companion.sit",
                        "controller": "controller.animation.jai_companion.main"
                      },
                      "scripts": {"animate": ["controller"]},
                      "sound_effects": {
                        "ambient": "jai:companion.idle",
                        "hurt": "jai:companion.hurt",
                        "death": "jai:companion.attack"
                      },
                      "render_controllers": ["controller.render.jai_companion"]
                    }
                  }
                }
                """;
    }

    private String animationJson() {
        return """
                {
                  "format_version": "1.10.0",
                  "animations": {
                    "animation.jai_companion.idle": {
                      "loop": true,
                      "animation_length": 2.0,
                      "bones": {
                        "body": {"position": {"0.0": [0,0,0], "1.0": [0,0.45,0], "2.0": [0,0,0]}},
                        "head": {"rotation": {"0.0": [0,0,0], "1.0": [0,3,0], "2.0": [0,0,0]}},
                        "tail": {"rotation": {"0.0": [0,-12,0], "1.0": [0,12,0], "2.0": [0,-12,0]}}
                      }
                    },
                    "animation.jai_companion.walk": {
                      "loop": true,
                      "animation_length": 0.8,
                      "bones": {
                        "left_leg": {"rotation": {"0.0": [-24,0,0], "0.4": [24,0,0], "0.8": [-24,0,0]}},
                        "right_leg": {"rotation": {"0.0": [24,0,0], "0.4": [-24,0,0], "0.8": [24,0,0]}},
                        "body": {"position": {"0.0": [0,0,0], "0.4": [0,0.7,0], "0.8": [0,0,0]}},
                        "left_arm": {"rotation": {"0.0": [24,0,0], "0.4": [-24,0,0], "0.8": [24,0,0]}},
                        "right_arm": {"rotation": {"0.0": [-24,0,0], "0.4": [24,0,0], "0.8": [-24,0,0]}},
                        "tail": {"rotation": {"0.0": [0,-18,0], "0.4": [0,18,0], "0.8": [0,-18,0]}}
                      }
                    },
                    "animation.jai_companion.run": {
                      "loop": true,
                      "animation_length": 0.48,
                      "bones": {
                        "left_leg": {"rotation": {"0.0": [-34,0,0], "0.24": [34,0,0], "0.48": [-34,0,0]}},
                        "right_leg": {"rotation": {"0.0": [34,0,0], "0.24": [-34,0,0], "0.48": [34,0,0]}},
                        "body": {"position": {"0.0": [0,0,0], "0.24": [0,1.1,0], "0.48": [0,0,0]}},
                        "left_arm": {"rotation": {"0.0": [38,0,0], "0.24": [-38,0,0], "0.48": [38,0,0]}},
                        "right_arm": {"rotation": {"0.0": [-38,0,0], "0.24": [38,0,0], "0.48": [-38,0,0]}}
                      }
                    },
                    "animation.jai_companion.attack": {
                      "loop": false,
                      "animation_length": 0.55,
                      "bones": {
                        "body": {"rotation": {"0.0": [0,0,0], "0.22": [-18,0,0], "0.55": [0,0,0]}},
                        "head": {"rotation": {"0.0": [0,0,0], "0.22": [12,0,0], "0.55": [0,0,0]}},
                        "right_leg": {"rotation": {"0.0": [0,0,0], "0.22": [-12,0,0], "0.55": [0,0,0]}},
                        "right_arm": {"rotation": {"0.0": [0,0,0], "0.22": [-55,0,0], "0.55": [0,0,0]}}
                      }
                    },
                    "animation.jai_companion.hurt": {
                      "loop": false,
                      "animation_length": 0.35,
                      "bones": {
                        "body": {"rotation": {"0.0": [0,0,0], "0.1": [0,0,16], "0.35": [0,0,0]}},
                        "head": {"rotation": {"0.0": [0,0,0], "0.1": [-12,0,0], "0.35": [0,0,0]}}
                      }
                    },
                    "animation.jai_companion.jump": {
                      "loop": false,
                      "animation_length": 0.55,
                      "bones": {
                        "body": {"position": {"0.0": [0,0,0], "0.24": [0,2,0], "0.55": [0,0,0]}},
                        "left_leg": {"rotation": {"0.0": [0,0,0], "0.24": [-28,0,0], "0.55": [0,0,0]}}
                      }
                    },
                    "animation.jai_companion.sit": {
                      "loop": true,
                      "animation_length": 1.0,
                      "bones": {
                        "body": {"rotation": [0,0,0]},
                        "head": {"rotation": {"0.0": [0,0,0], "0.5": [4,0,0], "1.0": [0,0,0]}}
                      }
                    }
                  }
                }
                """;
    }

    private String dragonGeometryJson() {
        return """
                {
                  "format_version": "1.12.0",
                  "minecraft:geometry": [{
                    "description": {
                      "identifier": "geometry.jai_companion",
                      "texture_width": 64,
                      "texture_height": 64,
                      "visible_bounds_width": 5,
                      "visible_bounds_height": 4.5,
                      "visible_bounds_offset": [0, 1.2, 0]
                    },
                    "bones": [
                      {"name": "root", "pivot": [0, 0, 0]},
                      {"name": "body", "parent": "root", "pivot": [0, 10, 0], "cubes": [{"origin": [-5, 5, -8], "size": [10, 9, 16], "uv": [0, 16]}]},
                      {"name": "neck", "parent": "body", "pivot": [0, 11, -7], "cubes": [{"origin": [-3, 9, -13], "size": [6, 5, 7], "uv": [0, 0]}]},
                      {"name": "head", "parent": "neck", "pivot": [0, 12, -12], "cubes": [{"origin": [-3, 10, -17], "size": [6, 5, 7], "uv": [24, 0]}, {"origin": [-2, 14, -16], "size": [1, 3, 2], "uv": [40, 0]}, {"origin": [1, 14, -16], "size": [1, 3, 2], "uv": [40, 8]}]},
                      {"name": "left_wing", "parent": "body", "pivot": [4, 12, -1], "cubes": [{"origin": [4, 11, -3], "size": [12, 1, 10], "uv": [0, 32]}, {"origin": [13, 10, 0], "size": [3, 1, 9], "uv": [0, 44]}]},
                      {"name": "right_wing", "parent": "body", "pivot": [-4, 12, -1], "cubes": [{"origin": [-16, 11, -3], "size": [12, 1, 10], "uv": [24, 32]}, {"origin": [-16, 10, 0], "size": [3, 1, 9], "uv": [24, 44]}]},
                      {"name": "left_leg", "parent": "body", "pivot": [3, 7, 5], "cubes": [{"origin": [2, 1, 4], "size": [3, 6, 3], "uv": [48, 0]}]},
                      {"name": "right_leg", "parent": "body", "pivot": [-3, 7, 5], "cubes": [{"origin": [-5, 1, 4], "size": [3, 6, 3], "uv": [48, 12]}]},
                      {"name": "tail", "parent": "body", "pivot": [0, 9, 7], "cubes": [{"origin": [-2, 7, 7], "size": [4, 4, 9], "uv": [0, 48]}]},
                      {"name": "tail_tip", "parent": "tail", "pivot": [0, 9, 15], "cubes": [{"origin": [-1, 8, 15], "size": [2, 2, 5], "uv": [24, 48]}]}
                    ]
                  }]
                }
                """;
    }

    private String dragonAnimationJson() {
        return """
                {
                  "format_version": "1.10.0",
                  "animations": {
                    "animation.jai_companion.idle": {"loop": true, "animation_length": 1.2, "bones": {
                      "body": {"position": {"0.0": [0,0,0], "0.6": [0,0.6,0], "1.2": [0,0,0]}},
                      "left_wing": {"rotation": {"0.0": [0,0,18], "0.3": [0,0,62], "0.6": [0,0,18], "0.9": [0,0,62], "1.2": [0,0,18]}},
                      "right_wing": {"rotation": {"0.0": [0,0,-18], "0.3": [0,0,-62], "0.6": [0,0,-18], "0.9": [0,0,-62], "1.2": [0,0,-18]}},
                      "tail": {"rotation": {"0.0": [0,-8,0], "0.6": [0,8,0], "1.2": [0,-8,0]}}
                    }},
                    "animation.jai_companion.walk": {"loop": true, "animation_length": 0.7, "bones": {
                      "left_wing": {"rotation": {"0.0": [0,0,28], "0.35": [0,0,54], "0.7": [0,0,28]}},
                      "right_wing": {"rotation": {"0.0": [0,0,-28], "0.35": [0,0,-54], "0.7": [0,0,-28]}},
                      "left_leg": {"rotation": {"0.0": [-18,0,0], "0.35": [18,0,0], "0.7": [-18,0,0]}},
                      "right_leg": {"rotation": {"0.0": [18,0,0], "0.35": [-18,0,0], "0.7": [18,0,0]}},
                      "tail": {"rotation": {"0.0": [0,-12,0], "0.35": [0,12,0], "0.7": [0,-12,0]}}
                    }},
                    "animation.jai_companion.run": {"loop": true, "animation_length": 0.42, "bones": {
                      "left_wing": {"rotation": {"0.0": [0,0,12], "0.21": [0,0,72], "0.42": [0,0,12]}},
                      "right_wing": {"rotation": {"0.0": [0,0,-12], "0.21": [0,0,-72], "0.42": [0,0,-12]}},
                      "body": {"position": {"0.0": [0,0,0], "0.21": [0,1,0], "0.42": [0,0,0]}}
                    }},
                    "animation.jai_companion.attack": {"loop": false, "animation_length": 0.65, "bones": {
                      "head": {"rotation": {"0.0": [0,0,0], "0.25": [-24,0,0], "0.65": [0,0,0]}},
                      "body": {"rotation": {"0.0": [0,0,0], "0.25": [-16,0,0], "0.65": [0,0,0]}},
                      "left_wing": {"rotation": {"0.0": [0,0,20], "0.25": [0,0,78], "0.65": [0,0,20]}},
                      "right_wing": {"rotation": {"0.0": [0,0,-20], "0.25": [0,0,-78], "0.65": [0,0,-20]}}
                    }},
                    "animation.jai_companion.hurt": {"loop": false, "animation_length": 0.4, "bones": {
                      "body": {"rotation": {"0.0": [0,0,0], "0.12": [0,0,18], "0.4": [0,0,0]}},
                      "left_wing": {"rotation": {"0.0": [0,0,18], "0.12": [0,0,5], "0.4": [0,0,18]}},
                      "right_wing": {"rotation": {"0.0": [0,0,-18], "0.12": [0,0,-5], "0.4": [0,0,-18]}}
                    }},
                    "animation.jai_companion.jump": {"loop": false, "animation_length": 0.6, "bones": {
                      "body": {"position": {"0.0": [0,0,0], "0.25": [0,2.5,0], "0.6": [0,0,0]}},
                      "left_wing": {"rotation": {"0.0": [0,0,18], "0.25": [0,0,82], "0.6": [0,0,18]}},
                      "right_wing": {"rotation": {"0.0": [0,0,-18], "0.25": [0,0,-82], "0.6": [0,0,-18]}}
                    }},
                    "animation.jai_companion.sit": {"loop": true, "animation_length": 1.0, "bones": {
                      "body": {"rotation": [0,12,0]},
                      "left_wing": {"rotation": [0,0,8]},
                      "right_wing": {"rotation": [0,0,-8]},
                      "tail": {"rotation": [0,0,0]}
                    }}
                  }
                }
                """;
    }

    private String animationControllerJson() {
        return """
                {
                  "format_version": "1.10.0",
                  "animation_controllers": {
                    "controller.animation.jai_companion.main": {
                      "initial_state": "idle",
                      "states": {
                        "idle": {"animations": ["idle"], "transitions": [
                          {"hurt": "query.hurt_time > 0"},
                          {"jumping": "!query.is_on_ground"},
                          {"sitting": "query.is_sitting"},
                          {"attacking": "query.is_angry"},
                          {"walking": "query.modified_move_speed > 0.05"}
                        ]},
                        "walking": {"animations": ["walk"], "transitions": [
                          {"hurt": "query.hurt_time > 0"},
                          {"jumping": "!query.is_on_ground"},
                          {"attacking": "query.is_angry"},
                          {"running": "query.is_sprinting"},
                          {"idle": "query.modified_move_speed <= 0.05"}
                        ]},
                        "running": {"animations": ["run"], "transitions": [
                          {"hurt": "query.hurt_time > 0"},
                          {"jumping": "!query.is_on_ground"},
                          {"attacking": "query.is_angry"},
                          {"walking": "!query.is_sprinting"}
                        ]},
                        "attacking": {"animations": ["attack"], "transitions": [
                          {"hurt": "query.hurt_time > 0"},
                          {"idle": "query.all_animations_finished"}
                        ]},
                        "hurt": {"animations": ["hurt"], "transitions": [
                          {"idle": "query.all_animations_finished"}
                        ]},
                        "jumping": {"animations": ["jump"], "transitions": [
                          {"idle": "query.is_on_ground"}
                        ]},
                        "sitting": {"animations": ["sit"], "transitions": [
                          {"idle": "!query.is_sitting"}
                        ]}
                      }
                    }
                  }
                }
                """;
    }

    private String renderControllerJson() {
        return "{\n  \"format_version\": \"1.10.0\",\n  \"render_controllers\": {\n    \"controller.render.jai_companion\": {\n      \"geometry\": \"Geometry.default\",\n      \"materials\": [{\"*\": \"Material.default\"}],\n      \"textures\": [\"Texture.default\"]\n    }\n  }\n}\n";
    }

    private String soundDefinitionsJson() {
        return "{\n  \"format_version\": \"1.20.20\",\n  \"sound_definitions\": {\n"
                + "    \"jai:companion.idle\": {\"category\": \"neutral\", \"sounds\": [{\"name\": \"sounds/mob/jai_companion/idle\", \"volume\": 0.65}]},\n"
                + "    \"jai:companion.walk\": {\"category\": \"neutral\", \"sounds\": [{\"name\": \"sounds/mob/jai_companion/walk\", \"volume\": 0.5}]},\n"
                + "    \"jai:companion.attack\": {\"category\": \"neutral\", \"sounds\": [{\"name\": \"sounds/mob/jai_companion/attack\", \"volume\": 0.8}]},\n"
                + "    \"jai:companion.hurt\": {\"category\": \"neutral\", \"sounds\": [{\"name\": \"sounds/mob/jai_companion/attack\", \"volume\": 0.65}]}\n"
                + "  }\n}\n";
    }

    private String scriptSource() {
        return "import { world, system } from \"@minecraft/server\";\n\n"
                + "const COMPANION = \"jai:forest_companion\";\n"
                + "world.afterEvents.entitySpawn.subscribe((event) => {\n"
                + "  const entity = event.entity;\n"
                + "  if (entity.typeId !== COMPANION) return;\n"
                + "  try { entity.nameTag = \"Ja.i Companion\"; entity.addTag(\"jai_spawned\"); }\n"
                + "  catch (error) { console.warn(\"Ja.i entity init: \" + error); }\n"
                + "});\n\n"
                + "// Periyodik kontrol: varlığı silmez/değiştirmez; etiket ve adın korunmasını sağlar.\n"
                + "system.runInterval(() => {\n"
                + "  for (const dimension of [world.getDimension(\"overworld\"), world.getDimension(\"nether\"), world.getDimension(\"the_end\")]) {\n"
                + "    for (const entity of dimension.getEntities({ type: COMPANION })) {\n"
                + "      if (!entity.hasTag(\"jai_spawned\")) entity.addTag(\"jai_spawned\");\n"
                + "    }\n"
                + "  }\n"
                + "}, 100);\n";
    }

    private String geometryJson() {
        return """
                {
                  "format_version": "1.12.0",
                  "minecraft:geometry": [{
                    "description": {
                      "identifier": "geometry.jai_companion",
                      "texture_width": 64,
                      "texture_height": 64,
                      "visible_bounds_width": 2,
                      "visible_bounds_height": 2.5,
                      "visible_bounds_offset": [0, 0.75, 0]
                    },
                    "bones": [
                      {"name": "root", "pivot": [0, 0, 0]},
                      {"name": "body", "parent": "root", "pivot": [0, 8, 0], "cubes": [{"origin": [-4, 4, -2], "size": [8, 8, 4], "uv": [0, 16]}]},
                      {"name": "head", "parent": "root", "pivot": [0, 12, 0], "cubes": [{"origin": [-4, 12, -4], "size": [8, 8, 8], "uv": [0, 0]}]},
                      {"name": "left_arm", "parent": "body", "pivot": [4, 10, 0], "cubes": [{"origin": [4, 5, -1], "size": [3, 7, 2], "uv": [40, 0]}]},
                      {"name": "right_arm", "parent": "body", "pivot": [-4, 10, 0], "cubes": [{"origin": [-7, 5, -1], "size": [3, 7, 2], "uv": [40, 18]}]},
                      {"name": "left_leg", "parent": "root", "pivot": [2, 6, 0], "cubes": [{"origin": [1, 0, -1], "size": [3, 6, 2], "uv": [32, 0]}]},
                      {"name": "right_leg", "parent": "root", "pivot": [-2, 6, 0], "cubes": [{"origin": [-4, 0, -1], "size": [3, 6, 2], "uv": [32, 16]}]},
                      {"name": "tail", "parent": "body", "pivot": [0, 7, 2], "cubes": [{"origin": [-1, 5, 2], "size": [2, 3, 6], "uv": [48, 0]}]}
                    ]
                  }]
                }
                """;
    }

    private String spawnRules(String prompt) {
        String q = normalize(prompt);
        boolean peaceful = contains(q, "pasif", "dost", "evcil", "bariscil", "friendly");
        String population = contains(q, "saldirgan", "agresif", "dusman", "dusmanca") || (isDragonPrompt(prompt) && !peaceful) ? "monster" : "animal";
        return "{\n  \"format_version\": \"1.8.0\",\n  \"minecraft:spawn_rules\": {\n    \"description\": {\"identifier\": \"jai:forest_companion\", \"population_control\": \""+population+"\"},\n    \"conditions\": [{\n      \"minecraft:spawns_on_surface\": {},\n      \"minecraft:weight\": {\"default\": 8},\n      \"minecraft:herd\": {\"min_size\": 1, \"max_size\": 2},\n      \"minecraft:biome_filter\": [{\"test\": \"has_biome_tag\", \"operator\": \"==\", \"value\": \"plains\"}]\n    }]\n  }\n}\n";
    }

    private String entityLoot() {
        return "{\n  \"pools\": [{\n    \"rolls\": 1,\n    \"entries\": [{\"type\": \"item\", \"name\": \"minecraft:amethyst_shard\", \"weight\": 1, \"functions\": [{\"function\": \"set_count\", \"count\": {\"min\": 1, \"max\": 2}}]}]\n  }]\n}\n";
    }

    private String lootTable() {
        return "{\n  \"pools\": [{\n    \"rolls\": 1,\n    \"entries\": [{\"type\": \"item\", \"name\": \"minecraft:emerald\", \"weight\": 1}]\n  }]\n}\n";
    }

    private String goldenAppleRecipe() {
        return "{\n  \"format_version\": \"1.20.10\",\n  \"minecraft:recipe_shaped\": {\n    \"description\": {\"identifier\": \"jai:golden_apple_alt\"},\n    \"tags\": [\"crafting_table\"],\n    \"pattern\": [\"GGG\", \"GAG\", \"GGG\"],\n    \"key\": {\"G\": {\"item\": \"minecraft:gold_ingot\"}, \"A\": {\"item\": \"minecraft:apple\"}},\n    \"result\": {\"item\": \"minecraft:golden_apple\", \"count\": 1}\n  }\n}\n";
    }

    private String terrainTextureJson(String name) {
        return "{\n  \"resource_pack_name\": \""+json(name)+"\",\n  \"texture_name\": \"atlas.terrain\",\n  \"padding\": 8,\n  \"num_mip_levels\": 4,\n  \"texture_data\": {\n    \"jai_moonstone\": {\"textures\": \"textures/blocks/jai_moonstone\"}\n  }\n}\n";
    }

    private String customBlock() {
        return "{\n  \"format_version\": \"1.21.50\",\n  \"minecraft:block\": {\n    \"description\": {\"identifier\": \"jai:moonstone\", \"menu_category\": {\"category\": \"construction\"}},\n    \"components\": {\n      \"minecraft:destructible_by_mining\": {\"seconds_to_destroy\": 3.0},\n      \"minecraft:map_color\": \"#7867ad\",\n      \"minecraft:geometry\": \"minecraft:geometry.full_block\",\n      \"minecraft:material_instances\": {\"*\": {\"texture\": \"jai_moonstone\", \"render_method\": \"opaque\"}},\n      \"minecraft:item_visual\": {\"geometry\": \"minecraft:geometry.full_block\", \"material_instances\": {\"*\": {\"texture\": \"jai_moonstone\", \"render_method\": \"opaque\"}}},\n      \"minecraft:loot\": \"loot_tables/blocks/jai_moonstone.json\"\n    }\n  }\n}\n";
    }

    private String blockRecipe() {
        return "{\n  \"format_version\": \"1.20.10\",\n  \"minecraft:recipe_shaped\": {\n    \"description\": {\"identifier\": \"jai:moonstone_recipe\"},\n    \"tags\": [\"crafting_table\"],\n    \"pattern\": [\"SSS\", \"SAS\", \"SSS\"],\n    \"key\": {\"S\": {\"item\": \"minecraft:stone\"}, \"A\": {\"item\": \"minecraft:amethyst_shard\"}},\n    \"result\": {\"item\": \"jai:moonstone\", \"count\": 1}\n  }\n}\n";
    }

    private String blockLoot() {
        return "{\n  \"pools\": [{\n    \"rolls\": 1,\n    \"entries\": [{\"type\": \"item\", \"name\": \"jai:moonstone\"}]\n  }]\n}\n";
    }

    private String customItem() {
        return "{\n  \"format_version\": \"1.20.50\",\n  \"minecraft:item\": {\n    \"description\": {\"identifier\": \"jai:moon_crystal\", \"menu_category\": {\"category\": \"items\"}},\n    \"components\": {\n      \"minecraft:icon\": \"jai_crystal\",\n      \"minecraft:display_name\": {\"value\": \"item.jai:moon_crystal.name\"},\n      \"minecraft:max_stack_size\": 64\n    }\n  }\n}\n";
    }

    private String crystalRecipe() {
        return "{\n  \"format_version\": \"1.20.10\",\n  \"minecraft:recipe_shaped\": {\n    \"description\": {\"identifier\": \"jai:moon_crystal_recipe\"},\n    \"tags\": [\"crafting_table\"],\n    \"pattern\": [\" A \", \"ADA\", \" A \"],\n    \"key\": {\"A\": {\"item\": \"minecraft:amethyst_shard\"}, \"D\": {\"item\": \"minecraft:diamond\"}},\n    \"result\": {\"item\": \"jai:moon_crystal\", \"count\": 1}\n  }\n}\n";
    }

    private static final class CreatureSpec {
        final String id;
        final String displayName;
        CreatureSpec(String id, String displayName) { this.id = id; this.displayName = displayName; }
    }

    private CreatureSpec parseCreatureSpec(String prompt) {
        String q = normalize(prompt);
        if (contains(q, "ejderha", "dragon")) return new CreatureSpec("dragon", "Ejderha");
        if (contains(q, "zombi", "zombie")) return new CreatureSpec("zombie", "Zombi");
        if (contains(q, "iskelet", "skeleton")) return new CreatureSpec("skeleton", "İskelet");
        if (contains(q, "kedi", "cat")) return new CreatureSpec("cat", "Özel Kedi");
        if (contains(q, "kurt", "wolf")) return new CreatureSpec("wolf", "Özel Kurt");
        if (contains(q, "yilan", "snake")) return new CreatureSpec("snake", "Yılan");
        if (contains(q, "orumucek", "spider")) return new CreatureSpec("spider", "Örümcek");
        if (contains(q, "golem")) return new CreatureSpec("golem", "Golem");
        if (contains(q, "robot")) return new CreatureSpec("robot", "Robot");
        return new CreatureSpec("forest_companion", "Orman Yoldaşı");
    }

    /** İstemden seçilen yaratık adını bütün RP/BP bağlantılarında tutarlı uygular. */
    private void customizeCreatureFiles(Map<String, byte[]> files, CreatureSpec creature) {
        if (creature == null || "forest_companion".equals(creature.id)) return;
        Map<String, byte[]> renamed = new LinkedHashMap<>();
        for (Map.Entry<String, byte[]> entry : files.entrySet()) {
            String path = entry.getKey()
                    .replace("jai_companion", "jai_" + creature.id)
                    .replace("forest_companion", creature.id);
            byte[] bytes = entry.getValue();
            String lower = path.toLowerCase(Locale.ROOT);
            if (lower.endsWith(".json") || lower.endsWith(".js") || lower.endsWith(".mcfunction")
                    || lower.endsWith(".lang") || lower.endsWith(".md") || lower.endsWith(".txt")) {
                String text = new String(bytes, java.nio.charset.StandardCharsets.UTF_8)
                        .replace("jai_companion", "jai_" + creature.id)
                        .replace("forest_companion", creature.id)
                        .replace("companion", creature.id)
                        .replace("Orman Yoldaşı", creature.displayName);
                bytes = text.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            }
            renamed.put(path, bytes);
        }
        files.clear();
        files.putAll(renamed);
        appendEntityName(files, "texts/tr_TR.lang", "entity.jai:" + creature.id + ".name=" + creature.displayName + "\n");
        appendEntityName(files, "texts/en_US.lang", "entity.jai:" + creature.id + ".name=" + creature.displayName + "\n");
    }

    private void appendEntityName(Map<String, byte[]> files, String path, String line) {
        byte[] current = files.get(path);
        String text = current == null ? "" : new String(current, java.nio.charset.StandardCharsets.UTF_8);
        files.put(path, (text + (text.endsWith("\n") || text.isEmpty() ? "" : "\n") + line)
                .getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    private static final class ItemSpec {
        final String id;
        final String displayName;
        ItemSpec(String displayName) {
            this.displayName = displayName;
            String slug = normalize(displayName).replaceAll("[^a-z0-9]+", "_").replaceAll("^_|_$", "");
            if (slug.isEmpty()) slug = "custom_item";
            if (slug.length() > 36) slug = slug.substring(0, 36);
            this.id = slug;
        }
    }

    private java.util.List<ItemSpec> parseItemSpecs(String prompt) {
        String q = prompt == null ? "" : prompt;
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile(
                "(?iu)(?:yeni\\s+)?(?:item(?:ler)?|e[sş]ya(?:lar)?)\\s*(?:ad[ıi]|olarak|ekle|olu[sş]tur)?\\s*[:=]\\s*([^.!?\\n]{2,140})").matcher(q);
        java.util.LinkedHashMap<String, ItemSpec> items = new java.util.LinkedHashMap<>();
        if (matcher.find()) {
            String captured = matcher.group(1)
                    .replaceAll("(?iu)\\b(?:stack|yığın|yigin|tutalım|tutalim|tutsun|tutulsun|tut|adet|tane|oluştur|olustur|ekle|yap)\\b.*$", "");
            for (String part : captured.split("(?iu)\\s*(?:,|;|/|\\bve\\b|\\bveya\\b)\\s*")) {
                String name = part.replaceAll("[^\\p{L}\\p{N} _-]", " ").trim().replaceAll("\\s+", " ");
                if (name.length() < 2 || name.matches("(?iu)(?:999|64|32|eşya|esya|item|items|sınırlı|sinirli|tutuluyor|tutalım)")) continue;
                if (isRestrictedItemName(name)) {
                    throw new IllegalArgumentException("Bu içerik türündeki eşya üretilemiyor. Bunun yerine dekoratif, koleksiyonluk veya yardımcı oyun eşyası tasarlayabilirsin.");
                }
                if (name.length() > 32) name = name.substring(0, 32).trim();
                ItemSpec item = new ItemSpec(name);
                items.put(item.id, item);
                if (items.size() >= 12) break;
            }
        }
        if (items.isEmpty()) {
            String lower = normalize(q);
            String defaultName = contains(lower, "elmas", "diamond") ? "Elmas Parçası"
                    : contains(lower, "bakir", "copper") ? "Bakır Parçası"
                    : contains(lower, "zumrut", "emerald") ? "Zümrüt Parçası"
                    : contains(lower, "yildiz", "star") ? "Yıldız Kristali"
                    : contains(lower, "item", "esya") ? "Özel Eşya" : "Ay Kristali";
            ItemSpec item = new ItemSpec(defaultName);
            items.put(item.id, item);
        }
        return new java.util.ArrayList<>(items.values());
    }

    private boolean isRestrictedItemName(String name) {
        String q = normalize(name);
        return contains(q, "kilic", "sword", "bicak", "knife", "hancer", "dagger", "yay", "bow",
                "silah", "weapon", "tabanca", "pistol", "tufek", "rifle", "pompali", "spear", "mızrak", "mizrak");
    }

    private int parseBulkCount(String prompt) {
        String q = normalize(prompt);
        java.util.regex.Matcher direct = java.util.regex.Pattern.compile("\\b(\\d{1,5})\\s*(?:adet|tane|stack|yigin|tutalim|tutalım|tutsun|tutulsun|tut)\\b").matcher(q);
        if (direct.find()) return Math.max(1, Math.min(9999, Integer.parseInt(direct.group(1))));
        java.util.regex.Matcher reverse = java.util.regex.Pattern.compile("(?:stack(?: size)?|ust uste|yigin|en fazla)[^0-9]{0,18}(\\d{1,5})").matcher(q);
        if (reverse.find()) return Math.max(1, Math.min(9999, Integer.parseInt(reverse.group(1))));
        return 64;
    }

    private void addDynamicItemResources(Map<String,byte[]> files, java.util.List<ItemSpec> items, String prompt) throws IOException {
        StringBuilder atlas = new StringBuilder("{\n  \"resource_pack_name\": \"Ja.i\",\n  \"texture_name\": \"atlas.items\",\n  \"texture_data\": {\n    \"jai_crystal\": {\"textures\": \"textures/items/jai_crystal\"}");
        StringBuilder tr = new StringBuilder("item.jai:moon_crystal.name=Ay Kristali\n");
        StringBuilder en = new StringBuilder("item.jai:moon_crystal.name=Moon Crystal\n");
        for (int i = 0; i < items.size(); i++) {
            ItemSpec item = items.get(i);
            ProceduralImageGenerator.Result texture = imageGenerator.generateMinecraftTexture(
                    prompt + " " + item.displayName + " Minecraft item texture", 64);
            put(files, "textures/items/" + item.id + ".png", texture.pngBytes);
            atlas.append(",\n    \"").append(item.id).append("\": {\"textures\": \"textures/items/")
                    .append(item.id).append("\"}");
            tr.append("item.jai:").append(item.id).append(".name=").append(item.displayName).append("\n");
            en.append("item.jai:").append(item.id).append(".name=").append(item.displayName).append("\n");
        }
        atlas.append("\n  }\n}\n");
        put(files, "textures/item_texture.json", atlas.toString());
        put(files, "texts/tr_TR.lang", tr.toString());
        put(files, "texts/en_US.lang", en.toString());
    }

    private void addDynamicItemsAndBulkFunction(Map<String,byte[]> files, java.util.List<ItemSpec> items, int amount) {
        for (ItemSpec item : items) {
            put(files, "items/" + item.id + ".json", customItem(item.id, 64));
            put(files, "recipes/" + item.id + "_recipe.json", itemRecipe(item.id));
            StringBuilder give = new StringBuilder("# İstenen toplam: ").append(amount)
                    .append(". Tek yığın en fazla 64; komutlar yasal yığınlara bölünür.\n");
            int remaining = amount;
            while (remaining > 0) {
                int chunk = Math.min(64, remaining);
                give.append("give @s jai:").append(item.id).append(' ').append(chunk).append('\n');
                remaining -= chunk;
            }
            put(files, "functions/jai/give_" + item.id + "_" + amount + ".mcfunction", give.toString());
        }
    }

    private String customItem(String id, int maxStack) {
        int safeStack = Math.max(1, Math.min(64, maxStack));
        return "{\n  \"format_version\": \"1.20.50\",\n  \"minecraft:item\": {\n"
                + "    \"description\": {\"identifier\": \"jai:" + json(id) + "\", \"menu_category\": {\"category\": \"items\"}},\n"
                + "    \"components\": {\"minecraft:icon\": \"" + json(id) + "\", \"minecraft:display_name\": {\"value\": \"item.jai:" + json(id) + ".name\"}, \"minecraft:max_stack_size\": " + safeStack + "}\n"
                + "  }\n}\n";
    }

    private String itemRecipe(String id) {
        return "{\n  \"format_version\": \"1.20.10\",\n  \"minecraft:recipe_shaped\": {\n"
                + "    \"description\": {\"identifier\": \"jai:" + json(id) + "_recipe\"},\n"
                + "    \"tags\": [\"crafting_table\"], \"pattern\": [\" A \", \"ADA\", \" A \"],\n"
                + "    \"key\": {\"A\": {\"item\": \"minecraft:amethyst_shard\"}, \"D\": {\"item\": \"minecraft:diamond\"}},\n"
                + "    \"result\": {\"item\": \"jai:" + json(id) + "\", \"count\": 1}\n"
                + "  }\n}\n";
    }

    private String projectNotes(String prompt, String researchContext, java.util.List<ItemSpec> items, int amount) {
        StringBuilder out = new StringBuilder("# Ja.i Bedrock proje notları\n\n")
                .append("İstemci hedef profili: ").append(TARGET_CLIENT_VERSION).append("\n")
                .append("Bedrock minimum motor sürümü: 1.21.132\n")
                .append("Script API bağımlılığı: @minecraft/server 2.4.0 (1.21.130 sonrası kararlı API profili)\n")
                .append("Özel eşyalar: ");
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) out.append(", ");
            out.append(items.get(i).displayName).append(" (`jai:").append(items.get(i).id).append("`)");
        }
        out.append("\nİstenen toplu adet: ").append(amount).append("\n")
                .append("Bedrock normal eşya yığını en fazla 64 adettir. Ja.i, daha büyük miktarı tek yığına yazmaz; 64 veya daha az yığınlara bölen `functions/jai/give_<item>_").append(amount).append(".mcfunction` üretir. Komut `/function jai/give_<item>_").append(amount).append("` ile çağrılır; envanterde yeterli boş yer olmalıdır.\n\n")
                .append("## Üretim isteği\n\n").append(prompt == null ? "" : prompt.trim()).append("\n\n");
        String research = researchContext == null ? "" : researchContext.trim();
        if (!research.isEmpty()) {
            if (research.length() > 14000) research = research.substring(0, 14000) + "\n[Not: araştırma metni güvenli boyut nedeniyle kısaltıldı.]";
            out.append("## Ara açıkken toplanan web araştırma bağlamı\n\n").append(research).append("\n\n");
        } else {
            out.append("## Araştırma durumu\n\nBu üretim çağrısında ek web araştırma metni aktarılmadı.\n");
        }
        return out.toString();
    }

    private String repairInPlace(Map<String,byte[]> files) throws IOException {
        BedrockPackRepairEngine.Result report = repairEngine.validateAndRepair(files);
        files.clear();
        files.putAll(report.files);
        return report.report;
    }

    private String extractName(String prompt) {
        String q=prompt==null?"Minecraft Add-on":prompt.trim();
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("(?i)(?:ad[ıi]|paket adı|ismi)\\s*[:=]?\\s*([\\p{L}0-9 _-]{2,32})").matcher(q);
        if(matcher.find()) return matcher.group(1).trim();
        String normalized=normalize(q);
        boolean resource=contains(normalized,"kaynak","resource");
        boolean behavior=contains(normalized,"davranis","behavior","behaviour");
        if(resource && behavior) return "Ja.i Combined Add-on";
        if(resource) return "Ja.i Kaynak Paketi";
        if(behavior) return "Ja.i Davranis Paketi";
        if(contains(normalized,"ejderha","dragon")) return "Ja.i Ejderha Add-on";
        if(contains(normalized,"kedi","cat")) return "Ja.i Kedi Add-on";
        return "Ja.i Minecraft Add-on";
    }

    private static String slug(String value) {
        String q=normalize(value).replaceAll("[^a-z0-9]+","-").replaceAll("^-|-$","");
        return q.length()>40?q.substring(0,40):q;
    }
    private static String normalize(String value) {
        String q=(value==null?"":value).toLowerCase(Locale.ROOT);
        return q.replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c');
    }
    private static boolean contains(String text,String... items) { for(String item:items) if(text.contains(item)) return true; return false; }
    private static String json(String value) { return (value==null?"":value).replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ").replace("\r"," "); }
    private static void put(Map<String,byte[]> files,String path,String text) { files.put(path,text.getBytes(java.nio.charset.StandardCharsets.UTF_8)); }
    private static void put(Map<String,byte[]> files,String path,byte[] data) { files.put(path,data); }
}
