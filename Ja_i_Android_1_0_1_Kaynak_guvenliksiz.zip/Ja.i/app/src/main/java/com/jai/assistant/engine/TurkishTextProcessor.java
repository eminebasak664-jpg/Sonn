package com.jai.assistant.engine;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Hafif Türkçe metin normalleştirme ve arama yardımcısı.
 * Tam bir biçimbilim çözümleyicisi değildir; yalnızca kısa ve güvenli kök/sinonim
 * eşleştirmeleri yapar. Bilgi üretmez, sınıflandırma ve hafıza bulmayı iyileştirir.
 */
public final class TurkishTextProcessor {
    private static final Pattern TOKEN_PATTERN = Pattern.compile("[\\p{L}\\p{N}]{2,}");
    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
            "ve", "veya", "ile", "ama", "fakat", "icin", "için", "bu", "bir", "şu", "su",
            "o", "da", "de", "mi", "mı", "mu", "mü", "ne", "nasil", "nedir",
            "kac", "bana", "ben", "sen", "biz", "siz", "onlar", "bunu", "sunu", "hakkinda", "lutfen", "anlat", "acikla",
            "yapar", "yap", "eder", "et", "olarak", "gibi", "daha", "cok", "en",
            "hangi", "nerede", "zaman", "olan", "olması", "olmasi", "var", "yok"));
    private static final String[] SUFFIXES = {
            "lerinizden", "larinizdan", "lerimizden", "larimizdan", "lerindeki", "larindaki",
            "lerinden", "larından", "lerinden", "larından", "lerimiz", "larımız", "leriniz", "lariniz",
            "lerinin", "larının", "lerden", "lardan", "lerin", "ların", "leri", "lari", "ler", "lar",
            "siniz", "sınız", "sunuz", "sünüz", "siniz", "ınız", "iniz", "unuz", "ünüz",
            "lardan", "lerden", "larda", "lerde", "lara", "lere", "dan", "den", "tan", "ten",
            "dır", "dir", "dur", "dür", "tır", "tir", "tur", "tür", "nin", "nın", "nun", "nün",
            "yla", "yle", "lık", "lik", "luk", "lük", "cı", "ci", "cu", "cü", "çı", "çi", "çu", "çü",
            "mek", "mak", "miş", "mış", "muş", "müş", "ıyor", "iyor", "uyor", "üyor",
            "acak", "ecek", "ınca", "ince", "unca", "ünce", "dan", "den", "de", "da", "te", "ta",
            "ye", "ya", "si", "sı", "su", "sü"
    };
    private static final Map<String, List<String>> SYNONYMS = createSynonyms();

    private TurkishTextProcessor() { }

    public static String normalize(String text) {
        if (text == null) return "";
        String lower = text.toLowerCase(Locale.forLanguageTag("tr-TR")).replace('ı', 'i');
        String decomposed = Normalizer.normalize(lower, Normalizer.Form.NFD);
        StringBuilder out = new StringBuilder(decomposed.length());
        for (int i = 0; i < decomposed.length(); i++) {
            char c = decomposed.charAt(i);
            int type = Character.getType(c);
            if (type == Character.NON_SPACING_MARK || type == Character.COMBINING_SPACING_MARK) continue;
            if (Character.isLetterOrDigit(c) || Character.isWhitespace(c)) out.append(c);
            else out.append(' ');
        }
        return out.toString().replaceAll("\\s+", " ").trim();
    }

    public static List<String> tokens(String text) {
        String normalized = normalize(text);
        if (normalized.isEmpty()) return Collections.emptyList();
        List<String> result = new ArrayList<>();
        Matcher matcher = TOKEN_PATTERN.matcher(normalized);
        while (matcher.find()) {
            String token = stem(matcher.group());
            if (token.length() >= 2 && !isStopWord(token) && !result.contains(token)) result.add(token);
        }
        return result;
    }

    /** Hafıza sorgusu için kökleri, yazım varyantlarını ve az sayıdaki eş anlamlıyı döndürür. */
    public static List<String> searchTerms(String text) {
        LinkedHashSet<String> result = new LinkedHashSet<>();
        // Önce kullanıcının özgün yazımını ekle ki SQLite LIKE araması Türkçe harfleri bulabilsin.
        String original = text == null ? "" : text.toLowerCase(Locale.forLanguageTag("tr-TR"));
        Matcher originalMatcher = TOKEN_PATTERN.matcher(original);
        while (originalMatcher.find()) {
            String originalToken = originalMatcher.group();
            if (originalToken.length() >= 3 && !isStopWord(normalize(originalToken))) result.add(originalToken);
            if (result.size() >= 16) break;
        }
        String normalized = normalize(text);
        Matcher matcher = TOKEN_PATTERN.matcher(normalized);
        while (matcher.find()) {
            String raw = matcher.group();
            String root = stem(raw);
            if (root.length() >= 2 && !isStopWord(root)) result.add(root);
            if (raw.length() >= 3 && !isStopWord(raw)) result.add(raw);
            List<String> synonyms = SYNONYMS.get(root);
            if (synonyms != null) result.addAll(synonyms);
            if (result.size() >= 24) break;
        }
        return new ArrayList<>(result);
    }

    public static String stem(String token) {
        if (token == null) return "";
        String value = normalize(token).replace(" ", "");
        if (value.length() < 6) return value;
        // Bir kerede en fazla iki ek kaldır; kökün en az üç harf kalması zorunlu.
        for (int pass = 0; pass < 1; pass++) {
            boolean removed = false;
            for (String suffix : SUFFIXES) {
                String normalizedSuffix = normalize(suffix).replace(" ", "");
                if (value.endsWith(normalizedSuffix) && value.length() - normalizedSuffix.length() >= 3) {
                    value = value.substring(0, value.length() - normalizedSuffix.length());
                    removed = true;
                    break;
                }
            }
            if (!removed) break;
        }
        return value;
    }

    private static boolean isStopWord(String token) {
        if (STOP_WORDS.contains(token)) return true;
        for (String word : STOP_WORDS) {
            if (normalize(word).equals(token)) return true;
        }
        return false;
    }

    private static Map<String, List<String>> createSynonyms() {
        Map<String, List<String>> map = new HashMap<>();
        map.put("site", Arrays.asList("web", "sayfa", "html"));
        map.put("web", Arrays.asList("site", "internet", "html"));
        map.put("uygulama", Arrays.asList("app", "program"));
        map.put("program", Arrays.asList("uygulama", "yazilim", "kod"));
        map.put("hata", Arrays.asList("sorun", "bug", "ariza"));
        map.put("sorun", Arrays.asList("hata", "problem"));
        map.put("hafiza", Arrays.asList("bellek", "kayit", "hatirla"));
        map.put("bellek", Arrays.asList("hafiza", "ram"));
        map.put("resim", Arrays.asList("fotograf", "gorsel", "image"));
        map.put("fotograf", Arrays.asList("resim", "gorsel", "image"));
        map.put("dokuman", Arrays.asList("pdf", "dosya", "belge"));
        map.put("belge", Arrays.asList("dokuman", "pdf", "dosya"));
        map.put("oyun", Arrays.asList("game", "etkilesim"));
        map.put("kod", Arrays.asList("program", "kaynak", "yazilim"));
        return map;
    }
}
