package com.jai.assistant.engine;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Random;
import java.util.zip.CRC32;
import java.util.zip.DeflaterOutputStream;

/**
 * Haricî model/API kullanmayan, kurallı sahne kompozisyonu ve PNG raster motoru.
 * Bu motor çizgi, şekil, palet, piksel gürültüsü ve katmanları kodla birleştirir;
 * diffusion/LLM tabanlı serbest resim modeli değildir.
 */
public final class ProceduralImageGenerator {
    public static final class Result {
        public final byte[] pngBytes;
        public final int width;
        public final int height;
        public final String subject;
        public final String description;

        private Result(byte[] pngBytes, int width, int height, String subject, String description) {
            this.pngBytes = pngBytes;
            this.width = width;
            this.height = height;
            this.subject = subject;
            this.description = description;
        }
    }

    public boolean isImageRequest(String prompt) {
        String q = normalize(prompt);
        boolean output = containsWordOrPrefix(q, "gorsel", "resim", "ciz", "cizim", "png", "piksel sanat",
                "pixel art", "ikon", "logo", "duvar kagidi", "texture", "doku", "karakter", "hayvan",
                "ejderha", "kedi", "agac", "ev", "manzara", "dag", "kristal", "cicek", "balik", "robot", "mantar", "roket",
                "televizyon", "tv", "araba", "otomobil", "kopek", "insan", "bilgisayar", "laptop", "telefon", "ucak", "gezegen", "kus", "zurafa", "zürafa", "giraffe", "resim çiz", "video karesi");
        boolean action = containsWordOrPrefix(q, "yap", "uret", "olustur", "ciz", "tasarla", "hazirla");
        return output && action;
    }

    public Result generate(String prompt) throws IOException {
        int[] size = requestedDimensions(normalize(prompt));
        return generate(prompt, size[0], size[1]);
    }

    public Result generate(String prompt, VisualLearningEngine learningEngine) throws IOException {
        int[] size = requestedDimensions(normalize(prompt));
        return generate(prompt, size[0], size[1], learningEngine, "");
    }

    /** Web araştırması varsa metinsel tasarım ipuçları yerel sahne kurucusuna aktarılır. */
    public Result generate(String prompt, VisualLearningEngine learningEngine, String researchContext) throws IOException {
        int[] size = requestedDimensions(normalize(prompt));
        return generate(prompt, size[0], size[1], learningEngine, researchContext);
    }

    private int[] requestedDimensions(String q) {
        if (containsWordOrPrefix(q, "720p", "hd 720p", "1280x720")) return new int[]{1280, 720};
        if (containsWordOrPrefix(q, "720x1280")) return new int[]{720, 1280};
        java.util.regex.Matcher dimensions = java.util.regex.Pattern.compile("(16|32|64|128|256|512|720|960|1280)\\s*x\\s*(16|32|64|128|256|512|720|960|1280)").matcher(q);
        if (dimensions.find()) return new int[]{Integer.parseInt(dimensions.group(1)), Integer.parseInt(dimensions.group(2))};
        java.util.regex.Matcher explicitSize = java.util.regex.Pattern.compile("\\b(16|32|64|128|256|512)\\b").matcher(q);
        if (explicitSize.find()) {
            int size = Integer.parseInt(explicitSize.group(1));
            return new int[]{size, size};
        }
        // Boyut belirtilmezse varsayılan hedef 720p yatay PNG'dir.
        return new int[]{1280, 720};
    }

    /** Minecraft model UV atlası için resim değil, bölgelere ayrılmış doku haritası üretir. */
    public Result generateMinecraftTexture(String prompt, int size) throws IOException {
        if (size < 32 || size > 128) throw new IllegalArgumentException("Minecraft doku boyutu 32–128 piksel aralığında olmalı.");
        String q = normalize(prompt);
        Palette palette = Palette.from(q);
        Canvas canvas = new Canvas(size, size, new Random((prompt == null ? "jai-minecraft" : prompt).hashCode()));
        canvas.rect(0, 0, size, size, palette.main);
        int cell = Math.max(1, size / 32);
        // UV atlası tek renk düzlem değil: baş, gövde ve uzuv alanlarına ayrı ton/detay verir.
        for (int y = 0; y < size; y += cell) {
            for (int x = 0; x < size; x += cell) {
                int zone = (x < size / 2 ? 0 : 1) + (y < size / 2 ? 0 : 2);
                int base = zone == 0 ? palette.light : zone == 1 ? palette.main : zone == 2 ? palette.shadow : palette.accent;
                int variation = canvas.random.nextInt(9) - 4;
                canvas.rect(x, y, cell, cell, shade(base, variation));
            }
        }
        for (int band = 0; band < 4; band++) {
            int y = band * size / 4;
            for (int x = 0; x < size; x += Math.max(2, size / 16)) {
                if (canvas.random.nextBoolean()) canvas.rect(x, y, Math.max(1, size / 32), Math.max(1, size / 64), palette.light);
            }
        }
        for (int i = 0; i < size / 3; i++) {
            int x = canvas.random.nextInt(size), y = canvas.random.nextInt(size);
            canvas.rect(x, y, cell, cell, canvas.random.nextBoolean() ? palette.accent : palette.shadow);
        }
        byte[] png = encodePng(size, size, canvas.pixels);
        return new Result(png, size, size, "minecraft_uv", "Minecraft için bölümlü UV doku haritası oluşturuldu.");
    }

    private static int shade(int color, int amount) {
        int r = clamp(((color >>> 16) & 255) + amount * 5);
        int g = clamp(((color >>> 8) & 255) + amount * 5);
        int b = clamp((color & 255) + amount * 5);
        return (color & 0xff000000) | (r << 16) | (g << 8) | b;
    }
    private static int clamp(int value) { return Math.max(0, Math.min(255, value)); }

    public Result generate(String prompt, int width, int height) throws IOException {
        return generate(prompt, width, height, null);
    }

    public Result generate(String prompt, int width, int height, VisualLearningEngine learningEngine) throws IOException {
        return generate(prompt, width, height, learningEngine, "");
    }

    public Result generate(String prompt, int width, int height, VisualLearningEngine learningEngine, String researchContext) throws IOException {
        if (width < 16 || height < 16 || width > 1280 || height > 1280 || (long) width * height > 921600L) {
            throw new IllegalArgumentException("Görsel boyutu en fazla 1280×720 (veya aynı piksel bütçesindeki portre/kare) olabilir.");
        }
        String q = normalize(prompt);
        String researchHints = researchContext == null ? "" : researchContext.trim();
        if (researchHints.length() > 5000) researchHints = researchHints.substring(0, 5000);
        String scenePrompt = q + " " + normalize(researchHints);
        String subject = detectSubject(q);
        boolean pixelArt = containsWordOrPrefix(q, "piksel", "pixel art", "8 bit", "8-bit", "16 bit", "retro pixel");
        if (learningEngine != null) {
            if (!learningEngine.canGenerate(prompt)) {
                String label = learningLabelForPrompt(prompt);
                throw new IllegalStateException("'" + label + "' için Ja.i'nin yerel görsel öğrenme örneği bulunmuyor. "
                        + "Ara'yı açıp bu isteği yeniden gönder veya Görsel Öğrenme bölümünden örnek fotoğraf öğret. "
                        + "Bu sürüm, öğrenmediği bir nesneyi geometrik şablonla çizip bunu yapay zekâ görseli gibi sunmaz.");
            }
            int[] learned = learningEngine.generateLearnedImage(prompt, width, height, pixelArt);
            if (learned == null) throw new IllegalStateException("Etiketli görsel örnekleri okunamadı; üretim durduruldu.");
            byte[] png = encodePng(width, height, learned);
            String label = learningLabelForPrompt(prompt);
            return new Result(png, width, height, subject,
                    "Ja.i'nin yerel 16→128→64→3 ağı, '" + label + "' etiketli "
                            + learningEngine.referenceSampleCount(label) + " görsel örneğinin piksel örüntülerini öğrenerek "
                            + width + "×" + height + " yeni raster PNG oluşturdu. "
                            + (pixelArt ? "Keskin en-yakın-komşu ölçekleme kullanıldı. " : "Piksel verisi yumuşak ölçeklendi. ")
                            + "Çıktı referans pikselleriyle ağın renk tahminlerini birleştirir; genel amaçlı görsel tanıma/diffusion modeli değildir. "
                            + "Ağırlıklar ve örnekler cihazda kalır; haricî AI API/model kullanılmaz. " + learningEngine.status());
        }
        // Yalnızca bağımsız/geriye dönük çağrılarda eski raster çizici kalır. Android uygulaması
        // VisualLearningEngine gönderdiği için öğrenilmemiş nesnelerde bu çiziciye düşmez.
        int renderWidth = pixelArt ? Math.max(16, (width + 3) / 4) : width;
        int renderHeight = pixelArt ? Math.max(16, (height + 3) / 4) : height;
        if ((long) renderWidth * renderHeight > 230400L) renderHeight = Math.max(16, 230400 / renderWidth);
        Palette palette = Palette.from(scenePrompt);
        Canvas canvas = new Canvas(renderWidth, renderHeight, new Random((prompt == null ? "jai" : prompt).hashCode()));
        drawBackground(canvas, scenePrompt, palette);
        switch (subject) {
            case "ejderha": drawDragon(canvas, palette); break;
            case "kedi": drawCat(canvas, palette); break;
            case "agac": drawTree(canvas, palette); break;
            case "ev": drawHouse(canvas, palette); break;
            case "dag": drawMountains(canvas, palette); break;
            case "kristal": drawCrystal(canvas, palette); break;
            case "cicek": drawFlower(canvas, palette); break;
            case "balik": drawFish(canvas, palette); break;
            case "robot": drawRobot(canvas, palette); break;
            case "mantar": drawMushroom(canvas, palette); break;
            case "roket": drawRocket(canvas, palette); break;
            case "televizyon": drawTelevision(canvas, palette, q); break;
            case "araba": drawCar(canvas, palette); break;
            case "kopek": drawDog(canvas, palette); break;
            case "insan": drawPerson(canvas, palette); break;
            case "bilgisayar": drawComputer(canvas, palette); break;
            case "ucak": drawPlane(canvas, palette); break;
            case "gezegen": drawPlanet(canvas, palette); break;
            case "kus": drawBird(canvas, palette); break;
            // Zürafa gibi yeni kavramlar elle çizim şablonuna eklenmez; öğrenilmiş piksel yolu gerekir.
            default: drawPromptObject(canvas, palette, scenePrompt); break;
        }
        drawFinishingPixels(canvas, palette);
        int[] finalPixels = (renderWidth == width && renderHeight == height)
                ? canvas.pixels : nearestScale(canvas.pixels, renderWidth, renderHeight, width, height);
        byte[] png = encodePng(width, height, finalPixels);
        String description = "Ja.i'nin yerel raster motoru " + width + "×" + height + " PNG üretti. Konu: "
                + subjectLabel(subject) + ". Bu çıktı henüz öğrenilmiş nesne modeli değil; mevcut yerel sahne çizicisinin piksel çıktısıdır."
                + (pixelArt ? " Temel ızgara " + renderWidth + "×" + renderHeight + " piksel; en yakın komşu ölçekleme." : "")
                + (researchHints.isEmpty() ? " Web araştırması aktarılmadı." : " Web araştırması metni üretim bağlamına eklendi.")
                + " Kendi ürettiği resmi kendine eğitim verisi olarak kaydetmedi. Haricî model/API kullanılmadı.";
        return new Result(png, width, height, subject, description);
    }

    private static int[] nearestScale(int[] source, int sw, int sh, int width, int height) {
        int[] out = new int[width * height];
        for (int y = 0; y < height; y++) {
            int sy = Math.min(sh - 1, (int) ((long) y * sh / height));
            for (int x = 0; x < width; x++) {
                int sx = Math.min(sw - 1, (int) ((long) x * sw / width));
                out[y * width + x] = source[sy * sw + sx];
            }
        }
        return out;
    }


    /** Görsel örneklerini aynı etiket altında toplamak için istekten nesne etiketini çıkarır. */
    public String learningLabelForPrompt(String prompt) {
        String q = normalize(prompt);
        String subject = detectSubject(q);
        return "diger".equals(subject) ? trainingLabel(prompt, subject) : subjectLabel(subject);
    }

    private String detectSubject(String q) {
        if (containsWordOrPrefix(q, "zurafa", "giraffe")) return "zurafa";
        if (containsWordOrPrefix(q, "ejderha", "dragon", "drakon")) return "ejderha";
        if (containsWordOrPrefix(q, "kedi", "cat", "pisi")) return "kedi";
        if (containsWordOrPrefix(q, "agac", "tree", "orman")) return "agac";
        if (containsWordOrPrefix(q, "ev", "evcik", "house", "kulube")) return "ev";
        if (containsWordOrPrefix(q, "dag", "mountain", "tepe", "manzara")) return "dag";
        if (containsWordOrPrefix(q, "kristal", "gem", "maden", "cevher")) return "kristal";
        if (containsWordOrPrefix(q, "cicek", "flower", "bitki")) return "cicek";
        if (containsWordOrPrefix(q, "balik", "fish", "su alti")) return "balik";
        if (containsWordOrPrefix(q, "robot", "android karakter")) return "robot";
        if (containsWordOrPrefix(q, "mantar", "mushroom")) return "mantar";
        if (containsWordOrPrefix(q, "roket", "rocket", "uzay gemisi")) return "roket";
        if (containsWordOrPrefix(q, "televizyon", "tv", "ekran")) return "televizyon";
        if (containsWordOrPrefix(q, "araba", "otomobil", "car")) return "araba";
        if (containsWordOrPrefix(q, "kopek", "dog")) return "kopek";
        if (containsWordOrPrefix(q, "insan", "kisi", "adam", "kadin", "karakter")) return "insan";
        if (containsWordOrPrefix(q, "bilgisayar", "laptop", "notebook", "pc")) return "bilgisayar";
        if (containsWordOrPrefix(q, "ucak", "plane", "jet")) return "ucak";
        if (containsWordOrPrefix(q, "gezegen", "planet", "saturn")) return "gezegen";
        if (containsWordOrPrefix(q, "kus", "bird", "kartal")) return "kus";
        return "diger";
    }

    private void drawBackground(Canvas c, String q, Palette p) {
        boolean night = contains(q, "gece", "yildiz", "uzay", "space", "karanlik");
        boolean water = contains(q, "deniz", "okyanus", "su alti", "balik");
        int top = night ? 0xff10152f : water ? 0xff277b9a : p.backgroundTop;
        int bottom = night ? 0xff27224c : water ? 0xff123f69 : p.backgroundBottom;
        for (int y = 0; y < c.h; y++) {
            float t = y / (float) Math.max(1, c.h - 1);
            int color = mix(top, bottom, t);
            for (int x = 0; x < c.w; x++) c.set(x, y, color);
        }
        if (night) {
            for (int i = 0; i < Math.max(14, c.w * c.h / 900); i++) {
                int x = c.random.nextInt(c.w), y = c.random.nextInt(Math.max(1, c.h * 2 / 3));
                c.rect(x, y, 1 + c.random.nextInt(2), 1 + c.random.nextInt(2), 0xfff8edb7);
            }
        } else {
            c.circle((int) (c.w * 0.78f), (int) (c.h * 0.22f), Math.max(5, c.w / 15), p.sun);
            for (int i = 0; i < 3; i++) {
                int x = c.random.nextInt(Math.max(1, c.w));
                int y = c.h / 8 + c.random.nextInt(Math.max(1, c.h / 4));
                c.ellipse(x, y, Math.max(7, c.w / 18), Math.max(3, c.h / 45), 0x66ffffff);
            }
        }
    }

    private void drawDragon(Canvas c, Palette p) {
        int s = Math.max(2, Math.min(c.w, c.h) / 32);
        int cx = c.w / 2, cy = c.h / 2;
        c.polygon(new int[]{cx - 8*s, cx - 2*s, cx - 12*s, cx - 14*s}, new int[]{cy - 2*s, cy - 8*s, cy - 7*s, cy + 1*s}, p.shadow);
        c.ellipse(cx, cy + 2*s, 9*s, 6*s, p.main);
        c.ellipse(cx + 7*s, cy - 5*s, 6*s, 5*s, p.light);
        c.polygon(new int[]{cx - 3*s, cx - 12*s, cx - 6*s, cx + 1*s}, new int[]{cy, cy - 14*s, cy - 7*s, cy - 2*s}, p.main);
        c.polygon(new int[]{cx + 3*s, cx + 2*s, cx + 11*s, cx + 8*s}, new int[]{cy - 1*s, cy - 15*s, cy - 7*s, cy + 1*s}, p.accent);
        c.polygon(new int[]{cx + 8*s, cx + 12*s, cx + 14*s}, new int[]{cy - 8*s, cy - 15*s, cy - 6*s}, p.shadow);
        c.polygon(new int[]{cx + 4*s, cx + 8*s, cx + 10*s}, new int[]{cy - 9*s, cy - 17*s, cy - 8*s}, p.shadow);
        c.rect(cx + 9*s, cy - 6*s, 2*s, 2*s, 0xff201a28);
        c.rect(cx + 10*s, cy + 3*s, 5*s, 2*s, p.light);
        c.rect(cx - 4*s, cy + 7*s, 3*s, 7*s, p.shadow);
        c.rect(cx + 5*s, cy + 7*s, 3*s, 7*s, p.shadow);
        c.polygon(new int[]{cx - 4*s, cx - 11*s, cx - 8*s, cx - 1*s}, new int[]{cy - 2*s, cy - 12*s, cy - 8*s, cy + 3*s}, p.light);
    }

    private void drawCat(Canvas c, Palette p) {
        int s = Math.max(2, c.w / 30), cx = c.w / 2, cy = c.h / 2;
        c.ellipse(cx, cy + 5*s, 8*s, 7*s, p.main);
        c.circle(cx, cy - 5*s, 7*s, p.light);
        c.polygon(new int[]{cx - 7*s, cx - 6*s, cx - 2*s}, new int[]{cy - 8*s, cy - 16*s, cy - 7*s}, p.main);
        c.polygon(new int[]{cx + 2*s, cx + 6*s, cx + 7*s}, new int[]{cy - 7*s, cy - 16*s, cy - 8*s}, p.main);
        c.polygon(new int[]{cx - 5*s, cx - 5*s, cx - 3*s}, new int[]{cy - 9*s, cy - 13*s, cy - 9*s}, p.accent);
        c.polygon(new int[]{cx + 3*s, cx + 5*s, cx + 5*s}, new int[]{cy - 9*s, cy - 13*s, cy - 9*s}, p.accent);
        c.rect(cx - 3*s, cy - 6*s, 2*s, 2*s, 0xff161b2b);
        c.rect(cx + 2*s, cy - 6*s, 2*s, 2*s, 0xff161b2b);
        c.polygon(new int[]{cx - s, cx + s, cx}, new int[]{cy - 2*s, cy - 2*s, cy}, p.accent);
        c.line(cx - 2*s, cy + 9*s, cx + 2*s, cy + 9*s, p.shadow);
        c.line(cx + 7*s, cy + 10*s, cx + 13*s, cy + 5*s, p.main);
        c.line(cx + 13*s, cy + 5*s, cx + 15*s, cy - 1*s, p.main);
    }

    private void drawTree(Canvas c, Palette p) {
        int s = Math.max(2, c.w / 32), cx = c.w / 2, cy = c.h / 2;
        c.rect(cx - 3*s, cy + 1*s, 6*s, 15*s, 0xff76503d);
        c.circle(cx, cy - 7*s, 11*s, p.main);
        c.circle(cx - 7*s, cy - 2*s, 7*s, p.light);
        c.circle(cx + 7*s, cy - 2*s, 7*s, p.accent);
        c.circle(cx, cy - 13*s, 7*s, p.main);
        c.rect(cx - 1*s, cy + 4*s, 2*s, 8*s, 0xffa77950);
    }

    private void drawHouse(Canvas c, Palette p) {
        int s = Math.max(2, c.w / 32), cx = c.w / 2, cy = c.h / 2;
        c.rect(cx - 11*s, cy - 1*s, 22*s, 15*s, 0xffe4c28d);
        c.polygon(new int[]{cx - 14*s, cx, cx + 14*s}, new int[]{cy, cy - 13*s, cy}, p.main);
        c.rect(cx - 3*s, cy + 5*s, 6*s, 9*s, 0xff79503e);
        c.rect(cx - 8*s, cy + 3*s, 4*s, 4*s, 0xff9bd7e5);
        c.rect(cx + 5*s, cy + 3*s, 4*s, 4*s, 0xff9bd7e5);
        c.rect(cx + 5*s, cy - 12*s, 4*s, 7*s, p.shadow);
    }

    private void drawMountains(Canvas c, Palette p) {
        c.polygon(new int[]{0, c.w/3, c.w*2/3, c.w}, new int[]{c.h*3/4, c.h/5, c.h*3/4, c.h/2}, p.shadow);
        c.polygon(new int[]{c.w/4, c.w/2, c.w*3/4}, new int[]{c.h*3/4, c.h/4, c.h*3/4}, p.main);
        c.polygon(new int[]{c.w/2-c.w/12, c.w/2, c.w/2+c.w/12}, new int[]{c.h/3, c.h/4, c.h/3}, 0xffeaf3f7);
        c.polygon(new int[]{0, c.w/3, c.w*2/3, c.w}, new int[]{c.h, c.h*3/4, c.h*4/5, c.h}, p.accent);
    }

    private void drawCrystal(Canvas c, Palette p) {
        int cx = c.w / 2, cy = c.h / 2, s = Math.max(2, c.w / 28);
        c.polygon(new int[]{cx, cx+8*s, cx+5*s, cx, cx-5*s, cx-8*s},
                new int[]{cy-15*s, cy-2*s, cy+12*s, cy+16*s, cy+12*s, cy-2*s}, p.main);
        c.polygon(new int[]{cx, cx+8*s, cx, cx-8*s}, new int[]{cy-15*s, cy-2*s, cy+3*s, cy-2*s}, p.light);
        c.polygon(new int[]{cx, cx+5*s, cx, cx-5*s}, new int[]{cy+3*s, cy+12*s, cy+16*s, cy+12*s}, p.accent);
        c.line(cx-2*s, cy-9*s, cx-5*s, cy-1*s, 0xfff4ffff);
    }

    private void drawFlower(Canvas c, Palette p) {
        int s = Math.max(2, c.w / 34), cx = c.w / 2, cy = c.h / 2;
        c.rect(cx-s, cy, 2*s, 16*s, 0xff39824d);
        c.ellipse(cx+4*s, cy+7*s, 5*s, 2*s, 0xff55a75c);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            c.circle(cx + (int)(Math.cos(a)*5*s), cy-5*s + (int)(Math.sin(a)*5*s), 4*s, p.main);
        }
        c.circle(cx, cy-5*s, 3*s, p.sun);
    }

    private void drawFish(Canvas c, Palette p) {
        int s = Math.max(2, c.w / 32), cx = c.w / 2, cy = c.h / 2;
        c.ellipse(cx, cy, 12*s, 7*s, p.main);
        c.polygon(new int[]{cx-10*s, cx-17*s, cx-11*s}, new int[]{cy, cy-7*s, cy+7*s}, p.accent);
        c.circle(cx+7*s, cy-2*s, 2*s, 0xff17172a);
        c.line(cx-2*s, cy-5*s, cx+2*s, cy+5*s, p.light);
        c.line(cx+2*s, cy-5*s, cx+6*s, cy+5*s, p.light);
        for (int i=0;i<5;i++) c.circle(c.w/8+i*c.w/7, c.h*3/4+(i%2)*4, 2, 0x887fffff);
    }

    private void drawRobot(Canvas c, Palette p) {
        int s=Math.max(2,Math.min(c.w,c.h)/32),cx=c.w/2,cy=c.h/2;
        c.rect(cx-8*s,cy-6*s,16*s,13*s,p.main);
        c.rect(cx-6*s,cy-16*s,12*s,9*s,p.light);
        c.rect(cx-4*s,cy-13*s,3*s,3*s,0xff182038);
        c.rect(cx+2*s,cy-13*s,3*s,3*s,0xff182038);
        c.rect(cx-3*s,cy-8*s,6*s,2*s,p.accent);
        c.rect(cx-5*s,cy+7*s,4*s,8*s,p.shadow);
        c.rect(cx+2*s,cy+7*s,4*s,8*s,p.shadow);
        c.line(cx,cy-16*s,cx,cy-20*s,p.shadow);
        c.circle(cx,cy-21*s,2*s,p.sun);
        c.rect(cx-12*s,cy-3*s,4*s,3*s,p.accent);
        c.rect(cx+8*s,cy-3*s,4*s,3*s,p.accent);
    }

    private void drawMushroom(Canvas c, Palette p) {
        int s=Math.max(2,Math.min(c.w,c.h)/32),cx=c.w/2,cy=c.h/2;
        c.rect(cx-4*s,cy,8*s,14*s,0xffefdfbb);
        c.ellipse(cx,cy-4*s,13*s,9*s,p.main);
        c.circle(cx-6*s,cy-7*s,2*s,p.light);
        c.circle(cx+5*s,cy-5*s,2*s,p.light);
        c.circle(cx,cy-10*s,2*s,p.light);
        c.ellipse(cx,cy+12*s,8*s,2*s,p.accent);
    }

    private void drawRocket(Canvas c, Palette p) {
        int s=Math.max(2,Math.min(c.w,c.h)/32),cx=c.w/2,cy=c.h/2;
        c.polygon(new int[]{cx,cx+6*s,cx+5*s,cx-5*s,cx-6*s},new int[]{cy-17*s,cy-5*s,cy+9*s,cy+9*s,cy-5*s},p.light);
        c.polygon(new int[]{cx-5*s,cx-12*s,cx-5*s},new int[]{cy+4*s,cy+13*s,cy+10*s},p.main);
        c.polygon(new int[]{cx+5*s,cx+12*s,cx+5*s},new int[]{cy+4*s,cy+13*s,cy+10*s},p.main);
        c.circle(cx,cy-4*s,3*s,p.accent);
        c.polygon(new int[]{cx-3*s,cx,cx+3*s},new int[]{cy+9*s,cy+18*s,cy+9*s},p.sun);
        c.rect(cx-1,cy+12*s,2*s,7*s,0xffff8c48);
    }

    private void drawTelevision(Canvas c, Palette p, String q) {
        int s = Math.max(2, Math.min(c.w, c.h) / 32), cx = c.w / 2, cy = c.h / 2;
        int w = Math.min(c.w * 3 / 4, 28 * s), h = Math.min(c.h * 2 / 3, 18 * s);
        c.rect(cx - w / 2 - s, cy - h / 2 - s, w + 2 * s, h + 2 * s, 0xff20212b);
        c.rect(cx - w / 2, cy - h / 2, w, h, 0xff111827);
        c.rect(cx - w / 2 + s, cy - h / 2 + s, w - 2 * s, h - 2 * s, p.main);
        for (int y = cy - h / 2 + s; y < cy + h / 2 - s; y++) {
            float t = (y - (cy - h / 2 + s)) / (float) Math.max(1, h - 2 * s);
            c.line(cx - w / 2 + s, y, cx + w / 2 - s, y, mix(p.light, p.shadow, t));
        }
        c.circle(cx - w / 5, cy - h / 10, Math.max(2, s), p.sun);
        c.line(cx - w / 3, cy + h / 5, cx + w / 3, cy - h / 4, p.accent);
        c.line(cx - w / 2 - s, cy - h / 2 - s, cx - w / 2 - 5 * s, cy - h / 2 - 7 * s, 0xff555766);
        c.line(cx + w / 2 + s, cy - h / 2 - s, cx + w / 2 + 5 * s, cy - h / 2 - 7 * s, 0xff555766);
        c.rect(cx - 4 * s, cy + h / 2 + s, 8 * s, 2 * s, 0xff454650);
        c.rect(cx - 8 * s, cy + h / 2 + 3 * s, 16 * s, s, 0xff30313b);
        if (contains(q, "eski", "retro", "tup", "crt")) {
            c.circle(cx + w / 2 - 2 * s, cy - h / 4, s, p.sun);
            c.circle(cx + w / 2 - 2 * s, cy, s, p.accent);
        }
    }

    private void drawCar(Canvas c, Palette p) {
        int s=Math.max(2,Math.min(c.w,c.h)/32), cx=c.w/2, cy=c.h/2;
        c.polygon(new int[]{cx-15*s,cx-10*s,cx-6*s,cx+8*s,cx+13*s,cx+16*s,cx+16*s,cx-16*s},
                new int[]{cy+2*s,cy-6*s,cy-9*s,cy-9*s,cy-3*s,cy+2*s,cy+6*s,cy+6*s},p.main);
        c.polygon(new int[]{cx-7*s,cx-4*s,cx+6*s,cx+10*s},new int[]{cy-7*s,cy-7*s,cy-7*s,cy-3*s},p.light);
        c.circle(cx-10*s,cy+7*s,4*s,0xff252733); c.circle(cx+10*s,cy+7*s,4*s,0xff252733);
        c.circle(cx-10*s,cy+7*s,2*s,p.light); c.circle(cx+10*s,cy+7*s,2*s,p.light);
        c.rect(cx+14*s,cy,2*s,2*s,p.sun); c.rect(cx-16*s,cy,2*s,2*s,0xffff8a69);
    }

    private void drawDog(Canvas c, Palette p) {
        int s=Math.max(2,Math.min(c.w,c.h)/32),cx=c.w/2,cy=c.h/2;
        c.ellipse(cx,cy+4*s,10*s,7*s,p.main); c.circle(cx+8*s,cy-5*s,6*s,p.light);
        c.ellipse(cx+12*s,cy-2*s,5*s,3*s,p.main);
        c.polygon(new int[]{cx+4*s,cx+5*s,cx+10*s},new int[]{cy-8*s,cy-17*s,cy-8*s},p.shadow);
        c.polygon(new int[]{cx+11*s,cx+14*s,cx+17*s},new int[]{cy-8*s,cy-16*s,cy-5*s},p.shadow);
        c.circle(cx+10*s,cy-6*s,1+s/2,0xff171827); c.circle(cx+16*s,cy-1*s,1+s/2,0xff171827);
        c.rect(cx-6*s,cy+8*s,3*s,7*s,p.shadow); c.rect(cx+5*s,cy+8*s,3*s,7*s,p.shadow);
        c.line(cx-8*s,cy+1*s,cx-15*s,cy-5*s,p.main);
    }

    private void drawPerson(Canvas c, Palette p) {
        int s=Math.max(2,Math.min(c.w,c.h)/32),cx=c.w/2,cy=c.h/2;
        c.circle(cx,cy-12*s,6*s,p.light); c.rect(cx-8*s,cy-5*s,16*s,15*s,p.main);
        c.polygon(new int[]{cx-8*s,cx-12*s,cx-16*s,cx-10*s},new int[]{cy-3*s,cy+5*s,cy+12*s,cy+12*s},p.shadow);
        c.polygon(new int[]{cx+8*s,cx+12*s,cx+16*s,cx+10*s},new int[]{cy-3*s,cy+5*s,cy+12*s,cy+12*s},p.shadow);
        c.rect(cx-6*s,cy+10*s,5*s,12*s,p.shadow); c.rect(cx+2*s,cy+10*s,5*s,12*s,p.shadow);
        c.rect(cx-3*s,cy-13*s,2*s,2*s,0xff202033); c.rect(cx+3*s,cy-13*s,2*s,2*s,0xff202033);
    }

    private void drawComputer(Canvas c, Palette p) {
        int s=Math.max(2,Math.min(c.w,c.h)/32),cx=c.w/2,cy=c.h/2;
        c.rect(cx-13*s,cy-15*s,26*s,20*s,0xff252a38);
        c.rect(cx-11*s,cy-13*s,22*s,16*s,p.main);
        c.line(cx-9*s,cy+1*s,cx+9*s,cy-8*s,p.accent);
        c.rect(cx-2*s,cy+5*s,4*s,5*s,0xff777b8c);
        c.rect(cx-8*s,cy+10*s,16*s,2*s,0xff777b8c);
        c.rect(cx-14*s,cy+14*s,28*s,3*s,0xff343846);
    }

    private void drawPlane(Canvas c, Palette p) {
        int s=Math.max(2,Math.min(c.w,c.h)/32),cx=c.w/2,cy=c.h/2;
        c.polygon(new int[]{cx-18*s,cx+18*s,cx+8*s,cx+3*s,cx-7*s},new int[]{cy,cy,cy+4*s,cy+1*s,cy+1*s},p.light);
        c.polygon(new int[]{cx-2*s,cx+7*s,cx+1*s,cx-7*s},new int[]{cy,cy-12*s,cy-8*s,cy+1*s},p.main);
        c.polygon(new int[]{cx-2*s,cx+7*s,cx+1*s,cx-7*s},new int[]{cy,cy+12*s,cy+8*s,cy+1*s},p.main);
        c.polygon(new int[]{cx-15*s,cx-18*s,cx-10*s},new int[]{cy,cy-6*s,cy},p.shadow);
    }

    private void drawPlanet(Canvas c, Palette p) {
        int s=Math.max(2,Math.min(c.w,c.h)/32),cx=c.w/2,cy=c.h/2;
        c.ellipse(cx,cy,12*s,12*s,p.main);
        c.ellipse(cx-3*s,cy-4*s,5*s,3*s,p.light);
        c.ellipse(cx+5*s,cy+5*s,4*s,3*s,p.accent);
        c.ellipse(cx,cy,18*s,5*s,p.sun);
        c.ellipse(cx,cy,18*s,2*s,0xff5b527f);
    }

    private void drawBird(Canvas c, Palette p) {
        int s=Math.max(2,Math.min(c.w,c.h)/32),cx=c.w/2,cy=c.h/2;
        c.ellipse(cx,cy,10*s,6*s,p.main);
        c.polygon(new int[]{cx-2*s,cx-13*s,cx-8*s,cx+2*s},new int[]{cy,cy-10*s,cy-5*s,cy+2*s},p.light);
        c.circle(cx+7*s,cy-3*s,3*s,p.light);
        c.polygon(new int[]{cx+10*s,cx+17*s,cx+10*s},new int[]{cy-3*s,cy,cy+1*s},p.sun);
        c.line(cx-3*s,cy+5*s,cx-4*s,cy+12*s,p.shadow);
        c.line(cx+3*s,cy+5*s,cx+4*s,cy+12*s,p.shadow);
    }

    private void drawPromptObject(Canvas c, Palette p, String q) {
        // Hazır listede olmayan nesneler için istem + araştırma ipuçlarından parçalı kompozisyon kur.
        int s=Math.max(2,Math.min(c.w,c.h)/32),cx=c.w/2,cy=c.h/2;
        int seed=Math.abs(q.hashCode());
        if (contains(q,"teleskop","telescope")) {
            c.polygon(new int[]{cx-8*s,cx+9*s,cx+7*s,cx-10*s},new int[]{cy-13*s,cy-8*s,cy-3*s,cy-8*s},p.main);
            c.ellipse(cx-9*s,cy-10*s,2*s,3*s,p.light); c.ellipse(cx+8*s,cy-5*s,2*s,3*s,p.accent);
            c.line(cx,cy-3*s,cx,cy+7*s,p.shadow); c.line(cx,cy+2*s,cx-9*s,cy+13*s,p.shadow);
            c.line(cx,cy+2*s,cx+9*s,cy+13*s,p.shadow); c.line(cx,cy+6*s,cx,cy+14*s,p.shadow);
        } else if (contains(q,"sandalye","chair")) {
            c.rect(cx-9*s,cy-13*s,18*s,17*s,p.main); c.rect(cx-11*s,cy+2*s,22*s,4*s,p.light);
            c.line(cx-8*s,cy+6*s,cx-11*s,cy+16*s,p.shadow); c.line(cx+8*s,cy+6*s,cx+11*s,cy+16*s,p.shadow);
            c.line(cx-8*s,cy-10*s,cx-8*s,cy+2*s,p.accent); c.line(cx+8*s,cy-10*s,cx+8*s,cy+2*s,p.accent);
        } else if (contains(q,"kupa","bardak","cup","mug")) {
            c.rect(cx-9*s,cy-10*s,18*s,23*s,p.main); c.rect(cx-7*s,cy-8*s,14*s,3*s,p.light);
            c.circle(cx+10*s,cy-1*s,7*s,p.accent); c.circle(cx+10*s,cy-1*s,4*s,p.backgroundTop);
            c.rect(cx-7*s,cy+10*s,14*s,2*s,p.shadow);
        } else if (contains(q,"gemi","tekne","ship","boat")) {
            c.polygon(new int[]{cx-18*s,cx+18*s,cx+11*s,cx-12*s},new int[]{cy+3*s,cy+3*s,cy+12*s,cy+12*s},p.main);
            c.line(cx,cy-17*s,cx,cy+3*s,p.shadow);
            c.polygon(new int[]{cx-1*s,cx-1*s,cx-12*s},new int[]{cy-15*s,cy-2*s,cy-2*s},p.light);
            c.polygon(new int[]{cx+2*s,cx+2*s,cx+12*s},new int[]{cy-12*s,cy-1*s,cy-1*s},p.accent);
            c.line(cx-20*s,cy+15*s,cx+20*s,cy+15*s,p.light);
        } else if (contains(q,"kamera","camera")) {
            c.rect(cx-17*s,cy-9*s,34*s,22*s,p.main); c.rect(cx-8*s,cy-13*s,15*s,5*s,p.shadow);
            c.circle(cx,cy+2*s,9*s,p.shadow); c.circle(cx,cy+2*s,6*s,p.accent); c.circle(cx,cy+2*s,3*s,p.light);
            c.circle(cx+12*s,cy-5*s,2*s,p.sun);
        } else if (contains(q,"saat","clock")) {
            c.circle(cx,cy,16*s,p.shadow); c.circle(cx,cy,13*s,p.light); c.circle(cx,cy,11*s,p.backgroundTop);
            for(int i=0;i<12;i++){ double a=i*Math.PI/6; c.circle(cx+(int)(9*s*Math.sin(a)),cy-(int)(9*s*Math.cos(a)),Math.max(1,s),p.accent); }
            c.line(cx,cy,cx,cy-7*s,p.main); c.line(cx,cy,cx+7*s,cy+4*s,p.main);
        } else if (contains(q,"kitap","book")) {
            c.polygon(new int[]{cx-14*s,cx-2*s,cx-2*s,cx-14*s},new int[]{cy-13*s,cy-10*s,cy+13*s,cy+10*s},p.main);
            c.polygon(new int[]{cx-1*s,cx+14*s,cx+14*s,cx-1*s},new int[]{cy-10*s,cy-13*s,cy+10*s,cy+13*s},p.accent);
            c.line(cx-1*s,cy-10*s,cx-1*s,cy+13*s,p.light);
        } else {
            // Bilinmeyen adlarda tek bir kutu yerine farklı gövdeler, çıkıntılar ve yüzey ayrıntısı üret.
            int w=(8+(seed%10))*s, h=(7+((seed>>>4)%10))*s;
            int shape=(seed>>>8)%4;
            if(shape==0) c.rect(cx-w/2,cy-h/2,w,h,p.main);
            else if(shape==1) c.ellipse(cx,cy,w/2,h/2,p.main);
            else if(shape==2) c.polygon(new int[]{cx-w/2,cx+w/2,cx+w/3,cx-w/3},new int[]{cy,cy,cy+h/2,cy+h/2},p.main);
            else c.polygon(new int[]{cx,cx+w/2,cx,cx-w/2},new int[]{cy-h/2,cy,cy+h/2,cy},p.main);
            c.rect(cx-w/2+s,cy-h/2+s,w-2*s,Math.max(s,h/5),p.light);
            c.rect(cx-w/2+s,cy+h/4,w-2*s,Math.max(s,h/8),p.shadow);
            c.circle(cx+w/3,cy-h/5,Math.max(2,s),p.sun);
            c.line(cx-w/2,cy+h/2,cx-w/2-3*s,cy+h/2+4*s,p.accent);
            c.line(cx+w/2,cy+h/2,cx+w/2+3*s,cy+h/2+4*s,p.accent);
            for(int i=0;i<6;i++) c.rect(cx-w/2+s+i*(w/6),cy+h/2+s,Math.max(1,s/2),Math.max(1,s/2),p.accent);
        }
        // İstem ve web araştırmasındaki renk/ışık vurgularından sahneye rastgele ama tekrarlanabilir ayrıntı.
        for(int i=0;i<5;i++) {
            int x=Math.floorMod(seed + i*73, c.w), y=Math.floorMod((seed>>>3) + i*41, Math.max(1,c.h*2/3));
            if((seed & (1<<i))!=0) c.circle(x,y,Math.max(1,s/2),p.sun);
        }
    }

    private void drawAbstract(Canvas c, Palette p) {
        int cx = c.w/2, cy = c.h/2;
        for (int i=12;i>=1;i--) c.circle(cx, cy, i*Math.max(2,c.w/34), (p.main & 0x00ffffff) | (Math.min(170, 20+i*8)<<24));
        for (int i=0;i<8;i++) {
            int x = c.random.nextInt(c.w), y=c.random.nextInt(c.h);
            c.line(cx, cy, x, y, (p.accent & 0x00ffffff) | 0x887fffff);
            c.circle(x,y,Math.max(2,c.w/80),p.light);
        }
        c.polygon(new int[]{cx, cx+c.w/9, cx, cx-c.w/9}, new int[]{cy-c.h/5,cy,cy+c.h/5,cy},p.accent);
    }

    private void drawFinishingPixels(Canvas c, Palette p) {
        int count = Math.max(8, c.w*c.h/700);
        for (int i=0;i<count;i++) {
            int x=c.random.nextInt(c.w), y=c.random.nextInt(c.h);
            if (c.get(x,y) == p.backgroundTop || c.get(x,y) == p.backgroundBottom) {
                c.rect(x,y,1,1,p.light);
            }
        }
    }


    private String trainingLabel(String prompt, String subject) {
        if (!"diger".equals(subject)) return subjectLabel(subject);
        String label = normalize(prompt)
                .replaceAll("\\b(?:resim|gorsel|foto|png|720p|1280x720|ciz|cizim|yap|uret|olustur|hazirla|tasarla|bana|bir|lutfen|istiyorum)\\b", " ")
                .replaceAll("[^\\p{L}\\p{N} ]", " ").replaceAll("\\s+", " ").trim();
        if (label.length() < 2) return "özel nesne";
        if (label.length() > 48) label = label.substring(0, 48).trim();
        return label;
    }

    private String subjectLabel(String s) {
        switch (s) {
            case "ejderha": return "ejderha";
            case "kedi": return "kedi";
            case "agac": return "ağaç";
            case "ev": return "ev";
            case "dag": return "dağ manzarası";
            case "kristal": return "kristal";
            case "cicek": return "çiçek";
            case "balik": return "balık";
            case "robot": return "robot";
            case "mantar": return "mantar";
            case "roket": return "roket";
            case "televizyon": return "televizyon";
            case "araba": return "araba";
            case "kopek": return "köpek";
            case "insan": return "insan";
            case "bilgisayar": return "bilgisayar";
            case "ucak": return "uçak";
            case "gezegen": return "gezegen";
            case "kus": return "kuş";
            case "zurafa": return "zürafa";
            default: return "prompt tabanlı özel nesne";
        }
    }

    private static byte[] encodePng(int width, int height, int[] pixels) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        output.write(new byte[]{(byte)137,80,78,71,13,10,26,10});
        ByteArrayOutputStream ihdr = new ByteArrayOutputStream();
        writeInt(ihdr,width); writeInt(ihdr,height); ihdr.write(8); ihdr.write(6); ihdr.write(0); ihdr.write(0); ihdr.write(0);
        writeChunk(output,"IHDR",ihdr.toByteArray());
        ByteArrayOutputStream compressed = new ByteArrayOutputStream();
        try (DeflaterOutputStream deflater = new DeflaterOutputStream(compressed)) {
            byte[] row = new byte[1 + width*4];
            for (int y=0;y<height;y++) {
                row[0]=0;
                int pos=1;
                for (int x=0;x<width;x++) {
                    int color=pixels[y*width+x];
                    row[pos++]=(byte)(color>>>16); row[pos++]=(byte)(color>>>8); row[pos++]=(byte)color; row[pos++]=(byte)(color>>>24);
                }
                deflater.write(row);
            }
        }
        writeChunk(output,"IDAT",compressed.toByteArray());
        writeChunk(output,"IEND",new byte[0]);
        return output.toByteArray();
    }

    private static void writeChunk(ByteArrayOutputStream out, String type, byte[] data) throws IOException {
        byte[] name=type.getBytes(StandardCharsets.US_ASCII);
        writeInt(out,data.length); out.write(name); out.write(data);
        CRC32 crc=new CRC32(); crc.update(name); crc.update(data); writeInt(out,(int)crc.getValue());
    }
    private static void writeInt(ByteArrayOutputStream out,int value) { out.write((value>>>24)&255); out.write((value>>>16)&255); out.write((value>>>8)&255); out.write(value&255); }
    private static int mix(int a,int b,float t) {
        int aa=(a>>>24)&255, ar=(a>>>16)&255, ag=(a>>>8)&255, ab=a&255;
        int ba=(b>>>24)&255, br=(b>>>16)&255, bg=(b>>>8)&255, bb=b&255;
        return ((int)(aa+(ba-aa)*t)<<24)|((int)(ar+(br-ar)*t)<<16)|((int)(ag+(bg-ag)*t)<<8)|(int)(ab+(bb-ab)*t);
    }

    private static boolean contains(String text,String... values) { for(String value:values) if(text.contains(value)) return true; return false; }

    /** Kelime sınırı kullanır; "görev" içindeki "ev" gibi yanlış eşleşmeleri engeller. */
    private static boolean containsWordOrPrefix(String text, String... values) {
        String normalized = " " + text.replaceAll("[^a-z0-9]+", " ").trim() + " ";
        String[] words = normalized.trim().isEmpty() ? new String[0] : normalized.trim().split("\\s+");
        for (String value : values) {
            if (value.indexOf(' ') >= 0) {
                if (normalized.contains(" " + value + " ")) return true;
                continue;
            }
            for (String word : words) {
                if (word.equals(value) || (value.length() >= 3 && word.startsWith(value))) return true;
            }
        }
        return false;
    }
    private static String normalize(String text) {
        String q=(text==null?"":text).toLowerCase(Locale.ROOT);
        return q.replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c');
    }

    private static final class Palette {
        final int backgroundTop,backgroundBottom,main,light,shadow,accent,sun;
        Palette(int top,int bottom,int main,int light,int shadow,int accent,int sun) { this.backgroundTop=top;this.backgroundBottom=bottom;this.main=main;this.light=light;this.shadow=shadow;this.accent=accent;this.sun=sun; }
        static Palette from(String q) {
            if(contains(q,"kirmizi","red","ates","fire")) return new Palette(0xfff2b48e,0xff743b58,0xffc63745,0xffff986e,0xff642c46,0xffffcf76,0xffffe5a0);
            if(contains(q,"mavi","blue","buz","ice")) return new Palette(0xffb6e0ed,0xff3f6c9b,0xff397fd0,0xff8ee6fb,0xff203c70,0xff66d5d2,0xffffefad);
            if(contains(q,"yesil","green","doga","orman")) return new Palette(0xffd2e8af,0xff559b76,0xff438b4b,0xffa6d75f,0xff285b43,0xffe0bd68,0xffffe39a);
            if(contains(q,"mor","purple","efsun","sihir")) return new Palette(0xffd8b9ef,0xff584b89,0xff8055c8,0xffc49af3,0xff392b68,0xff5de0cd,0xffffe3a0);
            if(contains(q,"siyah","black","gri","gray","grey")) return new Palette(0xffc7cbd5,0xff4c5363,0xff6b7280,0xffe5e7eb,0xff293241,0xff29b6b0,0xffffdc86);
            if(contains(q,"beyaz","white")) return new Palette(0xffe8edf5,0xff9da8b8,0xffd9e2ef,0xffffffff,0xff78869a,0xff53c8ba,0xffffd88a);
            if(contains(q,"sari","yellow","altin","gold")) return new Palette(0xffffebad,0xffbd853f,0xffe8b83e,0xffffec87,0xff876025,0xffeb795b,0xffffffff);
            return new Palette(0xffd5d8fa,0xff6589ad,0xff6e71c8,0xffb5b8ff,0xff383b70,0xff45c7b2,0xffffdf8e);
        }
    }

    private static final class Canvas {
        final int w,h; final int[] pixels; final Random random;
        Canvas(int width,int height,Random random) { w=width;h=height;pixels=new int[width*height];this.random=random; }
        void set(int x,int y,int color) { if(x>=0&&y>=0&&x<w&&y<h) pixels[y*w+x]=color; }
        int get(int x,int y) { return x>=0&&y>=0&&x<w&&y<h?pixels[y*w+x]:0; }
        void rect(int x,int y,int width,int height,int color) { for(int yy=Math.max(0,y);yy<Math.min(h,y+height);yy++) for(int xx=Math.max(0,x);xx<Math.min(w,x+width);xx++) set(xx,yy,color); }
        void circle(int cx,int cy,int radius,int color) { int r=Math.max(1,radius); for(int y=-r;y<=r;y++) for(int x=-r;x<=r;x++) if(x*x+y*y<=r*r) set(cx+x,cy+y,color); }
        void ellipse(int cx,int cy,int rx,int ry,int color) { int ax=Math.max(1,rx),ay=Math.max(1,ry); for(int y=-ay;y<=ay;y++) for(int x=-ax;x<=ax;x++) if((double)x*x/(ax*ax)+(double)y*y/(ay*ay)<=1) set(cx+x,cy+y,color); }
        void line(int x0,int y0,int x1,int y1,int color) { int dx=Math.abs(x1-x0),sx=x0<x1?1:-1,dy=-Math.abs(y1-y0),sy=y0<y1?1:-1,err=dx+dy; while(true){set(x0,y0,color);if(x0==x1&&y0==y1)break;int e2=2*err;if(e2>=dy){err+=dy;x0+=sx;}if(e2<=dx){err+=dx;y0+=sy;}} }
        void polygon(int[] xs,int[] ys,int color) {
            if(xs.length<3||xs.length!=ys.length)return;
            int minY=h,maxY=0; for(int y:ys){minY=Math.min(minY,y);maxY=Math.max(maxY,y);}
            for(int y=Math.max(0,minY);y<=Math.min(h-1,maxY);y++) {
                int[] nodes=new int[xs.length];int n=0;
                for(int i=0,j=xs.length-1;i<xs.length;j=i++) if((ys[i]<y&&ys[j]>=y)||(ys[j]<y&&ys[i]>=y)) nodes[n++]=xs[i]+(y-ys[i])*(xs[j]-xs[i])/(ys[j]-ys[i]);
                java.util.Arrays.sort(nodes,0,n);
                for(int i=0;i+1<n;i+=2) for(int x=Math.max(0,nodes[i]);x<=Math.min(w-1,nodes[i+1]);x++)set(x,y,color);
            }
        }
    }
}
