package com.jai.assistant.engine;

import com.jai.assistant.data.MemoryDatabase;
import com.jai.assistant.data.ChatMessage;
import com.jai.assistant.data.TaskRecord;
import com.jai.assistant.tools.FileManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import java.io.InputStream;
import java.io.IOException;

/** Yerel istek sınıflandırma, küçük araç seçimi ve cevap birleştirme çekirdeği. */
public final class BrainEngine {
    private final MemoryDatabase database;
    private final ModelEngine modelEngine;
    private final LocalSearchEngine localSearchEngine;
    private final LearningEngine learningEngine;
    private final TaskPlanner taskPlanner;
    private final TaskPersistence taskPersistence;
    private final CodeLabEngine codeLabEngine;
    private final LocalLanguageEngine localLanguageEngine;
    private final LocalOnnxLanguageModel conversationalModel;
    private final CodeGenerator codeGenerator;
    private final ResourceManager resourceManager;
    private final ToolRegistry tools;
    private final FileManager fileManager;

    public BrainEngine(android.content.Context context, MemoryDatabase database) {
        this(context, database, new FileManager(), null);
    }

    public BrainEngine(android.content.Context context, MemoryDatabase database, FileManager fileManager) {
        this(context, database, fileManager, null);
    }

    public BrainEngine(android.content.Context context, MemoryDatabase database, FileManager fileManager,
                       VisualLearningEngine visualLearningEngine) {
        this.database = database;
        this.modelEngine = new ModelEngine(database);
        this.localSearchEngine = new LocalSearchEngine(database);
        this.learningEngine = new LearningEngine(database);
        this.taskPlanner = new TaskPlanner();
        this.taskPersistence = new TaskPersistence(database);
        this.codeLabEngine = new CodeLabEngine();
        this.localLanguageEngine = new LocalLanguageEngine(database);
        this.conversationalModel = context == null ? null : new LocalOnnxLanguageModel(context);
        this.codeGenerator = new CodeGenerator(visualLearningEngine, context);
        this.resourceManager = new ResourceManager(context);
        this.tools = new ToolRegistry();
        this.fileManager = fileManager == null ? new FileManager() : fileManager;
        tools.register("calculator", expression -> expression + " = " + formatNumber(ExpressionEvaluator.evaluate(expression))
                        + "\n\nHesaplama yerel ifade değerlendiricisiyle yapıldı; dış servise gönderilmedi.",
                request -> looksLikeMath(request) ? 100 : 0, this::extractExpression);
        tools.register("memory_search", query -> localSearchEngine.search(query, 8),
                request -> containsAny(request.toLowerCase(Locale.forLanguageTag("tr-TR")),
                        "hafızada ara", "hafizada ara", "ne hatırlıyorsun", "ne hatirliyorsun", "yerel hafıza", "yerel hafiza") ? 90 : 0,
                this::extractMemorySearchQuery);
        tools.register("device_resources", ignored -> resourceManager.describe(),
                request -> containsAny(request.toLowerCase(Locale.forLanguageTag("tr-TR")),
                        "ram durum", "bellek durumu", "depolama durumu", "telefon kaynakları", "kaynak kullanım") ? 90 : 0,
                ignored -> "");
        tools.register("static_code_check", input -> {
            int newline = input.indexOf('\n');
            String language = newline < 0 ? "bilinmeyen dil" : input.substring(0, newline).trim();
            String code = newline < 0 ? input : input.substring(newline + 1);
            return codeLabEngine.analyze(code, language);
        }, request -> {
            String lower = request.toLowerCase(Locale.forLanguageTag("tr-TR"));
            boolean asksForCheck = containsAny(lower, "kodu kontrol et", "kod hatası", "kod hatasi", "ayraç kontrol", "ayrac kontrol");
            return asksForCheck && (!extractAttachedCode(request).isEmpty() || !extractFencedCode(request).isEmpty()) ? 110 : 0;
        }, request -> {
            String code = extractAttachedCode(request);
            if (code.isEmpty()) code = extractFencedCode(request);
            return detectLanguage(request) + "\n" + code;
        });
        // Dosya eki, kullanıcı tarafından seçilip okunmuş içerikten gelir; araç keyfî URI açmaz.
        tools.register("file_inspect", request -> this.fileManager.inspectAttachmentContext(request),
                request -> request != null && request.contains("[Metin eki:") ? 90 : 0,
                request -> request == null ? "" : request);
    }

    /** ONNX dosyası arka plan iş parçacığında açılır; Activity açılışında UI kilitlenmez. */
    public boolean initializeLanguageModel() {
        return conversationalModel != null && conversationalModel.reload();
    }

    public void close() {
        if (conversationalModel != null) conversationalModel.close();
    }

    public String getLanguageModelStatus() {
        return conversationalModel == null ? "Yerel dil modeli yöneticisi başlatılamadı." : conversationalModel.getStatus();
    }

    public boolean hasConversationalModel() {
        return conversationalModel != null && conversationalModel.isReady();
    }

    public String importLanguageModel(InputStream input) throws IOException {
        if (conversationalModel == null) throw new IOException("Yerel model yöneticisi hazır değil.");
        return conversationalModel.importPackage(input);
    }

    public interface StageProgressListener {
        void onStage(int completed, int total, String label);
    }

    public String answer(String prompt, String mode, String effort) {
        return answer(prompt, mode, effort, true, 8, null);
    }

    /** Flash doğrudan çalışır; Think her gerçek yerel adımı SQLite'a kontrol noktası olarak yazar. */
    public String answer(String prompt, String mode, String effort, boolean autoStageMode,
                         int manualStageCount, StageProgressListener progressListener) {
        return answer(prompt, mode, effort, autoStageMode, manualStageCount, progressListener, "");
    }

    /** Web araştırma raporu gibi dış kanıtları, yanıt üretilmeden önce Flash/Think bağlamına ekler. */
    public String answer(String prompt, String mode, String effort, boolean autoStageMode,
                         int manualStageCount, StageProgressListener progressListener, String supplementalContext) {
        String safePrompt = prompt == null ? "" : prompt.trim();
        String safeSupplementalContext = supplementalContext == null ? "" : supplementalContext.trim();
        String lower = safePrompt.toLowerCase(Locale.forLanguageTag("tr-TR"));
        if (startsWithCommand(lower, "görev devam:", "gorev devam:")) {
            long resumeId = parseTrailingId(safePrompt);
            if (resumeId > 0 && isPersistentBrainTask(resumeId)) {
                return resumeBrainTask(resumeId, progressListener);
            }
        }
        if (!"Think".equalsIgnoreCase(mode) || safePrompt.isEmpty()) {
            return answerCore(safePrompt, mode, effort, null, safeSupplementalContext, "", "");
        }

        TaskStageEngine.Plan stagePlan = TaskStageEngine.createPlan(
                safePrompt, effort, autoStageMode, manualStageCount);
        try {
            JSONObject state = new JSONObject();
            state.put("schema", "jai-brain-task-v1");
            state.put("mode", "Think");
            state.put("effort", effort == null ? "Orta" : effort);
            state.put("automatic", stagePlan.automatic);
            state.put("requested_stage_limit", stagePlan.requestedStageLimit);
            state.put("stop_reason", stagePlan.stopReason);
            state.put("next_stage", 0);
            state.put("intent", "");
            state.put("classification_confidence", 0.0);
            state.put("context", "");
            state.put("supplemental_context", safeSupplementalContext);
            state.put("selected_tool", "");
            state.put("selected_tool_input", "");
            state.put("result", "");
            state.put("verification", "bekliyor");
            JSONArray stages = new JSONArray();
            for (TaskStageEngine.Stage stage : stagePlan.stages) stages.put(stage.name());
            state.put("stages", stages);
            JSONArray completed = new JSONArray();
            state.put("completed", completed);

            String title = safePrompt.length() > 100 ? safePrompt.substring(0, 97) + "…" : safePrompt;
            long taskId = taskPersistence.enqueueBrainTask(title, "Çalışıyor", state.toString(), safePrompt);
            if (taskId <= 0) return "Think görevi başlatılamadı: yerel görev kaydı oluşturulamadı.";
            return runBrainTask(taskId, state, stagePlan, progressListener);
        } catch (Exception exception) {
            return "Think görevi hazırlanırken hata oluştu: " + safeMessage(exception);
        }
    }

    /** Görev tablosundaki kind alanından yerel Think görevi olup olmadığını belirler. */
    public boolean isPersistentBrainTask(long taskId) {
        return taskPersistence.isKind(taskId, "brain");
    }

    private String resumeBrainTask(long taskId, StageProgressListener listener) {
        TaskRecord record = taskPersistence.get(taskId);
        if (record == null || !"brain".equals(record.kind)) return "Bu numarayla devam ettirilebilir bir Think görevi bulunamadı.";
        try {
            JSONObject state = new JSONObject(record.details == null ? "{}" : record.details);
            if (!"jai-brain-task-v1".equals(state.optString("schema"))) {
                return "Görev kaydı bu sürümün Think görev biçimiyle uyumlu değil; mevcut kayıt değiştirilmedi.";
            }
            if ("Tamamlandı".equals(record.status)) {
                String saved = state.optString("final_result", "");
                return saved.isEmpty() ? "Bu Think görevi tamamlanmış ancak sonuç kaydı bulunamadı." : saved;
            }
            JSONArray stageNames = state.getJSONArray("stages");
            List<TaskStageEngine.Stage> stages = new java.util.ArrayList<>();
            for (int i = 0; i < stageNames.length(); i++) stages.add(TaskStageEngine.Stage.valueOf(stageNames.getString(i)));
            TaskStageEngine.Plan plan = TaskStageEngine.restorePlan(
                    state.optBoolean("automatic", true), state.optInt("requested_stage_limit", stages.size()),
                    stages, state.optString("stop_reason", ""));
            return runBrainTask(taskId, state, plan, listener);
        } catch (Exception exception) {
            return "Think görevi okunamadı: " + safeMessage(exception) + ". Kayıt silinmedi.";
        }
    }

    private String runBrainTask(long taskId, JSONObject state, TaskStageEngine.Plan stagePlan,
                                StageProgressListener progressListener) {
        try {
            String prompt = taskPersistence.getBrainTaskPrompt(taskId);
            if (prompt == null || prompt.trim().isEmpty()) {
                throw new IllegalStateException("Think görevinin özgün girdisi bulunamadı; görev tamamlandı sayılmadı.");
            }
            String effort = state.optString("effort", "Orta");
            String intent = state.optString("intent", "");
            String context = state.optString("context", "");
            String result = state.optString("result", "");
            int nextStage = Math.max(0, Math.min(state.optInt("next_stage", 0), stagePlan.stages.size()));
            JSONArray completed = state.optJSONArray("completed");
            if (completed == null) completed = new JSONArray();

            for (int index = nextStage; index < stagePlan.stages.size(); index++) {
                TaskStageEngine.Stage stage = stagePlan.stages.get(index);
                state.put("current_stage", index);
                state.put("phase", "running");
                persistCheckpoint(taskId, "Çalışıyor · " + stage.displayName, state.toString());
                String label;
                switch (stage) {
                    case ANALYZE_REQUEST: {
                        String analysisPrompt = userRequestBeforeAttachment(prompt);
                        if (analysisPrompt.isEmpty()) analysisPrompt = prompt;
                        ModelEngine.Classification classification = modelEngine.classifyDetailed(analysisPrompt);
                        LocalIntelligenceEngine.Analysis analysis = LocalIntelligenceEngine.analyze(prompt, classification);
                        intent = analysis.intent;
                        state.put("intent", intent);
                        state.put("classification_confidence", classification.confidence);
                        state.put("classification_margin", classification.margin);
                        state.put("classification_known_tokens", classification.knownTokenCount);
                        state.put("classification_token_count", classification.tokenCount);
                        state.put("classification_known_ratio", classification.knownTokenRatio);
                        state.put("classification_evidence_strength", classification.evidenceStrength);
                        state.put("request_kind", analysis.taskKind.name());
                        state.put("request_complexity", analysis.complexity);
                        state.put("requires_fresh_information", analysis.requiresFreshInformation);
                        state.put("needs_clarification", analysis.needsClarification);
                        state.put("clarification_question", analysis.clarificationQuestion);
                        JSONArray concepts = new JSONArray();
                        for (String concept : analysis.concepts) concepts.put(concept);
                        state.put("request_concepts", concepts);
                        label = "İstek anlaşıldı · " + analysis.describe();
                        break;
                    }
                    case RETRIEVE_CONTEXT: {
                        int contextLimit = "Derin".equalsIgnoreCase(effort) ? 8
                                : ("Maksimum".equalsIgnoreCase(effort) ? 6 : 4);
                        String retrievalPrompt = userRequestBeforeAttachment(prompt);
                        if (retrievalPrompt.isEmpty()) retrievalPrompt = prompt;
                        LocalLanguageEngine.KnowledgeAssessment knowledge = localLanguageEngine.assessKnowledge(retrievalPrompt, contextLimit);
                        context = knowledge.context;
                        state.put("knowledge_status", knowledge.status.name());
                        state.put("knowledge_term_coverage", knowledge.termCoverage);
                        state.put("knowledge_matched_terms", knowledge.matchedTerms);
                        state.put("knowledge_query_terms", knowledge.queryTerms);
                        state.put("knowledge_evidence_count", knowledge.evidenceCount);
                        state.put("knowledge_best_relevance", knowledge.bestRelevance);
                        String supplemental = state.optString("supplemental_context", "");
                        if (!supplemental.isEmpty()) {
                            if (!context.isEmpty()) context += "\n\n";
                            context += supplemental;
                        }
                        state.put("context", context);
                        // Kanıt artık birleşik context'te; JSON kontrol noktasında ikinci kopyayı tutma.
                        state.put("supplemental_context", "");
                        label = "Yerel bilgi durumu · " + knowledge.statusLabel() + " · kelime kapsamı "
                                + String.format(Locale.ROOT, "%.0f%%", knowledge.termCoverage * 100.0)
                                + (supplemental.isEmpty() ? "" : " · ek dosya/web kanıtı eklendi");
                        break;
                    }
                    case BUILD_PLAN: {
                        String planningPrompt = userRequestBeforeAttachment(prompt);
                        if (planningPrompt.isEmpty()) planningPrompt = "Ekli dosyayı incele";
                        ToolRegistry.Selection selection = tools.selectBest(prompt);
                        ModelEngine.Classification planClassification = modelEngine.classifyDetailed(planningPrompt);
                        LocalIntelligenceEngine.Analysis requestAnalysis = LocalIntelligenceEngine.analyze(prompt, planClassification);
                        LocalLanguageEngine.KnowledgeAssessment knowledge = localLanguageEngine.assessKnowledge(planningPrompt,
                                "Derin".equalsIgnoreCase(effort) ? 8 : ("Maksimum".equalsIgnoreCase(effort) ? 6 : 4));
                        TaskPlanner.ExecutionPlan executionPlan = taskPlanner.createExecutionPlan(
                                planningPrompt, effort, intent, selection, requestAnalysis, knowledge);
                        state.put("request_kind", requestAnalysis.taskKind.name());
                        state.put("request_complexity", requestAnalysis.complexity);
                        state.put("requires_fresh_information", requestAnalysis.requiresFreshInformation);
                        state.put("needs_clarification", requestAnalysis.needsClarification);
                        state.put("clarification_question", requestAnalysis.clarificationQuestion);
                        state.put("plan_evidence_status", executionPlan.evidenceStatus);
                        state.put("plan_evidence_coverage", executionPlan.evidenceCoverage);
                        state.put("plan_intent", executionPlan.intent == null ? "genel" : executionPlan.intent);
                        state.put("selected_tool", executionPlan.selectedTool);
                        // Dosya ekinin tüm metni özgün prompt'ta ayrı saklanır; JSON checkpoint'e kopyalama.
                        String selectedInput = selection == null ? "" : selection.input;
                        if (selection != null && ("file_inspect".equals(selection.name)
                                || "static_code_check".equals(selection.name))) selectedInput = "";
                        state.put("selected_tool_input", selectedInput);
                        state.put("retrieve_context", executionPlan.retrieveContext);
                        state.put("verify_output", executionPlan.verifyOutput);
                        JSONArray steps = new JSONArray();
                        for (String step : executionPlan.steps) steps.put(step);
                        state.put("plan_steps", steps);
                        label = "Uygulanabilir plan oluşturuldu · " + steps.length() + " işlem";
                        break;
                    }
                    case EXECUTE_TASK: {
                        String selectedTool = state.optString("selected_tool", "");
                        String selectedInput = state.optString("selected_tool_input", "");
                        if ("file_inspect".equals(selectedTool) && selectedInput.isEmpty()) selectedInput = prompt;
                        if ("static_code_check".equals(selectedTool) && selectedInput.isEmpty()) {
                            String code = extractAttachedCode(prompt);
                            if (code.isEmpty()) code = extractFencedCode(prompt);
                            selectedInput = detectLanguage(prompt) + "\n" + code;
                        }
                        result = answerCore(prompt, "Flash", effort, intent, context, selectedTool, selectedInput);
                        state.put("result", result);
                        label = "Seçilen yerel görev/araç çalıştırıldı";
                        break;
                    }
                    case VERIFY_RESULT: {
                        if (result.trim().isEmpty()) {
                            state.put("verification", "başarısız: boş çıktı");
                            result = "İşlem yanıt üretemedi. Görev çıktısı boş olduğu için tamamlanmış sayılmadı.";
                            state.put("result", result);
                            label = "Doğrulama başarısız · boş çıktı";
                        } else if (result.contains("```")) {
                            String code = extractFencedCode(result);
                            String language = detectGeneratedLanguage(result, prompt);
                            String check = codeLabEngine.analyze(code, language);
                            result += "\n\nThink statik kod ön kontrolü:\n" + check;
                            state.put("result", result);
                            state.put("verification", "statik ön kontrol yapıldı; derleme/çalıştırma yapılmadı");
                            label = "Kod statik ön kontrolden geçirildi · derleme yapılmadı";
                        } else {
                            state.put("verification", "çıktı boş değil; olgusal doğrulama yapılmadı");
                            label = "Çıktı kontrol edildi · bağımsız olgu doğrulaması yapılmadı";
                        }
                        break;
                    }
                    default:
                        throw new IllegalStateException("Bilinmeyen Think aşaması: " + stage);
                }
                completed.put(stage.name());
                state.put("completed", completed);
                state.put("next_stage", index + 1);
                state.put("last_label", label);
                state.remove("error");
                persistCheckpoint(taskId, "Çalışıyor", state.toString());
                if (progressListener != null) progressListener.onStage(index + 1, stagePlan.stages.size(), label);
            }

            if (result.trim().isEmpty()) result = answerCore(prompt, "Flash", effort, intent, context, "", "");
            StringBuilder report = new StringBuilder(result)
                    .append("\n\nThink işlem raporu (yerel motor):")
                    .append("\n• Görev: #").append(taskId)
                    .append("\n• Mod: ").append(stagePlan.automatic ? "Akıllı" : "Manuel")
                    .append("\n• Efor: ").append(effort)
                    .append("\n• İstenen aşama sınırı: ").append(stagePlan.requestedStageLimit)
                    .append("\n• Gerçek çalıştırılan farklı aşama: ").append(completed.length())
                    .append("\n• Sınıflandırma: ").append(intent.isEmpty() ? "çalıştırma sırasında" : intent)
                    .append("\n• Sınıflandırma göreli puanı: ")
                    .append(String.format(Locale.ROOT, "%.0f%%", state.optDouble("classification_confidence", 0.0) * 100.0))
                    .append("\n• Eğitim sözlüğü eşleşmesi: ")
                    .append(state.optInt("classification_known_tokens", 0)).append("/")
                    .append(state.optInt("classification_token_count", 0))
                    .append(" kelime · kanıt gücü ")
                    .append(String.format(Locale.ROOT, "%.0f%%", state.optDouble("classification_evidence_strength", 0.0) * 100.0))
                    .append("\n• İstek biçimi: ").append(state.optString("request_kind", "genel"))
                    .append(" · karmaşıklık ").append(state.optInt("request_complexity", 1)).append("/5")
                    .append("\n• Yerel bilgi yeterliliği: ").append(state.optString("knowledge_status", "değerlendirilmedi"))
                    .append(" · kelime kapsamı ")
                    .append(String.format(Locale.ROOT, "%.0f%%", state.optDouble("knowledge_term_coverage", 0.0) * 100.0))
                    .append("\n• Seçilen araç: ").append(state.optString("selected_tool", "").isEmpty() ? "otomatik araç seçilmedi" : state.optString("selected_tool"))
                    .append("\n• Aşamalar: ");
            for (int i = 0; i < stagePlan.stages.size(); i++) {
                if (i > 0) report.append(" → ");
                report.append(stagePlan.stages.get(i).displayName);
            }
            if (!stagePlan.stopReason.isEmpty()) report.append("\n• Durma açıklaması: ").append(stagePlan.stopReason);
            report.append("\n• Model durumu: Bu işlem yerel sınıflandırma, arama, planlama ve araç yürütmesidir; eğitilmiş genel dil modeli çıkarımı değildir.");
            JSONArray planSteps = state.optJSONArray("plan_steps");
            if (planSteps != null && planSteps.length() > 0) {
                report.append("\n\nUygulanan iş planı:");
                for (int i = 0; i < planSteps.length(); i++) report.append("\n• ").append(planSteps.optString(i));
            }
            String finalResult = report.toString();
            state.put("phase", "completed");
            state.put("final_result", finalResult);
            state.put("next_stage", stagePlan.stages.size());
            persistCheckpoint(taskId, "Tamamlandı", state.toString());
            return finalResult;
        } catch (Exception exception) {
            try {
                state.put("phase", "paused_after_error");
                state.put("error", safeMessage(exception));
                taskPersistence.checkpoint(taskId, "Hata · devam edebilir", state.toString());
            } catch (Exception ignored) { }
            return "Think görevi #" + taskId + " şu aşamada durdu: " + safeMessage(exception)
                    + "\nKaydedilmiş kontrol noktasından sürdürmek için 'görev devam: " + taskId + "' yaz.\n"
                    + "Tamamlanmış aşamalar yeniden çalıştırılmayacak.";
        }
    }

    private String answerCore(String prompt, String mode, String effort) {
        return answerCore(prompt, mode, effort, null, "", "", "");
    }

    private String answerCore(String prompt, String mode, String effort, String preclassifiedIntent) {
        return answerCore(prompt, mode, effort, preclassifiedIntent, "", "", "");
    }

    private String answerCore(String prompt, String mode, String effort, String preclassifiedIntent,
                              String retrievedContext, String plannedTool, String plannedToolInput) {
        String text = prompt == null ? "" : prompt.trim();
        if (text.isEmpty()) return "Boş bir mesaj aldım. Bir soru veya görev yaz.";
        String analysisText = userRequestBeforeAttachment(text);
        if (analysisText.isEmpty()) analysisText = text;
        String lower = analysisText.toLowerCase(Locale.forLanguageTag("tr-TR"));
        ModelEngine.Classification classification = modelEngine.classifyDetailed(analysisText);
        LocalIntelligenceEngine.Analysis requestAnalysis = LocalIntelligenceEngine.analyze(text, classification);
        String label = preclassifiedIntent == null || preclassifiedIntent.isEmpty() ? requestAnalysis.intent : preclassifiedIntent;
        String answer;

        if (requestAnalysis.needsClarification && (plannedTool == null || plannedTool.isEmpty())) {
            return requestAnalysis.clarificationQuestion;
        }
        if (plannedTool != null && !plannedTool.isEmpty()) {
            if ("file_inspect".equals(plannedTool)) {
                String fileContext = toolsExecute(plannedTool, plannedToolInput);
                String combinedContext = joinContext(retrievedContext, "[JA.I DOSYA BAĞLAMI]\n" + fileContext);
                String modelAnswer = generateConversationalAnswer(analysisText, effort, combinedContext);
                return modelAnswer != null ? modelAnswer
                        : localLanguageEngine.respondWithContext(analysisText, effort, combinedContext, "seçilen dosya eki");
            }
            return toolsExecute(plannedTool, plannedToolInput);
        }
        ToolRegistry.Selection automaticTool = tools.selectBest(text);
        if (automaticTool != null) {
            if ("file_inspect".equals(automaticTool.name)) {
                String fileContext = toolsExecute(automaticTool);
                String combinedContext = joinContext(retrievedContext, "[JA.I DOSYA BAĞLAMI]\n" + fileContext);
                String modelAnswer = generateConversationalAnswer(analysisText, effort, combinedContext);
                return modelAnswer != null ? modelAnswer
                        : localLanguageEngine.respondWithContext(analysisText, effort, combinedContext, "seçilen dosya eki");
            }
            return toolsExecute(automaticTool);
        }

        if (startsWithCommand(lower, "hatırla:", "hatirla:", "/hatırla ", "/hatirla ")) {
            String content = text.substring(text.indexOf(':') >= 0 ? text.indexOf(':') + 1 : firstSpace(text)).trim();
            if (content.isEmpty()) return "Kaydedilecek metin boş. 'hatırla: kaydetmek istediğin bilgi' biçimini kullan.";
            long memoryId = database.saveMemory("Kullanıcı notu", content, "kullanıcı tarafından girildi", false);
            answer = memoryId > 0
                    ? "Bilgiyi yerel hafızaya kaydettim (#" + memoryId + "). Bu işlem genel dil yeteneğimi eğitmez; yalnızca daha sonra aranabilecek bir kayıt oluşturur. Arşivlemek için 'arşivle: " + memoryId + "' yazabilirsin."
                    : "Hafıza kaydı veritabanına yazılamadı; kaydedildiğini söyleyemem.";
        } else if (startsWithCommand(lower, "öğren:", "ogren:", "öğren ", "ogren ")) {
            String topic = text.replaceFirst("(?i)^(öğren|ogren)\\s*:?\\s*", "").trim();
            if (topic.isEmpty()) return "Öğrenme kuyruğuna eklemek için bir konu yaz: 'öğren: Java döngüleri'.";
            long id = learningEngine.enqueueTopic(topic);
            answer = "'" + topic + "' konusu yerel öğrenme kuyruğuna eklendi (görev #" + id + "). Ara açıksa görev kalıcı arka plan kuyruğuna alınabilir; internet bulunduğunda kaynakları okuyup notları ve yerel bir özeti kaydeder. Ara kapalıysa görev yalnızca bekler. Bu işlem genel dil modelini eğitmez.";
        } else if (startsWithCommand(lower, "kod üret:", "kod uret:")) {
            answer = generateCodeAnswer(text.substring(text.indexOf(':') + 1).trim(), safeSupplementalContext);
        } else if (codeGenerator.isArtifactRequest(text)) {
            answer = generateCodeAnswer(text, safeSupplementalContext);
        } else if (containsAny(lower, "arşivdekileri göster", "arsivdekileri goster", "gereksizleri göster", "gereksizleri goster")) {
            answer = localSearchEngine.archived(30);
        } else if (startsWithCommand(lower, "arşivle:", "arsivle:")) {
            answer = setMemoryStateFromCommand(text, true);
        } else if (startsWithCommand(lower, "arşivden çıkar:", "arsivden cikar:")) {
            answer = setMemoryStateFromCommand(text, false);
        } else if (startsWithCommand(lower, "hafızadan sil:", "hafizadan sil:")) {
            answer = deleteMemoryFromCommand(text);
        } else if (containsAny(lower, "görevleri göster", "gorevleri goster", "öğrenme kuyruğu", "ogrenme kuyrugu")) {
            answer = describeTasks();
        } else if (startsWithCommand(lower, "görev duraklat:", "gorev duraklat:")) {
            answer = updateTaskFromCommand(text, true);
        } else if (startsWithCommand(lower, "görev devam:", "gorev devam:")) {
            answer = updateTaskFromCommand(text, false);
        } else if (lower.startsWith("öğret-intent:") || lower.startsWith("ogret-intent:")) {
            String body = text.substring(text.indexOf(':') + 1);
            int separator = body.indexOf('|');
            if (separator <= 0 || separator >= body.length() - 1) {
                answer = "Biçim: öğret-intent:etiket|örnek cümle. Etiketler: " + String.join(", ", modelEngine.knownLabels());
            } else {
                String intent = body.substring(0, separator).trim().toLowerCase(Locale.ROOT);
                String example = body.substring(separator + 1).trim();
                answer = modelEngine.learnExample(example, intent)
                        ? "Örnek yerel sınıflandırıcının eğitim kayıtlarına eklendi ve sınıflandırıcı yeniden kuruldu. Bu yalnızca istek türü sınıflandırmasını etkiler; genel dil üretimini öğretmez."
                        : "Örnek eklenmedi. Etiketi kontrol et: " + String.join(", ", modelEngine.knownLabels());
            }
        } else if (looksLikeMath(text)) {
            String expression = extractExpression(text);
            try {
                answer = expression + " = " + formatNumber(ExpressionEvaluator.evaluate(expression)) + "\n\nHesaplama yerel dört işlem ayrıştırıcısıyla yapıldı; dış servise gönderilmedi.";
            } catch (IllegalArgumentException exception) {
                answer = "Bu matematik ifadesini hesaplayamadım: " + exception.getMessage();
            }
        } else if (containsAny(lower, "saat kaç", "bugünün tarihi", "bugün tarih", "şu an saat", "tarih nedir")) {
            answer = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT, Locale.forLanguageTag("tr-TR")).format(new Date()) + " (telefonun yerel saati).";
        } else if (containsAny(lower, "hafızada ara", "hafizada ara", "ne hatırlıyorsun", "ne hatirliyorsun", "kaydettiğim", "kayitli hafiza", "yerel hafıza", "yerel hafiza")) {
            answer = toolsExecute("memory_search", extractMemorySearchQuery(text));
        } else if (containsAny(lower, "ram durum", "bellek durumu", "depolama durumu", "telefon kaynakları", "kaynak kullanım")) {
            answer = toolsExecute("device_resources", "");
        } else if (containsAny(lower, "kodu kontrol et", "kod hatası", "kod hatasi", "ayraç kontrol", "ayrac kontrol")) {
            String attachedCode = extractAttachedCode(text);
            if (attachedCode.isEmpty()) attachedCode = extractFencedCode(text);
            if (!attachedCode.isEmpty()) {
                String language = detectLanguage(text);
                answer = toolsExecute("static_code_check", language + "\n" + attachedCode);
            } else {
                answer = "Kodu statik kontrol edebilmem için metin tabanlı bir kaynak dosyası ekle veya mesajına ```java ... ``` gibi bir kod bloğu koy. Bu araç yalnızca basit ayraçları denetler; kodu derlemez ya da çalıştırmaz.";
            }
        } else if (containsAny(lower, "merhaba", "selam", "günaydın", "iyi akşamlar", "iyi aksamlar", "nasılsın", "naber") && label.equals("selam")) {
            answer = generateConversationalAnswer(text, effort, retrievedContext);
            if (answer == null) answer = "Merhaba! Ben Ja.i. Henüz Colab'da eğitilmiş sohbet modelim yüklenmedi; yerel hafıza ve araçlarımla yardımcı olabilirim.";
        } else if (containsAny(lower, "zeka durumu", "zekâ durumu", "yerel zeka raporu", "yerel zekâ raporu")) {
            answer = describeIntelligence(requestAnalysis);
        } else if (containsAny(lower, "ne yapabiliyorsun", "özelliklerin neler", "ozelliklerin neler", "yardım", "yardim")) {
            answer = "Ja.i; çevrimdışı yerel hafıza, Ara açıkken web araştırması, PDF/fotoğraf metin analizi, kod ve web projesi üretimi, piksel tabanlı PNG, yerel görsel örnek öğrenmesi, video taslağı ve Minecraft Bedrock paket araçlarını içerir.\n\nSohbet zekâsı: "
                    + (hasConversationalModel()
                    ? "Colab'da sıfırdan eğitilip bu cihaza aktarılan yerel GRU dil modeli yüklü. Yanıt kalitesi eğitim verisine bağlıdır."
                    : "Üretken sohbet modeli henüz yüklenmedi. Colab notebook'unda model eğitip Zekâ ayarı bölümünden içe aktarmalısın.")
                    + "\n\nSınırlar: Model küçük bir yerel dil modelidir; büyük genel amaçlı modellerle eşdeğer olduğu iddia edilmez. Görsel/video araçları fotogerçekçi diffusion modeli değildir. Üretilen kod, dosya veya Minecraft paketleri için gerçek derleme/oyun testi gerekebilir.";
        } else if (label.equals("kod") && wantsCodeGeneration(lower)) {
            answer = generateCodeAnswer(text, safeSupplementalContext);
        } else {
            if (retrievedContext != null && (retrievedContext.contains("[JA.I WEB ARAŞTIRMA BAĞLAMI]")
                    || retrievedContext.contains("[JA.I DOSYA BAĞLAMI]"))) {
                answer = generateConversationalAnswer(text, effort, retrievedContext);
                if (answer == null) {
                    answer = localLanguageEngine.respondWithContext(text, effort, retrievedContext, "yerel hafıza ve web kanıtı");
                }
            } else {
                answer = generateConversationalAnswer(text, effort, retrievedContext);
                if (answer == null) answer = localLanguageEngine.respond(text, effort, retrievedContext);
            }
        }

        return answer;
    }

    private String generateConversationalAnswer(String prompt, String effort, String context) {
        if (conversationalModel == null || !conversationalModel.isReady()) return null;
        List<ChatMessage> history = database.getRecentMessages(8);
        String generated = conversationalModel.generate(history, prompt, context, effort);
        return generated;
    }

    public boolean shouldResearch(String prompt) {
        String text = prompt == null ? "" : prompt.trim().toLowerCase(Locale.forLanguageTag("tr-TR"));
        if (text.length() < 5) return false;
        boolean fileOnlyRequest = containsAny(text, "dosyayı incele", "dosyayi incele", "dosyayı oku", "dosyayi oku",
                "dosyada ne var", "dosyadaki", "dosyanın içeriği", "dosyanin icerigi", "dosya içeriği", "dosya icerigi",
                "ekli dosya", "eklediğim dosya", "ekledigim dosya", "yüklediğim dosya", "yukledigim dosya",
                "belgeyi incele", "belgeyi oku", "pdf'i incele", "pdfi incele", "zip içeriği", "zip icerigi");
        boolean explicitOnlineResearch = containsAny(text, "internetten", "webde ara", "web'de ara",
                "web araştır", "web arastir", "internette ara", "kaynakları araştır", "kaynaklari arastir");
        if (fileOnlyRequest && !explicitOnlineResearch) return false;
        if (containsAny(text,
                "hatırla:", "hatirla:", "hafızada ara", "hafizada ara", "ne hatırlıyorsun", "ne hatirliyorsun",
                "arşivle:", "arsivle:", "arşivden çıkar:", "arsivden cikar:", "arşivdekileri göster", "arsivdekileri goster", "gereksizleri göster", "gereksizleri goster",
                "hafızadan sil:", "hafizadan sil:", "görevleri göster", "gorevleri goster", "görev duraklat:", "gorev duraklat:",
                "görev devam:", "gorev devam:", "öğrenme kuyruğu", "ogrenme kuyrugu", "öğren:", "ogren:",
                "saat kaç", "bugün tarih", "hesapla:", "kodu kontrol et", "öğret-intent:", "ogret-intent:")) return false;
        if (looksLikeMath(text)) return false;
        if (containsAny(text, "merhaba", "selam", "günaydın", "nasılsın", "naber")) return false;
        return true;
    }

    private String describeIntelligence(LocalIntelligenceEngine.Analysis analysis) {
        StringBuilder report = new StringBuilder("Ja.i yerel zekâ durumu\n")
                .append("• İstek sınıflandırma: Naive Bayes + kural tabanlı Türkçe istek profili\n")
                .append("• Tanınan niyetler: ").append(String.join(", ", modelEngine.knownLabels())).append("\n")
                .append("• Hafıza: SQLite kayıt arama, alaka puanlama ve kelime kapsamı ölçümü\n")
                .append("• Planlama: görev türü, kavramlar, karmaşıklık, araç ve bilgi yeterliliği\n")
                .append("• Öğrenme: kullanıcı tarafından verilen etiketli örneklerle yerel sınıflandırıcıyı yeniden kurma\n")
                .append("• Üretken sohbet modeli: ").append(hasConversationalModel() ? "Colab'da sıfırdan eğitilmiş ONNX modeli yüklü" : "henüz yüklenmedi; Colab eğitimi ve model içe aktarma gerekli").append("\n")
                .append("• Harici sohbet API'si: kullanılmıyor; model dosyası yalnızca kullanıcı tarafından eğitilip içe aktarılır.");
        if (analysis != null) report.append("\n\nBu istek için analiz: ").append(analysis.describe());
        report.append("\n\nSınır: Üretken model yüklenmemişse yanıtlar eski yerel eşleştirme motorundan gelir. Yüklenmiş modelin kalitesi Colab'da kullanılan eğitim verisine bağlıdır; model dosyası bulunması tek başına iyi sohbet kalitesini kanıtlamaz.");
        return report.toString();
    }

    public String getRegisteredToolSummary() {
        StringBuilder builder = new StringBuilder("Kayıtlı yerel araçlar:");
        for (Map.Entry<String, ToolRegistry.Tool> entry : tools.registeredTools().entrySet()) {
            builder.append("\n• ").append(entry.getKey());
        }
        return builder.toString();
    }


    private String setMemoryStateFromCommand(String text, boolean archived) {
        long id = parseTrailingId(text);
        if (id <= 0) return "Biçim: " + (archived ? "arşivle: 12" : "arşivden çıkar: 12") + " (hafıza kayıt numarası).";
        boolean changed = database.setMemoryArchived(id, archived);
        if (!changed) return "Bu numarayla hafıza kaydı bulunamadı: #" + id;
        return archived
                ? "#" + id + " numaralı kayıt Gereksizler arşivine taşındı. Arşiv kayıtları hafıza aramasında bulunmaya devam eder."
                : "#" + id + " numaralı kayıt arşivden çıkarıldı ve normal hafızaya döndü.";
    }

    private String deleteMemoryFromCommand(String text) {
        long id = parseTrailingId(text);
        if (id <= 0) return "Biçim: hafızadan sil: 12. Bu işlem kaydı kalıcı olarak siler.";
        return database.deleteMemory(id)
                ? "#" + id + " numaralı hafıza kaydı kalıcı olarak silindi."
                : "Bu numarayla hafıza kaydı bulunamadı: #" + id;
    }

    private String describeTasks() {
        List<TaskRecord> records = taskPersistence.recent(30);
        if (records.isEmpty()) return "Kalıcı görev kaydı yok. 'öğren: konu' ile öğrenme görevi veya Think modunda bir istekle Think görevi oluşturabilirsin.";
        StringBuilder result = new StringBuilder("Kalıcı yerel görev kayıtları (Think + öğrenme):\n");
        for (TaskRecord task : records) {
            result.append("\n#").append(task.id).append(" · ").append(task.title)
                    .append(" — ").append(task.status).append(" [").append(task.kind).append("]");
            if ("brain".equals(task.kind) && ("Hata · devam edebilir".equals(task.status)
                    || "Duraklatıldı".equals(task.status) || "Bekliyor".equals(task.status))) {
                result.append(" · 'görev devam: ").append(task.id).append("' ile sürdür");
            }
        }
        result.append("\n\nThink görevleri kontrol noktalarını yerel SQLite'a kaydeder; devam komutu aynı görev kimliğinden sürdürür. Öğrenme/web görevleri Ara açık olduğunda WorkManager kuyruğunda çalışabilir. Android arka plan çalışma politikaları görev başlangıcını geciktirebilir.");
        return result.toString();
    }

    private String updateTaskFromCommand(String text, boolean pause) {
        long id = parseTrailingId(text);
        if (id <= 0) return "Görev numarası gerekli. Örnek: görev devam: 3";
        boolean changed = pause ? learningEngine.pauseTask(id) : learningEngine.requeueTask(id);
        if (!changed) return "Görev bulunamadı: #" + id;
        return pause
                ? "#" + id + " görevi duraklatıldı."
                : "#" + id + " görevi yeniden bekleme kuyruğuna alındı. Ara açıksa uygulama kalıcı görev kuyruğuna yeniden ekler.";
    }

    private long parseTrailingId(String text) {
        if (text == null) return -1;
        java.util.regex.Matcher matcher = Pattern.compile("(\\d+)\\s*$").matcher(text.trim());
        if (!matcher.find()) return -1;
        try { return Long.parseLong(matcher.group(1)); }
        catch (NumberFormatException ignored) { return -1; }
    }

    private String extractMemorySearchQuery(String text) {
        String query = text == null ? "" : text.trim();
        String lower = query.toLowerCase(Locale.forLanguageTag("tr-TR"));
        String[] prefixes = {"hafızada ara", "hafizada ara"};
        for (String prefix : prefixes) {
            if (lower.startsWith(prefix)) {
                return query.substring(prefix.length()).trim();
            }
        }
        if (containsAny(lower, "ne hatırlıyorsun", "ne hatirliyorsun", "yerel hafıza", "yerel hafiza", "kayıtlı hafıza", "kayitli hafiza")) {
            return "";
        }
        return query;
    }

    private String extractAttachedCode(String text) {
        int marker = text.indexOf("[Metin eki:");
        if (marker < 0) return "";
        int firstLine = text.indexOf('\n', marker);
        if (firstLine < 0 || firstLine + 1 >= text.length()) return "";
        return text.substring(firstLine + 1).trim();
    }

    private String extractFencedCode(String text) {
        int opening = text.indexOf("```");
        if (opening < 0) return "";
        int contentStart = text.indexOf('\n', opening);
        int closing = text.indexOf("```", contentStart < 0 ? opening + 3 : contentStart + 1);
        if (contentStart < 0 || closing < 0 || closing <= contentStart) return "";
        return text.substring(contentStart + 1, closing).trim();
    }

    private String detectGeneratedLanguage(String response, String prompt) {
        if (response != null) {
            int opening = response.indexOf("```");
            if (opening >= 0) {
                int lineEnd = response.indexOf('\n', opening + 3);
                if (lineEnd > opening) {
                    String language = response.substring(opening + 3, lineEnd).trim();
                    if (!language.isEmpty()) return language;
                }
            }
        }
        return detectLanguage(prompt);
    }

    private String detectLanguage(String text) {
        String lower = text.toLowerCase(Locale.forLanguageTag("tr-TR"));
        // Check JavaScript before Java so the shared "java" prefix cannot misclassify it.
        if (lower.contains("javascript") || lower.contains("```js") || lower.contains(".js")) return "JavaScript";
        if (lower.contains("```java") || lower.contains(".java") || lower.contains("java kod")) return "Java";
        if (lower.contains("```python") || lower.contains(".py") || lower.contains("python")) return "Python";
        if (lower.contains("```xml") || lower.contains(".xml")) return "XML";
        if (lower.contains("```html") || lower.contains(".html")) return "HTML";
        if (lower.contains(".css") || lower.contains("```css")) return "CSS";
        return "kaynak kod";
    }

    /** Büyük ek gövdesini sınıflandırma ve cümle eşleştirme sorgusundan ayırır. */
    private String userRequestBeforeAttachment(String prompt) {
        if (prompt == null) return "";
        int marker = prompt.indexOf("[Metin eki:");
        return (marker >= 0 ? prompt.substring(0, marker) : prompt).trim();
    }

    private String joinContext(String first, String second) {
        String a = first == null ? "" : first.trim();
        String b = second == null ? "" : second.trim();
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        return a + "\n\n" + b;
    }

    private String toolsExecute(String tool, String input) {
        try {
            return tools.execute(tool, input);
        } catch (Exception exception) {
            return "Yerel araç çalıştırılamadı: " + exception.getMessage();
        }
    }

    private String toolsExecute(ToolRegistry.Selection selection) {
        try {
            return tools.execute(selection);
        } catch (Exception exception) {
            return "Seçilen yerel araç çalıştırılamadı (" + selection.name + "): " + safeMessage(exception);
        }
    }


    /** İstekten tek dosyalı kaynak veya dışa aktarılabilir çok dosyalı proje üretir. */
    private String generateCodeAnswer(String prompt, String researchContext) {
        CodeGenerator.GeneratedCode generated = codeGenerator.generate(prompt, researchContext);
        if (!generated.supported) return generated.explanation;
        if (generated.hasArtifact()) {
            return generated.title + "\n" + generated.explanation
                    + "\n\nBu çıktı ikili dosyadır; sohbet mesajı içine kaynak metni gibi yazılmaz. Dosyayı almak için Kod Laboratuvarı'nı aç, aynı isteği Üret ile çalıştır ve 'Üretilen dosyayı kaydet' düğmesine bas."
                    + " Çıktı: " + generated.artifactFileName + ".";
        }
        if (generated.project) {
            StringBuilder out = new StringBuilder("Yerel çok dosyalı proje üretildi: ")
                    .append(generated.title).append("\n")
                    .append(generated.explanation).append("\n\n")
                    .append("Dosyalar: ").append(String.join(", ", generated.projectFiles.keySet()))
                    .append("\n\n");
            for (Map.Entry<String, String> file : generated.projectFiles.entrySet()) {
                out.append("### ").append(file.getKey()).append("\n\n```")
                        .append(codeFenceLanguage(file.getKey())).append("\n")
                        .append(file.getValue()).append("\n```\n\n");
            }
            out.append("Proje ZIP dışa aktarımı için Kod Laboratuvarı'nı açıp aynı isteği Üret düğmesiyle çalıştır ve 'Çok dosyalı projeyi ZIP olarak kaydet' düğmesini kullan. Bu proje web projesidir; Android APK değildir.");
            return out.toString();
        }
        String generationLabel = "structured-js-compiler".equals(generated.templateId)
                ? "Yerel kaynak sentezi" : "Yerel kod üretimi";
        String answer = generationLabel + ": " + generated.title + " (" + generated.templateId + ")\n"
                + generated.explanation + "\n\n```" + generated.language.toLowerCase(Locale.ROOT) + "\n"
                + generated.source + "\n```";
        if (generated.runnableInLab) {
            answer += "\n\nÇalıştırma: JavaScript kodunu Kod Laboratuvarı'nda sınırlı yerel sandbox içinde deneyebilirsin.";
        } else {
            answer += "\n\nKaynak kod üretildi ancak uygulama içinde derlenmedi veya çalıştırılmadı.";
        }
        return answer;
    }

    private String codeFenceLanguage(String fileName) {
        String lower = fileName == null ? "" : fileName.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".html")) return "html";
        if (lower.endsWith(".css")) return "css";
        if (lower.endsWith(".js")) return "javascript";
        if (lower.endsWith(".md")) return "markdown";
        return "text";
    }

    private boolean wantsCodeGeneration(String lower) {
        return containsAny(lower,
                "kod yaz", "kod üret", "kod uret", "program yaz", "program yap", "program oluştur", "program olustur",
                "uygulama yap", "uygulama oluştur", "uygulama olustur", "oyun yap", "oyun oluştur", "oyun olustur",
                "site yap", "web sitesi oluştur", "web sitesi olustur", "web sayfası yap", "web sayfasi yap",
                "web projesi üret", "web projesi uret", "proje üret", "proje uret", "çok dosyalı proje", "cok dosyali proje",
                "hafıza oyunu yap", "hafiza oyunu yap", "hafıza kartı yap", "hafiza karti yap",
                "hafıza kartı eşleştirme", "hafiza karti eslestirme", "eşleştirme oyunu yap", "eslestirme oyunu yap",
                "refleks testi yap", "tıklama oyunu yap", "tiklama oyunu yap", "x-o oyunu yap", "x o oyunu yap",
                "bilgi yarışması yap", "bilgi yarismasi yap", "portfolyo sitesi yap", "tanıtım sitesi yap", "tanitim sitesi yap",
                "hesap makinesi yap", "kronometre yap",
                "not defteri yap", "görev listesi yap", "sayacı yap", "sayaci yap",
                "fonksiyon yaz", "sınıf yaz", "sinif yaz", "script yaz", "otomasyon yaz", "kodla",
                "minecraft", "mcpack", "mcaddon", "davranış paketi", "davranis paketi", "kaynak paketi", "resource pack",
                "görsel oluştur", "gorsel olustur", "resim çiz", "resim ciz", "png üret", "png uret", "karakter çiz", "karakter ciz");
    }

    private boolean looksLikeMath(String text) {
        String expression = extractExpression(text);
        return expression.matches("[0-9\\s.,+*/()\\-]+") && Pattern.compile("[+*/\\-]").matcher(expression).find() && Pattern.compile("\\d").matcher(expression).find();
    }

    private String extractExpression(String text) {
        String candidate = text.trim();
        candidate = candidate.replaceAll("(?i)^(hesapla|sonuç|sonuc)\\s*[:：]?\\s*", "");
        candidate = candidate.replaceAll("(?i)\\s*(kaç eder|kac eder|kaçtır|kactir)\\??\\s*$", "");
        candidate = candidate.replaceAll("=\\s*$", "").replace("?", "").trim();
        return candidate;
    }

    private boolean startsWithCommand(String lower, String... prefixes) {
        for (String prefix : prefixes) if (lower.startsWith(prefix)) return true;
        return false;
    }

    private int firstSpace(String value) {
        int index = value.indexOf(' ');
        return index < 0 ? value.length() : index;
    }

    private boolean containsAny(String text, String... fragments) {
        for (String fragment : fragments) if (text.contains(fragment)) return true;
        return false;
    }

    private String formatNumber(double value) {
        if (Math.abs(value - Math.rint(value)) < 1e-10 && Math.abs(value) < 9e15) return String.format(Locale.ROOT, "%.0f", value);
        return String.format(Locale.ROOT, "%.8f", value).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private void persistCheckpoint(long taskId, String status, String serializedState) throws Exception {
        if (!taskPersistence.checkpoint(taskId, status, serializedState)) {
            throw new IllegalStateException("Think görevinin kontrol noktası SQLite'a kaydedilemedi.");
        }
    }

    private String safeMessage(Exception exception) {
        if (exception == null) return "Bilinmeyen hata";
        String message = exception.getMessage();
        return message == null || message.trim().isEmpty()
                ? exception.getClass().getSimpleName() : message.trim();
    }
}
