package com.jai.assistant.messaging;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Ja.i'nin kendi HTTPS mesaj backend'i için REST istemcisi. */
public final class MessagingClient {
    public JSONObject register(String baseUrl, String username, String password) throws Exception {
        JSONObject body = new JSONObject().put("username", username).put("password", password);
        return request(baseUrl, "/v1/register", "POST", null, body);
    }

    public JSONObject login(String baseUrl, String username, String password) throws Exception {
        JSONObject body = new JSONObject().put("username", username).put("password", password);
        return request(baseUrl, "/v1/login", "POST", null, body);
    }

    public JSONObject send(String baseUrl, String token, String recipient, String text) throws Exception {
        JSONObject body = new JSONObject().put("recipient", recipient).put("text", text);
        return request(baseUrl, "/v1/messages", "POST", token, body);
    }

    public JSONArray inbox(String baseUrl, String token, long afterId) throws Exception {
        JSONObject response = request(baseUrl, "/v1/messages?after_id=" + Math.max(0, afterId), "GET", token, null);
        return response.optJSONArray("messages") == null ? new JSONArray() : response.getJSONArray("messages");
    }

    public JSONObject status(String baseUrl, String token, long messageId) throws Exception {
        return request(baseUrl, "/v1/messages/" + messageId + "/status", "GET", token, null);
    }

    public JSONObject markRead(String baseUrl, String token, long messageId) throws Exception {
        return request(baseUrl, "/v1/messages/" + messageId + "/read", "POST", token, new JSONObject());
    }

    private JSONObject request(String baseUrl, String path, String method, String token, JSONObject payload) throws Exception {
        if (baseUrl == null || !baseUrl.startsWith("https://")) {
            throw new IllegalArgumentException("Mesajlaşma sunucusu HTTPS adresi olmalı. Önce Sunucu bölümüne adresi kaydet.");
        }
        URI base = URI.create(baseUrl);
        if (base.getHost() == null || base.getUserInfo() != null) throw new IllegalArgumentException("Sunucu adresi geçersiz.");
        String root = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        HttpURLConnection connection = null;
        try {
            URL url = URI.create(root + path).toURL();
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(method);
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(15000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "JaI-Android-Messaging/0.6");
            if (token != null && !token.trim().isEmpty()) connection.setRequestProperty("Authorization", "Bearer " + token);
            if (payload != null) {
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream output = connection.getOutputStream()) { output.write(bytes); }
            }
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
            StringBuilder text = new StringBuilder();
            if (stream != null) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    char[] buffer = new char[4096];
                    int count;
                    while ((count = reader.read(buffer)) != -1) {
                        if (text.length() + count > 1_000_000) throw new IllegalStateException("Sunucu yanıtı 1 MB sınırını aşıyor.");
                        text.append(buffer, 0, count);
                    }
                }
            }
            JSONObject json;
            try { json = text.length() == 0 ? new JSONObject() : new JSONObject(text.toString()); }
            catch (Exception ex) { throw new IllegalStateException("Sunucu JSON yerine geçersiz yanıt döndürdü (HTTP " + status + ")."); }
            if (status < 200 || status >= 300) {
                throw new IllegalStateException("Sunucu HTTP " + status + ": " + json.optString("detail", json.optString("error", "İstek reddedildi.")));
            }
            return json;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
