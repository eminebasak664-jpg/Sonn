package com.jai.assistant.messaging;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Oturum belirtecini Android Keystore AES-GCM ile yerelde saklar. Parola saklanmaz. */
public final class MessagingSessionStore {
    private static final String PREFS = "jai_messaging_session";
    private static final String KEY_ALIAS = "jai_messaging_token_key_v1";
    private final SharedPreferences prefs;

    public MessagingSessionStore(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized void save(String username, String token) throws Exception {
        byte[][] encrypted = encrypt(token);
        boolean ok = prefs.edit().putString("username", username)
                .putString("token", Base64.encodeToString(encrypted[0], Base64.NO_WRAP))
                .putString("iv", Base64.encodeToString(encrypted[1], Base64.NO_WRAP)).commit();
        if (!ok) throw new IllegalStateException("Mesajlaşma oturumu kaydedilemedi.");
    }

    public synchronized String getUsername() { return prefs.getString("username", ""); }

    public synchronized String getToken() throws Exception {
        String cipherText = prefs.getString("token", null);
        String iv = prefs.getString("iv", null);
        if (cipherText == null || iv == null) return "";
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
        return new String(cipher.doFinal(Base64.decode(cipherText, Base64.NO_WRAP)), "UTF-8");
    }

    public synchronized long getLastMessageId() { return prefs.getLong("last_message_id", 0L); }
    public synchronized void setLastMessageId(long id) { prefs.edit().putLong("last_message_id", Math.max(0L, id)).apply(); }
    public synchronized long getLastSentId() { return prefs.getLong("last_sent_id", 0L); }
    public synchronized void setLastSentId(long id) { prefs.edit().putLong("last_sent_id", Math.max(0L, id)).apply(); }
    public synchronized void clear() { prefs.edit().clear().commit(); }

    private byte[][] encrypt(String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        return new byte[][]{cipher.doFinal(value.getBytes("UTF-8")), cipher.getIV()};
    }

    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        java.security.Key existing = store.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build());
        return generator.generateKey();
    }
}
