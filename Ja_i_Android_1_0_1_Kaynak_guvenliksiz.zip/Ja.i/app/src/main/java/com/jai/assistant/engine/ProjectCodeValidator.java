package com.jai.assistant.engine;

import java.util.Map;

/** Üretilen çok dosyalı web projesinde dosya bağlantılarını ve kaynak ayraçlarını denetler. */
public final class ProjectCodeValidator {
    public static final class Result {
        public final boolean valid;
        public final String report;
        private Result(boolean valid, String report) { this.valid = valid; this.report = report; }
    }

    public Result validate(Map<String, String> files) {
        if (files == null || files.isEmpty()) return new Result(false, "Proje dosyaları bulunamadı.");
        String html = files.get("index.html");
        String css = files.get("styles.css");
        String js = files.get("app.js");
        if (empty(html) || empty(css) || empty(js)) {
            return new Result(false, "index.html, styles.css ve app.js dosyalarının üçü de gerekli.");
        }
        if (!html.toLowerCase(java.util.Locale.ROOT).contains("<!doctype html>")) {
            return new Result(false, "index.html içinde HTML5 DOCTYPE bulunamadı.");
        }
        if (!html.contains("href=\"styles.css\"") || !html.contains("src=\"app.js\"")) {
            return new Result(false, "index.html, styles.css ve app.js dosyalarına doğru şekilde bağlanmıyor.");
        }
        if (!hasBalancedTagPair(html, "html") || !hasBalancedTagPair(html, "head")
                || !hasBalancedTagPair(html, "body") || !hasBalancedTagPair(html, "main")) {
            return new Result(false, "index.html temel belge etiketleri dengeli değil.");
        }

        CodeLabEngine checker = new CodeLabEngine();
        String cssReport = checker.analyze(css, "CSS");
        if (!cssReport.contains("ayraç kontrolü geçti")) return new Result(false, "CSS kontrolü: " + cssReport);
        String jsReport = checker.analyze(js, "JavaScript");
        if (!jsReport.contains("ayraç kontrolü geçti")) return new Result(false, "JavaScript kontrolü: " + jsReport);

        String readme = files.get("README.md");
        String report = "Proje yapısal kontrolü geçti: HTML temel etiketleri ve dosya bağlantıları mevcut; CSS ve JavaScript ayraç kontrolü geçti."
                + (empty(readme) ? " README.md bulunamadı (zorunlu değil)." : " README.md mevcut.")
                + " Bu kontrol tarayıcı çalıştırması, derleme veya görsel arayüz testi değildir.";
        return new Result(true, report);
    }

    private boolean empty(String value) { return value == null || value.trim().isEmpty(); }

    private boolean hasBalancedTagPair(String html, String tag) {
        java.util.regex.Pattern opening = java.util.regex.Pattern.compile("<" + tag + "(?:\\s|>)", java.util.regex.Pattern.CASE_INSENSITIVE);
        java.util.regex.Pattern closing = java.util.regex.Pattern.compile("</" + tag + "\\s*>", java.util.regex.Pattern.CASE_INSENSITIVE);
        return count(opening, html) == 1 && count(closing, html) == 1;
    }

    private int count(java.util.regex.Pattern pattern, String text) {
        int count = 0;
        java.util.regex.Matcher matcher = pattern.matcher(text);
        while (matcher.find()) count++;
        return count;
    }
}
