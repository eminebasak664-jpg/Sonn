package com.jai.assistant.tools;

import android.content.ContentResolver;
import android.media.MediaMetadataRetriever;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import com.jai.assistant.media.DocumentImageAnalyzer;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.zip.GZIPInputStream;

/** SAF dosyalarını uzantı ve içerik imzasına göre okur; arşivleri diske çıkarmadan işler. */
public final class FileManager {
    public String getDisplayName(Context context, Uri uri) {
        if (uri == null) return "ek_dosya";
        try (Cursor cursor = context.getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String name = cursor.getString(index);
                    if (name != null && !name.trim().isEmpty()) return name;
                }
            }
        } catch (Exception ignored) { }
        String segment = uri.getLastPathSegment();
        return segment == null ? "ek_dosya" : segment;
    }

    /** PDF/fotoğraf, arşiv, metin ve tanımlanabilir ikili dosyaları içeriklerine göre inceler. */
    public String readAttachment(Context context, Uri uri) throws IOException {
        if (uri == null) throw new IOException("Dosya seçilmedi.");
        String name = getDisplayName(context, uri);
        String lower = name.toLowerCase(Locale.ROOT);
        String mime = context.getContentResolver().getType(uri);
        if (lower.endsWith(".pdf") || "application/pdf".equalsIgnoreCase(mime)
                || (mime != null && mime.startsWith("image/"))
                || lower.matches(".*\\.(jpg|jpeg|png|webp|bmp|heic|heif)$")) {
            try { return new DocumentImageAnalyzer(context).analyze(context, uri, name); }
            catch (Exception exception) { throw new IOException("PDF/fotoğraf analizi başarısız: " + safeMessage(exception), exception); }
        }
        if ((mime != null && (mime.startsWith("audio/") || mime.startsWith("video/")))
                || lower.matches(".*\\.(mp3|m4a|aac|wav|ogg|flac|opus|mp4|m4v|mkv|webm|mov|avi)$")) {
            return readMediaMetadata(context, uri, name);
        }

        try (InputStream input = context.getContentResolver().openInputStream(uri)) {
            if (input == null) throw new IOException("Dosya açılamadı.");
            // ZIP/GZIP imzası ilk baytlarda, TAR ustar imzası 257. bayttadır.
            byte[] prefix = new byte[262];
            int prefixLength = 0;
            while (prefixLength < prefix.length) {
                int count = input.read(prefix, prefixLength, prefix.length - prefixLength);
                if (count < 0) break;
                prefixLength += count;
            }
            byte[] first = prefixLength <= 0 ? new byte[0] : java.util.Arrays.copyOf(prefix, prefixLength);
            java.io.SequenceInputStream combined = new java.io.SequenceInputStream(
                    new java.io.ByteArrayInputStream(first), input);
            if (isZip(first) || isZipExtension(lower)) return new ZipArchiveInspector().inspect(combined);
            if ((lower.endsWith(".tar.gz") || lower.endsWith(".tgz")) && isGzip(first)) {
                // TAR girdilerini GZIP katmanından akış olarak besle; tüm açılmış TAR'ı byte[] içine alma.
                try (GZIPInputStream gzip = new GZIPInputStream(combined)) {
                    return new TarArchiveInspector().inspect(gzip);
                }
            }
            if (isGzip(first)) {
                try (GZIPInputStream gzip = new GZIPInputStream(combined)) {
                    byte[] decompressed = readLimited(gzip, "GZIP dosyasının tekil içeriği telefonun o anki bellek tamponunu aşıyor.");
                    if (isTar(decompressed)) return new TarArchiveInspector().inspect(new java.io.ByteArrayInputStream(decompressed));
                    if (isZip(decompressed)) return new ZipArchiveInspector().inspect(new java.io.ByteArrayInputStream(decompressed));
                    return decodeOrDescribe(decompressed, name);
                }
            }
            if (lower.endsWith(".tar") || isTarPrefix(first)) {
                // TAR girdileri akıştan tek tek okunur; tüm arşiv belleğe alınmaz.
                return new TarArchiveInspector().inspect(combined);
            }
            byte[] data = readLimited(combined, "Dosya metni telefonun o anki bellek bütçesini aşıyor.");
            return decodeOrDescribe(data, name);
        }
    }

    /**
     * Seçilmiş dosyanın daha önce analiz edilip kullanıcı mesajına eklenmiş metnini araç bağlamına
     * taşır. Araç yalnızca kullanıcının açıkça seçtiği dosya metnini işler; keyfî URI açmaz.
     */
    public String inspectAttachmentContext(String request) throws IOException {
        String text = request == null ? "" : request;
        String marker = "[Metin eki:";
        int start = text.indexOf(marker);
        if (start < 0) throw new IOException("Bu istekte seçilmiş dosya eki bulunamadı.");
        int headerEnd = text.indexOf("]", start + marker.length());
        if (headerEnd < 0) throw new IOException("Dosya eki başlığı eksik.");
        String content = text.substring(headerEnd + 1).trim();
        if (content.isEmpty()) throw new IOException("Seçilen dosyanın okunabilir içeriği boş.");
        return content;
    }

    /** Uzantısı tanınmasa da geçerli metin içeriğini UTF-8/UTF-16 olarak algılamayı dener. */
    public String readText(Context context, Uri uri) throws IOException {
        if (uri == null) throw new IOException("Dosya seçilmedi.");
        try (InputStream input = context.getContentResolver().openInputStream(uri)) {
            if (input == null) throw new IOException("Dosya açılamadı.");
            byte[] data = readLimited(input, "Metin dosyası telefonun o anki bellek bütçesini aşıyor.");
            String decoded = decodeText(data);
            if (decoded == null) throw new IOException("Dosya metin kodlamasıyla okunamıyor. Dosya ikili biçimde olabilir; genel ek analizini kullan.");
            return decoded;
        }
    }

    public void writeText(ContentResolver resolver, Uri destination, String contents) throws IOException {
        if (destination == null) throw new IOException("Kayıt konumu seçilmedi.");
        try (OutputStream output = resolver.openOutputStream(destination, "wt")) {
            if (output == null) throw new IOException("Seçilen dosya konumu açılamadı.");
            output.write((contents == null ? "" : contents).getBytes(StandardCharsets.UTF_8));
            output.flush();
        }
    }

    /** Üretilen ZIP/proje gibi ikili çıktıları Storage Access Framework konumuna yazar. */
    public void writeBytes(ContentResolver resolver, Uri destination, byte[] contents) throws IOException {
        if (destination == null) throw new IOException("Kayıt konumu seçilmedi.");
        if (contents == null) throw new IOException("Kaydedilecek içerik boş.");
        try (OutputStream output = resolver.openOutputStream(destination, "wt")) {
            if (output == null) throw new IOException("Seçilen dosya konumu açılamadı.");
            output.write(contents);
            output.flush();
        }
    }

    /** Büyük MP4 gibi çıktıları tüm dosyayı RAM'e almadan akış halinde dışa aktarır. */
    public void writeFile(ContentResolver resolver, Uri destination, File source) throws IOException {
        if (destination == null) throw new IOException("Kayıt konumu seçilmedi.");
        if (source == null || !source.isFile() || source.length() <= 0L) {
            throw new IOException("Kaydedilecek geçici çıktı dosyası bulunamadı veya boş.");
        }
        try (InputStream input = new FileInputStream(source);
             OutputStream output = resolver.openOutputStream(destination, "wt")) {
            if (output == null) throw new IOException("Seçilen dosya konumu açılamadı.");
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            output.flush();
        }
    }

    private String readMediaMetadata(Context context, Uri uri, String name) throws IOException {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context, uri);
            StringBuilder out = new StringBuilder("Medya dosyası: ").append(name).append("\n");
            appendMetadata(out, "Başlık", retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE));
            appendMetadata(out, "Sanatçı", retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST));
            appendMetadata(out, "Albüm", retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM));
            appendMetadata(out, "Süre (ms)", retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            appendMetadata(out, "MIME", retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE));
            out.append("\nNot: Bu sürüm medya meta verilerini okur; ses/video içeriğini yazıya dökme (transkripsiyon) yapmaz.");
            return out.toString();
        } catch (RuntimeException exception) {
            throw new IOException("Medya meta verisi okunamadı: " + safeMessage(exception), exception);
        } finally {
            try { retriever.release(); } catch (RuntimeException ignored) { }
        }
    }

    private void appendMetadata(StringBuilder out, String label, String value) {
        if (value != null && !value.trim().isEmpty()) out.append(label).append(": ").append(value.trim()).append("\n");
    }

    private String decodeOrDescribe(byte[] data, String name) {
        String decoded = decodeText(data);
        if (decoded != null) return decoded;
        String strings = extractReadableStrings(data, 160);
        String lower = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String formatNote = (lower.endsWith(".rar") || lower.endsWith(".7z"))
                ? "Bu RAR/7z arşiv biçimi için açma kütüphanesi eklenmedi; arşivin tüm dosyaları çıkarılmadı. "
                : "Bu biçim için özel ayrıştırıcı bulunmadığından yalnızca okunabilir dizeler çıkarıldı. ";
        return "Dosya: " + name + "\nBoyut: " + data.length + " bayt\nİçerik: ikili veri\n"
                + "Dosya uzantısı tek başına içeriği çözmeye yetmez. " + formatNote + "\n\n"
                + (strings.isEmpty() ? "Okunabilir metin dizisi bulunamadı." : strings);
    }

    /**
     * Metin/akış tamponu artık 8 MiB veya 128 MiB sabit kotasına bağlı değildir.
     * Android uygulama heap'inin o anki boş alanına göre dinamik bütçe uygulanır.
     */
    private byte[] readLimited(InputStream input, String error) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count;
        long total = 0;
        long maxArrayBytes = ResourceAwareBudget.currentSafeArrayBytes();
        while ((count = input.read(buffer)) != -1) {
            total += count;
            if (total > maxArrayBytes) {
                throw new IOException(error + " Sabit dosya boyutu sınırı yok; daha fazla boş RAM ile tekrar deneyebilirsin.");
            }
            output.write(buffer, 0, count);
        }
        return output.toByteArray();
    }

    private String decodeText(byte[] bytes) {
        if (bytes == null || bytes.length == 0) return "";
        Charset charset = StandardCharsets.UTF_8;
        int offset = 0;
        if (bytes.length >= 3 && (bytes[0] & 0xff) == 0xef && (bytes[1] & 0xff) == 0xbb && (bytes[2] & 0xff) == 0xbf) offset = 3;
        else if (bytes.length >= 2 && (bytes[0] & 0xff) == 0xff && (bytes[1] & 0xff) == 0xfe) { charset = StandardCharsets.UTF_16LE; offset = 2; }
        else if (bytes.length >= 2 && (bytes[0] & 0xff) == 0xfe && (bytes[1] & 0xff) == 0xff) { charset = StandardCharsets.UTF_16BE; offset = 2; }
        int controls = 0;
        for (int i = offset; i < Math.min(bytes.length, 4096); i++) {
            int b = bytes[i] & 0xff;
            if (b == 0) return null;
            if (b < 0x20 && b != 9 && b != 10 && b != 13 && b != 12) controls++;
        }
        if (controls > Math.max(2, Math.min(bytes.length, 4096) / 100)) return null;
        try {
            return charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes, offset, bytes.length - offset)).toString();
        } catch (CharacterCodingException exception) { return null; }
    }

    private String extractReadableStrings(byte[] bytes, int maxStrings) {
        StringBuilder out = new StringBuilder();
        int start = -1;
        int found = 0;
        for (int i = 0; i <= bytes.length && found < maxStrings; i++) {
            boolean printable = i < bytes.length && (bytes[i] & 0xff) >= 32 && (bytes[i] & 0xff) <= 126;
            if (printable && start < 0) start = i;
            if (!printable && start >= 0) {
                if (i - start >= 4) { out.append(new String(bytes, start, i - start, StandardCharsets.US_ASCII)).append('\n'); found++; }
                start = -1;
            }
        }
        return out.toString();
    }

    private boolean isZipExtension(String name) {
        return name.endsWith(".zip") || name.endsWith(".jar") || name.endsWith(".apk") || name.endsWith(".aab")
                || name.endsWith(".mcpack") || name.endsWith(".mcaddon") || name.endsWith(".mcworld")
                || name.endsWith(".mctemplate") || name.endsWith(".docx") || name.endsWith(".xlsx")
                || name.endsWith(".pptx") || name.endsWith(".odt") || name.endsWith(".ods")
                || name.endsWith(".odp") || name.endsWith(".epub") || name.endsWith(".cbz");
    }

    private boolean isZip(byte[] bytes) {
        return bytes != null && bytes.length >= 4 && bytes[0] == 'P' && bytes[1] == 'K'
                && ((bytes[2] == 3 && bytes[3] == 4) || (bytes[2] == 5 && bytes[3] == 6) || (bytes[2] == 7 && bytes[3] == 8));
    }
    private boolean isGzip(byte[] bytes) { return bytes.length >= 2 && (bytes[0] & 0xff) == 0x1f && (bytes[1] & 0xff) == 0x8b; }
    private boolean isTarPrefix(byte[] bytes) { return bytes.length >= 262 && bytes[257] == 'u' && bytes[258] == 's' && bytes[259] == 't' && bytes[260] == 'a' && bytes[261] == 'r'; }
    private boolean isTar(byte[] bytes) { return isTarPrefix(bytes); }
    private String safeMessage(Exception exception) { return exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage(); }
}
