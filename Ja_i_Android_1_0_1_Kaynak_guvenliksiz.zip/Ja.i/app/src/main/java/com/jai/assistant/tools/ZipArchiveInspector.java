package com.jai.assistant.tools;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** ZIP tabanlı paketleri (ZIP/JAR/APK/MCPACK/Office/EPUB vb.) diske çıkarmadan okur. */
public final class ZipArchiveInspector {
    private static final int MAX_ENTRIES = 10_000;
    private static final int MAX_STRINGS_PER_BINARY = 80;

    private static final class State {
        long expandedBytes;
        long nestedBytesInMemory;
        int entries;
        boolean reportTruncated;
        final int maxReportChars = ResourceAwareBudget.currentSafeTextCharacters();
    }

    private static final class Frame {
        final ZipInputStream zip;
        final String prefix;
        final long retainedBytes;
        Frame(InputStream source, String prefix, long retainedBytes) {
            this.zip = new ZipInputStream(source, StandardCharsets.UTF_8);
            this.prefix = prefix;
            this.retainedBytes = retainedBytes;
        }
    }

    public String inspect(InputStream source) throws IOException {
        if (source == null) throw new IOException("Arşiv akışı açılamadı.");
        StringBuilder report = new StringBuilder("Arşiv içeriği (dosyalar diske çıkarılmadan okundu)\n");
        State state = new State();
        inspectZip(source, report, state);
        if (state.reportTruncated) report.append("\n[Gösterim, telefonun o anki kullanılabilir uygulama belleğine göre kısaltıldı.]\n");
        report.append("\n\nToplam arşiv girdisi: ").append(state.entries)
                .append(" · Okunan açılmış veri toplamı: ").append(state.expandedBytes).append(" bayt")
                .append("\nGüvenlik: arşiv diske çıkarılmadı; mutlak yollar ve '..' yol geçişleri reddedildi.")
                .append(" İç içe arşivlerde sabit derinlik veya toplam açılmış veri kotası yoktur; yalnızca aynı anda bellekte tutulan iç içe ZIP katmanları cihazın RAM bütçesine tabidir.");
        return report.toString();
    }

    /** Açık ZipInputStream yığınını kullanır; böylece iç içe arşivlerde Java çağrı yığını büyümez. */
    private void inspectZip(InputStream source, StringBuilder report, State state) throws IOException {
        Deque<Frame> stack = new ArrayDeque<>();
        stack.push(new Frame(source, "", 0L));
        try {
        while (!stack.isEmpty()) {
            Frame frame = stack.peek();
            ZipEntry entry = frame.zip.getNextEntry();
            if (entry == null) {
                frame.zip.close();
                stack.pop();
                state.nestedBytesInMemory = Math.max(0L, state.nestedBytesInMemory - frame.retainedBytes);
                continue;
            }

            state.entries++;
            if (state.entries > MAX_ENTRIES) {
                throw new IOException("Arşivde 10.000'den fazla girdi var; işlemci yükünü ve bellek kullanımını sınırlamak için inceleme durduruldu.");
            }
            String name = entry.getName() == null ? "" : entry.getName();
            validateEntryName(name);
            String fullName = frame.prefix + name;
            if (entry.isDirectory()) {
                append(report, state, "\n[Klasör] " + fullName + "\n");
                frame.zip.closeEntry();
                continue;
            }

            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int read;
            long entryBytes = 0;
            long maxEntryBuffer = ResourceAwareBudget.currentSafeArrayBytes();
            while ((read = frame.zip.read(buffer)) != -1) {
                entryBytes += read;
                state.expandedBytes += read;
                if (entryBytes > maxEntryBuffer) {
                    throw new IOException("Bu arşiv girdisi telefonun o anki tekil bellek tamponu bütçesini aşıyor. Sabit 16 MiB kotası yok; daha fazla boş RAM ile yeniden deneyebilirsin: " + fullName);
                }
                bytes.write(buffer, 0, read);
            }
            frame.zip.closeEntry();
            byte[] content = bytes.toByteArray();
            // İç tamponun bir kopyasını bırakma; özellikle iç içe ZIP'te aynı baytları iki kez tutma.
            bytes = null;
            append(report, state, "\n\n========== " + fullName + " (" + entryBytes + " bayt) ==========\n");

            if (isZip(content)) {
                append(report, state, "[İç içe arşiv: " + extensionOf(name) + "]\n");
                // Derinlik sabiti yok; açık arşivler yığınında tutulur. Yalnızca bellekte tutulan
                // iç içe arşiv baytları dinamik bütçeye tabidir; tüm ZIP'in toplam açılımı sınırlanmaz.
                long nestedAfterPush = state.nestedBytesInMemory + content.length;
                if (nestedAfterPush > ResourceAwareBudget.currentSafeExpansionBytes()) {
                    throw new IOException("İç içe ZIP katmanlarını aynı anda bellekte tutmak için telefonun boş uygulama belleği yetersiz: " + fullName);
                }
                state.nestedBytesInMemory = nestedAfterPush;
                stack.push(new Frame(new ByteArrayInputStream(content), fullName + "!", content.length));
            } else if (extensionOf(name).equals("nbt") || extensionOf(name).equals("mcstructure")) {
                try {
                    append(report, state, new NbtInspector().inspect(content, extensionOf(name).equals("mcstructure")));
                } catch (IOException nbtError) {
                    append(report, state, "[NBT olarak tanındı ancak ayrıştırılamadı: " + nbtError.getMessage() + "]\n");
                    append(report, state, extractReadableStrings(content));
                }
            } else {
                String text = decodeText(content);
                if (text != null) append(report, state, normalizeStructuredText(name, text));
                else {
                    String strings = extractReadableStrings(content);
                    if (!strings.isEmpty()) append(report, state, "[İkili dosya; bulunan okunabilir dizeler]\n" + strings);
                    else append(report, state, "[İkili dosya; metin olarak çözümlenemedi. Tür: " + extensionOf(name) + "]\n");
                }
            }
            if (state.reportTruncated) return;
        }
        } finally {
            while (!stack.isEmpty()) {
                try { stack.pop().zip.close(); } catch (IOException ignored) { }
            }
        }
    }

    private String normalizeStructuredText(String name, String text) {
        String extension = extensionOf(name);
        if ("xml".equals(extension) || "xhtml".equals(extension) || "html".equals(extension)
                || "htm".equals(extension) || "svg".equals(extension)) return text.replaceAll(">\\s*<", ">\n<").trim();
        return text.trim();
    }

    private boolean isZip(byte[] bytes) {
        return bytes != null && bytes.length >= 4 && bytes[0] == 'P' && bytes[1] == 'K'
                && ((bytes[2] == 3 && bytes[3] == 4) || (bytes[2] == 5 && bytes[3] == 6)
                || (bytes[2] == 7 && bytes[3] == 8));
    }

    private String decodeText(byte[] bytes) {
        if (bytes == null || bytes.length == 0) return "";
        Charset charset = StandardCharsets.UTF_8;
        int offset = 0;
        if (bytes.length >= 3 && (bytes[0] & 0xff) == 0xef && (bytes[1] & 0xff) == 0xbb && (bytes[2] & 0xff) == 0xbf) offset = 3;
        else if (bytes.length >= 2 && (bytes[0] & 0xff) == 0xff && (bytes[1] & 0xff) == 0xfe) { charset = StandardCharsets.UTF_16LE; offset = 2; }
        else if (bytes.length >= 2 && (bytes[0] & 0xff) == 0xfe && (bytes[1] & 0xff) == 0xff) { charset = StandardCharsets.UTF_16BE; offset = 2; }
        int controls = 0;
        int sample = Math.min(bytes.length, 4096);
        for (int i = offset; i < sample; i++) {
            int value = bytes[i] & 0xff;
            if (value == 0) return null;
            if (value < 0x20 && value != '\n' && value != '\r' && value != '\t' && value != '\f') controls++;
        }
        if (controls > Math.max(2, sample / 100)) return null;
        try {
            return charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes, offset, bytes.length - offset)).toString();
        } catch (CharacterCodingException exception) { return null; }
    }

    private String extractReadableStrings(byte[] bytes) {
        StringBuilder out = new StringBuilder();
        int start = -1;
        int found = 0;
        for (int i = 0; i <= bytes.length && found < MAX_STRINGS_PER_BINARY; i++) {
            boolean printable = i < bytes.length && ((bytes[i] & 0xff) >= 32 && (bytes[i] & 0xff) <= 126);
            if (printable && start < 0) start = i;
            if (!printable && start >= 0) {
                if (i - start >= 4) { out.append(new String(bytes, start, i - start, StandardCharsets.US_ASCII)).append('\n'); found++; }
                start = -1;
            }
        }
        return out.toString();
    }

    private String extensionOf(String name) {
        int dot = name == null ? -1 : name.lastIndexOf('.');
        return dot < 0 ? "bilinmiyor" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    private void append(StringBuilder out, State state, String value) {
        if (state.reportTruncated || value == null || value.isEmpty()) return;
        int remaining = state.maxReportChars - out.length();
        if (remaining <= 0) { state.reportTruncated = true; return; }
        if (value.length() <= remaining) out.append(value);
        else { out.append(value, 0, remaining); state.reportTruncated = true; }
    }

    private void validateEntryName(String name) throws IOException {
        String normal = name.replace('\\', '/');
        if (normal.isEmpty() || normal.startsWith("/") || normal.matches("^[A-Za-z]:.*")) throw new IOException("Arşiv içinde mutlak veya boş bir dosya yolu bulundu.");
        for (String part : normal.split("/")) if ("..".equals(part)) throw new IOException("Arşiv içinde güvenli olmayan '..' yol geçişi bulundu.");
    }
}
