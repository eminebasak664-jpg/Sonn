package com.jai.assistant.engine;

import com.jai.assistant.data.MemoryDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Çok küçük bir kelime-temelli Naive Bayes amaç sınıflandırıcısıdır.
 * Genel amaçlı dil modeli değildir. Yerleşik etiketli örneklerle başlar ve
 * açıkça verilen yeni örnekleri yerel veritabanına kaydedip yeniden eğitilebilir.
 */
public final class ModelEngine {
    private static final String[] LABELS = {
            "selam", "matematik", "hafiza", "kod", "ogrenme", "zaman",
            "arastirma", "dosya", "ozet", "karsilastirma", "genel"
    };
    private final MemoryDatabase database;
    private final Map<String, Map<String, Integer>> wordsByLabel = new HashMap<>();
    private final Map<String, Integer> wordTotals = new HashMap<>();
    private final Map<String, Integer> documentTotals = new HashMap<>();
    private final Set<String> vocabulary = new HashSet<>();
    private int totalDocuments;

    public ModelEngine(MemoryDatabase database) {
        this.database = database;
        rebuild();
    }

    public static final class Classification {
        public final String label;
        public final double confidence;
        public final double margin;
        public final Map<String, Double> probabilities;
        /** Sorguda eğitim sözlüğüyle eşleşen benzersiz kelime sayısı. */
        public final int knownTokenCount;
        /** Sorgudaki benzersiz kelime sayısı. */
        public final int tokenCount;
        /** 0..1 arası sözlük kapsaması; posterior güveniyle karıştırılmamalıdır. */
        public final double knownTokenRatio;
        /** Sınıflandırmanın gerçekten eğitim verisine dayanma gücü (0..1). */
        public final double evidenceStrength;

        private Classification(String label, double confidence, double margin, Map<String, Double> probabilities,
                               int knownTokenCount, int tokenCount) {
            this.label = label;
            this.confidence = confidence;
            this.margin = margin;
            this.probabilities = java.util.Collections.unmodifiableMap(probabilities);
            this.knownTokenCount = knownTokenCount;
            this.tokenCount = tokenCount;
            this.knownTokenRatio = tokenCount == 0 ? 0.0 : knownTokenCount / (double) tokenCount;
            double marginSignal = Math.min(1.0, Math.max(0.0, margin * 4.0));
            this.evidenceStrength = tokenCount == 0 ? 0.0
                    : knownTokenCount == 0 ? 0.0
                    : (0.65 * knownTokenRatio) + (0.35 * marginSignal);
        }
    }

    public synchronized String classify(String text) {
        return classifyDetailed(text).label;
    }

    /** Etiket yanında göreli güven ve ikinci en iyi etiket farkını da verir. */
    public synchronized Classification classifyDetailed(String text) {
        List<String> tokens = tokenize(text);
        if (tokens.isEmpty()) {
            Map<String, Double> empty = new java.util.LinkedHashMap<>();
            for (String label : LABELS) empty.put(label, 1.0 / LABELS.length);
            return new Classification("genel", 1.0 / LABELS.length, 0.0, empty, 0, 0);
        }

        int knownTokenCount = 0;
        for (String token : tokens) if (vocabulary.contains(token)) knownTokenCount++;

        Map<String, Double> scores = new java.util.LinkedHashMap<>();
        double maxScore = Double.NEGATIVE_INFINITY;
        String bestLabel = "genel";
        for (String label : LABELS) {
            int labelDocs = documentTotals.containsKey(label) ? documentTotals.get(label) : 0;
            double score = Math.log((labelDocs + 1.0) / (totalDocuments + LABELS.length));
            Map<String, Integer> counts = wordsByLabel.get(label);
            int totalWords = wordTotals.containsKey(label) ? wordTotals.get(label) : 0;
            for (String token : tokens) {
                int tokenCount = counts != null && counts.containsKey(token) ? counts.get(token) : 0;
                score += Math.log((tokenCount + 1.0) / (totalWords + vocabulary.size() + 1.0));
            }
            scores.put(label, score);
            if (score > maxScore) {
                maxScore = score;
                bestLabel = label;
            }
        }

        double denominator = 0.0;
        for (double score : scores.values()) denominator += Math.exp(score - maxScore);
        Map<String, Double> probabilities = new java.util.LinkedHashMap<>();
        double bestProbability = 0.0;
        double secondProbability = 0.0;
        for (Map.Entry<String, Double> entry : scores.entrySet()) {
            double probability = Math.exp(entry.getValue() - maxScore) / denominator;
            probabilities.put(entry.getKey(), probability);
            if (probability > bestProbability) {
                secondProbability = bestProbability;
                bestProbability = probability;
            } else if (probability > secondProbability) {
                secondProbability = probability;
            }
        }
        return new Classification(bestLabel, bestProbability, bestProbability - secondProbability,
                probabilities, knownTokenCount, tokens.size());
    }

    public synchronized boolean learnExample(String text, String label) {
        if (text == null || text.trim().length() < 2 || !isKnownLabel(label)) return false;
        database.saveTrainingExample(text.trim(), label);
        rebuild();
        return true;
    }

    public boolean isKnownLabel(String label) {
        if (label == null) return false;
        for (String item : LABELS) if (item.equals(label.trim().toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    public List<String> knownLabels() {
        return new ArrayList<>(Arrays.asList(LABELS));
    }

    private synchronized void rebuild() {
        wordsByLabel.clear();
        wordTotals.clear();
        documentTotals.clear();
        vocabulary.clear();
        totalDocuments = 0;

        List<String[]> examples = new ArrayList<>();
        examples.add(new String[]{"merhaba selam günaydın iyi akşamlar", "selam"});
        examples.add(new String[]{"selam ja.i nasılsın ne haber", "selam"});
        examples.add(new String[]{"2 + 2 kaç eder hesapla 15/3", "matematik"});
        examples.add(new String[]{"bir sayı işleminin sonucunu bul", "matematik"});
        examples.add(new String[]{"bunu hatırla hafızaya kaydet daha önce ne demiştim", "hafiza"});
        examples.add(new String[]{"hafızada ara kaydettiğim bilgiyi bul", "hafiza"});
        examples.add(new String[]{"java kod yaz program hata ayıkla derle", "kod"});
        examples.add(new String[]{"bu kodu kontrol et uygulama oluştur", "kod"});
        examples.add(new String[]{"görev listesi olan web uygulaması yap html css javascript üret", "kod"});
        examples.add(new String[]{"hafıza oyunu refleks testi tıklama oyunu geliştir", "kod"});
        examples.add(new String[]{"not defteri ve hesap makinesi olan uygulama oluştur", "kod"});
        examples.add(new String[]{"çok dosyalı web projesi üret index html css js", "kod"});
        examples.add(new String[]{"kod laboratuvarında yeni proje kodu üret", "kod"});
        examples.add(new String[]{"çince öğren java öğren konu öğret", "ogrenme"});
        examples.add(new String[]{"öğrenme kuyruğuna konu ekle çalışmayı başlat", "ogrenme"});
        examples.add(new String[]{"saat kaç bugün tarih nedir", "zaman"});
        examples.add(new String[]{"şu an saat kaç tarih göster", "zaman"});
        examples.add(new String[]{"internette araştır webde ara güncel bilgi kaynak bul", "arastirma"});
        examples.add(new String[]{"son gelişmeleri haberleri resmi kaynakları araştır", "arastirma"});
        examples.add(new String[]{"ekli dosyayı oku pdf incele zip dosyasını analiz et", "dosya"});
        examples.add(new String[]{"belge içeriğini çıkar dosyadaki metni bul", "dosya"});
        examples.add(new String[]{"bu metni özetle kısa özet çıkar ana fikirleri bul", "ozet"});
        examples.add(new String[]{"belgeyi kısalt önemli maddeleri özetle", "ozet"});
        examples.add(new String[]{"iki seçeneği karşılaştır farklarını benzerliklerini bul", "karsilastirma"});
        examples.add(new String[]{"A ile B arasındaki fark nedir hangisi daha iyi", "karsilastirma"});
        examples.add(new String[]{"fotosentez nasıl olur açıklama istiyorum", "genel"});
        examples.add(new String[]{"bana bilgi ver bunu karşılaştır", "genel"});
        examples.add(new String[]{"neden nasıl ne demek anlat", "genel"});
        examples.addAll(database.getTrainingExamples());

        for (String[] example : examples) {
            if (example == null || example.length < 2 || !isKnownLabel(example[1])) continue;
            addTrainingRecord(example[0], example[1]);
        }
    }

    private void addTrainingRecord(String text, String label) {
        totalDocuments++;
        documentTotals.put(label, documentTotals.containsKey(label) ? documentTotals.get(label) + 1 : 1);
        Map<String, Integer> counts = wordsByLabel.get(label);
        if (counts == null) {
            counts = new HashMap<>();
            wordsByLabel.put(label, counts);
        }
        for (String token : tokenize(text)) {
            vocabulary.add(token);
            counts.put(token, counts.containsKey(token) ? counts.get(token) + 1 : 1);
            wordTotals.put(label, wordTotals.containsKey(label) ? wordTotals.get(label) + 1 : 1);
        }
    }

    private static List<String> tokenize(String text) {
        return TurkishTextProcessor.tokens(text);
    }
}
