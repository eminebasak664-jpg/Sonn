package com.jai.assistant.engine;

import com.jai.assistant.data.MemoryDatabase;
import com.jai.assistant.data.TaskRecord;
import com.jai.assistant.tools.ResearchReport;
import com.jai.assistant.tools.ResearchSource;

import java.util.List;

/** Yerel görev kuyruğu ve web'den alınan kaynakların aranabilir yerel hafızası. */
public final class LearningEngine {
    private final TaskPersistence taskPersistence;
    private final MemoryDatabase database;

    public LearningEngine(MemoryDatabase database) {
        this.database = database;
        this.taskPersistence = new TaskPersistence(database);
    }

    public long enqueueTopic(String topic) {
        String cleaned = topic == null ? "" : topic.trim();
        if (cleaned.isEmpty()) throw new IllegalArgumentException("Öğrenilecek konu boş olamaz.");
        return taskPersistence.enqueue(cleaned, "öğrenme", "Konu yerel görev kuyruğuna alındı. Ara açıksa mesaj gönderildiğinde web kaynakları araştırılıp yerel kaynak hafızasına kaydedilebilir.");
    }

    /**
     * Okunan kısa kaynak parçalarını yerel SQLite hafızasına kaydeder.
     * Kayıtlar model ağırlıklarını eğitmez ve doğrulanmış olarak işaretlenmez.
     */
    public int rememberResearch(ResearchReport report) {
        if (report == null || report.getSources().isEmpty()) return 0;
        int stored = 0;
        for (ResearchSource source : report.getSources()) {
            if (source == null || source.url.isEmpty() || source.excerpt.length() < 25) continue;
            String content = "Araştırma konusu: " + report.query
                    + "\nAlınan kısa içerik: " + source.excerpt
                    + "\nSayfa okuma durumu: " + (source.pageRead ? "Sayfa içeriği alındı" : "Yalnızca arama sonucu özeti")
                    + "\nToplanma zamanı: " + report.collectedAt
                    + "\nYayın tarihi: otomatik olarak belirlenmedi"
                    + "\nÖnemli: Bu otomatik kaynak notu bağımsız olarak doğrulanmadı. Bu kayıt genel dil modelini eğitmez; yalnızca yerel hafızada aranabilir.";
            long id = database.saveResearchMemory("Web: " + source.title, content, source.url);
            if (id > 0) stored++;
        }
        return stored;
    }

    public boolean finishLatestTopic(String topic, String status, String details) {
        return database.updateLatestTask(topic, "öğrenme", status, details);
    }

    public List<TaskRecord> recentTasks(int limit) { return taskPersistence.recent(limit); }
    public boolean pauseTask(long id) { return taskPersistence.pause(id); }
    public boolean requeueTask(long id) { return taskPersistence.requeue(id); }
}
