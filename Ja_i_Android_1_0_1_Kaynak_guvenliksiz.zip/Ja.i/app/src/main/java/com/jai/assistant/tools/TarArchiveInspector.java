package com.jai.assistant.tools;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;

/** TAR arşivlerini diske çıkarmadan okur; boyut bütçesi cihazın anlık heap durumuna göre belirlenir. */
public final class TarArchiveInspector {
    private static final int BLOCK = 512;
    private static final int MAX_ENTRIES = 10_000;

    public String inspect(InputStream input) throws IOException {
        if (input == null) throw new IOException("TAR akışı açılamadı.");
        StringBuilder report = new StringBuilder("TAR arşivi içeriği (diske çıkarılmadan)\n");
        int maxReportChars = ResourceAwareBudget.currentSafeTextCharacters();
        long total = 0;
        int entries = 0;
        boolean truncated = false;
        byte[] header = new byte[BLOCK];
        while (true) {
            int headerRead = readFully(input, header);
            if (headerRead == 0) break;
            if (headerRead != BLOCK) throw new IOException("TAR başlığı eksik veya bozuk.");
            if (allZero(header)) break;
            String name = field(header, 0, 100);
            String prefix = field(header, 345, 155);
            if (!prefix.isEmpty()) name = prefix + "/" + name;
            long size = parseOctal(header, 124, 12);
            if (size < 0 || size > Integer.MAX_VALUE - 8L) throw new IOException("TAR girdisinin boyutu bu Android çalışma alanında temsil edilemiyor: " + name);
            total += size;
            long currentBuffer = ResourceAwareBudget.currentSafeArrayBytes();
            if (size > currentBuffer) throw new IOException("TAR girdisi şu an tek bir bellek tamponuna sığmıyor. Sabit 16 MiB dosya kotası kaldırıldı; yeterli boş uygulama belleği yok: " + name);

            ByteArrayOutputStream bytes = new ByteArrayOutputStream((int) size);
            byte[] buffer = new byte[8192];
            long remaining = size;
            while (remaining > 0) {
                int read = input.read(buffer, 0, (int) Math.min(buffer.length, remaining));
                if (read < 0) throw new IOException("TAR girdisi eksik: " + name);
                bytes.write(buffer, 0, read);
                remaining -= read;
            }
            long padding = (BLOCK - (size % BLOCK)) % BLOCK;
            skipFully(input, padding);
            entries++;
            if (entries > MAX_ENTRIES) throw new IOException("TAR arşivinde 10.000'den fazla girdi var; işlemci yükünü ve bellek kullanımını sınırlamak için inceleme durduruldu.");

            String heading = "\n\n========== " + name + " (" + size + " bayt) ==========\n";
            if (report.length() + heading.length() > maxReportChars) { truncated = true; break; }
            report.append(heading);
            byte[] content = bytes.toByteArray();
            String text = decodeText(content);
            String section = text != null ? text.trim() : printableStrings(content);
            if (section.isEmpty()) section = "[İkili içerik; metin çözümlenemedi.]";
            int remainingChars = maxReportChars - report.length();
            if (section.length() > remainingChars) {
                if (remainingChars > 0) report.append(section, 0, remainingChars);
                truncated = true;
                break;
            }
            report.append(section);
        }
        if (truncated) report.append("\n[İçerik, telefonun o anki kullanılabilir uygulama belleğine göre kısaltıldı.]");
        return report.append("\n\nToplam girdi: ").append(entries).append(" · Okunan açılmış veri toplamı: ").append(total)
                .append(" bayt\nTAR dosyaları diske çıkarılmadı.").toString();
    }

    private int readFully(InputStream input, byte[] target) throws IOException {
        int total = 0;
        while (total < target.length) {
            int count = input.read(target, total, target.length - total);
            if (count < 0) break;
            total += count;
        }
        return total;
    }

    private void skipFully(InputStream input, long count) throws IOException {
        while (count > 0) {
            long skipped = input.skip(count);
            if (skipped <= 0) { if (input.read() < 0) throw new IOException("TAR dolgu alanı eksik."); skipped = 1; }
            count -= skipped;
        }
    }

    private boolean allZero(byte[] bytes) { for (byte value : bytes) if (value != 0) return false; return true; }

    private String field(byte[] header, int start, int length) {
        int end = start;
        while (end < start + length && header[end] != 0) end++;
        return new String(header, start, end - start, StandardCharsets.UTF_8).trim();
    }

    private long parseOctal(byte[] header, int start, int length) throws IOException {
        String raw = new String(header, start, length, StandardCharsets.US_ASCII).replace("\u0000", "").trim();
        if (raw.isEmpty()) return 0;
        try { return Long.parseLong(raw, 8); }
        catch (NumberFormatException exception) { throw new IOException("TAR başlığındaki dosya boyutu geçersiz.", exception); }
    }

    private String decodeText(byte[] bytes) {
        if (bytes.length == 0) return "";
        for (byte value : bytes) if (value == 0) return null;
        try {
            return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
        } catch (CharacterCodingException exception) { return null; }
    }

    private String printableStrings(byte[] bytes) {
        StringBuilder out = new StringBuilder();
        int start = -1;
        int count = 0;
        for (int i = 0; i <= bytes.length && count < 100; i++) {
            boolean printable = i < bytes.length && (bytes[i] & 0xff) >= 32 && (bytes[i] & 0xff) <= 126;
            if (printable && start < 0) start = i;
            if (!printable && start >= 0) {
                if (i - start >= 4) { out.append(new String(bytes, start, i - start, StandardCharsets.US_ASCII)).append('\n'); count++; }
                start = -1;
            }
        }
        return out.toString();
    }
}
