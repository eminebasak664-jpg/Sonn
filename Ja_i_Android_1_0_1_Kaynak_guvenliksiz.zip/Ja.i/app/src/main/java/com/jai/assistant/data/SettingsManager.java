package com.jai.assistant.data;

import android.content.Context;
import android.content.SharedPreferences;

public final class SettingsManager {
    private final SharedPreferences preferences;

    public SettingsManager(Context context) {
        preferences = context.getApplicationContext().getSharedPreferences("jai_settings", Context.MODE_PRIVATE);
    }

    public boolean isWebResearchEnabled() {
        return preferences.getBoolean("web_research_enabled", false);
    }

    public void setWebResearchEnabled(boolean enabled) {
        preferences.edit().putBoolean("web_research_enabled", enabled).apply();
    }

    public String getMode() {
        return preferences.getString("mode", "Flash");
    }

    public void setMode(String mode) {
        preferences.edit().putString("mode", mode).apply();
    }

    public String getEffort() {
        return preferences.getString("effort", "Orta");
    }

    public void setEffort(String effort) {
        preferences.edit().putString("effort", effort).apply();
    }

    /** True means the future model pipeline may choose its own stage count. */
    public boolean isAutoStageMode() {
        return preferences.getBoolean("auto_stage_mode", true);
    }

    public void setAutoStageMode(boolean enabled) {
        preferences.edit().putBoolean("auto_stage_mode", enabled).apply();
    }

    /** Manual stage count is bounded to keep processor workload and execution time predictable. */
    public int getManualStageCount() {
        return Math.max(1, Math.min(115, preferences.getInt("manual_stage_count", 8)));
    }

    public void setManualStageCount(int count) {
        int safeCount = Math.max(1, Math.min(115, count));
        preferences.edit().putInt("manual_stage_count", safeCount).apply();
    }
}
