package com.jai.assistant.engine;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Bedrock world-container (.mcworld) writer: level.dat + DB seed directory + embedded packs. */
public final class BedrockWorldArchiveGenerator {
    private final ProjectArchiveWriter archiveWriter = new ProjectArchiveWriter();

    public byte[] create(String worldName, long seed, String resourceUuid, String behaviorUuid,
                         Map<String, byte[]> resourcePack, Map<String, byte[]> behaviorPack) throws IOException {
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("level.dat", createLevelDat(worldName, seed));
        // Keep a real empty db/ directory entry. Minecraft initializes its LevelDB store on first open.
        files.put("db/", new byte[0]);
        files.put("levelname.txt", (safe(worldName) + "\n").getBytes(StandardCharsets.UTF_8));
        files.put("world_resource_packs.json", packLink(resourceUuid));
        files.put("world_behavior_packs.json", packLink(behaviorUuid));
        copyPack(files, "resource_packs/" + resourceUuid + "/", resourcePack);
        copyPack(files, "behavior_packs/" + behaviorUuid + "/", behaviorPack);
        files.put("README_JAI_WORLD.txt", ("Ja.i Bedrock dünya paketi\nDünya adı: " + safe(worldName)
                + "\nSeed: " + seed + "\nMinecraft ilk açılışta db/ klasörünü kendi LevelDB biçiminde başlatır."
                + " Bu arşiv yapısal olarak hazırlanmıştır; hedef cihazda Minecraft içe aktarma ve dünya açma testi yapılmalıdır.\n").getBytes(StandardCharsets.UTF_8));
        return archiveWriter.createZipBinary(files);
    }

    private static byte[] packLink(String uuid) {
        String json = "[ { \"pack_id\": \"" + uuid + "\", \"version\": [1, 0, 0] } ]\n";
        return json.getBytes(StandardCharsets.UTF_8);
    }
    private static void copyPack(Map<String, byte[]> target, String prefix, Map<String, byte[]> source) {
        for (Map.Entry<String, byte[]> entry : source.entrySet()) target.put(prefix + entry.getKey(), entry.getValue());
    }

    /** Bedrock level.dat v10: little-endian header + little-endian NBT root compound. */
    private static byte[] createLevelDat(String name, long seed) throws IOException {
        ByteArrayOutputStream nbtBytes = new ByteArrayOutputStream();
        DataOutputStream nbt = new DataOutputStream(nbtBytes);
        nbt.writeByte(10); writeLeShort(nbt, 0); // root TAG_Compound, empty name
        writeIntTag(nbt, "GameType", 0);
        writeIntTag(nbt, "Difficulty", 2);
        writeIntTag(nbt, "Generator", 1);
        writeIntTag(nbt, "SpawnX", 0);
        writeIntTag(nbt, "SpawnY", 64);
        writeIntTag(nbt, "SpawnZ", 0);
        writeLongTag(nbt, "RandomSeed", seed);
        writeLongTag(nbt, "Time", 0L);
        writeLongTag(nbt, "LastPlayed", System.currentTimeMillis() / 1000L);
        writeByteTag(nbt, "commandsEnabled", 1);
        writeByteTag(nbt, "LANBroadcast", 1);
        writeByteTag(nbt, "MultiplayerGame", 1);
        writeByteTag(nbt, "SpawnMobs", 1);
        writeByteTag(nbt, "hasBeenLoadedInCreative", 0);
        writeStringTag(nbt, "LevelName", safe(name));
        nbt.writeByte(0); // TAG_End
        nbt.flush();
        byte[] payload = nbtBytes.toByteArray();
        ByteArrayOutputStream file = new ByteArrayOutputStream(payload.length + 8);
        DataOutputStream out = new DataOutputStream(file);
        writeLeInt(out, 10); writeLeInt(out, payload.length); out.write(payload); out.flush();
        return file.toByteArray();
    }
    private static void writeIntTag(DataOutputStream out, String name, int value) throws IOException { out.writeByte(3); writeLeString(out, name); writeLeInt(out, value); }
    private static void writeLongTag(DataOutputStream out, String name, long value) throws IOException { out.writeByte(4); writeLeString(out, name); writeLeLong(out, value); }
    private static void writeByteTag(DataOutputStream out, String name, int value) throws IOException { out.writeByte(1); writeLeString(out, name); out.writeByte(value); }
    private static void writeStringTag(DataOutputStream out, String name, String value) throws IOException { out.writeByte(8); writeLeString(out, name); writeLeString(out, value); }
    private static void writeLeString(DataOutputStream out, String text) throws IOException {
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > 65535) throw new IOException("NBT metin alanı çok uzun.");
        writeLeShort(out, bytes.length); out.write(bytes);
    }
    private static void writeLeShort(DataOutputStream out, int value) throws IOException { out.writeByte(value & 255); out.writeByte((value >>> 8) & 255); }
    private static void writeLeInt(DataOutputStream out, int value) throws IOException { out.writeByte(value & 255); out.writeByte((value >>> 8) & 255); out.writeByte((value >>> 16) & 255); out.writeByte((value >>> 24) & 255); }
    private static void writeLeLong(DataOutputStream out, long value) throws IOException { writeLeInt(out, (int) value); writeLeInt(out, (int) (value >>> 32)); }
    private static String safe(String value) { return (value == null || value.trim().isEmpty() ? "Ja.i Dünya" : value.trim()).replace("\n", " ").replace("\r", " "); }
}
