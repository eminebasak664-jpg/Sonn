package com.jai.assistant.tools;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ara açıkken web görsel araması yapar ve küçük, doğrulanmış görsel örneklerini indirir.
 * Haricî görsel modeli/API'si çağırmaz; yalnızca referans görselleri yerel öğrenme motoruna verir.
 * DuckDuckGo'nun i.js uç noktası resmî ve kararlı bir geliştirici API'si değildir; engellenebilir.
 */
public final class WebImageResearchEngine {
    private static final String BASE = "https://duckduckgo.com/";
    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36";
    private static final int MAX_SEARCH_HTML = 512 * 1024;
    private static final int MAX_JSON_BYTES = 1024 * 1024;
    private static final int MAX_IMAGE_BYTES = 1_500_000;

    public static final class DownloadedImage {
        public final String title;
        public final String imageUrl;
        public final String sourceUrl;
        public final String contentType;
        public final byte[] bytes;

        private DownloadedImage(String title, String imageUrl, String sourceUrl,
                                String contentType, byte[] bytes) {
            this.title = title;
            this.imageUrl = imageUrl;
            this.sourceUrl = sourceUrl;
            this.contentType = contentType;
            this.bytes = bytes;
        }
    }

    public static final class Result {
        public final String query;
        public final List<DownloadedImage> images;
        public final String note;

        private Result(String query, List<DownloadedImage> images, String note) {
            this.query = query;
            this.images = images;
            this.note = note;
        }
    }

    /** En fazla maxImages görsel indirir; bağlantı ve dosya boyutları kesin sınırlandırılır. */
    public Result searchAndDownload(String query, int maxImages) {
        String clean = cleanQuery(query);
        List<DownloadedImage> images = new ArrayList<>();
        if (clean.isEmpty()) return new Result(clean, images, "Görsel arama sorgusu boş.");
        int wanted = Math.max(1, Math.min(4, maxImages));
        HttpURLConnection connection = null;
        try {
            String encoded = URLEncoder.encode(clean, StandardCharsets.UTF_8.name());
            URL tokenUrl = URI.create(BASE + "?q=" + encoded + "&iax=images&ia=images").toURL();
            connection = open(tokenUrl, BASE);
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) {
                return new Result(clean, images, "Görsel arama sayfası HTTP " + status + " yanıtı verdi.");
            }
            String html;
            try (InputStream input = connection.getInputStream()) { html = readLimited(input, MAX_SEARCH_HTML); }
            String vqd = extractVqd(html);
            if (vqd.isEmpty()) return new Result(clean, images,
                    "Görsel arama belirteci alınamadı; servis sayfayı değiştirmiş veya isteği sınırlamış olabilir.");

            String imageSearchUrl = BASE + "i.js?q=" + encoded
                    + "&o=json&l=wt-wt&vqd=" + URLEncoder.encode(vqd, StandardCharsets.UTF_8.name())
                    + "&f=%2C%2C%2C%2C%2C&p=1";
            connection.disconnect();
            connection = open(URI.create(imageSearchUrl).toURL(), BASE);
            status = connection.getResponseCode();
            if (status < 200 || status >= 300) {
                return new Result(clean, images, "Görsel sonuç servisi HTTP " + status + " yanıtı verdi.");
            }
            String json;
            try (InputStream input = connection.getInputStream()) { json = readLimited(input, MAX_JSON_BYTES); }
            List<ImageHit> hits = parseImageHits(json);
            LinkedHashSet<String> seen = new LinkedHashSet<>();
            for (ImageHit hit : hits) {
                if (images.size() >= wanted) break;
                if (!seen.add(hit.imageUrl) || !isSafeHttpsUrl(hit.imageUrl)) continue;
                DownloadedImage downloaded = download(hit);
                if (downloaded != null) images.add(downloaded);
            }
            String note = images.isEmpty()
                    ? "Görsel araması tamamlandı ancak indirilebilir, güvenli görsel bulunamadı."
                    : images.size() + " web görseli indirildi; yerel piksel öğrenmesi için hazır.";
            return new Result(clean, images, note);
        } catch (Exception error) {
            return new Result(clean, images, "Web görsel araştırması tamamlanamadı: " + safeMessage(error));
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private DownloadedImage download(ImageHit hit) {
        HttpURLConnection connection = null;
        try {
            URL current = URI.create(hit.imageUrl).toURL();
            for (int redirects = 0; redirects <= 2; redirects++) {
                if (!isSafeHttpsUrl(current.toString())) return null;
                connection = open(current, BASE);
                connection.setRequestProperty("Accept", "image/jpeg,image/png,image/webp,image/gif,image/bmp,image/*;q=0.8");
                int status = connection.getResponseCode();
                if (status >= 300 && status < 400) {
                    String location = connection.getHeaderField("Location");
                    connection.disconnect(); connection = null;
                    if (location == null || redirects == 2) return null;
                    current = current.toURI().resolve(location).toURL();
                    continue;
                }
                if (status < 200 || status >= 300) return null;
                String type = connection.getContentType();
                if (!isSupportedRasterType(type)) return null;
                int length = connection.getContentLength();
                if (length > MAX_IMAGE_BYTES) return null;
                byte[] bytes;
                try (InputStream input = connection.getInputStream()) { bytes = readBytesLimited(input, MAX_IMAGE_BYTES); }
                if (bytes.length < 128) return null;
                return new DownloadedImage(hit.title, current.toString(), hit.sourceUrl, type, bytes);
            }
        } catch (Exception ignored) {
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
        return null;
    }

    static boolean isSupportedRasterType(String contentType) {
        if (contentType == null) return false;
        String type = contentType.split(";", 2)[0].trim().toLowerCase(java.util.Locale.ROOT);
        return type.equals("image/jpeg") || type.equals("image/png") || type.equals("image/webp")
                || type.equals("image/gif") || type.equals("image/bmp") || type.equals("image/x-ms-bmp");
    }

    private static HttpURLConnection open(URL url, String referer) throws IOException {
        if (!"https".equalsIgnoreCase(url.getProtocol())) throw new IOException("Yalnızca HTTPS bağlantıları kabul edilir.");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(8_000);
        connection.setReadTimeout(10_000);
        connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("User-Agent", USER_AGENT);
        connection.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7");
        connection.setRequestProperty("Referer", referer);
        return connection;
    }

    private static String extractVqd(String html) {
        String[] patterns = {
                "(?is)\\bvqd\\s*=\\s*\\\"([^\\\"]+)\\\"",
                "(?is)\\\"vqd\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"",
                "(?is)\\bvqd=([0-9-]{8,})"
        };
        for (String expression : patterns) {
            Matcher matcher = Pattern.compile(expression).matcher(html);
            if (matcher.find()) return matcher.group(1).trim();
        }
        return "";
    }

    static List<String> parseImageUrlsForTest(String json) {
        List<String> urls = new ArrayList<>();
        for (ImageHit hit : parseImageHits(json)) urls.add(hit.imageUrl);
        return urls;
    }

    private static List<ImageHit> parseImageHits(String json) {
        List<ImageHit> hits = new ArrayList<>();
        if (json == null) return hits;
        int results = json.indexOf("\"results\"");
        int arrayStart = results < 0 ? -1 : json.indexOf('[', results);
        if (arrayStart < 0) return hits;
        boolean inString = false, escaped = false;
        int objectDepth = 0, objectStart = -1;
        for (int i = arrayStart + 1; i < json.length(); i++) {
            char c = json.charAt(i);
            if (inString) {
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '"') inString = false;
                continue;
            }
            if (c == '"') { inString = true; continue; }
            if (c == '{') {
                if (objectDepth == 0) objectStart = i;
                objectDepth++;
            } else if (c == '}') {
                objectDepth--;
                if (objectDepth == 0 && objectStart >= 0) {
                    String object = json.substring(objectStart, i + 1);
                    String image = jsonString(object, "image");
                    if (!image.isEmpty()) hits.add(new ImageHit(
                            jsonString(object, "title"), image, jsonString(object, "url")));
                    objectStart = -1;
                }
            } else if (c == ']' && objectDepth == 0) break;
        }
        return hits;
    }

    private static String jsonString(String object, String key) {
        Matcher matcher = Pattern.compile("(?s)\\\"" + Pattern.quote(key)
                + "\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\\\\\"])*)\\\"").matcher(object);
        if (!matcher.find()) return "";
        return unescapeJson(matcher.group(1)).trim();
    }

    private static String unescapeJson(String value) {
        StringBuilder out = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c != '\\' || i + 1 >= value.length()) { out.append(c); continue; }
            char next = value.charAt(++i);
            switch (next) {
                case '"': out.append('"'); break;
                case '\\': out.append('\\'); break;
                case '/': out.append('/'); break;
                case 'b': out.append('\b'); break;
                case 'f': out.append('\f'); break;
                case 'n': out.append('\n'); break;
                case 'r': out.append('\r'); break;
                case 't': out.append('\t'); break;
                case 'u':
                    if (i + 4 < value.length()) {
                        try { out.append((char) Integer.parseInt(value.substring(i + 1, i + 5), 16)); i += 4; }
                        catch (NumberFormatException badEscape) { out.append('u'); }
                    } else out.append('u');
                    break;
                default: out.append(next);
            }
        }
        return out.toString();
    }

    static boolean isSafeHttpsUrl(String value) {
        try {
            URI uri = URI.create(value);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null
                    || uri.getUserInfo() != null || uri.getPort() != -1 && uri.getPort() != 443) return false;
            String host = uri.getHost().toLowerCase(java.util.Locale.ROOT);
            if (host.equals("localhost") || host.endsWith(".localhost") || host.endsWith(".local")) return false;
            // DNS adı da özel/yerel IP'ye çözülüyorsa reddet; resim URL'si yerel ağa erişememeli.
            InetAddress[] addresses = InetAddress.getAllByName(host);
            if (addresses.length == 0) return false;
            for (InetAddress address : addresses) {
                if (address.isAnyLocalAddress() || address.isLoopbackAddress() || address.isLinkLocalAddress()
                        || address.isSiteLocalAddress() || address.isMulticastAddress()) return false;
            }
            return true;
        } catch (Exception invalid) { return false; }
    }

    private static String readLimited(InputStream input, int limit) throws IOException {
        byte[] bytes = readBytesLimited(input, limit);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private static byte[] readBytesLimited(InputStream input, int limit) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream(Math.min(limit, 16 * 1024));
        byte[] buffer = new byte[8192];
        int read;
        while ((read = input.read(buffer)) != -1) {
            if (output.size() + read > limit) throw new IOException("İçerik boyut sınırını aştı.");
            output.write(buffer, 0, read);
        }
        return output.toByteArray();
    }

    private static String cleanQuery(String query) {
        if (query == null) return "";
        String value = query.replaceAll("[\\p{Cntrl}]", " ").replaceAll("\\s+", " ").trim();
        if (value.length() > 140) value = value.substring(0, 140).trim();
        return value;
    }

    private static String safeMessage(Exception error) {
        String message = error.getMessage();
        return message == null || message.trim().isEmpty() ? error.getClass().getSimpleName() : message;
    }

    private static final class ImageHit {
        final String title, imageUrl, sourceUrl;
        ImageHit(String title, String imageUrl, String sourceUrl) {
            this.title = title == null ? "" : title;
            this.imageUrl = imageUrl == null ? "" : imageUrl;
            this.sourceUrl = sourceUrl == null ? "" : sourceUrl;
        }
    }
}
