package com.jai.assistant.engine;

import android.content.Context;

import com.jai.assistant.data.ChatMessage;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.FloatBuffer;
import java.nio.LongBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Colab'da sıfırdan eğitilmiş Ja.i GRU dil modelini Android üzerinde çevrimdışı çalıştırır.
 * Bu sınıf hazır bir model indirmez; yalnızca kullanıcı tarafından eğitilip içe aktarılan ONNX paketini açar.
 */
public final class LocalOnnxLanguageModel implements AutoCloseable {
    public static final String PACKAGE_MODEL = "jai-chat-model.onnx";
    public static final String PACKAGE_CONFIG = "model_config.json";
    public static final String PACKAGE_REPORT = "training_report.json";
    private static final long MAX_MODEL_BYTES = 96L * 1024L * 1024L;
    private static final long MAX_CONFIG_BYTES = 64L * 1024L;
    private static final int MAX_ZIP_ENTRIES = 4;
    private static final int MAX_NEW_TOKENS = 640;
    private static final int MIN_HIDDEN = 64;
    private static final int MAX_HIDDEN = 512;
    private static final int MIN_LAYERS = 1;
    private static final int MAX_LAYERS = 4;

    private final File modelDirectory;
    private final File modelFile;
    private final File configFile;
    private final OrtEnvironment environment;
    private OrtSession session;
    // ONNX Runtime belgelerine göre seçenek nesnesi, onu kullanan oturum kapanana dek tutulur.
    private OrtSession.SessionOptions sessionOptions;
    private int hiddenSize = 256;
    private int layerCount = 2;
    private int maxContextTokens = 512;
    private volatile String status = "Eğitilmiş yerel sohbet modeli yüklenmedi. Colab notebook'u ile model eğitip içe aktar.";
    private final Random random = new Random();

    public LocalOnnxLanguageModel(Context context) {
        File root = context.getApplicationContext().getFilesDir();
        modelDirectory = new File(root, "jai_language_model");
        modelFile = new File(modelDirectory, PACKAGE_MODEL);
        configFile = new File(modelDirectory, PACKAGE_CONFIG);
        OrtEnvironment localEnvironment;
        try {
            localEnvironment = OrtEnvironment.getEnvironment();
        } catch (Throwable error) {
            localEnvironment = null;
            status = "ONNX Runtime başlatılamadı: " + safeMessage(error);
        }
        environment = localEnvironment;
        // Büyük ONNX dosyasını Activity açılışında UI iş parçacığında eşzamanlı yükleme.
    }

    public synchronized boolean isReady() {
        return session != null;
    }

    public String getStatus() {
        return status;
    }

    /** ZIP paketini güvenli geçici klasöre çıkarır, ONNX oturumuyla doğrular ve sonra etkinleştirir. */
    public synchronized String importPackage(InputStream source) throws IOException {
        if (source == null) throw new IllegalArgumentException("Model paketi okunamadı.");
        if (environment == null) throw new IOException("ONNX Runtime bu cihazda başlatılamadı: " + status);
        File parent = modelDirectory.getParentFile();
        if (parent == null || (!parent.exists() && !parent.mkdirs())) throw new IOException("Model klasörü oluşturulamadı.");
        File staging = new File(parent, "jai_language_model_staging");
        File backup = new File(parent, "jai_language_model_backup");
        deleteTree(staging);
        deleteTree(backup);
        if (!staging.mkdirs()) throw new IOException("Geçici model klasörü oluşturulamadı.");

        long modelBytes = 0;
        long configBytes = 0;
        int entries = 0;
        java.util.Set<String> seenEntries = new java.util.HashSet<>();
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(source))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if (++entries > MAX_ZIP_ENTRIES) throw new IOException("Model ZIP paketi beklenenden fazla dosya içeriyor.");
                String name = entry.getName();
                if (name == null || !seenEntries.add(name)) throw new IOException("ZIP içinde yinelenen veya boş dosya adı bulundu.");
                if (entry.isDirectory() || name.contains("/") || name.contains("\\")
                        || name.equals(".") || name.equals("..")) {
                    throw new IOException("Model ZIP içinde güvenli olmayan yol bulundu.");
                }
                File out;
                long limit;
                if (PACKAGE_MODEL.equals(name)) {
                    out = new File(staging, PACKAGE_MODEL);
                    limit = MAX_MODEL_BYTES;
                } else if (PACKAGE_CONFIG.equals(name)) {
                    out = new File(staging, PACKAGE_CONFIG);
                    limit = MAX_CONFIG_BYTES;
                } else if (PACKAGE_REPORT.equals(name)) {
                    out = null;
                    limit = MAX_CONFIG_BYTES;
                } else {
                    throw new IOException("Beklenmeyen model paketi dosyası: " + name);
                }
                long copied;
                if (out == null) copied = readBounded(zip, limit).length;
                else copied = copyBounded(zip, out, limit);
                if (PACKAGE_MODEL.equals(name)) modelBytes = copied;
                else if (PACKAGE_CONFIG.equals(name)) configBytes = copied;
                zip.closeEntry();
            }
        } catch (Exception error) {
            deleteTree(staging);
            if (error instanceof IOException) throw (IOException) error;
            throw new IOException("Model ZIP paketi açılamadı: " + error.getMessage(), error);
        }

        if (modelBytes < 1024 || configBytes < 20) {
            deleteTree(staging);
            throw new IOException("Model paketi eksik veya bozuk: ONNX ağı ve model_config.json gerekli.");
        }
        int previousHidden = hiddenSize;
        int previousLayers = layerCount;
        int previousContext = maxContextTokens;
        try {
            validateConfig(new File(staging, PACKAGE_CONFIG));
        } catch (Exception error) {
            hiddenSize = previousHidden;
            layerCount = previousLayers;
            maxContextTokens = previousContext;
            deleteTree(staging);
            throw new IOException("Model ayarları geçersiz: " + safeMessage(error), error);
        }
        try (OrtSession.SessionOptions options = new OrtSession.SessionOptions()) {
            options.setIntraOpNumThreads(2);
            options.setInterOpNumThreads(1);
            try (OrtSession candidate = environment.createSession(new File(staging, PACKAGE_MODEL).getAbsolutePath(), options)) {
                if (!candidate.getInputInfo().containsKey("input_ids")
                        || !candidate.getInputInfo().containsKey("hidden_in")
                        || !candidate.getOutputInfo().containsKey("logits")
                        || !candidate.getOutputInfo().containsKey("hidden_out")) {
                    throw new IOException("ONNX giriş/çıkış adları eğitim notebook'uyla uyumlu değil.");
                }
                validateSession(candidate);
            }
        } catch (Exception error) {
            hiddenSize = previousHidden;
            layerCount = previousLayers;
            maxContextTokens = previousContext;
            deleteTree(staging);
            throw new IOException("ONNX modeli açılmadı veya Ja.i model biçimiyle uyuşmuyor: " + safeMessage(error), error);
        }

        closeSession();
        if (modelDirectory.exists() && !modelDirectory.renameTo(backup)) {
            deleteTree(staging);
            reload();
            throw new IOException("Eski model güvenli biçimde yedeklenemedi; etkin model değiştirilmedi.");
        }
        if (!staging.renameTo(modelDirectory)) {
            if (backup.exists()) backup.renameTo(modelDirectory);
            deleteTree(staging);
            reload();
            throw new IOException("Yeni model etkin klasöre taşınamadı; önceki model geri yüklendi.");
        }
        if (!reload()) {
            String loadError = status;
            deleteTree(modelDirectory);
            if (backup.exists()) backup.renameTo(modelDirectory);
            reload();
            throw new IOException("Yeni model açılamadı; önceki model geri yüklendi. Ayrıntı: " + loadError);
        }
        deleteTree(backup);
        status = "Colab'da sıfırdan eğitilmiş Ja.i sohbet modeli yüklendi · " + modelBytes + " bayt";
        return status;
    }

    public synchronized boolean reload() {
        closeSession();
        if (environment == null) {
            status = "ONNX Runtime bu cihazda başlatılamadı; model yüklenemiyor.";
            return false;
        }
        if (!modelFile.isFile() || !configFile.isFile()) {
            status = "Eğitilmiş yerel sohbet modeli yok. Colab notebook'unda eğitim yapıp jai-chat-model.zip dosyasını içe aktar.";
            return false;
        }
        try {
            validateConfig(configFile);
            OrtSession.SessionOptions options = new OrtSession.SessionOptions();
            OrtSession candidate = null;
            try {
                // 4 GB RAM sınıfı telefonlarda aşırı CPU iş parçacığı açılmasını engelle.
                options.setIntraOpNumThreads(2);
                options.setInterOpNumThreads(1);
                options.setMemoryPatternOptimization(true);
                candidate = environment.createSession(modelFile.getAbsolutePath(), options);
                if (!candidate.getInputInfo().containsKey("input_ids") || !candidate.getInputInfo().containsKey("hidden_in")
                        || !candidate.getOutputInfo().containsKey("logits") || !candidate.getOutputInfo().containsKey("hidden_out")) {
                    throw new IOException("Model dosyası bulundu ancak giriş/çıkış biçimi uyumsuz.");
                }
                validateSession(candidate);
                session = candidate;
                sessionOptions = options;
                candidate = null;
                options = null;
                status = "Eğitilmiş Ja.i yerel sohbet modeli hazır.";
                return true;
            } finally {
                if (candidate != null) try { candidate.close(); } catch (Exception ignored) { }
                if (options != null) try { options.close(); } catch (Exception ignored) { }
            }
        } catch (Exception error) {
            closeSession();
            status = "Model yüklenemedi: " + safeMessage(error);
            return false;
        }
    }

    /** Model yoksa null döner; çağıran taraf mevcut yerel fallback motorunu kullanabilir. */
    public synchronized String generate(List<ChatMessage> history, String prompt, String context, String effort) {
        if (session == null) return null;
        int[] tokens = ByteTokenizer.buildConversation(history, prompt, context, maxContextTokens);
        float[][][] hidden = new float[layerCount][1][hiddenSize];
        float[] logits = null;
        try {
            Step promptStep = runTokens(tokens, hidden);
            hidden = promptStep.hidden;
            logits = promptStep.logits;
            if (logits == null) return null;

            int outputLimit = generationLimit(effort);
            List<Integer> generated = new ArrayList<>();
            for (int i = 0; i < outputLimit; i++) {
                int next = sample(logits, temperature(effort));
                if (next == ByteTokenizer.EOS) break;
                if (next < 0 || next > 255) continue;
                generated.add(next);
                Step step = runToken(next, hidden);
                hidden = step.hidden;
                logits = step.logits;
            }
            String answer = ByteTokenizer.decodeBytes(generated).trim();
            if (answer.isEmpty()) return "Model boş yanıt üretti. Eğitim verisini ve modeli yeniden kontrol et.";
            return answer;
        } catch (Exception error) {
            status = "Model çalışırken hata oluştu: " + safeMessage(error);
            return null;
        }
    }

    /** Model yüklenmiş sayılmadan önce gerçek bir tek-token ONNX çıkarımı yapar. */
    private void validateSession(OrtSession candidate) throws Exception {
        long[] ids = new long[]{ByteTokenizer.BOS};
        float[] zeros = new float[layerCount * hiddenSize];
        try (OnnxTensor inputIds = OnnxTensor.createTensor(environment, LongBuffer.wrap(ids), new long[]{1, 1});
             OnnxTensor hiddenInput = OnnxTensor.createTensor(environment, FloatBuffer.wrap(zeros), new long[]{layerCount, 1, hiddenSize})) {
            Map<String, OnnxTensor> inputs = new java.util.HashMap<>();
            inputs.put("input_ids", inputIds);
            inputs.put("hidden_in", hiddenInput);
            try (OrtSession.Result result = candidate.run(inputs)) {
                float[][][] logits = (float[][][]) result.get(0).getValue();
                float[][][] hidden = (float[][][]) result.get(1).getValue();
                if (logits == null || logits.length != 1 || logits[0].length != 1
                        || logits[0][0].length != ByteTokenizer.VOCAB_SIZE) {
                    throw new IOException("ONNX logits şekli 1×1×262 olmalı.");
                }
                if (hidden == null || hidden.length != layerCount || hidden[0].length != 1
                        || hidden[0][0].length != hiddenSize) {
                    throw new IOException("ONNX hidden_out şekli yapılandırmayla uyuşmuyor.");
                }
            }
        }
    }

    private Step runToken(int token, float[][][] hidden) throws Exception {
        return runTokens(new int[]{token}, hidden);
    }

    /** Tüm istem bağlamını tek ONNX çağrısında işler; üretilen baytlar tek tek devam eder. */
    private Step runTokens(int[] tokenIds, float[][][] hidden) throws Exception {
        if (tokenIds == null || tokenIds.length == 0) throw new IllegalArgumentException("Model girdisi boş olamaz.");
        long[] ids = new long[tokenIds.length];
        for (int i = 0; i < tokenIds.length; i++) ids[i] = tokenIds[i];
        float[] flattened = new float[layerCount * hiddenSize];
        int index = 0;
        for (int layer = 0; layer < layerCount; layer++) {
            for (int h = 0; h < hiddenSize; h++) flattened[index++] = hidden[layer][0][h];
        }
        try (OnnxTensor inputIds = OnnxTensor.createTensor(environment, LongBuffer.wrap(ids), new long[]{1, ids.length});
             OnnxTensor hiddenInput = OnnxTensor.createTensor(environment, FloatBuffer.wrap(flattened), new long[]{layerCount, 1, hiddenSize})) {
            Map<String, OnnxTensor> inputs = new java.util.HashMap<>();
            inputs.put("input_ids", inputIds);
            inputs.put("hidden_in", hiddenInput);
            try (OrtSession.Result result = session.run(inputs)) {
                float[][][] outputLogits = (float[][][]) result.get(0).getValue();
                float[][][] outputHidden = (float[][][]) result.get(1).getValue();
                float[] nextLogits = outputLogits[0][outputLogits[0].length - 1];
                float[][][] nextState = new float[layerCount][1][hiddenSize];
                for (int layer = 0; layer < layerCount; layer++) {
                    System.arraycopy(outputHidden[layer][0], 0, nextState[layer][0], 0, hiddenSize);
                }
                return new Step(nextLogits, nextState);
            }
        }
    }

    private int sample(float[] logits, float temperature) {
        if (logits == null || logits.length < ByteTokenizer.VOCAB_SIZE) return ByteTokenizer.EOS;
        final int topK = 32;
        int[] best = new int[topK];
        float[] bestScores = new float[topK];
        Arrays.fill(best, -1);
        Arrays.fill(bestScores, Float.NEGATIVE_INFINITY);
        for (int token = 0; token < ByteTokenizer.VOCAB_SIZE; token++) {
            if (token > 255 && token != ByteTokenizer.EOS) continue;
            float value = logits[token];
            if (Float.isNaN(value) || Float.isInfinite(value)) continue;
            for (int pos = 0; pos < topK; pos++) {
                if (value > bestScores[pos]) {
                    for (int shift = topK - 1; shift > pos; shift--) {
                        bestScores[shift] = bestScores[shift - 1];
                        best[shift] = best[shift - 1];
                    }
                    bestScores[pos] = value;
                    best[pos] = token;
                    break;
                }
            }
        }
        double total = 0.0;
        double[] probabilities = new double[topK];
        float max = bestScores[0];
        for (int i = 0; i < topK; i++) {
            if (best[i] < 0 || !Float.isFinite(bestScores[i])) continue;
            probabilities[i] = Math.exp((bestScores[i] - max) / Math.max(0.15f, temperature));
            total += probabilities[i];
        }
        if (total <= 0.0) return ByteTokenizer.EOS;
        double choice = random.nextDouble() * total;
        for (int i = 0; i < topK; i++) {
            choice -= probabilities[i];
            if (choice <= 0 && best[i] >= 0) return best[i];
        }
        return best[0] >= 0 ? best[0] : ByteTokenizer.EOS;
    }

    private static int generationLimit(String effort) {
        if ("Hızlı".equalsIgnoreCase(effort)) return 128;
        if ("Maksimum".equalsIgnoreCase(effort)) return 512;
        if ("Derin".equalsIgnoreCase(effort)) return MAX_NEW_TOKENS;
        return 256;
    }

    private static float temperature(String effort) {
        if ("Hızlı".equalsIgnoreCase(effort)) return 0.75f;
        if ("Maksimum".equalsIgnoreCase(effort)) return 0.68f;
        if ("Derin".equalsIgnoreCase(effort)) return 0.62f;
        return 0.72f;
    }

    private void validateConfig(File file) throws Exception {
        if (!file.isFile() || file.length() > MAX_CONFIG_BYTES) throw new IOException("model_config.json boyutu geçersiz.");
        byte[] bytes;
        try (FileInputStream input = new FileInputStream(file)) {
            bytes = readBounded(input, MAX_CONFIG_BYTES);
        }
        JSONObject config = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
        if (!"jai-gru-byte-v1".equals(config.optString("schema"))) throw new IOException("Model şeması ja.i-gru-byte-v1 olmalı.");
        if (config.optInt("vocab_size", -1) != ByteTokenizer.VOCAB_SIZE
                || config.optInt("pad_id", -1) != ByteTokenizer.PAD
                || config.optInt("bos_id", -1) != ByteTokenizer.BOS
                || config.optInt("user_id", -1) != ByteTokenizer.USER
                || config.optInt("assistant_id", -1) != ByteTokenizer.ASSISTANT
                || config.optInt("eos_id", -1) != ByteTokenizer.EOS
                || config.optInt("system_id", -1) != ByteTokenizer.SYSTEM) {
            throw new IOException("Tokenizer ayarları uygulamayla uyuşmuyor.");
        }
        int loadedHidden = config.optInt("hidden_size", 256);
        int loadedLayers = config.optInt("num_layers", 2);
        int loadedContext = config.optInt("max_context_tokens", 512);
        if (loadedHidden < MIN_HIDDEN || loadedHidden > MAX_HIDDEN || loadedLayers < MIN_LAYERS
                || loadedLayers > MAX_LAYERS || loadedContext < 64 || loadedContext > 2048) {
            throw new IOException("Model boyutları telefon güvenlik sınırlarının dışında.");
        }
        hiddenSize = loadedHidden;
        layerCount = loadedLayers;
        maxContextTokens = loadedContext;
    }

    private static long copyBounded(InputStream input, File target, long limit) throws IOException {
        long total = 0;
        byte[] buffer = new byte[16 * 1024];
        try (FileOutputStream output = new FileOutputStream(target)) {
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > limit) throw new IOException("Model paketindeki dosya boyut sınırını aşıyor.");
                output.write(buffer, 0, read);
            }
            output.flush();
        }
        return total;
    }

    private static byte[] readBounded(InputStream input, long limit) throws IOException {
        java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int read;
        while ((read = input.read(buffer)) != -1) {
            if (output.size() + read > limit) throw new IOException("Dosya boyutu sınırı aşıldı.");
            output.write(buffer, 0, read);
        }
        return output.toByteArray();
    }

    private static void deleteTree(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteTree(child);
        }
        file.delete();
    }

    private void closeSession() {
        if (session != null) {
            try { session.close(); } catch (Exception ignored) { }
            session = null;
        }
        if (sessionOptions != null) {
            try { sessionOptions.close(); } catch (Exception ignored) { }
            sessionOptions = null;
        }
    }

    private static String safeMessage(Throwable error) {
        String message = error == null ? "bilinmeyen hata" : error.getMessage();
        return message == null || message.trim().isEmpty() ? error.getClass().getSimpleName() : message;
    }

    @Override
    public synchronized void close() {
        closeSession();
    }

    private static final class Step {
        final float[] logits;
        final float[][][] hidden;
        Step(float[] logits, float[][][] hidden) { this.logits = logits; this.hidden = hidden; }
    }
}
