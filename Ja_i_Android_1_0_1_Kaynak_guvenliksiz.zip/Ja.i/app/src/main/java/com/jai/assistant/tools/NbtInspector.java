package com.jai.assistant.tools;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;

/** Minecraft NBT (Java big-endian / Bedrock little-endian) yapısını metin raporuna dönüştürür. */
public final class NbtInspector {
    private static final int MAX_DEPTH = 64;
    private static final int MAX_NODES = 1_000_000;
    private static final int MAX_ARRAY_ELEMENTS = 1_000_000;

    private static final class Reader {
        final ByteBuffer data;
        final boolean littleEndian;
        int nodes;
        final int maxOutputChars = ResourceAwareBudget.currentSafeTextCharacters();
        final StringBuilder out = new StringBuilder();
        Reader(byte[] bytes, boolean littleEndian) {
            data = ByteBuffer.wrap(bytes).order(littleEndian ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN);
            this.littleEndian = littleEndian;
        }
        int u8() throws IOException { require(1); return data.get() & 0xff; }
        short i16() throws IOException { require(2); return data.getShort(); }
        int u16() throws IOException { return i16() & 0xffff; }
        int i32() throws IOException { require(4); return data.getInt(); }
        long i64() throws IOException { require(8); return data.getLong(); }
        float f32() throws IOException { require(4); return data.getFloat(); }
        double f64() throws IOException { require(8); return data.getDouble(); }
        byte[] bytes(int length) throws IOException {
            if (length < 0 || length > data.remaining()) throw new IOException("NBT alan uzunluğu geçersiz.");
            byte[] result = new byte[length]; data.get(result); return result;
        }
        String string() throws IOException {
            int length = u16();
            return new String(bytes(length), StandardCharsets.UTF_8);
        }
        void require(int length) throws IOException {
            if (data.remaining() < length) throw new EOFException("NBT dosyası beklenenden erken bitti.");
        }
    }

    public String inspect(byte[] raw, boolean littleEndian) throws IOException {
        if (raw == null || raw.length == 0) throw new IOException("NBT verisi boş.");
        byte[] bytes = decompressIfNeeded(raw);
        Reader reader = new Reader(bytes, littleEndian);
        int rootType = reader.u8();
        if (rootType == 0 || rootType > 12) throw new IOException("NBT kök etiketi tanınmıyor.");
        String rootName = reader.string();
        reader.out.append("Minecraft NBT\nByte sırası: ").append(littleEndian ? "Little-endian (Bedrock)" : "Big-endian (Java)")
                .append("\nKök etiket: ").append(rootName).append(" (tip ").append(rootType).append(")\n");
        readPayload(reader, rootType, rootName, 0);
        if (reader.data.hasRemaining()) reader.out.append("\n[Okunan yapıdan sonra ").append(reader.data.remaining()).append(" ek bayt var.]");
        return reader.out.toString();
    }

    private byte[] decompressIfNeeded(byte[] raw) throws IOException {
        if (raw.length >= 2 && (raw[0] & 0xff) == 0x1f && (raw[1] & 0xff) == 0x8b) {
            try (GZIPInputStream gzip = new GZIPInputStream(new ByteArrayInputStream(raw))) { return readLimited(gzip); }
        }
        if (raw.length >= 2 && (raw[0] & 0xff) == 0x78) {
            try (InflaterInputStream inflater = new InflaterInputStream(new ByteArrayInputStream(raw))) {
                return readLimited(inflater);
            } catch (IOException ignored) { return raw; }
        }
        return raw;
    }

    private byte[] readLimited(java.io.InputStream input) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192]; int count;
        long maxArrayBytes = ResourceAwareBudget.currentSafeArrayBytes();
        while ((count = input.read(buffer)) != -1) {
            if ((long) out.size() + count > maxArrayBytes) {
                throw new IOException("Sıkıştırılmış NBT içeriği sabit 64 MiB kotasına değil, telefonun o anki boş uygulama belleği bütçesine takıldı.");
            }
            out.write(buffer, 0, count);
        }
        return out.toByteArray();
    }

    private void readPayload(Reader r, int type, String name, int depth) throws IOException {
        if (depth > MAX_DEPTH) throw new IOException("NBT iç içe yapı derinliği çok büyük.");
        if (++r.nodes > MAX_NODES) throw new IOException("NBT etiket sayısı güvenli inceleme sınırını aşıyor.");
        indent(r.out, depth).append(name).append(" = ");
        switch (type) {
            case 1: r.out.append((byte) r.u8()); break;
            case 2: r.out.append(r.i16()); break;
            case 3: r.out.append(r.i32()); break;
            case 4: r.out.append(r.i64()); break;
            case 5: r.out.append(r.f32()); break;
            case 6: r.out.append(r.f64()); break;
            case 7: {
                int length = checkedLength(r.i32(), r);
                byte[] bytes = r.bytes(length);
                r.out.append("ByteArray[ ").append(length).append(" ]");
                String text = printable(bytes);
                if (!text.isEmpty()) r.out.append(" · okunabilir: ").append(text);
                break;
            }
            case 8: r.out.append('"').append(r.string()).append('"'); break;
            case 9: {
                int childType = r.u8();
                int length = checkedLength(r.i32(), r);
                r.out.append("List<tag=").append(childType).append(")[ ").append(length).append(" ]\n");
                for (int i = 0; i < length; i++) {
                    if (childType == 0) break;
                    readPayload(r, childType, "[" + i + "]", depth + 1);
                    if (r.out.length() >= r.maxOutputChars) break;
                }
                return;
            }
            case 10: {
                r.out.append("Compound {\n");
                while (true) {
                    int childType = r.u8();
                    if (childType == 0) break;
                    if (childType > 12) throw new IOException("NBT içinde bilinmeyen etiket tipi: " + childType);
                    String childName = r.string();
                    readPayload(r, childType, childName, depth + 1);
                    if (r.out.length() >= r.maxOutputChars) break;
                }
                indent(r.out, depth).append("}\n");
                return;
            }
            case 11: {
                int length = checkedLength(r.i32(), r);
                r.out.append("IntArray[ ").append(length).append(" ] [");
                int shown = Math.min(length, 256);
                for (int i = 0; i < length; i++) {
                    int value = r.i32();
                    if (i < shown) { if (i > 0) r.out.append(", "); r.out.append(value); }
                }
                if (length > shown) r.out.append(", … ").append(length - shown).append(" değer daha");
                r.out.append(']');
                break;
            }
            case 12: {
                int length = checkedLength(r.i32(), r);
                r.out.append("LongArray[ ").append(length).append(" ] [");
                int shown = Math.min(length, 256);
                for (int i = 0; i < length; i++) {
                    long value = r.i64();
                    if (i < shown) { if (i > 0) r.out.append(", "); r.out.append(value); }
                }
                if (length > shown) r.out.append(", … ").append(length - shown).append(" değer daha");
                r.out.append(']');
                break;
            }
            default: throw new IOException("NBT etiket tipi desteklenmiyor: " + type);
        }
        r.out.append('\n');
        if (r.out.length() > r.maxOutputChars) throw new IOException("NBT metin çıktısı telefonun o anki boş uygulama belleği bütçesini aşıyor.");
    }

    private int checkedLength(int length, Reader reader) throws IOException {
        if (length < 0 || length > MAX_ARRAY_ELEMENTS) throw new IOException("NBT dizi uzunluğu geçersiz.");
        return length;
    }

    private StringBuilder indent(StringBuilder out, int depth) {
        for (int i = 0; i < depth; i++) out.append("  ");
        return out;
    }

    private String printable(byte[] bytes) {
        StringBuilder out = new StringBuilder();
        for (byte value : bytes) {
            int b = value & 0xff;
            if (b >= 32 && b <= 126) out.append((char) b);
            else if (b == 10 || b == 13) out.append(' ');
            if (out.length() >= 160) break;
        }
        return out.toString().trim();
    }
}
