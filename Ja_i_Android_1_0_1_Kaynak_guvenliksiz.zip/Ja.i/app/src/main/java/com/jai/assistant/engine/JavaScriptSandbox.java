package com.jai.assistant.engine;

import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextAction;
import org.mozilla.javascript.ContextFactory;
import org.mozilla.javascript.EvaluatorException;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;


/**
 * Çevrimdışı JavaScript çalıştırıcısı. Java/Android nesnelerini betiğe açmaz,
 * talimat sayısı ve metin boyutu sınırlar. İşlemler ana UI iş parçacığında çalıştırılmamalıdır.
 */
public final class JavaScriptSandbox {
    private static final int MAX_SOURCE_CHARS = 80_000;
    private static final int MAX_OUTPUT_CHARS = 12_000;
    private static final int INSTRUCTION_OBSERVER_THRESHOLD = 10_000;
    private static final long DEFAULT_TIMEOUT_MS = 1500L;

    private final ThreadLocal<Long> deadlineNanos = new ThreadLocal<>();
    private final ThreadLocal<StringBuilder> output = new ThreadLocal<>();
    private final ContextFactory factory = new ContextFactory() {
        @Override
        protected Context makeContext() {
            Context context = super.makeContext();
            context.setOptimizationLevel(-1);
            context.setLanguageVersion(Context.VERSION_ES6);
            context.setInstructionObserverThreshold(INSTRUCTION_OBSERVER_THRESHOLD);
            context.setClassShutter(className -> false);
            context.setMaximumInterpreterStackDepth(256);
            return context;
        }

        @Override
        protected void observeInstructionCount(Context context, int instructionCount) {
            Long deadline = deadlineNanos.get();
            if (deadline != null && System.nanoTime() > deadline) {
                throw new EvaluatorException("Çalıştırma süresi aşıldı; betik durduruldu.");
            }
        }
    };

    public String execute(String source) {
        return execute(source, DEFAULT_TIMEOUT_MS);
    }

    public String execute(String source, long timeoutMs) {
        if (source == null || source.trim().isEmpty()) return "Çalıştırılacak JavaScript boş.";
        if (source.length() > MAX_SOURCE_CHARS) return "Kod 80.000 karakter sınırını aşıyor.";
        long safeTimeout = Math.max(100L, Math.min(timeoutMs, 5000L));
        StringBuilder log = new StringBuilder();
        output.set(log);
        deadlineNanos.set(System.nanoTime() + safeTimeout * 1_000_000L);
        try {
            Object result = factory.call((ContextAction<Object>) context -> {
                Scriptable scope = context.initSafeStandardObjects(null, false);
                installPrint(scope, log);
                Object value = context.evaluateString(scope, source, "Ja.i-KodLab", 1, null);
                if (value != null && value != Context.getUndefinedValue() && !"undefined".equals(Context.toString(value))) {
                    appendOutput(log, "Sonuç: " + Context.toString(value));
                }
                return value;
            });
            if (log.length() == 0) return "JavaScript çalıştı; yazdırılacak çıktı üretmedi.";
            return log.toString();
        } catch (Exception exception) {
            String message = exception.getMessage();
            return "JavaScript çalıştırma hatası: " + (message == null ? exception.getClass().getSimpleName() : message);
        } finally {
            deadlineNanos.remove();
            output.remove();
        }
    }

    private void installPrint(Scriptable scope, StringBuilder log) {
        BaseFunction printer = new BaseFunction() {
            @Override
            public Object call(Context context, Scriptable scope, Scriptable thisObj, Object[] args) {
                StringBuilder line = new StringBuilder();
                for (int i = 0; i < args.length; i++) {
                    if (i > 0) line.append(' ');
                    line.append(Context.toString(args[i]));
                }
                appendOutput(log, line.toString());
                return Context.getUndefinedValue();
            }
        };
        ScriptableObject.putProperty(scope, "print", printer);
        Scriptable obj = Context.getCurrentContext().newObject(scope);
        ScriptableObject.putProperty(obj, "log", printer);
        ScriptableObject.putProperty(scope, "console", obj);
    }

    private void appendOutput(StringBuilder target, String line) {
        if (target.length() >= MAX_OUTPUT_CHARS) return;
        if (target.length() > 0) target.append('\n');
        int remaining = MAX_OUTPUT_CHARS - target.length();
        target.append(line, 0, Math.min(line.length(), remaining));
    }
}
