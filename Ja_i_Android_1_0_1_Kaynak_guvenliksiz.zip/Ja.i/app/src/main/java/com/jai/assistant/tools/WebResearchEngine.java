package com.jai.assistant.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Haricî AI servisi kullanmadan, kaynak çeşitliliği ve yeni bilgiye göre genişleyen web araştırması. */
public final class WebResearchEngine {
    private static final String SEARCH_ENDPOINT = "https://html.duckduckgo.com/html/";
    private static final int MAX_SEARCH_CHARS = 1_200_000;
    private static final int MAX_PAGE_CHARS = 650_000;
    private static final int MAX_EXCERPT_CHARS = 8_000;
    private static final int MAX_QUERY_CHARS = 400;
    private static final int MAX_SEARCH_REDIRECTS = 0;
    private static final String USER_AGENT = "JaI-Android-Research/0.9 (user-enabled web research)";

    private static final class SearchResult {
        final String title;
        final String link;
        final String snippet;
        final int start;
        final int end;
        SearchResult(String title, String link, String snippet, int start, int end) {
            this.title = title; this.link = link; this.snippet = snippet; this.start = start; this.end = end;
        }
    }

    private static final class HtmlFragment {
        final int start; final int end; final String text;
        HtmlFragment(int start, int end, String text) { this.start = start; this.end = end; this.text = text; }
    }

    private static final class PageContent {
        final String title; final String excerpt; final String publishedDate;
        PageContent(String title, String excerpt, String publishedDate) {
            this.title = title; this.excerpt = excerpt; this.publishedDate = publishedDate;
        }
    }

    private static final class SearchPage {
        final List<SearchResult> results;
        final boolean completed;
        final String note;
        final String vqd;
        SearchPage(List<SearchResult> results, boolean completed, String note, String vqd) {
            this.results = results; this.completed = completed; this.note = note; this.vqd = vqd == null ? "" : vqd;
        }
    }

    /** Geriye dönük uyumluluk: tek sorgunun istenen sayıda ilk kaynağını okur. */
    public String research(String query, int maxResults) {
        return researchDetailed(query, maxResults).toDisplayText();
    }

    public ResearchReport researchDetailed(String query, int maxResults) {
        String cleanQuery = cleanQuery(query);
        long now = System.currentTimeMillis();
        if (cleanQuery.isEmpty()) return new ResearchReport("", now, false, new ArrayList<>(),
                "Sorgu boş olduğu için ağ isteği gönderilmedi.");
        SearchPage page = searchPage(cleanQuery, 1, "");
        if (!page.completed) return new ResearchReport(cleanQuery, now, false, new ArrayList<>(), page.note);
        List<ResearchSource> sources = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        int wanted = Math.max(1, maxResults);
        for (SearchResult result : page.results) {
            if (sources.size() >= wanted) break;
            if (!seen.add(normalizeUrl(result.link))) continue;
            PageContent content = fetchPage(result.link);
            String title = content != null && !content.title.isEmpty() ? content.title : result.title;
            String excerpt = content != null && !content.excerpt.isEmpty() ? content.excerpt : result.snippet;
            if (excerpt.isEmpty()) continue;
            sources.add(new ResearchSource(title, result.link, domainOf(result.link), excerpt,
                    content != null, content == null ? "" : content.publishedDate));
        }
        return new ResearchReport(cleanQuery, now, true, sources, page.note);
    }

    /**
     * Sabit 5/6 arama sayısı yoktur. Yeni kaynaklar yeni alt sorgular üretir; arama motoru yeni
     * sonuç vermeyi bıraktığında ve kuyruk tükendiğinde araştırma doğal olarak sonlanır.
     * Her arama sayfasının ve kaynağın bağlantı/zaman aşımı sınırları Android'i korur.
     */
    public ResearchReport researchAdaptive(String query, String effort) {
        String cleanQuery = cleanQuery(query);
        long startedAt = System.currentTimeMillis();
        if (cleanQuery.isEmpty()) return new ResearchReport("", startedAt, false, new ArrayList<>(),
                "Sorgu boş olduğu için ağ isteği gönderilmedi.");

        Deque<String> pending = new ArrayDeque<>();
        Set<String> queuedOrSearched = new LinkedHashSet<>();
        Set<String> visitedUrls = new HashSet<>();
        Map<String, ResearchSource> collected = new LinkedHashMap<>();
        List<String> notes = new ArrayList<>();

        enqueue(cleanQuery, pending, queuedOrSearched);
        String level = effort == null ? "Orta" : effort.trim().toLowerCase(Locale.ROOT);
        enqueue(cleanQuery + " resmi kaynak dokümantasyon", pending, queuedOrSearched);
        if (!"hızlı".equals(level) && !"hizli".equals(level)) {
            enqueue(cleanQuery + " teknik ayrıntılar", pending, queuedOrSearched);
            enqueue(cleanQuery + " sorunlar çözümler", pending, queuedOrSearched);
        }
        if ("maksimum".equals(level) || "derin".equals(level)) {
            enqueue(cleanQuery + " güncel sürümler standartlar", pending, queuedOrSearched);
            enqueue(cleanQuery + " bağımsız kaynak karşılaştırma", pending, queuedOrSearched);
        }
        if ("derin".equals(level)) {
            enqueue(cleanQuery + " araştırma makaleleri birincil kaynaklar", pending, queuedOrSearched);
            enqueue(cleanQuery + " alternatif açıklamalar sınırlamalar", pending, queuedOrSearched);
        }

        int searchCalls = 0;
        int pagesRead = 0;
        int pageFetchAttempts = 0;
        int stagnantRounds = 0;
        boolean anySearchCompleted = false;
        int maxSearchCalls = researchSearchBudget(level);
        int maxPageFetches = researchPageBudget(level);
        long deadline = startedAt + researchTimeBudgetMillis(level);
        while (!pending.isEmpty() && searchCalls < maxSearchCalls
                && pageFetchAttempts < maxPageFetches && System.currentTimeMillis() < deadline) {
            String currentQuery = pending.removeFirst();
            int before = collected.size();
            SearchPage firstPage = searchPage(currentQuery, 1, "");
            searchCalls++;
            if (!firstPage.completed) {
                notes.add(currentQuery + ": " + firstPage.note);
                continue;
            }
            anySearchCompleted = true;

            int pageNumber = 1;
            String vqd = firstPage.vqd;
            SearchPage currentPage = firstPage;
            Set<String> pageSeen = new HashSet<>();
            while (currentPage.completed && !currentPage.results.isEmpty()) {
                int freshOnPage = 0;
                for (SearchResult result : currentPage.results) {
                    if (pageSeen.add(normalizeUrl(result.link))) freshOnPage++;
                }
                if (freshOnPage == 0) break;
                for (SearchResult result : currentPage.results) {
                    if (pageFetchAttempts >= maxPageFetches || System.currentTimeMillis() >= deadline) break;
                    String normalizedUrl = normalizeUrl(result.link);
                    if (!visitedUrls.add(normalizedUrl)) continue;
                    pageFetchAttempts++;
                    PageContent content = fetchPage(result.link);
                    String title = content != null && !content.title.isEmpty() ? content.title : result.title;
                    String excerpt = content != null && !content.excerpt.isEmpty() ? content.excerpt : result.snippet;
                    if (excerpt.isEmpty()) continue;
                    String publishedDate = content == null ? "" : content.publishedDate;
                    ResearchSource source = new ResearchSource(title, result.link, domainOf(result.link),
                            excerpt, content != null, publishedDate);
                    collected.put(normalizedUrl, source);
                    if (content != null) pagesRead++;
                    String followUp = buildFollowUpQuery(cleanQuery, source, level);
                    if (!followUp.isEmpty()) enqueue(followUp, pending, queuedOrSearched);
                }

                // DuckDuckGo sayfalaması: sonraki sayfa ancak yeni URL içeren sonuçlardan sonra denenir.
                if (searchCalls >= maxSearchCalls || pageFetchAttempts >= maxPageFetches
                        || System.currentTimeMillis() >= deadline) break;
                pageNumber++;
                SearchPage next = searchPage(currentQuery, pageNumber, vqd);
                searchCalls++;
                if (!next.completed || next.results.isEmpty()) break;
                if (!next.vqd.isEmpty()) vqd = next.vqd;
                boolean hasNew = false;
                for (SearchResult result : next.results) {
                    if (!pageSeen.contains(normalizeUrl(result.link))) { hasNew = true; break; }
                }
                if (!hasNew) break;
                currentPage = next;
            }

            if (collected.size() == before) stagnantRounds++;
            else stagnantRounds = 0;
            // Kuyruk yeni kaynağın başlık/içeriğinden üretildiği için yeni sonuç kalmayınca doğal durur.
            if (stagnantRounds >= 2) {
                pending.clear();
                notes.add("Ardışık sorgular yeni kaynak üretmedi; tekrar aramalar durduruldu.");
            }
        }

        List<ResearchSource> sources = new ArrayList<>(collected.values());
        boolean budgetReached = !pending.isEmpty() && (searchCalls >= maxSearchCalls
                || pageFetchAttempts >= maxPageFetches || System.currentTimeMillis() >= deadline);
        String note = "Akıllı araştırma tamamlandı: " + searchCalls + " arama isteği, "
                + sources.size() + " benzersiz kaynak, " + pagesRead + " okunabilen sayfa. "
                + "Araştırma eforuna göre belirlenen telefon/ağ bütçesi kullanıldı.";
        if (budgetReached) note += " Efor bütçesi dolduğu için takip kuyruğu durduruldu; mevcut kaynaklar yine yanıta aktarılır.";
        if (!notes.isEmpty()) note += " Ayrıntılar: " + joinNotes(notes, 4);
        if (sources.isEmpty() && !anySearchCompleted) note = "Arama servisinden kullanılabilir sonuç alınamadı. " + note;
        return new ResearchReport(cleanQuery, startedAt, anySearchCompleted, sources, note);
    }

    private int researchSearchBudget(String level) {
        if ("derin".equals(level)) return 16;
        if ("maksimum".equals(level)) return 12;
        if ("hızlı".equals(level) || "hizli".equals(level)) return 4;
        return 7;
    }

    private int researchPageBudget(String level) {
        if ("derin".equals(level)) return 32;
        if ("maksimum".equals(level)) return 24;
        if ("hızlı".equals(level) || "hizli".equals(level)) return 8;
        return 14;
    }

    private long researchTimeBudgetMillis(String level) {
        if ("derin".equals(level)) return 180_000L;
        if ("maksimum".equals(level)) return 150_000L;
        if ("hızlı".equals(level) || "hizli".equals(level)) return 60_000L;
        return 90_000L;
    }

    private String cleanQuery(String query) {
        String cleaned = query == null ? "" : query.trim().replaceAll("\\s+", " ");
        return cleaned.length() > MAX_QUERY_CHARS ? cleaned.substring(0, MAX_QUERY_CHARS) : cleaned;
    }

    private void enqueue(String query, Deque<String> pending, Set<String> seen) {
        String cleaned = cleanQuery(query);
        String key = cleaned.toLowerCase(Locale.ROOT);
        if (cleaned.length() >= 5 && seen.add(key)) pending.addLast(cleaned);
    }

    private String buildFollowUpQuery(String original, ResearchSource source, String effort) {
        String title = (source.title == null ? "" : source.title) + " "
                + ("derin".equals(effort) || "maksimum".equals(effort) ? source.excerpt : "");
        String[] words = title.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N} ]", " ").split("\\s+");
        Set<String> selected = new LinkedHashSet<>();
        Set<String> stop = new HashSet<>();
        String stopWords = "ve veya ile için hakkında nedir nasıl olan olarak the and for with from what how guide official documentation introduction overview";
        for (String word : stopWords.split(" ")) stop.add(word);
        for (String word : words) {
            if (word.length() < 4 || stop.contains(word) || original.toLowerCase(Locale.ROOT).contains(word)) continue;
            selected.add(word);
            if (selected.size() >= 3) break;
        }
        if (selected.isEmpty()) return "";
        StringBuilder query = new StringBuilder();
        for (String word : selected) {
            if (query.length() > 0) query.append(' ');
            query.append(word);
        }
        query.append(" ").append(original);
        return cleanQuery(query.toString());
    }

    private String buildInitialSearchUrl(String encodedQuery) {
        return SEARCH_ENDPOINT + "?q=" + encodedQuery + "&kl=tr-tr";
    }

    private SearchPage searchPage(String query, int pageNumber, String vqd) {
        HttpURLConnection connection = null;
        try {
            if (query == null || query.length() >= 500) {
                return new SearchPage(new ArrayList<>(), false, "DuckDuckGo sorgu uzunluğu 499 karakter sınırını aşıyor.", "");
            }
            String encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.name());
            boolean nextPage = pageNumber > 1;
            String endpoint = nextPage ? SEARCH_ENDPOINT : buildInitialSearchUrl(encoded);
            URL url = URI.create(endpoint).toURL();
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(10_000);
            connection.setReadTimeout(15_000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("User-Agent", USER_AGENT);
            connection.setRequestProperty("Accept", "text/html,application/xhtml+xml");
            connection.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.6");
            connection.setRequestProperty("Referer", "https://html.duckduckgo.com/");
            connection.setRequestProperty("Sec-Fetch-Dest", "document");
            connection.setRequestProperty("Sec-Fetch-Mode", "navigate");
            connection.setRequestProperty("Sec-Fetch-Site", "same-origin");
            connection.setRequestProperty("Sec-Fetch-User", "?1");

            if (nextPage) {
                if (vqd == null || vqd.trim().isEmpty()) {
                    return new SearchPage(new ArrayList<>(), false,
                            "DuckDuckGo sonraki sayfa için gerekli vqd belirtecini vermedi; engel/captcha tetiklememek için sayfalama denenmedi.", "");
                }
                int offset = pageNumber == 2 ? 10 : 10 + (pageNumber - 2) * 15;
                String form = "q=" + encoded
                        + "&vqd=" + URLEncoder.encode(vqd, StandardCharsets.UTF_8.name())
                        + "&nextParams=&api=d.js&o=json&v=l&dc=" + (offset + 1)
                        + "&s=" + offset + "&kl=tr-tr";
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                connection.setRequestProperty("Origin", "https://html.duckduckgo.com");
                connection.setRequestProperty("Referer", "https://html.duckduckgo.com/html/");
                try (java.io.OutputStream output = connection.getOutputStream()) {
                    output.write(form.getBytes(StandardCharsets.UTF_8));
                    output.flush();
                }
            } else {
                connection.setRequestMethod("GET");
            }

            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) {
                return new SearchPage(new ArrayList<>(), false, "Arama servisi HTTP " + status + " yanıtı verdi.", "");
            }
            String html;
            try (InputStream stream = connection.getInputStream()) { html = readLimited(stream, MAX_SEARCH_CHARS); }
            String pageVqd = extractVqd(html);
            return new SearchPage(parseResults(html), true, "Arama sayfası okundu.", pageVqd);
        } catch (Exception exception) {
            return new SearchPage(new ArrayList<>(), false, "Arama isteği başarısız: " + safeMessage(exception), "");
        } finally { if (connection != null) connection.disconnect(); }
    }

    private String extractVqd(String html) {
        String[] patterns = {
                "(?is)<input\\b[^>]*name\\s*=\\s*['\"]vqd['\"][^>]*value\\s*=\\s*['\"]([^'\"]+)['\"]",
                "(?is)<input\\b[^>]*value\\s*=\\s*['\"]([^'\"]+)['\"][^>]*name\\s*=\\s*['\"]vqd['\"]"
        };
        for (String expression : patterns) {
            Matcher matcher = Pattern.compile(expression).matcher(html);
            if (matcher.find()) return matcher.group(1).trim();
        }
        return "";
    }

    private PageContent fetchPage(String link) {
        HttpURLConnection connection = null;
        try {
            if (!isSafeExternalHttpsUrl(link)) return null;
            URL url = URI.create(link).toURL();
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(8_000);
            connection.setReadTimeout(12_000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("User-Agent", USER_AGENT);
            connection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json,text/plain;q=0.8");
            connection.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.6");
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) return null;
            String contentType = connection.getContentType();
            if (contentType != null && !(contentType.toLowerCase(Locale.ROOT).contains("text/html")
                    || contentType.toLowerCase(Locale.ROOT).contains("application/xhtml+xml")
                    || contentType.toLowerCase(Locale.ROOT).contains("text/plain")
                    || contentType.toLowerCase(Locale.ROOT).contains("application/json"))) return null;
            String body;
            try (InputStream stream = connection.getInputStream()) { body = readLimited(stream, MAX_PAGE_CHARS); }
            String title = extractTitle(body);
            String date = extractPublishedDate(body);
            String readable = extractReadableText(body);
            if (readable.length() > MAX_EXCERPT_CHARS) readable = readable.substring(0, MAX_EXCERPT_CHARS).trim() + "…";
            if (readable.isEmpty()) return null;
            return new PageContent(title, readable, date);
        } catch (Exception ignored) { return null; }
        finally { if (connection != null) connection.disconnect(); }
    }

    private String readLimited(InputStream stream, int maxChars) throws IOException {
        StringBuilder builder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                if (builder.length() + read > maxChars) throw new IOException("Web yanıtı güvenli boyut sınırını aşıyor.");
                builder.append(buffer, 0, read);
            }
        }
        return builder.toString();
    }

    private List<SearchResult> parseResults(String html) {
        List<HtmlFragment> anchors = new ArrayList<>();
        List<HtmlFragment> snippets = new ArrayList<>();
        Pattern anchorPattern = Pattern.compile("(?is)<a\\b([^>]*)>(.*?)</a>");
        Pattern classPattern = Pattern.compile("(?is)class\\s*=\\s*['\"]([^'\"]*)['\"]");
        Pattern hrefPattern = Pattern.compile("(?is)href\\s*=\\s*['\"]([^'\"]+)['\"]");
        Matcher anchorMatcher = anchorPattern.matcher(html);
        while (anchorMatcher.find()) {
            Matcher classMatcher = classPattern.matcher(anchorMatcher.group(1));
            if (!classMatcher.find() || !classMatcher.group(1).contains("result__a")) continue;
            Matcher hrefMatcher = hrefPattern.matcher(anchorMatcher.group(1));
            if (!hrefMatcher.find()) continue;
            String title = cleanHtml(anchorMatcher.group(2));
            String link = unwrapLink(decodeHtml(hrefMatcher.group(1)));
            if (title.isEmpty() || !isSafeExternalHttpsUrl(link)) continue;
            anchors.add(new HtmlFragment(anchorMatcher.start(), anchorMatcher.end(), title + "\n" + link));
        }
        Pattern snippetPattern = Pattern.compile("(?is)<(?:a|div|td)\\b([^>]*)>(.*?)</(?:a|div|td)>");
        Matcher snippetMatcher = snippetPattern.matcher(html);
        while (snippetMatcher.find()) {
            Matcher classMatcher = classPattern.matcher(snippetMatcher.group(1));
            if (!classMatcher.find() || !classMatcher.group(1).contains("result__snippet")) continue;
            String snippet = cleanHtml(snippetMatcher.group(2));
            if (!snippet.isEmpty()) snippets.add(new HtmlFragment(snippetMatcher.start(), snippetMatcher.end(), snippet));
        }
        List<SearchResult> results = new ArrayList<>();
        for (int i = 0; i < anchors.size(); i++) {
            HtmlFragment anchor = anchors.get(i);
            int nextStart = i + 1 < anchors.size() ? anchors.get(i + 1).start : Integer.MAX_VALUE;
            String snippet = "";
            for (HtmlFragment candidate : snippets) if (candidate.start >= anchor.end && candidate.start < nextStart) { snippet = candidate.text; break; }
            String[] parts = anchor.text.split("\\n", 2);
            if (parts.length == 2) results.add(new SearchResult(parts[0], parts[1], snippet, anchor.start, anchor.end));
        }
        return results;
    }

    private boolean isSafeExternalHttpsUrl(String value) {
        if (value == null || value.length() > 2048) return false;
        try {
            URI uri = URI.create(value);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getUserInfo() != null) return false;
            String host = uri.getHost();
            if (host == null || host.isEmpty() || host.equalsIgnoreCase("localhost") || host.endsWith(".localhost")
                    || host.endsWith(".local") || host.endsWith(".internal")) return false;
            InetAddress address = InetAddress.getByName(host);
            return !address.isAnyLocalAddress() && !address.isLoopbackAddress()
                    && !address.isLinkLocalAddress() && !address.isSiteLocalAddress();
        } catch (Exception ignored) { return false; }
    }

    private String extractPublishedDate(String html) {
        String[] patterns = {
                "(?is)<meta[^>]+(?:property|name|itemprop)\\s*=\\s*['\"](?:article:published_time|datePublished|date|publish_date|pubdate)['\"][^>]+content\\s*=\\s*['\"]([^'\"]+)['\"]",
                "(?is)<meta[^>]+content\\s*=\\s*['\"]([^'\"]+)['\"][^>]+(?:property|name|itemprop)\\s*=\\s*['\"](?:article:published_time|datePublished|date|publish_date|pubdate)['\"]",
                "(?is)<time[^>]+datetime\\s*=\\s*['\"]([^'\"]+)['\"]"
        };
        for (String expression : patterns) {
            Matcher matcher = Pattern.compile(expression).matcher(html);
            if (matcher.find()) return cleanDate(matcher.group(1));
        }
        return "";
    }

    private String cleanDate(String value) {
        String date = decodeHtml(value == null ? "" : value).trim();
        return date.length() > 80 ? date.substring(0, 80) : date;
    }

    private String extractTitle(String html) {
        Matcher matcher = Pattern.compile("(?is)<title\\b[^>]*>(.*?)</title>").matcher(html);
        return matcher.find() ? cleanHtml(matcher.group(1)) : "";
    }

    private String extractReadableText(String html) {
        String reduced = html.replaceAll("(?is)<(script|style|noscript|svg|nav|footer|header|aside|form)\\b[^>]*>.*?</\\1>", " ")
                .replaceAll("(?is)<(script|style|noscript|svg|nav|footer|header|aside|form)\\b[^>]*/>", " ")
                .replaceAll("(?is)</(p|h1|h2|h3|h4|h5|li|article|section|div|tr)\\s*>", "\\n")
                .replaceAll("(?is)<br\\s*/?>", "\\n");
        return cleanHtml(reduced);
    }

    private String cleanHtml(String text) {
        String decoded = decodeHtml(text).replaceAll("(?is)<script[^>]*>.*?</script>", " ")
                .replaceAll("(?is)<style[^>]*>.*?</style>", " ").replaceAll("(?s)<[^>]+>", " ");
        return decoded.replaceAll("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F]", " ")
                .replaceAll("[ \\t]+", " ").replaceAll(" *\\n *", "\n").trim();
    }

    private String decodeHtml(String text) {
        return text.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
                .replace("&apos;", "'").replace("&lt;", "<").replace("&gt;", ">")
                .replace("&nbsp;", " ").replace("&mdash;", "—").replace("&ndash;", "–")
                .replace("&hellip;", "…").replace("&#x27;", "'");
    }

    private String unwrapLink(String link) {
        if (link == null) return "";
        try {
            URI uri = URI.create(link);
            String host = uri.getHost();
            if (host != null && host.toLowerCase(Locale.ROOT).contains("duckduckgo.com")
                    && uri.getPath() != null && uri.getPath().contains("/l/")) {
                String query = uri.getRawQuery();
                if (query != null) for (String item : query.split("&")) if (item.startsWith("uddg=")) {
                    return URLDecoder.decode(item.substring(5), StandardCharsets.UTF_8.name());
                }
            }
        } catch (Exception ignored) { }
        return link;
    }

    private String normalizeUrl(String value) {
        try {
            URI uri = URI.create(value).normalize();
            String path = uri.getPath() == null ? "" : uri.getPath().replaceAll("/$", "");
            return (uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT)) + path
                    + (uri.getQuery() == null ? "" : "?" + uri.getQuery());
        } catch (Exception ignored) { return value == null ? "" : value; }
    }

    private String domainOf(String value) {
        try { return URI.create(value).getHost(); } catch (Exception ignored) { return ""; }
    }

    private String joinNotes(List<String> notes, int max) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < notes.size() && i < max; i++) {
            if (i > 0) out.append(" | ");
            out.append(notes.get(i));
        }
        if (notes.size() > max) out.append(" | diğer ").append(notes.size() - max).append(" not");
        return out.toString();
    }

    private String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.trim().isEmpty() ? exception.getClass().getSimpleName() : message;
    }
}
