package com.jai.assistant.engine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Yerel video sahne planlayıcısı. Açık sahne tarifleri varsa onları korur;
 * yoksa bir istemden açılış, ayrıntı ve final kadrajları çıkarır.
 */
public final class VideoScenePlanner {
    private VideoScenePlanner() { }

    public static List<String> plan(String prompt, String researchContext) {
        String source = prompt == null ? "" : prompt.trim();
        String research = researchContext == null ? "" : researchContext.trim();
        if (research.length() > 2400) research = research.substring(0, 2400);

        List<String> explicit = new ArrayList<>();
        String[] lines = source.split("(?im)(?:\\R+|\\s*(?:sahne\\s*\\d+\\s*[:.-]|sonra[, ]+))");
        for (String line : lines) {
            String candidate = line.replaceAll("(?iu)\\b(?:video|mp4|olu[sş]tur|yap|hazirla|uret|1\\s*dakika|60\\s*saniye|720p)\\b", " ")
                    .replaceAll("\\s+", " ").trim();
            if (candidate.length() >= 5 && !explicit.contains(candidate)) explicit.add(candidate);
            if (explicit.size() == 4) break;
        }

        List<String> scenes = new ArrayList<>();
        if (explicit.size() >= 2) {
            for (String scene : explicit) scenes.add(scene + " sinematik sahne, net ana konu, katmanlı arka plan");
        } else {
            String subject = source.isEmpty() ? "Ja.i'nin oluşturduğu sahne" : source;
            scenes.add(subject + " geniş açı açılış planı, çevreyi ve ana konuyu göster");
            scenes.add(subject + " yakın plan ayrıntı planı, malzeme, doku ve küçük hareketleri vurgula");
            scenes.add(subject + " dinamik aksiyon planı, hareket ve perspektif değişimi");
            scenes.add(subject + " sinematik final planı, dengeli kompozisyon ve belirgin odak");
        }
        if (!research.isEmpty()) {
            String hint = research.replaceAll("\\s+", " ");
            if (hint.length() > 700) hint = hint.substring(0, 700);
            for (int i = 0; i < scenes.size(); i++) scenes.set(i, scenes.get(i) + ". Araştırılmış tasarım bilgisi: " + hint);
        }
        return Collections.unmodifiableList(scenes);
    }

}
