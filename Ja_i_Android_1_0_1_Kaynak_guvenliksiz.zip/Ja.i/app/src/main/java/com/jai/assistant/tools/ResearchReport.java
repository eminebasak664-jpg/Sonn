package com.jai.assistant.tools;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Araştırma çıktısı; arama, sayfa okuma ve doğrulama düzeylerini birbirinden ayırır. */
public final class ResearchReport {
    public final String query;
    public final long collectedAt;
    public final boolean searchCompleted;
    private final List<ResearchSource> sources;
    public final String note;

    public ResearchReport(String query, long collectedAt, boolean searchCompleted,
                          List<ResearchSource> sources, String note) {
        this.query = query == null ? "" : query.trim();
        this.collectedAt = collectedAt;
        this.searchCompleted = searchCompleted;
        this.sources = Collections.unmodifiableList(new ArrayList<>(sources == null
                ? Collections.emptyList() : sources));
        this.note = note == null ? "" : note.trim();
    }

    public List<ResearchSource> getSources() { return sources; }

    public int getReadPageCount() {
        int count = 0;
        for (ResearchSource source : sources) if (source.pageRead) count++;
        return count;
    }

    public int getDistinctDomainCount() {
        Set<String> domains = new LinkedHashSet<>();
        for (ResearchSource source : sources) if (!source.domain.isEmpty()) domains.add(source.domain);
        return domains.size();
    }

    public String toDisplayText() {
        StringBuilder out = new StringBuilder("Web araştırması raporu\n")
                .append("Sorgu: ").append(query).append("\n")
                .append("Toplanma zamanı: ").append(DateFormat.getDateTimeInstance(
                        DateFormat.MEDIUM, DateFormat.SHORT, Locale.forLanguageTag("tr-TR"))
                        .format(new Date(collectedAt))).append("\n")
                .append("Arama isteği: ").append(searchCompleted ? "başarılı yanıt aldı" : "tamamlanamadı").append("\n")
                .append("Okunabilen kaynak sayfası: ").append(getReadPageCount()).append(" / ")
                .append(sources.size()).append("\n")
                .append("Farklı alan adı: ").append(getDistinctDomainCount()).append("\n");
        if (sources.isEmpty()) {
            out.append("Okunabilir kaynak sonucu alınamadı. Bu, internette bilgi olmadığı anlamına gelmez.\n");
        }
        for (int i = 0; i < sources.size(); i++) {
            ResearchSource source = sources.get(i);
            out.append("\n").append(i + 1).append(". ").append(source.title).append("\n")
                    .append("Yayın tarihi: ").append(source.publishedDate.isEmpty() ? "sayfadan çıkarılamadı" : source.publishedDate).append("\n")
                    .append("Alan adı: ").append(source.domain.isEmpty() ? "belirlenemedi" : source.domain).append("\n")
                    .append("Sayfa durumu: ").append(source.pageRead ? "sayfa içeriği alındı" : "yalnızca arama sonucu özeti mevcut").append("\n");
            if (!source.excerpt.isEmpty()) out.append("Kısa içerik: ").append(source.excerpt).append("\n");
            out.append("Kaynak: ").append(source.url).append("\n");
        }
        out.append("\nDoğrulama notu: Sayfaların okunması, içerdikleri iddiaların doğru olduğunu kanıtlamaz. Bu sürüm kaynakları otomatik olarak uzman onaylı veya kesin doğrulanmış diye işaretlemez.");
        if (!note.isEmpty()) out.append("\nİşlem notu: ").append(note);
        return out.toString();
    }
}
