package com.jai.assistant.server;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.net.URI;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Sunucu adresini saklar; erişim anahtarını Android Keystore AES-GCM ile şifreler. */
public final class ServerSettingsManager {
    private static final String PREFS = "jai_server_settings";
    private static final String KEY_ALIAS = "jai_server_token_key_v1";
    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";
    private final SharedPreferences prefs;

    public ServerSettingsManager(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized void save(String baseUrl, String healthPath, String token) throws Exception {
        String normalized = normalizeBaseUrl(baseUrl);
        String path = normalizeHealthPath(healthPath);
        SharedPreferences.Editor editor = prefs.edit().putString("base_url", normalized).putString("health_path", path);
        if (token == null || token.trim().isEmpty()) {
            editor.remove("token_cipher").remove("token_iv");
        } else {
            byte[][] encrypted = encrypt(token.trim());
            editor.putString("token_cipher", Base64.encodeToString(encrypted[0], Base64.NO_WRAP));
            editor.putString("token_iv", Base64.encodeToString(encrypted[1], Base64.NO_WRAP));
        }
        if (!editor.commit()) throw new IllegalStateException("Sunucu ayarları kaydedilemedi.");
    }

    public synchronized ServerConfig get() throws Exception {
        String base = prefs.getString("base_url", "");
        String path = prefs.getString("health_path", "/health");
        String cipherText = prefs.getString("token_cipher", null);
        String ivText = prefs.getString("token_iv", null);
        String token = "";
        if (cipherText != null && ivText != null) {
            token = decrypt(Base64.decode(cipherText, Base64.NO_WRAP), Base64.decode(ivText, Base64.NO_WRAP));
        }
        return new ServerConfig(base, path, token);
    }

    public synchronized boolean isConfigured() {
        return !prefs.getString("base_url", "").trim().isEmpty();
    }

    public synchronized void clear() {
        prefs.edit().clear().commit();
    }

    public static String normalizeBaseUrl(String input) throws Exception {
        return ServerUrlRules.normalizeBaseUrl(input);
    }

    public static String normalizeHealthPath(String input) {
        return ServerUrlRules.normalizeHealthPath(input);
    }

    private byte[][] encrypt(String plainText) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        return new byte[][]{cipher.doFinal(plainText.getBytes("UTF-8")), cipher.getIV()};
    }

    private String decrypt(byte[] cipherText, byte[] iv) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(cipherText), "UTF-8");
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(ANDROID_KEYSTORE);
        keyStore.load(null);
        java.security.Key existing = keyStore.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE);
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }
}
