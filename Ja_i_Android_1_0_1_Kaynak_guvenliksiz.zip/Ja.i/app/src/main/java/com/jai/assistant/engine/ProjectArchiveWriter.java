package com.jai.assistant.engine;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Çok dosyalı yerel kod projelerini güvenli ZIP arşivine dönüştürür. */
public final class ProjectArchiveWriter {
    private static final int MAX_FILES = 64;
    private static final int MAX_TOTAL_UTF8_BYTES = 2 * 1024 * 1024;

    public byte[] createZip(Map<String, String> files) throws IOException {
        if (files == null || files.isEmpty()) throw new IOException("Arşivlenecek proje dosyası yok.");
        if (files.size() > MAX_FILES) throw new IOException("Proje 64 dosya sınırını aşıyor.");
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int total = 0;
        try (ZipOutputStream zip = new ZipOutputStream(buffer, StandardCharsets.UTF_8)) {
            for (Map.Entry<String, String> file : files.entrySet()) {
                String path = file.getKey();
                validatePath(path);
                byte[] contents = (file.getValue() == null ? "" : file.getValue()).getBytes(StandardCharsets.UTF_8);
                total += contents.length;
                if (total > MAX_TOTAL_UTF8_BYTES) throw new IOException("Proje kaynakları 2 MiB güvenli dışa aktarma sınırını aşıyor.");
                ZipEntry entry = new ZipEntry(path);
                entry.setTime(0L);
                zip.putNextEntry(entry);
                zip.write(contents);
                zip.closeEntry();
            }
        }
        return buffer.toByteArray();
    }

    /** PNG gibi ikili varlıkları da koruyarak güvenli ZIP tabanlı paket üretir. */
    public byte[] createZipBinary(Map<String, byte[]> files) throws IOException {
        if (files == null || files.isEmpty()) throw new IOException("Arşivlenecek paket dosyası yok.");
        if (files.size() > 128) throw new IOException("Paket 128 dosya sınırını aşıyor.");
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        long total = 0;
        try (ZipOutputStream zip = new ZipOutputStream(buffer, StandardCharsets.UTF_8)) {
            for (Map.Entry<String, byte[]> file : files.entrySet()) {
                String path = file.getKey();
                validatePath(path);
                byte[] contents = file.getValue() == null ? new byte[0] : file.getValue();
                total += contents.length;
                if (total > 16L * 1024L * 1024L) throw new IOException("Paket kaynakları 16 MiB dışa aktarma sınırını aşıyor.");
                ZipEntry entry = new ZipEntry(path);
                entry.setTime(0L);
                zip.putNextEntry(entry);
                zip.write(contents);
                zip.closeEntry();
            }
        }
        return buffer.toByteArray();
    }

    private void validatePath(String path) throws IOException {
        if (path == null || path.trim().isEmpty() || path.startsWith("/") || path.startsWith("\\")
                || path.contains("..") || path.indexOf('\\') >= 0 || path.matches("^[A-Za-z]:.*")) {
            throw new IOException("Güvensiz proje dosya yolu: " + path);
        }
        for (String part : path.split("/")) {
            if (part.isEmpty() || ".".equals(part)) throw new IOException("Geçersiz proje dosya yolu: " + path);
        }
    }
}
