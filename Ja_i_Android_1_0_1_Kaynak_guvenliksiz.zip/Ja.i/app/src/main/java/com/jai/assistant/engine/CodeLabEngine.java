package com.jai.assistant.engine;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.io.StringReader;
import javax.xml.parsers.DocumentBuilderFactory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/** Derleyici değildir: yorum ve dizgeleri atlayarak basit ayraç ön kontrolü yapar. */
public final class CodeLabEngine {
    public String analyze(String code, String language) {
        if (code == null || code.trim().isEmpty()) return "İncelenecek kod boş.";

        String lang = language == null ? "" : language.toLowerCase(Locale.ROOT);
        if (lang.contains("xml")) return analyzeXml(code);
        boolean pythonLike = lang.contains("python") || lang.contains("yaml") || lang.contains("shell");
        boolean xmlLike = lang.contains("html") || lang.contains("svg");
        Deque<Character> stack = new ArrayDeque<>();
        char quote = 0;
        boolean escaped = false;
        boolean tripleQuote = false;
        boolean lineComment = false;
        boolean blockComment = false;
        boolean xmlComment = false;
        int line = 1;

        for (int i = 0; i < code.length(); i++) {
            char c = code.charAt(i);
            char next = i + 1 < code.length() ? code.charAt(i + 1) : 0;
            char next2 = i + 2 < code.length() ? code.charAt(i + 2) : 0;

            if (c == '\n') line++;

            if (lineComment) {
                if (c == '\n') lineComment = false;
                continue;
            }
            if (blockComment) {
                if (c == '*' && next == '/') {
                    blockComment = false;
                    i++;
                }
                continue;
            }
            if (xmlComment) {
                if (c == '-' && next == '-' && next2 == '>') {
                    xmlComment = false;
                    i += 2;
                }
                continue;
            }

            if (quote != 0) {
                if (escaped) {
                    escaped = false;
                } else if (c == '\\') {
                    escaped = true;
                } else if (tripleQuote && c == quote && next == quote && next2 == quote) {
                    quote = 0;
                    tripleQuote = false;
                    i += 2;
                } else if (!tripleQuote && c == quote) {
                    quote = 0;
                }
                continue;
            }

            if (xmlLike && c == '<' && next == '!' && next2 == '-') {
                if (i + 3 < code.length() && code.charAt(i + 3) == '-') {
                    xmlComment = true;
                    i += 3;
                    continue;
                }
            }
            if (!pythonLike && !xmlLike && c == '/' && next == '/') {
                lineComment = true;
                i++;
                continue;
            }
            if (!pythonLike && !xmlLike && c == '/' && next == '*') {
                blockComment = true;
                i++;
                continue;
            }
            if (pythonLike && c == '#') {
                lineComment = true;
                continue;
            }

            if ((pythonLike || lang.equals("java")) && (c == '\'' || c == '"')
                    && next == c && next2 == c) {
                quote = c;
                tripleQuote = true;
                i += 2;
                continue;
            }
            if (c == '\'' || c == '"' || (c == '`' && !pythonLike && !xmlLike)) {
                quote = c;
                continue;
            }

            if (c == '{' || c == '(' || c == '[') {
                stack.push(c);
            } else if (c == '}' || c == ')' || c == ']') {
                if (stack.isEmpty()) {
                    return "Statik ön kontrol sonucu (" + safeLanguage(language) + "):\nSatır "
                            + line + " civarında eşleşmeyen kapatma karakteri '" + c + "'.\n"
                            + "Bu kontrol derleme veya çalıştırma testi değildir.";
                }
                char open = stack.pop();
                if (!matches(open, c)) {
                    return "Statik ön kontrol sonucu (" + safeLanguage(language) + "):\nSatır "
                            + line + " civarında '" + open + "' ve '" + c + "' eşleşmiyor.\n"
                            + "Bu kontrol derleme veya çalıştırma testi değildir.";
                }
            }
        }

        if (blockComment) {
            return "Statik ön kontrol: dosya sonunda kapanmamış bir /* yorum bloğu olabilir. Bu kontrol derleme veya çalıştırma testi değildir.";
        }
        if (xmlComment) {
            return "Statik ön kontrol: dosya sonunda kapanmamış bir XML/HTML yorum bloğu olabilir. Bu kontrol derleme veya çalıştırma testi değildir.";
        }
        if (quote != 0) {
            return "Statik ön kontrol: dosya sonunda kapanmamış bir dizge/tırnak olabilir. Bu kontrol derleme veya çalıştırma testi değildir.";
        }
        if (!stack.isEmpty()) {
            return "Statik ön kontrol: kapanmamış '" + stack.peek() + "' ayıracı var. Bu kontrol derleme veya çalıştırma testi değildir.";
        }
        return "Basit ayraç kontrolü geçti (" + safeLanguage(language) + "). Yorum ve dizgeler atlandı; bu, sözdiziminin tamamen doğru olduğunu kanıtlamaz. Kod derlenmedi veya çalıştırılmadı.";
    }

    private String analyzeXml(String code) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            factory.setXIncludeAware(false);
            factory.setExpandEntityReferences(false);
            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setErrorHandler(new DefaultHandler() {
                @Override public void error(SAXParseException exception) throws SAXException { throw exception; }
                @Override public void fatalError(SAXParseException exception) throws SAXException { throw exception; }
            });
            builder.parse(new InputSource(new StringReader(code)));
            return "XML iyi biçimlenmiş görünüyor. Harici varlık/DOCTYPE yüklenmedi. Bu kontrol Android kaynak birleştirmesinin veya uygulama derlemesinin yerini tutmaz.";
        } catch (Exception exception) {
            String message = exception.getMessage();
            return "XML doğrulaması başarısız: " + (message == null ? exception.getClass().getSimpleName() : message)
                    + "\nBu kontrol yalnızca XML biçimlendirmesini inceler; Android derlemesi değildir.";
        }
    }

    private boolean matches(char open, char close) {
        return (open == '{' && close == '}') || (open == '(' && close == ')') || (open == '[' && close == ']');
    }

    private String safeLanguage(String language) {
        return language == null || language.trim().isEmpty() ? "bilinmeyen dil" : language.trim();
    }
}
