package com.jai.assistant.engine;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.jai.assistant.data.MemoryDatabase;
import com.jai.assistant.data.MemoryEntry;
import com.jai.assistant.data.TaskRecord;
import com.jai.assistant.data.SettingsManager;
import com.jai.assistant.tools.ResearchReport;
import com.jai.assistant.tools.WebResearchEngine;

import org.json.JSONObject;

import java.util.List;

/**
 * Her çalıştırmada tek bir küçük adım işler ve bir sonraki adımı WorkManager'a bırakır.
 * Böylece görev ilerlemesi SQLite'da kalır; Android'in çalışma penceresi garantisi değildir.
 */
public final class DurableTaskWorker extends Worker {
    private final MemoryDatabase database;

    public DurableTaskWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
        database = new MemoryDatabase(context);
    }

    @NonNull
    @Override
    public Result doWork() {
        try { return runTask(); }
        finally { database.close(); }
    }

    private Result runTask() {
        long id = getInputData().getLong("task_id", -1L);
        int step = getInputData().getInt("step", 0);
        TaskRecord task = database.getTask(id);
        if (task == null) return Result.failure();
        if ("Duraklatıldı".equals(task.status) || isStopped()) return Result.success();
        try {
            JSONObject state = parseState(task.details, task.title);
            String topic = state.optString("topic", task.title);
            if (step <= 0) {
                state.put("step", 1);
                state.put("state", "Hazırlık tamamlandı; ağ bağlantısı bekleniyor.");
                database.updateTask(id, "Ağ bekleniyor", state.toString());
                enqueueNext(id, 1);
                return Result.success();
            }
            if (step == 1) {
                // Kullanıcı Ara anahtarını görev kuyruğa alındıktan sonra kapatmış olabilir.
                // Bu kapı, arka plan işinin web isteği göndermesini de engeller.
                if (!new SettingsManager(getApplicationContext()).isWebResearchEnabled()) {
                    state.put("state", "Ara kapalı; çevrimiçi adım beklemede bırakıldı.");
                    database.updateTask(id, "Ara kapalı · bekliyor", state.toString());
                    return Result.success();
                }
                state.put("state", "Araştırma başladı");
                database.updateTask(id, "Araştırılıyor", state.toString());
                ResearchReport report = new WebResearchEngine().researchAdaptive(topic, "Derin");
                TaskRecord afterNetwork = database.getTask(id);
                if (isStopped() || afterNetwork == null || "Duraklatıldı".equals(afterNetwork.status)) {
                    return Result.success();
                }
                if (!report.searchCompleted) {
                    state.put("research_note", report.note == null ? "Bağlantı kurulamadı." : report.note);
                    state.put("state", "Ağ araştırması başarısız; WorkManager yeniden deneyecek.");
                    database.updateTask(id, "Ağ hatası · yeniden denenecek", state.toString());
                    return Result.retry();
                }
                int saved = new LearningEngine(database).rememberResearch(report);
                state.put("sources_saved", saved);
                state.put("search_completed", report.searchCompleted);
                state.put("research_note", report.note == null ? "" : report.note);
                state.put("step", 2);
                database.updateTask(id, saved > 0 ? "Kaynaklar kaydedildi" : "Kaynak bulunamadı", state.toString());
                enqueueNext(id, 2);
                return Result.success();
            }
            if (step == 2) {
                List<MemoryEntry> entries = database.searchMemories(topic, 12);
                StringBuilder text = new StringBuilder();
                for (MemoryEntry entry : entries) {
                    if (entry.source != null && entry.source.startsWith("web:")) {
                        text.append(entry.title).append(". ").append(entry.content).append("\n\n");
                    }
                }
                String summary = text.length() == 0
                        ? "Araştırma tamamlandı ancak yerel hafızada özetlenecek kaynak metni bulunamadı."
                        : new LocalLanguageEngine(database).summarize("Araştırma özeti: " + topic, text.toString(), 5);
                database.saveMemory("Araştırma özeti: " + topic, summary,
                        "WorkManager yerel cümle seçici özeti; doğrulanmamış", false);
                state.put("summary_saved", true);
                state.put("step", 3);
                state.put("state", "Yerel özet kaydedildi.");
                database.updateTask(id, "Özet hazırlanıyor", state.toString());
                enqueueNext(id, 3);
                return Result.success();
            }
            state.put("step", 4);
            state.put("state", "Araştırma, kaynak kaydı ve yerel özet tamamlandı. Web notları doğrulanmış bilgi sayılmaz.");
            database.updateTask(id, "Tamamlandı", state.toString());
            return Result.success(new Data.Builder().putLong("task_id", id).putBoolean("completed", true).build());
        } catch (Exception exception) {
            TaskRecord latest = database.getTask(id);
            if (latest != null) database.updateTask(id, "Hata · devam bekliyor", latest.details);
            return Result.retry();
        }
    }

    private void enqueueNext(long id, int nextStep) {
        // Worker'ın kendi içinden zincirin sonraki bağımsız, kalıcı adımını sıraya koyması.
        androidx.work.OneTimeWorkRequest request = new androidx.work.OneTimeWorkRequest.Builder(DurableTaskWorker.class)
                .setInputData(new Data.Builder().putLong("task_id", id).putInt("step", nextStep).build())
                .addTag(DurableTaskManager.tag(id))
                .setConstraints(new androidx.work.Constraints.Builder()
                        .setRequiredNetworkType(nextStep == 1 ? androidx.work.NetworkType.CONNECTED : androidx.work.NetworkType.NOT_REQUIRED)
                        .build())
                .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 15, java.util.concurrent.TimeUnit.SECONDS)
                .build();
        androidx.work.WorkManager.getInstance(getApplicationContext())
                .enqueueUniqueWork(DurableTaskManager.workName(id, nextStep), androidx.work.ExistingWorkPolicy.KEEP, request);
    }

    static int readStep(String details) {
        try { return new JSONObject(details == null ? "{}" : details).optInt("step", 0); }
        catch (Exception ignored) { return 0; }
    }

    private JSONObject parseState(String details, String fallbackTopic) throws Exception {
        JSONObject state;
        try { state = new JSONObject(details == null ? "{}" : details); }
        catch (Exception ignored) { state = new JSONObject(); }
        if (!state.has("topic")) state.put("topic", fallbackTopic);
        return state;
    }
}
