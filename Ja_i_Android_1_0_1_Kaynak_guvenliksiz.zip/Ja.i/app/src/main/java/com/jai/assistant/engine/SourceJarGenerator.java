package com.jai.assistant.engine;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/** Java 8 uyumlu, gerçekten çalıştırılabilir küçük Main sınıfı içeren JAR üreticisi. */
public final class SourceJarGenerator {
    private final ProjectArchiveWriter archiveWriter = new ProjectArchiveWriter();

    public MinecraftPackGenerator.Result generate(String prompt) throws IOException {
        String message = "Ja.i tarafından çevrimdışı üretildi: " + safeMessage(prompt);
        byte[] classBytes = createMainClass(message);
        String source = "public final class Main {\n"
                + "    public static void main(String[] args) {\n"
                + "        System.out.println(\"" + escapeJava(message) + "\");\n"
                + "    }\n}\n";
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("META-INF/MANIFEST.MF", "Manifest-Version: 1.0\r\nMain-Class: Main\r\nCreated-By: Ja.i\r\n\r\n".getBytes(StandardCharsets.UTF_8));
        files.put("Main.class", classBytes);
        files.put("src/Main.java", source.getBytes(StandardCharsets.UTF_8));
        files.put("README_TR.md", ("# Ja.i Java JAR\n\nBu arşiv geçerli bir Java JAR dosyasıdır. `Main.class` Java 8 bytecode olarak derlenmiş ve `Main-Class` manifestine bağlanmıştır.\n\nÇalıştırma: `java -jar jai-generated.jar`\n\nİçerik: `Main.class`, kaynak `src/Main.java`, manifest. Bu genel Java JAR'ıdır; Fabric/Forge modu değildir.\n").getBytes(StandardCharsets.UTF_8));
        byte[] jar = archiveWriter.createZipBinary(files);
        return new MinecraftPackGenerator.Result(jar, "jai-generated.jar", "application/java-archive",
                "Çalıştırılabilir Java 8 JAR üretildi. Main.class bytecode içerir; kaynak kodu ve Main-Class manifesti eklendi. Bu genel Java JAR'ıdır, Fabric/Forge modu değildir.", "java_jar", files.size());
    }

    private byte[] createMainClass(String message) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(0xCAFEBABE); out.writeShort(0); out.writeShort(52); // Java 8
        out.writeShort(28); // constant_pool_count
        utf(out, "Main");                 // 1
        out.writeByte(7); out.writeShort(1); // 2 Class Main
        utf(out, "java/lang/Object");     // 3
        out.writeByte(7); out.writeShort(3); // 4 Class Object
        utf(out, "<init>");               // 5
        utf(out, "()V");                  // 6
        out.writeByte(12); out.writeShort(5); out.writeShort(6); // 7 NameAndType
        out.writeByte(10); out.writeShort(4); out.writeShort(7); // 8 Object.<init>
        utf(out, "Code");                 // 9
        utf(out, "main");                 // 10
        utf(out, "([Ljava/lang/String;)V"); // 11
        utf(out, "java/lang/System");     // 12
        out.writeByte(7); out.writeShort(12); // 13 Class System
        utf(out, "out");                  // 14
        utf(out, "Ljava/io/PrintStream;"); // 15
        out.writeByte(12); out.writeShort(14); out.writeShort(15); // 16 NameAndType
        out.writeByte(9); out.writeShort(13); out.writeShort(16); // 17 Fieldref System.out
        utf(out, message);                 // 18
        out.writeByte(8); out.writeShort(18); // 19 String message
        utf(out, "java/io/PrintStream");  // 20
        out.writeByte(7); out.writeShort(20); // 21 Class PrintStream
        utf(out, "println");              // 22
        utf(out, "(Ljava/lang/String;)V"); // 23
        out.writeByte(12); out.writeShort(22); out.writeShort(23); // 24 NameAndType
        out.writeByte(10); out.writeShort(21); out.writeShort(24); // 25 Methodref println
        utf(out, "SourceFile");           // 26
        utf(out, "Main.java");            // 27
        out.writeShort(0x0021); // public + super
        out.writeShort(2); out.writeShort(4);
        out.writeShort(0); // interfaces
        out.writeShort(0); // fields
        out.writeShort(2); // methods
        writeMethod(out, 0x0001, 5, 6, new byte[]{0x2a, (byte)0xb7, 0, 8, (byte)0xb1}, 1, 1);
        writeMethod(out, 0x0009, 10, 11, new byte[]{(byte)0xb2, 0, 17, 0x12, 19, (byte)0xb6, 0, 25, (byte)0xb1}, 2, 1);
        out.writeShort(1); out.writeShort(26); out.writeInt(2); out.writeShort(27);
        out.flush();
        return bytes.toByteArray();
    }

    private static void writeMethod(DataOutputStream out, int access, int name, int descriptor,
                                    byte[] code, int maxStack, int maxLocals) throws IOException {
        out.writeShort(access); out.writeShort(name); out.writeShort(descriptor); out.writeShort(1);
        out.writeShort(9); out.writeInt(12 + code.length);
        out.writeShort(maxStack); out.writeShort(maxLocals); out.writeInt(code.length); out.write(code);
        out.writeShort(0); out.writeShort(0);
    }

    private static void utf(DataOutputStream out, String value) throws IOException {
        out.writeByte(1); out.writeUTF(value);
    }
    private static String safeMessage(String input) {
        String value = input == null ? "Ja.i" : input.replaceAll("\\s+", " ").trim();
        if (value.length() > 180) value = value.substring(0, 180);
        return value.isEmpty() ? "Ja.i" : value;
    }
    private static String escapeJava(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", " ").replace("\n", " ");
    }
}
