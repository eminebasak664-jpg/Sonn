package com.jai.assistant.engine;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Küçük, güvenli bir JavaScript kaynak sentezleyicisi.
 * Sabit program şablonlarını seçmez; kullanıcının verdiği ifade ve kontrol akışı
 * tanımlarını ayrıştırıp yeni kaynak metni üretir. Genel amaçlı doğal dil modeli değildir.
 */
public final class StructuredProgramCompiler {
    public static final class Result {
        public final boolean recognized;
        public final boolean supported;
        public final String source;
        public final String message;

        private Result(boolean recognized, boolean supported, String source, String message) {
            this.recognized = recognized;
            this.supported = supported;
            this.source = source;
            this.message = message;
        }
    }

    private static final int MAX_INPUT_CHARS = 16_384;
    private static final int MAX_STATEMENTS = 100;
    private static final Pattern VARIABLE = Pattern.compile("^(?:değişken|let|const|var)\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*=\\s*(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern FUNCTION = Pattern.compile("^(?:fonksiyon|function)\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\(([^)]*)\\)\\s*=\\s*(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern PRINT = Pattern.compile("^(?:yazdır|yazdir|print|log)\\s+(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern CONDITION = Pattern.compile("^(?:eğer|eger|if)\\s+(.+?)\\s+(?:ise|then)\\s+(?:yazdır|yazdir|print|log)\\s+(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern LOOP = Pattern.compile("^(?:döngü|dongu|loop|for)\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s+(?:başlangıç|baslangic|from)\\s+(-?\\d+)\\s+(?:bitiş|bitis|to)\\s+(-?\\d+)\\s+(?:yazdır|yazdir|print|log)\\s+(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern ASSIGN = Pattern.compile("^(?:ata|set)\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*=\\s*(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Set<String> RESERVED = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "break", "case", "catch", "class", "const", "continue", "debugger", "default", "delete",
            "do", "else", "export", "extends", "finally", "for", "function", "if", "import", "in",
            "instanceof", "let", "new", "return", "super", "switch", "this", "throw", "try", "typeof",
            "var", "void", "while", "with", "yield", "await", "enum", "implements", "interface", "package",
            "private", "protected", "public", "static", "null", "true", "false")));

    public Result compile(String specification) {
        String input = specification == null ? "" : specification.trim();
        if (input.isEmpty()) return failure(false, "Program tanımı boş.");
        if (input.length() > MAX_INPUT_CHARS) return failure(false, "Program tanımı 16.384 karakter sınırını aşıyor.");

        String[] lines = input.replace("\r", "").split("\n");
        List<String> output = new ArrayList<>();
        boolean recognized = false;
        int statementCount = 0;

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) continue;
            if (statementCount >= MAX_STATEMENTS) return failure(true, lineError(i, "En fazla 100 komut kullanılabilir."));
            if (line.matches("(?i)^(program|javascript programı|javascript programi|js programı|js programi)$")) continue;

            Matcher matcher = VARIABLE.matcher(line);
            if (matcher.matches()) {
                recognized = true;
                String name = matcher.group(1);
                if (isReserved(name)) return failure(true, lineError(i, "Değişken adı JavaScript anahtar sözcüğü olamaz: " + name));
                Expr expression = parseExpression(matcher.group(2), i);
                if (expression.error != null) return failure(true, expression.error);
                output.add("let " + name + " = " + expression.code + ";");
                statementCount++;
                continue;
            }

            matcher = FUNCTION.matcher(line);
            if (matcher.matches()) {
                recognized = true;
                String name = matcher.group(1);
                if (isReserved(name)) return failure(true, lineError(i, "Fonksiyon adı JavaScript anahtar sözcüğü olamaz: " + name));
                List<String> parameters = parseParameters(matcher.group(2));
                if (parameters == null) return failure(true, lineError(i, "Fonksiyon parametreleri geçersiz veya yinelenmiş."));
                Expr expression = parseExpression(matcher.group(3), i);
                if (expression.error != null) return failure(true, expression.error);
                output.add("function " + name + "(" + String.join(", ", parameters) + ") {");
                output.add("    return " + expression.code + ";");
                output.add("}");
                statementCount++;
                continue;
            }

            matcher = CONDITION.matcher(line);
            if (matcher.matches()) {
                recognized = true;
                Expr condition = parseExpression(matcher.group(1), i);
                if (condition.error != null) return failure(true, condition.error);
                Expr value = parseExpression(matcher.group(2), i);
                if (value.error != null) return failure(true, value.error);
                output.add("if (" + condition.code + ") {");
                output.add("    console.log(" + value.code + ");");
                output.add("}");
                statementCount++;
                continue;
            }

            matcher = LOOP.matcher(line);
            if (matcher.matches()) {
                recognized = true;
                String variable = matcher.group(1);
                if (isReserved(variable)) return failure(true, lineError(i, "Döngü değişkeni JavaScript anahtar sözcüğü olamaz: " + variable));
                int start;
                int end;
                try {
                    start = Integer.parseInt(matcher.group(2));
                    end = Integer.parseInt(matcher.group(3));
                } catch (NumberFormatException exception) {
                    return failure(true, lineError(i, "Döngü sınırı geçerli bir tam sayı değil."));
                }
                if (Math.abs((long) end - start) > 10000L) {
                    return failure(true, lineError(i, "Döngü aralığı en fazla 10.000 adım olabilir."));
                }
                Expr value = parseExpression(matcher.group(4), i);
                if (value.error != null) return failure(true, value.error);
                output.add("for (let " + variable + " = " + start + "; " + variable + " <= " + end + "; " + variable + "++) {");
                output.add("    console.log(" + value.code + ");");
                output.add("}");
                statementCount++;
                continue;
            }

            matcher = ASSIGN.matcher(line);
            if (matcher.matches()) {
                recognized = true;
                String name = matcher.group(1);
                if (isReserved(name)) return failure(true, lineError(i, "Atama hedefi JavaScript anahtar sözcüğü olamaz: " + name));
                Expr expression = parseExpression(matcher.group(2), i);
                if (expression.error != null) return failure(true, expression.error);
                output.add(name + " = " + expression.code + ";");
                statementCount++;
                continue;
            }

            matcher = PRINT.matcher(line);
            if (matcher.matches()) {
                recognized = true;
                Expr expression = parseExpression(matcher.group(1), i);
                if (expression.error != null) return failure(true, expression.error);
                output.add("console.log(" + expression.code + ");");
                statementCount++;
                continue;
            }

            if (recognized || hasRecognizedDirective(lines)) {
                return failure(true, lineError(i, "Bu satır tanınmadı. Değişken, fonksiyon, eğer, döngü, ata veya yazdır kullan."));
            }
        }

        if (!recognized || statementCount == 0) return failure(false, "Bu metin yapılandırılmış program tanımı değil.");
        StringBuilder source = new StringBuilder("'use strict';\n\n");
        for (String line : output) source.append(line).append('\n');
        return new Result(true, true, source.toString().trim(),
                "İstekten yeni JavaScript kaynak kodu sentezlendi. Tanınan ifade ve kontrol akışı kuralları kullanıldı; genel doğal dil modeli değildir.");
    }

    private boolean hasRecognizedDirective(String[] lines) {
        for (String raw : lines) {
            String line = raw == null ? "" : raw.trim();
            if (VARIABLE.matcher(line).matches() || FUNCTION.matcher(line).matches()
                    || PRINT.matcher(line).matches() || CONDITION.matcher(line).matches()
                    || LOOP.matcher(line).matches() || ASSIGN.matcher(line).matches()) return true;
        }
        return false;
    }

    private List<String> parseParameters(String raw) {
        List<String> result = new ArrayList<>();
        if (raw.trim().isEmpty()) return result;
        Set<String> unique = new HashSet<>();
        for (String item : raw.split(",", -1)) {
            String parameter = item.trim();
            if (!parameter.matches("[A-Za-z_$][A-Za-z0-9_$]*") || isReserved(parameter) || !unique.add(parameter)) return null;
            result.add(parameter);
        }
        return result;
    }

    private Expr parseExpression(String source, int lineIndex) {
        try {
            ExpressionParser parser = new ExpressionParser(source);
            String code = parser.parse();
            return new Expr(code, null);
        } catch (IllegalArgumentException exception) {
            return new Expr("", lineError(lineIndex, "İfade ayrıştırılamadı: " + exception.getMessage()));
        }
    }

    private boolean isReserved(String name) { return RESERVED.contains(name.toLowerCase(Locale.ROOT)); }
    private String lineError(int zeroBasedLine, String message) { return "Satır " + (zeroBasedLine + 1) + ": " + message; }
    private Result failure(boolean recognized, String message) { return new Result(recognized, false, "", message); }

    private static final class Expr {
        final String code;
        final String error;
        Expr(String code, String error) { this.code = code; this.error = error; }
    }

    private static final class ExpressionParser {
        private static final Pattern TOKEN = Pattern.compile("\\s*(?:(\\d+(?:\\.\\d+)?)|([A-Za-z_$][A-Za-z0-9_$]*)|((?:\\\"(?:\\\\.|[^\\\"\\\\])*\\\")|(?:'(?:\\\\.|[^'\\\\])*'))|(===|!==|==|!=|>=|<=|&&|\\|\\||[+\\-*/%><!(),]))");
        private final List<String> tokens = new ArrayList<>();
        private int position;

        ExpressionParser(String expression) {
            if (expression == null || expression.trim().isEmpty()) throw new IllegalArgumentException("boş ifade");
            Matcher matcher = TOKEN.matcher(expression);
            int cursor = 0;
            while (cursor < expression.length()) {
                matcher.region(cursor, expression.length());
                if (!matcher.lookingAt()) throw new IllegalArgumentException("desteklenmeyen karakter: " + expression.charAt(cursor));
                String token = firstNonNull(matcher.group(1), matcher.group(2), matcher.group(3), matcher.group(4));
                if (token == null) throw new IllegalArgumentException("geçersiz belirteç");
                tokens.add(token);
                if (tokens.size() > 256) throw new IllegalArgumentException("ifade 256 belirteç sınırını aşıyor");
                cursor = matcher.end();
            }
        }

        String parse() {
            String value = parseBinary(1);
            if (position != tokens.size()) throw new IllegalArgumentException("fazladan ifade: " + tokens.get(position));
            return value;
        }

        private String parseBinary(int minimumPrecedence) {
            String left = parseUnary();
            while (position < tokens.size()) {
                String operator = tokens.get(position);
                int precedence = precedence(operator);
                if (precedence < minimumPrecedence) break;
                position++;
                String right = parseBinary(precedence + 1);
                left = "(" + left + " " + operator + " " + right + ")";
            }
            return left;
        }

        private String parseUnary() {
            if (position < tokens.size() && ("!".equals(tokens.get(position)) || "-".equals(tokens.get(position)) || "+".equals(tokens.get(position)))) {
                String operator = tokens.get(position++);
                return "(" + operator + parseUnary() + ")";
            }
            return parsePrimary();
        }

        private String parsePrimary() {
            if (position >= tokens.size()) throw new IllegalArgumentException("ifade bekleniyordu");
            String token = tokens.get(position++);
            if ("(".equals(token)) {
                String value = parseBinary(1);
                require(")");
                return "(" + value + ")";
            }
            if (token.matches("\\d+(?:\\.\\d+)?") || isQuoted(token)) return token;
            if (token.matches("[A-Za-z_$][A-Za-z0-9_$]*")) {
                if (position < tokens.size() && "(".equals(tokens.get(position))) {
                    position++;
                    List<String> arguments = new ArrayList<>();
                    if (position < tokens.size() && !")".equals(tokens.get(position))) {
                        do {
                            arguments.add(parseBinary(1));
                            if (position >= tokens.size() || !",".equals(tokens.get(position))) break;
                            position++;
                        } while (true);
                    }
                    require(")");
                    return token + "(" + String.join(", ", arguments) + ")";
                }
                return token;
            }
            throw new IllegalArgumentException("beklenmeyen belirteç: " + token);
        }

        private void require(String expected) {
            if (position >= tokens.size() || !expected.equals(tokens.get(position))) {
                throw new IllegalArgumentException("'" + expected + "' bekleniyordu");
            }
            position++;
        }

        private int precedence(String token) {
            if ("||".equals(token)) return 1;
            if ("&&".equals(token)) return 2;
            if ("==".equals(token) || "===".equals(token) || "!=".equals(token) || "!==".equals(token)) return 3;
            if (">".equals(token) || "<".equals(token) || ">=".equals(token) || "<=".equals(token)) return 4;
            if ("+".equals(token) || "-".equals(token)) return 5;
            if ("*".equals(token) || "/".equals(token) || "%".equals(token)) return 6;
            return 0;
        }

        private boolean isQuoted(String token) { return token.length() >= 2 && (token.charAt(0) == '\'' || token.charAt(0) == '"'); }
        private static String firstNonNull(String... values) { for (String value : values) if (value != null) return value; return null; }
    }
}
