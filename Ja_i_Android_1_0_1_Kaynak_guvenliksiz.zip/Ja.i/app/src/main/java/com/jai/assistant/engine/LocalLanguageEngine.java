package com.jai.assistant.engine;

import com.jai.assistant.data.MemoryDatabase;
import com.jai.assistant.data.MemoryEntry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Yerel dil işleme motoru: Türkçe normalleştirme, hafıza getirimi, cümle sıralama,
 * tekrar azaltma ve kontrollü yanıt birleştirme yapar. Büyük dil modeli değildir.
 */
public final class LocalLanguageEngine {
    private static final int MAX_SENTENCES = 5;
    private static final int MAX_QUERY_TERMS = 10;
    private final MemoryDatabase database;

    public LocalLanguageEngine(MemoryDatabase database) {
        if (database == null) throw new IllegalArgumentException("MemoryDatabase gerekli");
        this.database = database;
    }

    public String respond(String prompt, String effort) {
        return respond(prompt, effort, "");
    }

    /** Önceden getirilmiş ve puanlanmış bağlamı yanıt seçiminde doğrudan kullanır. */
    public String respond(String prompt, String effort, String retrievedContext) {
        String query = prompt == null ? "" : prompt.trim();
        String context = retrievedContext == null ? "" : retrievedContext.trim();
        if (!context.isEmpty()) {
            StringBuilder response = new StringBuilder();
            response.append("Yerel hafızadan bu isteğe en yakın bulunan bilgiler:\n");
            response.append(context);
            response.append("\n\nBu içerik cihazdaki kayıtlı notlardan getirildi. Kayıtların 'doğrulanmış olarak işaretli' olması dış kaynakta bağımsız doğrulama yapıldığı anlamına gelmez.");
            return response.toString();
        }
        if (query.length() < 2) return "Biraz daha ayrıntılı yazar mısın?";

        List<MemoryEntry> memories = retrieveRelevantMemories(query, "Derin".equalsIgnoreCase(effort) ? 30 : 16);
        List<ScoredSentence> candidates = new ArrayList<>();
        for (MemoryEntry memory : memories) {
            for (String sentence : splitSentences(memory.content)) {
                double relevance = score(query, sentence, memory.title, memory.source);
                if (relevance >= 1.4) {
                    candidates.add(new ScoredSentence(sentence, memory.title, memory.source,
                            memory.verified, relevance));
                }
            }
        }
        Collections.sort(candidates, Comparator.comparingDouble((ScoredSentence s) -> s.score).reversed());

        if (candidates.isEmpty()) {
            return "Bu soruyu yerel olarak işleyebildim ancak hafızamda güvenilir bir yanıt oluşturacak kadar ilgili bilgi bulamadım. "
                    + "Ara açıksa konuyu araştırabilir veya 'hatırla: ...' komutuyla bilgi kaydedebilirsin. "
                    + "Bu uygulamada harici yapay zekâ API'si ya da büyük dil modeli yok; bilmediğim cevabı uydurmayacağım.";
        }

        String intent = detectIntent(query);
        StringBuilder answer = new StringBuilder(opening(intent));
        Set<String> usedSentences = new LinkedHashSet<>();
        Map<String, String> sources = new LinkedHashMap<>();
        int accepted = 0;
        for (ScoredSentence item : candidates) {
            String normalized = TurkishTextProcessor.normalize(item.text);
            if (normalized.length() < 12 || !usedSentences.add(normalized)) continue;
            if (accepted > 0) answer.append(" ");
            answer.append(capitalize(item.text.trim()));
            if (item.source != null && item.source.startsWith("web:")) {
                sources.put(item.source, item.verified ? "kaynak kaydı" : "doğrulanmamış kaynak notu");
            }
            accepted++;
            if (accepted >= MAX_SENTENCES) break;
        }

        if (!sources.isEmpty()) {
            answer.append("\n\nKaynak notları:");
            for (Map.Entry<String, String> source : sources.entrySet()) {
                answer.append("\n• ").append(source.getKey().substring(4))
                        .append(" (").append(source.getValue()).append(")");
            }
        }
        answer.append("\n\nYanıt, cihazdaki kayıtlı metinlerden seçilip birleştirildi. Yeni olgu veya bağımsız doğrulama üretilmedi.");
        return answer.toString();
    }

    /**
     * Dosya eki veya web araştırmasından gelen kanıt metnini kullanıcı isteğine göre seçer.
     * Bu işlem yeni bilgi üretmez; kaynak metinden eşleşen cümleleri sıralayıp kaynak satırlarını korur.
     */
    public String respondWithContext(String prompt, String effort, String evidenceContext, String sourceLabel) {
        String query = prompt == null ? "" : prompt.trim();
        String context = evidenceContext == null ? "" : evidenceContext.trim();
        if (context.isEmpty()) return "İncelenecek dosya veya araştırma kanıtı bulunamadı.";

        List<ScoredSentence> candidates = new ArrayList<>();
        List<String> sourceLines = new ArrayList<>();
        for (String line : context.split("\\r?\\n")) {
            String cleanLine = line.trim();
            if (cleanLine.isEmpty()) continue;
            if (cleanLine.startsWith("Kaynak:") || cleanLine.startsWith("Yayın tarihi:")
                    || cleanLine.startsWith("Alan adı:") || cleanLine.startsWith("Sayfa durumu:")) {
                sourceLines.add(cleanLine);
                continue;
            }
            if (cleanLine.startsWith("[Metin eki:") || cleanLine.startsWith("[Dosya eki:")
                    || cleanLine.startsWith("[JA.I WEB ARAŞTIRMA BAĞLAMI]")
                    || cleanLine.startsWith("[JA.I DOSYA BAĞLAMI]")
                    || cleanLine.startsWith("Web araştırması raporu")
                    || cleanLine.startsWith("Sorgu:")
                    || cleanLine.startsWith("Toplanma zamanı:")
                    || cleanLine.startsWith("Arama isteği:")
                    || cleanLine.startsWith("Okunabilen kaynak sayfası:")
                    || cleanLine.startsWith("Farklı alan adı:")
                    || cleanLine.startsWith("Doğrulama notu:")
                    || cleanLine.startsWith("İşlem notu:")) continue;
            String candidateText = cleanLine.startsWith("Kısa içerik:")
                    ? cleanLine.substring("Kısa içerik:".length()).trim() : cleanLine;
            for (String sentence : splitSentences(candidateText)) {
                String cleanSentence = sentence.trim();
                if (cleanSentence.length() < 12) continue;
                double relevance = score(query, cleanSentence, sourceLabel, null);
                candidates.add(new ScoredSentence(cleanSentence, sourceLabel, null, false, relevance));
            }
        }
        Collections.sort(candidates, Comparator.comparingDouble((ScoredSentence item) -> item.score).reversed());
        int limit = "Derin".equalsIgnoreCase(effort) ? 10 : ("Maksimum".equalsIgnoreCase(effort) ? 8 : 5);
        StringBuilder answer = new StringBuilder("İstekle ilişkili ")
                .append(sourceLabel == null || sourceLabel.trim().isEmpty() ? "bağlam" : sourceLabel.trim())
                .append(" bölümleri (yerel metin eşleştirmesi):\n");
        Set<String> used = new LinkedHashSet<>();
        int added = 0;
        for (ScoredSentence candidate : candidates) {
            String normalized = TurkishTextProcessor.normalize(candidate.text);
            if (!used.add(normalized)) continue;
            if (added > 0) answer.append("\n");
            answer.append("• ").append(candidate.text);
            added++;
            if (added >= limit) break;
        }
        if (added == 0) {
            answer.append("İstekle doğrudan eşleşen cümle bulunamadı. Kaynak metnin başlangıç bölümü:\n");
            int shown = 0;
            for (ScoredSentence candidate : candidates) {
                if (shown++ > 0) answer.append("\n");
                answer.append("• ").append(candidate.text);
                if (shown >= Math.min(3, limit)) break;
            }
        }
        if (!sourceLines.isEmpty()) {
            answer.append("\n\nKaynak bilgileri:");
            Set<String> uniqueSources = new LinkedHashSet<>(sourceLines);
            for (String line : uniqueSources) answer.append("\n• ").append(line);
        }
        answer.append("\n\nNot: Yerel motor kaynak metninden ilgili cümleleri seçti; yeni bilgi üretmedi. Web sayfasının okunması iddiaların doğruluğunu tek başına kanıtlamaz.");
        return answer.toString();
    }

    public enum EvidenceStatus { SUFFICIENT, PARTIAL, NONE }

    /**
     * Hafıza kanıtının kapsamını açıkça raporlar. Coverage yalnızca sorgu terimlerinin
     * bulunan metinlerdeki eşleşme oranıdır; anlamsal doğruluk veya gerçeklik puanı değildir.
     */
    public static final class KnowledgeAssessment {
        public final EvidenceStatus status;
        public final String context;
        public final int evidenceCount;
        public final int matchedTerms;
        public final int queryTerms;
        public final double termCoverage;
        public final double bestRelevance;

        private KnowledgeAssessment(EvidenceStatus status, String context, int evidenceCount,
                                    int matchedTerms, int queryTerms, double termCoverage, double bestRelevance) {
            this.status = status;
            this.context = context;
            this.evidenceCount = evidenceCount;
            this.matchedTerms = matchedTerms;
            this.queryTerms = queryTerms;
            this.termCoverage = termCoverage;
            this.bestRelevance = bestRelevance;
        }

        public String statusLabel() {
            switch (status) {
                case SUFFICIENT: return "eşleşme kapsamı yüksek";
                case PARTIAL: return "kısmi eşleşme";
                default: return "ilgili kayıt bulunamadı";
            }
        }
    }

    /** Think aşaması için kanıt kapsamı ve sıralanmış bağlam üretir. */
    public KnowledgeAssessment assessKnowledge(String query, int limit) {
        String cleanQuery = query == null ? "" : query.trim();
        List<String> terms = TurkishTextProcessor.tokens(cleanQuery);
        if (cleanQuery.length() < 2 || terms.isEmpty()) {
            return new KnowledgeAssessment(EvidenceStatus.NONE, "", 0, 0, terms.size(), 0.0, 0.0);
        }
        int safeLimit = Math.max(1, Math.min(limit, 12));
        List<MemoryEntry> memories = retrieveRelevantMemories(cleanQuery, Math.max(safeLimit, 8));
        List<ScoredSentence> candidates = new ArrayList<>();
        Set<String> matched = new LinkedHashSet<>();
        for (MemoryEntry memory : memories) {
            for (String sentence : splitSentences(memory.content)) {
                double relevance = score(cleanQuery, sentence, memory.title, memory.source);
                if (relevance < 1.4) continue;
                candidates.add(new ScoredSentence(sentence, memory.title, memory.source, memory.verified, relevance));
                collectMatchedTerms(terms, sentence + " " + memory.title, matched);
            }
        }
        Collections.sort(candidates, Comparator.comparingDouble((ScoredSentence item) -> item.score).reversed());
        double coverage = matched.size() / (double) terms.size();
        EvidenceStatus status = coverage >= 0.65 && !candidates.isEmpty() ? EvidenceStatus.SUFFICIENT
                : coverage >= 0.25 && !candidates.isEmpty() ? EvidenceStatus.PARTIAL : EvidenceStatus.NONE;

        Set<String> seen = new LinkedHashSet<>();
        StringBuilder result = new StringBuilder();
        int added = 0;
        double best = candidates.isEmpty() ? 0.0 : candidates.get(0).score;
        for (ScoredSentence item : candidates) {
            String normalized = TurkishTextProcessor.normalize(item.text);
            if (normalized.length() < 12 || !seen.add(normalized)) continue;
            if (added > 0) result.append("\n");
            result.append("• ").append(capitalize(item.text.trim()))
                    .append(" [").append(item.verified ? "kullanıcı/uygulama tarafından doğrulanmış işaretli" : "bağımsız doğrulama yok").append("]");
            added++;
            if (added >= safeLimit) break;
        }
        return new KnowledgeAssessment(status, result.toString(), added, matched.size(), terms.size(), coverage, best);
    }

    /** Geriye dönük API: yalnızca kanıt bağlamını döndürür. */
    public String retrieveRelevantContext(String query, int limit) {
        return assessKnowledge(query, limit).context;
    }

    private void collectMatchedTerms(List<String> queryTerms, String candidateText, Set<String> matched) {
        List<String> candidateTokens = TurkishTextProcessor.tokens(candidateText);
        for (String term : queryTerms) {
            for (String candidate : candidateTokens) {
                if (candidate.equals(term) || (term.length() >= 4 && candidate.length() >= 4
                        && (candidate.startsWith(term) || term.startsWith(candidate)))) {
                    matched.add(term);
                    break;
                }
            }
        }
    }

    public String summarize(String title, String text, int maxSentences) {
        if (text == null || text.trim().isEmpty()) return "Özetlenecek metin bulunamadı.";
        String[] sentences = splitSentences(text);
        if (sentences.length == 0) return text.substring(0, Math.min(500, text.length()));
        List<ScoredSentence> ranked = new ArrayList<>();
        String whole = TurkishTextProcessor.normalize(text);
        List<String> terms = TurkishTextProcessor.tokens(whole);
        for (int i = 0; i < sentences.length; i++) {
            String sentence = sentences[i].trim();
            if (sentence.isEmpty()) continue;
            double score = scoreTerms(terms, sentence) + Math.max(0, 0.4 - i * 0.015);
            if (sentence.length() > 360) score *= 0.8;
            ranked.add(new ScoredSentence(sentence, title, null, false, score));
        }
        Collections.sort(ranked, Comparator.comparingDouble((ScoredSentence s) -> s.score).reversed());
        int count = Math.max(1, Math.min(maxSentences, 8));
        StringBuilder result = new StringBuilder(title == null || title.trim().isEmpty() ? "Yerel metin özeti" : title.trim());
        result.append("\n");
        for (int i = 0; i < Math.min(count, ranked.size()); i++) result.append("• ").append(ranked.get(i).text).append("\n");
        result.append("\nNot: Özet, kaynak metindeki cümlelerin önem puanına göre seçilmesidir; yeni bilgi üreten bir model özeti değildir.");
        return result.toString();
    }

    private List<MemoryEntry> retrieveRelevantMemories(String query, int limit) {
        Map<Long, MemoryEntry> unique = new LinkedHashMap<>();
        List<String> terms = TurkishTextProcessor.searchTerms(query);
        int count = 0;
        int candidateLimit = Math.min(100, Math.max(32, limit * 6));
        for (String term : terms) {
            for (MemoryEntry entry : database.searchMemories(term, candidateLimit)) unique.put(entry.id, entry);
            count++;
            if (count >= MAX_QUERY_TERMS || unique.size() >= candidateLimit) break;
        }
        if (unique.isEmpty()) {
            for (MemoryEntry entry : database.searchMemories(query, candidateLimit)) unique.put(entry.id, entry);
        }
        List<MemoryEntry> result = new ArrayList<>(unique.values());
        // Önce sorgu alakasına göre sırala; güncellik yalnızca eşit puanda bağlayıcı olsun.
        Collections.sort(result, (a, b) -> {
            double scoreA = score(query, a.content, a.title, a.source);
            double scoreB = score(query, b.content, b.title, b.source);
            int byRelevance = Double.compare(scoreB, scoreA);
            return byRelevance != 0 ? byRelevance : Long.compare(b.updatedAt, a.updatedAt);
        });
        if (result.size() > limit) return new ArrayList<>(result.subList(0, limit));
        return result;
    }

    private String[] splitSentences(String text) {
        String clean = text == null ? "" : text.replaceAll("\\s+", " ").trim();
        if (clean.isEmpty()) return new String[0];
        return clean.split("(?<=[.!?])\\s+");
    }

    private double score(String query, String sentence, String title, String source) {
        List<String> terms = TurkishTextProcessor.tokens(query);
        if (terms.isEmpty()) return 0;
        double sentenceScore = scoreTerms(terms, sentence);
        double titleScore = scoreTerms(terms, title == null ? "" : title) * 1.7;
        String normalizedQuery = TurkishTextProcessor.normalize(query);
        String normalizedSentence = TurkishTextProcessor.normalize(sentence);
        double phraseBonus = normalizedQuery.length() >= 5 && normalizedSentence.contains(normalizedQuery) ? 2.5 : 0;
        double sourceBonus = source != null && source.startsWith("web:") ? 0.15 : 0;
        if (sentence.length() < 35) sentenceScore *= 0.65;
        if (sentence.length() > 500) sentenceScore *= 0.75;
        return sentenceScore + titleScore + phraseBonus + sourceBonus;
    }

    private double scoreTerms(List<String> terms, String candidateText) {
        List<String> candidateTokens = TurkishTextProcessor.tokens(candidateText);
        if (candidateTokens.isEmpty()) return 0;
        double score = 0;
        int matched = 0;
        for (String term : terms) {
            boolean found = false;
            for (String candidate : candidateTokens) {
                if (candidate.equals(term)) { found = true; score += term.length() >= 6 ? 1.4 : 1.0; break; }
                if (term.length() >= 4 && candidate.length() >= 4
                        && (candidate.startsWith(term) || term.startsWith(candidate))) {
                    found = true; score += 0.65; break;
                }
            }
            if (found) matched++;
        }
        if (matched > 1) score += Math.min(1.5, matched * 0.12);
        return score;
    }

    private String detectIntent(String query) {
        String normalized = TurkishTextProcessor.normalize(query);
        if (containsAny(normalized, "ozet", "kisaca", "kisa anlat")) return "summary";
        if (containsAny(normalized, "adim adim", "nasil yap", "nasil calis")) return "howto";
        if (containsAny(normalized, "neden", "sebep")) return "why";
        if (containsAny(normalized, "fark", "karsilast")) return "compare";
        return "general";
    }

    private String opening(String intent) {
        if ("summary".equals(intent)) return "Kayıtlı bilgilerden kısa özet: ";
        if ("howto".equals(intent)) return "Yerel kayıtlarda bulduğum adımlar ve açıklamalar: ";
        if ("why".equals(intent)) return "Yerel kayıtlarda belirtilen nedenler: ";
        if ("compare".equals(intent)) return "Kayıtlı kaynaklarda bulunan karşılaştırma bilgileri: ";
        return "Yerel hafızada bulduğum ilgili bilgiler: ";
    }

    private String capitalize(String value) {
        if (value.isEmpty()) return value;
        return value.substring(0, 1).toUpperCase(Locale.forLanguageTag("tr-TR")) + value.substring(1);
    }

    private boolean containsAny(String text, String... values) {
        for (String value : values) if (text.contains(value)) return true;
        return false;
    }

    private static final class ScoredSentence {
        final String text;
        final String title;
        final String source;
        final boolean verified;
        final double score;
        ScoredSentence(String text, String title, String source, boolean verified, double score) {
            this.text = text;
            this.title = title;
            this.source = source;
            this.verified = verified;
            this.score = score;
        }
    }
}
