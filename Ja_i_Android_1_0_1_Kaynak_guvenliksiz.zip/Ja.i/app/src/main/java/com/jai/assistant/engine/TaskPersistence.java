package com.jai.assistant.engine;

import com.jai.assistant.data.MemoryDatabase;
import com.jai.assistant.data.TaskRecord;

import java.util.List;

/** Yerel görev kayıtları, durum geçişleri ve adım kontrol noktaları için SQLite arayüzü. */
public final class TaskPersistence {
    private final MemoryDatabase database;

    public TaskPersistence(MemoryDatabase database) {
        if (database == null) throw new IllegalArgumentException("Veritabanı zorunludur.");
        this.database = database;
    }

    public long enqueue(String title, String kind, String details) {
        return enqueue(title, kind, "Bekliyor", details);
    }

    public long enqueue(String title, String kind, String initialStatus, String details) {
        if (title == null || title.trim().isEmpty()) throw new IllegalArgumentException("Görev başlığı boş olamaz.");
        return database.saveTask(title.trim(), kind, initialStatus, details == null ? "" : details);
    }

    /** Think görevi durumunu ve büyük kullanıcı girdisini ayrı tabloda tek işlemle oluşturur. */
    public long enqueueBrainTask(String title, String status, String serializedState, String prompt) {
        if (title == null || title.trim().isEmpty()) throw new IllegalArgumentException("Görev başlığı boş olamaz.");
        return database.saveBrainTask(title.trim(), status, serializedState, prompt);
    }

    public String getBrainTaskPrompt(long id) {
        return database.getBrainTaskPrompt(id);
    }

    /** Bir iş adımının tamamlanan kontrol noktasını kalıcı olarak yazar. */
    public boolean checkpoint(long id, String status, String serializedState) {
        if (id <= 0 || serializedState == null) return false;
        return database.updateTask(id, status == null ? "Çalışıyor" : status, serializedState);
    }

    public boolean isKind(long id, String kind) {
        TaskRecord record = database.getTask(id);
        return record != null && kind != null && kind.equals(record.kind);
    }

    public List<TaskRecord> recent(int limit) {
        return database.getRecentTasks(limit);
    }

    public TaskRecord get(long id) {
        return database.getTask(id);
    }

    public boolean pause(long id) {
        TaskRecord task = database.getTask(id);
        return task != null && database.updateTask(id, "Duraklatıldı", task.details);
    }

    /** Duraklatılan görevi yeniden bekleme kuyruğuna alır; otomatik çalıştırma anlamına gelmez. */
    public boolean requeue(long id) {
        TaskRecord task = database.getTask(id);
        return task != null && database.updateTask(id, "Bekliyor", task.details);
    }

    public boolean complete(long id, String result) {
        return database.updateTask(id, "Tamamlandı", result == null ? "" : result);
    }
}
