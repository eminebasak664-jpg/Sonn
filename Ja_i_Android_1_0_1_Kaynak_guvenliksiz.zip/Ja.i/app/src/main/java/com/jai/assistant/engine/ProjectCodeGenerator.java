package com.jai.assistant.engine;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Yerel, kurallı proje kaynak üreticisi.
 * Doğal dil isteğini desteklenen özelliklere ayırır ve birden çok gerçek kaynak dosyası üretir.
 * Haricî model veya ağ kullanmaz; desteklenmeyen gereksinimleri sessizce taklit etmez.
 */
public final class ProjectCodeGenerator {
    public static final class Project {
        public final String title;
        public final String kind;
        public final Map<String, String> files;
        public final List<String> features;
        public final String explanation;

        private Project(String title, String kind, Map<String, String> files,
                        List<String> features, String explanation) {
            this.title = title;
            this.kind = kind;
            this.files = Collections.unmodifiableMap(new LinkedHashMap<>(files));
            this.features = Collections.unmodifiableList(new ArrayList<>(features));
            this.explanation = explanation;
        }
    }

    private static final String[] CREATE_VERBS = {
            "yap", "yapma", "oluştur", "olustur", "üret", "uret", "yaz", "kodla", "hazırla", "hazirla"
    };

    public Project generate(String prompt) {
        String raw = prompt == null ? "" : prompt.trim();
        String text = normalize(raw);
        if (text.isEmpty()) return null;

        boolean game = containsAny(text, "oyun", "game", "quiz", "bilgi yarismasi", "hafiza karti", "refleks testi", "x-o", "clicker");
        boolean website = containsAny(text, "web sitesi", "internet sitesi", "web sayfasi", "web projesi", "html web", "portfolyo", "landing page", "tanitim sitesi", "anasayfa", "html sitesi", "site yap");
        boolean app = containsAny(text, "uygulama", "app", "panel", "dashboard", "arac seti", "arac uygulamasi");
        boolean hasFeature = hasFeatureKeyword(text);
        boolean hasCreateVerb = containsAny(text, CREATE_VERBS);
        boolean questionOnly = containsAny(text, "kurallari nelerdir", "kurallari", "nasil oynanir", "nasil yapilir", "nedir", "anlat")
                && !hasCreateVerb;
        if (questionOnly) return null;
        if (!game && !website && !app && !(hasFeature && hasCreateVerb)) return null;

        LinkedHashSet<String> features = new LinkedHashSet<>();
        if (containsAny(text, "x-o", "x o", "tic tac toe", "tic-tac-toe", "uc tas", "uc tas oyunu")) features.add("xo");
        if (containsAny(text, "hafiza oyunu", "hafiza karti", "eslestirme oyunu", "kart eslestirme", "memory game")) features.add("memory");
        if (containsAny(text, "reaksiyon", "refleks oyunu", "refleks testi", "tepki suresi", "reaction game")) features.add("reaction");
        if (containsAny(text, "quiz", "bilgi yarismasi", "bilgi yarismasi", "sinav oyunu", "soru oyunu", "test uygulamasi")) features.add("quiz");
        if (containsAny(text, "tiklama oyunu", "tiklayarak puan", "clicker", "tiklama ile puan", "tiklama") && game) features.add("clicker");
        if (containsAny(text, "sayac", "sayaç", "puan", "skor", "score", "tiklama sayaci", "tıklama sayacı")) features.add("counter");
        if (containsAny(text, "gorev listesi", "yapilacak", "yapılacak", "todo", "alisveris listesi", "alışveriş listesi", "liste uygulamasi")) features.add("todo");
        if (containsAny(text, "not defteri", "not uygulamasi", "not al", "notlar", "notes")) features.add("notes");
        if (containsAny(text, "hesap makinesi", "calculator", "dort islem", "dört işlem")) features.add("calculator");
        if (containsAny(text, "kronometre", "zamanlayici", "zamanlayıcı", "sure tut", "süre tut", "stopwatch", "timer")) features.add("timer");

        if (features.contains("clicker")) features.remove("counter");
        if (app && features.isEmpty()) {
            features.add("todo");
            features.add("notes");
        }
        if (website && features.isEmpty()) features.add("showcase");
        if (features.isEmpty()) return null;

        String title = extractTitle(raw, game, website, app, features);
        String slug = slug(title);
        String accent = accentColor(text);
        String description = extractDescription(raw);
        String html = buildHtml(title, description, features);
        String css = buildCss(accent);
        String js = buildJavaScript(slug, features);
        String readme = buildReadme(title, description, features);

        Map<String, String> files = new LinkedHashMap<>();
        files.put("index.html", html);
        files.put("styles.css", css);
        files.put("app.js", js);
        files.put("README.md", readme);

        String kind = app ? "web uygulaması" : game ? "oyun" : website ? "web sitesi" : "web uygulaması";
        List<String> labels = featureLabels(features);
        String explanation = "Yerel proje oluşturucu " + kind + " projesini özellikleri birleştirerek üretti. "
                + "Üretilen dosyalar: " + String.join(", ", files.keySet()) + ". Özellikler: "
                + String.join(", ", labels) + ". Proje haricî kütüphane veya ağ bağlantısı gerektirmez. "
                + "Kaynaklar yapısal olarak kontrol edilebilir; gerçek tarayıcı/cihaz testi ayrıca yapılmalıdır.";
        return new Project(title, kind, files, labels, explanation);
    }

    private boolean hasFeatureKeyword(String text) {
        return containsAny(text, "sayac", "puan", "skor", "gorev listesi", "yapilacak", "todo",
                "not defteri", "not uygulamasi", "notlar", "hafiza karti", "hafiza oyunu", "eslestirme oyunu", "hesap makinesi", "calculator", "kronometre",
                "zamanlayici", "quiz", "bilgi yarismasi", "hafiza oyunu", "eslestirme oyunu",
                "reaksiyon", "refleks", "x-o", "tic tac toe", "tiklama oyunu", "portfolyo", "tanitim sitesi");
    }

    private String buildHtml(String title, String description, Set<String> features) {
        StringBuilder out = new StringBuilder(4096);
        out.append("<!doctype html>\n<html lang=\"tr\">\n<head>\n")
                .append("  <meta charset=\"utf-8\">\n")
                .append("  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n")
                .append("  <meta name=\"theme-color\" content=\"#101827\">\n")
                .append("  <title>").append(htmlEscape(title)).append("</title>\n")
                .append("  <link rel=\"stylesheet\" href=\"styles.css\">\n</head>\n<body>\n")
                .append("  <header class=\"topbar\"><a class=\"brand\" href=\"#top\">").append(htmlEscape(title)).append("</a>")
                .append("<span class=\"local-badge\">Çevrimdışı çalışır</span></header>\n")
                .append("  <main id=\"top\" class=\"container\">\n")
                .append("    <section class=\"hero\"><p class=\"eyebrow\">JA.I · YEREL PROJE</p><h1>")
                .append(htmlEscape(title)).append("</h1><p class=\"intro\">")
                .append(htmlEscape(description.isEmpty() ? "İhtiyacına göre oluşturulmuş, cihazında çalışan küçük bir proje." : description))
                .append("</p></section>\n");
        for (String feature : features) out.append(featureMarkup(feature));
        out.append("  </main>\n  <footer>Veriler bu tarayıcının yerel depolamasında tutulur. · Ja.i yerel proje üreticisi</footer>\n")
                .append("  <script src=\"app.js\" defer></script>\n</body>\n</html>\n");
        return out.toString();
    }

    private String featureMarkup(String feature) {
        switch (feature) {
            case "counter":
            case "clicker":
                return "    <section class=\"card feature\" data-feature=\"counter\"><h2>" + ("clicker".equals(feature) ? "Tıklama oyunu" : "Puan sayacı") + "</h2>"
                        + "<p class=\"big-number\" id=\"counter-value\">0</p><div class=\"actions\"><button id=\"counter-minus\" class=\"secondary\">Azalt</button>"
                        + "<button id=\"counter-plus\">Artır</button><button id=\"counter-reset\" class=\"ghost\">Sıfırla</button></div></section>\n";
            case "todo":
                return "    <section class=\"card feature\" data-feature=\"todo\"><h2>Görev listesi</h2><form id=\"todo-form\" class=\"inline-form\"><label class=\"sr-only\" for=\"todo-input\">Yeni görev</label>"
                        + "<input id=\"todo-input\" maxlength=\"160\" placeholder=\"Yeni görev yaz…\" required><button type=\"submit\">Ekle</button></form><ul id=\"todo-list\" class=\"item-list\"></ul></section>\n";
            case "notes":
                return "    <section class=\"card feature\" data-feature=\"notes\"><h2>Not defteri</h2><label class=\"sr-only\" for=\"notes-text\">Notların</label>"
                        + "<textarea id=\"notes-text\" rows=\"5\" maxlength=\"20000\" placeholder=\"Notlarını buraya yaz…\"></textarea><div class=\"actions\"><button id=\"notes-save\">Notu kaydet</button><span id=\"notes-status\" class=\"muted\" aria-live=\"polite\"></span></div></section>\n";
            case "calculator":
                return "    <section class=\"card feature\" data-feature=\"calculator\"><h2>Hesap makinesi</h2><div class=\"calc-grid\"><label>İlk sayı<input id=\"calc-a\" type=\"number\" step=\"any\" value=\"12\"></label>"
                        + "<label>İşlem<select id=\"calc-op\"><option value=\"+\">+</option><option value=\"-\">−</option><option value=\"*\">×</option><option value=\"/\">÷</option></select></label>"
                        + "<label>İkinci sayı<input id=\"calc-b\" type=\"number\" step=\"any\" value=\"8\"></label></div><button id=\"calc-run\">Hesapla</button><p id=\"calc-result\" class=\"result\" aria-live=\"polite\">Sonuç burada görünür.</p></section>\n";
            case "timer":
                return "    <section class=\"card feature\" data-feature=\"timer\"><h2>Kronometre</h2><p id=\"timer-display\" class=\"big-number\">00:00.0</p><div class=\"actions\"><button id=\"timer-start\">Başlat</button><button id=\"timer-reset\" class=\"secondary\">Sıfırla</button></div></section>\n";
            case "quiz":
                return "    <section class=\"card feature\" data-feature=\"quiz\"><h2>Bilgi yarışması</h2><p id=\"quiz-count\" class=\"muted\"></p><h3 id=\"quiz-question\">Hazır mısın?</h3><div id=\"quiz-options\" class=\"option-list\"></div><p id=\"quiz-feedback\" aria-live=\"polite\" class=\"result\"></p><button id=\"quiz-next\" class=\"secondary\" disabled>Sonraki soru</button></section>\n";
            case "memory":
                return "    <section class=\"card feature\" data-feature=\"memory\"><h2>Hafıza kartları</h2><p class=\"muted\">Aynı simgeleri eşleştir.</p><div id=\"memory-board\" class=\"memory-board\"></div><p id=\"memory-status\" aria-live=\"polite\" class=\"result\"></p><button id=\"memory-reset\" class=\"secondary\">Yeniden başlat</button></section>\n";
            case "reaction":
                return "    <section class=\"card feature\" data-feature=\"reaction\"><h2>Refleks testi</h2><p id=\"reaction-status\" class=\"muted\">Başlat'a bas, yeşil olduğunda mümkün olduğunca hızlı dokun.</p><button id=\"reaction-button\" class=\"reaction-button\">Başlat</button><p id=\"reaction-result\" class=\"result\" aria-live=\"polite\"></p></section>\n";
            case "xo":
                return "    <section class=\"card feature\" data-feature=\"xo\"><h2>X-O oyunu</h2><p id=\"xo-status\" class=\"muted\">Sıra: X</p><div id=\"xo-board\" class=\"xo-board\">"
                        + "<button data-cell=\"0\" aria-label=\"1. hücre\"></button><button data-cell=\"1\" aria-label=\"2. hücre\"></button><button data-cell=\"2\" aria-label=\"3. hücre\"></button>"
                        + "<button data-cell=\"3\" aria-label=\"4. hücre\"></button><button data-cell=\"4\" aria-label=\"5. hücre\"></button><button data-cell=\"5\" aria-label=\"6. hücre\"></button>"
                        + "<button data-cell=\"6\" aria-label=\"7. hücre\"></button><button data-cell=\"7\" aria-label=\"8. hücre\"></button><button data-cell=\"8\" aria-label=\"9. hücre\"></button></div><button id=\"xo-reset\" class=\"secondary\">Yeniden başlat</button></section>\n";
            default:
                return "    <section class=\"card feature\"><h2>Hoş geldin</h2><p>Bu sayfa çevrimdışı kullanım için hazırlandı.</p></section>\n";
        }
    }

    private String buildCss(String accent) {
        return ":root{color-scheme:dark;--bg:#0b1020;--panel:#141d2f;--panel2:#1b2940;--text:#eef2ff;--muted:#aab6cf;--accent:" + accent + ";--border:#2a3852}"
                + "*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top right,#1b2b48 0,#0b1020 42%);color:var(--text);font:16px/1.55 system-ui,-apple-system,Segoe UI,sans-serif;min-height:100vh}"
                + ".topbar{position:sticky;top:0;z-index:2;display:flex;justify-content:space-between;align-items:center;padding:14px max(18px,calc((100% - 900px)/2));background:#0b1020eF;border-bottom:1px solid var(--border);backdrop-filter:blur(12px)}"
                + ".brand{font-weight:800;color:var(--text);text-decoration:none}.local-badge,.eyebrow{color:var(--accent);font-size:.78rem;font-weight:700;letter-spacing:.08em}.container{width:min(900px,calc(100% - 28px));margin:28px auto 54px}.hero{padding:24px 4px 18px}.hero h1{font-size:clamp(2rem,7vw,3.6rem);line-height:1.08;margin:8px 0 12px}.intro,.muted{color:var(--muted)}"
                + ".card{background:linear-gradient(145deg,var(--panel),#111a2b);border:1px solid var(--border);border-radius:20px;padding:20px;margin:16px 0;box-shadow:0 12px 30px #0003}.card h2{margin:0 0 16px}.big-number{font-size:clamp(2.5rem,10vw,4rem);font-weight:800;text-align:center;margin:12px 0 20px}.actions,.inline-form{display:flex;gap:10px;align-items:center;flex-wrap:wrap}button{border:0;border-radius:12px;padding:12px 18px;background:var(--accent);color:#0b1020;font-weight:800;font-size:1rem;cursor:pointer;min-height:44px}button:disabled{opacity:.45;cursor:not-allowed}.secondary{background:var(--panel2);color:var(--text);border:1px solid var(--border)}.ghost{background:transparent;color:var(--muted);border:1px solid var(--border)}input,textarea,select{width:100%;min-width:0;border:1px solid var(--border);border-radius:10px;padding:12px;background:#0d1626;color:var(--text);font:inherit}textarea{resize:vertical}.inline-form input{flex:1}.item-list{padding-left:22px}.item-list li{padding:9px 0;border-bottom:1px solid var(--border)}.item-list li.done{text-decoration:line-through;color:var(--muted)}.item-list button{padding:5px 9px;min-height:32px;margin-left:8px;font-size:.8rem}.calc-grid{display:grid;grid-template-columns:2fr 1fr 2fr;gap:10px;margin-bottom:12px}.calc-grid label{font-size:.85rem;color:var(--muted)}.result{color:var(--accent);font-weight:700;min-height:1.5em}.option-list{display:grid;gap:9px;margin:15px 0}.option-list button{text-align:left;background:var(--panel2);color:var(--text);border:1px solid var(--border)}.memory-board,.xo-board{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin:15px 0}.memory-board button{font-size:1.6rem;min-height:64px;padding:6px}.xo-board{grid-template-columns:repeat(3,1fr);max-width:340px}.xo-board button{font-size:2rem;min-height:82px;background:var(--panel2);color:var(--text);border:1px solid var(--border)}.reaction-button{width:100%;min-height:110px;background:#334155;color:white}.reaction-button.ready{background:#16a34a;color:#04120a}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}footer{text-align:center;color:var(--muted);padding:24px 12px;border-top:1px solid var(--border);font-size:.8rem}@media(max-width:560px){.calc-grid{grid-template-columns:1fr 1fr}.calc-grid label:first-child{grid-column:span 2}.card{padding:16px}.topbar{padding:12px 16px}}";
    }

    private String buildJavaScript(String slug, Set<String> features) {
        StringBuilder js = new StringBuilder("'use strict';\n\n(function(){\n  const STORAGE_PREFIX = ")
                .append(jsString("jai-project-" + slug + "-" )).append(";\n")
                .append("  function readJson(key, fallback){try{const value=localStorage.getItem(STORAGE_PREFIX+key);return value===null?fallback:JSON.parse(value);}catch(_){return fallback;}}\n")
                .append("  function writeJson(key, value){try{localStorage.setItem(STORAGE_PREFIX+key,JSON.stringify(value));return true;}catch(_){return false;}}\n\n");
        for (String feature : features) {
            switch (feature) {
                case "counter":
                case "clicker": js.append(counterJs()); break;
                case "todo": js.append(todoJs()); break;
                case "notes": js.append(notesJs()); break;
                case "calculator": js.append(calculatorJs()); break;
                case "timer": js.append(timerJs()); break;
                case "quiz": js.append(quizJs()); break;
                case "memory": js.append(memoryJs()); break;
                case "reaction": js.append(reactionJs()); break;
                case "xo": js.append(xoJs()); break;
                default: break;
            }
            js.append('\n');
        }
        js.append("})();\n");
        return js.toString();
    }

    private String counterJs() {
        return "  // Puan sayacı: değer cihazda saklanır.\n"
                + "  const counterValue=document.getElementById('counter-value');\n"
                + "  if(counterValue){let count=Number(readJson('counter',0))||0;const render=()=>counterValue.textContent=String(count);render();\n"
                + "    document.getElementById('counter-plus').addEventListener('click',()=>{count++;writeJson('counter',count);render();});\n"
                + "    document.getElementById('counter-minus').addEventListener('click',()=>{count--;writeJson('counter',count);render();});\n"
                + "    document.getElementById('counter-reset').addEventListener('click',()=>{count=0;writeJson('counter',count);render();});}\n";
    }

    private String todoJs() {
        return "  // Görev listesi: ekle, tamamla ve sil.\n"
                + "  const todoForm=document.getElementById('todo-form');\n"
                + "  if(todoForm){const input=document.getElementById('todo-input'),list=document.getElementById('todo-list');let items=readJson('todos',[]);if(!Array.isArray(items))items=[];\n"
                + "    const save=()=>writeJson('todos',items);const render=()=>{list.replaceChildren();items.forEach(item=>{const li=document.createElement('li');if(item.done)li.classList.add('done');const label=document.createElement('span');label.textContent=item.text;li.appendChild(label);const done=document.createElement('button');done.type='button';done.className='secondary';done.textContent=item.done?'Geri al':'Bitti';done.addEventListener('click',()=>{item.done=!item.done;save();render();});const remove=document.createElement('button');remove.type='button';remove.className='ghost';remove.textContent='Sil';remove.addEventListener('click',()=>{items=items.filter(x=>x.id!==item.id);save();render();});li.append(done,remove);list.appendChild(li);});};\n"
                + "    todoForm.addEventListener('submit',event=>{event.preventDefault();const text=input.value.trim();if(!text)return;items.push({id:Date.now()+Math.random(),text,done:false});input.value='';save();render();input.focus();});render();}\n";
    }

    private String notesJs() {
        return "  // Notlar otomatik olarak bu cihazda saklanır.\n"
                + "  const notesText=document.getElementById('notes-text');if(notesText){notesText.value=readJson('notes','');const status=document.getElementById('notes-status');\n"
                + "    document.getElementById('notes-save').addEventListener('click',()=>{const ok=writeJson('notes',notesText.value);status.textContent=ok?'Kaydedildi.':'Tarayıcı depolaması kullanılamıyor.';});}\n";
    }

    private String calculatorJs() {
        return "  // eval kullanılmayan dört işlem hesaplayıcısı.\n"
                + "  const calcRun=document.getElementById('calc-run');if(calcRun){calcRun.addEventListener('click',()=>{const a=Number(document.getElementById('calc-a').value),b=Number(document.getElementById('calc-b').value),op=document.getElementById('calc-op').value,result=document.getElementById('calc-result');\n"
                + "    if(!Number.isFinite(a)||!Number.isFinite(b)){result.textContent='Geçerli iki sayı gir.';return;}if(op==='/'&&b===0){result.textContent='Sıfıra bölme yapılamaz.';return;}const values={'+':()=>a+b,'-':()=>a-b,'*':()=>a*b,'/':()=>a/b};result.textContent='Sonuç: '+String(values[op]());});}\n";
    }

    private String timerJs() {
        return "  // Kronometre: geçen süre Date.now() ile ölçülür.\n"
                + "  const timerDisplay=document.getElementById('timer-display');if(timerDisplay){let started=0,elapsed=0,interval=null;const render=()=>{const ms=elapsed+(started?Date.now()-started:0),tenths=Math.floor(ms/100),seconds=Math.floor(tenths/10)%60,minutes=Math.floor(tenths/600);timerDisplay.textContent=String(minutes).padStart(2,'0')+':'+String(seconds).padStart(2,'0')+'.'+(tenths%10);};\n"
                + "    document.getElementById('timer-start').addEventListener('click',event=>{if(started){elapsed+=Date.now()-started;started=0;clearInterval(interval);interval=null;event.currentTarget.textContent='Devam et';}else{started=Date.now();event.currentTarget.textContent='Duraklat';if(!interval)interval=setInterval(render,100);}render();});\n"
                + "    document.getElementById('timer-reset').addEventListener('click',()=>{started=0;elapsed=0;clearInterval(interval);interval=null;document.getElementById('timer-start').textContent='Başlat';render();});render();}\n";
    }

    private String quizJs() {
        return "  // Örnek sorular app.js içindeki bu dizi düzenlenerek değiştirilebilir.\n"
                + "  const quizOptions=document.getElementById('quiz-options');if(quizOptions){const questions=[{q:'JavaScript hangi ortamda çalışabilir?',a:['Tarayıcıda','Yalnızca yazıcıda','Sadece BIOS içinde'],correct:0},{q:'HTML neyi tanımlar?',a:['Sayfanın yapısını','Pil voltajını','Ağ kablosunu'],correct:0},{q:'CSS ne için kullanılır?',a:['Görünüm ve düzen','Veritabanı yedeği','Ses kaydı'],correct:0}];let index=0,score=0,answered=false;const render=()=>{const item=questions[index];document.getElementById('quiz-count').textContent='Soru '+(index+1)+' / '+questions.length+' · Puan: '+score;document.getElementById('quiz-question').textContent=item.q;document.getElementById('quiz-feedback').textContent='';document.getElementById('quiz-next').disabled=true;quizOptions.replaceChildren();answered=false;item.a.forEach((answer,i)=>{const button=document.createElement('button');button.type='button';button.textContent=answer;button.addEventListener('click',()=>{if(answered)return;answered=true;if(i===item.correct){score++;document.getElementById('quiz-feedback').textContent='Doğru!';}else{document.getElementById('quiz-feedback').textContent='Doğru cevap: '+item.a[item.correct];}document.getElementById('quiz-next').disabled=false;});quizOptions.appendChild(button);});};\n"
                + "    document.getElementById('quiz-next').addEventListener('click',()=>{if(index<questions.length-1){index++;render();}else{document.getElementById('quiz-count').textContent='Tamamlandı · '+score+'/'+questions.length+' doğru';document.getElementById('quiz-question').textContent='Yarışma bitti';quizOptions.replaceChildren();document.getElementById('quiz-next').disabled=true;}});render();}\n";
    }

    private String memoryJs() {
        return "  // Hafıza kartları: eşleri bul.\n"
                + "  const memoryBoard=document.getElementById('memory-board');if(memoryBoard){const symbols=['◆','●','▲','★','☀','♥'];let deck=[],opened=[],matched=0,locked=false;const status=document.getElementById('memory-status');const start=()=>{deck=[...symbols,...symbols].sort(()=>Math.random()-.5);opened=[];matched=0;locked=false;memoryBoard.replaceChildren();deck.forEach((symbol,index)=>{const button=document.createElement('button');button.type='button';button.className='secondary';button.textContent='?';button.dataset.index=String(index);button.addEventListener('click',()=>{if(locked||button.dataset.open==='1'||button.dataset.matched==='1')return;button.dataset.open='1';button.textContent=symbol;opened.push(button);if(opened.length===2){locked=true;if(opened[0].textContent===opened[1].textContent){opened.forEach(x=>x.dataset.matched='1');matched++;opened=[];locked=false;status.textContent=matched===symbols.length?'Tebrikler, hepsini buldun!':'Eşleşme bulundu.';}else{setTimeout(()=>{opened.forEach(x=>{x.dataset.open='0';x.textContent='?';});opened=[];locked=false;},650);}}});memoryBoard.appendChild(button);});status.textContent='Eşleri bulmaya başla.';};document.getElementById('memory-reset').addEventListener('click',start);start();}\n";
    }

    private String reactionJs() {
        return "  // Refleks testi: erken tıklama ve zaman aşımı durumları ele alınır.\n"
                + "  const reactionButton=document.getElementById('reaction-button');if(reactionButton){let timeout=null,readyAt=0,state='idle';const status=document.getElementById('reaction-status'),result=document.getElementById('reaction-result');const reset=()=>{clearTimeout(timeout);timeout=null;state='idle';reactionButton.classList.remove('ready');reactionButton.textContent='Başlat';};\n"
                + "    reactionButton.addEventListener('click',()=>{if(state==='idle'){state='waiting';result.textContent='';status.textContent='Bekle…';reactionButton.textContent='Bekle';timeout=setTimeout(()=>{state='ready';readyAt=performance.now();reactionButton.classList.add('ready');reactionButton.textContent='ŞİMDİ!';status.textContent='Şimdi dokun!';},1000+Math.random()*2500);}else if(state==='waiting'){reset();status.textContent='Çok erken! Yeniden dene.';}else if(state==='ready'){const ms=Math.round(performance.now()-readyAt);result.textContent='Tepki süren: '+ms+' ms';status.textContent='Güzel! Tekrar deneyebilirsin.';reset();}});}\n";
    }

    private String xoJs() {
        return "  // İki kişilik X-O oyunu ve kazanan kontrolü.\n"
                + "  const xoBoard=document.getElementById('xo-board');if(xoBoard){let cells=Array(9).fill(''),turn='X',finished=false;const wins=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];const status=document.getElementById('xo-status');const render=()=>{xoBoard.querySelectorAll('button').forEach((button,i)=>{button.textContent=cells[i];button.disabled=finished||!!cells[i];});};const reset=()=>{cells=Array(9).fill('');turn='X';finished=false;status.textContent='Sıra: X';render();};\n"
                + "    xoBoard.addEventListener('click',event=>{const button=event.target.closest('button[data-cell]');if(!button||finished)return;const i=Number(button.dataset.cell);if(cells[i])return;cells[i]=turn;const win=wins.some(line=>line.every(index=>cells[index]===turn));if(win){finished=true;status.textContent=turn+' kazandı!';}else if(cells.every(Boolean)){finished=true;status.textContent='Berabere!';}else{turn=turn==='X'?'O':'X';status.textContent='Sıra: '+turn;}render();});document.getElementById('xo-reset').addEventListener('click',reset);reset();}\n";
    }

    private String buildReadme(String title, String description, Set<String> features) {
        StringBuilder out = new StringBuilder("# ").append(title).append("\n\n")
                .append(description.isEmpty() ? "Ja.i tarafından yerel olarak oluşturulan çevrimdışı web projesi." : description)
                .append("\n\n## Çalıştırma\n\n1. ZIP arşivini bir klasöre çıkar.\n2. `index.html` dosyasını modern bir tarayıcıda aç.\n3. İnternet bağlantısı gerekmez; proje haricî kütüphane yüklemez.\n\n## Dosyalar\n\n- `index.html`: sayfa yapısı\n- `styles.css`: mobil uyumlu görünüm\n- `app.js`: etkileşim ve yerel kayıt\n\n## İçerilen özellikler\n\n");
        for (String feature : featureLabels(features)) out.append("- ").append(feature).append('\n');
        out.append("\n## Veri ve güvenlik\n\n- Uygulama verileri tarayıcının `localStorage` alanında saklanır.\n- Ağ isteği, uzaktaki API veya üçüncü taraf kitaplık kullanılmaz.\n- Tarayıcı verileri temizlenirse yerel kayıtlar silinebilir.\n- Bu ZIP, kaynak dosyaları içerir; APK veya yerel Android uygulaması değildir.\n");
        return out.toString();
    }

    private List<String> featureLabels(Set<String> features) {
        List<String> labels = new ArrayList<>();
        for (String feature : features) {
            switch (feature) {
                case "counter": labels.add("Kalıcı puan sayacı"); break;
                case "clicker": labels.add("Tıklama oyunu"); break;
                case "todo": labels.add("Görev ekleme, tamamlama ve silme"); break;
                case "notes": labels.add("Yerel not defteri"); break;
                case "calculator": labels.add("Dört işlem hesap makinesi"); break;
                case "timer": labels.add("Kronometre"); break;
                case "quiz": labels.add("Çoktan seçmeli bilgi yarışması"); break;
                case "memory": labels.add("Hafıza kartı eşleştirme oyunu"); break;
                case "reaction": labels.add("Refleks testi"); break;
                case "xo": labels.add("İki kişilik X-O oyunu"); break;
                case "showcase": labels.add("Tanıtım bölümü"); break;
                default: labels.add(feature); break;
            }
        }
        return labels;
    }

    private String extractTitle(String raw, boolean game, boolean website, boolean app, Set<String> features) {
        Pattern quoted = Pattern.compile("(?iu)(?:ad[ıi]|ismi|başlık|baslik)\\s*[:=]?\\s*[\"']([^\"']{2,48})[\"']");
        Matcher matcher = quoted.matcher(raw);
        if (matcher.find()) return cleanTitle(matcher.group(1));
        Pattern named = Pattern.compile("(?iu)([^\\n,.!?]{2,48}?)\\s+adlı\\b");
        matcher = named.matcher(raw);
        if (matcher.find()) return cleanTitle(matcher.group(1));
        if (app && features.size() > 1) return "Yerel Web Uygulaması";
        if (game) {
            if (features.contains("xo")) return "X-O Oyunu";
            if (features.contains("memory")) return "Hafıza Kartları";
            if (features.contains("reaction")) return "Refleks Testi";
            if (features.contains("quiz")) return "Bilgi Yarışması";
            if (features.contains("clicker")) return "Tıklama Oyunu";
        }
        if (website) return "Yerel Web Sayfası";
        if (features.contains("todo") && features.contains("notes")) return "Görev ve Notlar";
        if (features.contains("todo")) return "Görev Listesi";
        if (features.contains("notes")) return "Not Defteri";
        if (features.contains("calculator")) return "Hesap Makinesi";
        if (features.contains("timer")) return "Kronometre";
        if (features.contains("counter")) return "Puan Sayacı";
        if (app) return "Yerel Web Uygulaması";
        return "Ja.i Projesi";
    }

    private String extractDescription(String raw) {
        Matcher matcher = Pattern.compile("(?iu)(?:açıklama|aciklama|amaç|amac|hakkında|hakkinda)\\s*[:=]\\s*([^\\n]{3,180})").matcher(raw);
        return matcher.find() ? matcher.group(1).trim() : "";
    }

    private String cleanTitle(String value) {
        String cleaned = value == null ? "" : value.trim().replaceAll("\\s+", " ");
        if (cleaned.isEmpty()) return "Ja.i Projesi";
        return cleaned.length() > 48 ? cleaned.substring(0, 48).trim() : cleaned;
    }

    private String slug(String value) {
        String normalized = normalize(value).replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
        if (normalized.isEmpty()) normalized = "jai-app";
        return normalized.length() > 36 ? normalized.substring(0, 36) : normalized;
    }

    private String accentColor(String text) {
        if (containsAny(text, "turkuaz", "camgobegi", "cyan")) return "#2dd4bf";
        if (containsAny(text, "mavi", "blue")) return "#60a5fa";
        if (containsAny(text, "yesil", "green")) return "#4ade80";
        if (containsAny(text, "kirmizi", "red")) return "#fb7185";
        if (containsAny(text, "turuncu", "orange")) return "#fb923c";
        if (containsAny(text, "sari", "yellow")) return "#facc15";
        return "#7c5cff";
    }

    private String normalize(String value) {
        String decomposed = Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFD);
        StringBuilder out = new StringBuilder(decomposed.length());
        for (int i = 0; i < decomposed.length(); i++) {
            char c = decomposed.charAt(i);
            if (Character.getType(c) != Character.NON_SPACING_MARK) out.append(c);
        }
        return out.toString().toLowerCase(Locale.ROOT).replace('ı', 'i').replace('ş', 's').replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o').replace('ç', 'c');
    }

    private boolean containsAny(String text, String... values) {
        for (String value : values) if (text.contains(normalize(value))) return true;
        return false;
    }

    private String htmlEscape(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    private String jsString(String value) {
        return "'" + value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "\\r") + "'";
    }
}
