package com.jai.assistant.media;

import org.junit.Test;
import static org.junit.Assert.*;

public final class VideoResourcePolicyTest {
    private static final long MIB = 1024L * 1024L;

    @Test public void choosesHighQualityWhenCpuRamAndStorageAreAvailable() {
        VideoResourcePolicy.Profile profile = VideoResourcePolicy.choose(
                false, 8, 20, 2L * 1024L * MIB, 128L * MIB,
                512L * MIB, 60, 4);
        assertEquals(1280, profile.width);
        assertEquals(720, profile.height);
        assertEquals(24, profile.fps);
    }

    @Test public void reducesQualityOnLowRamDevice() {
        VideoResourcePolicy.Profile profile = VideoResourcePolicy.choose(
                true, 8, 20, 1024L * MIB, 48L * MIB,
                256L * MIB, 30, 4);
        assertEquals(960, profile.width);
        assertEquals(540, profile.height);
        assertEquals(20, profile.fps);
    }

    @Test public void selectsLightProfileWhenCpuAndHeapAreLimited() {
        VideoResourcePolicy.Profile profile = VideoResourcePolicy.choose(
                true, 4, 20, 220L * MIB, 20L * MIB,
                128L * MIB, 20, 4);
        assertEquals(640, profile.width);
        assertEquals(360, profile.height);
        assertEquals(15, profile.fps);
    }

    @Test public void lowersQualityWhenStorageIsLimited() {
        VideoResourcePolicy.Profile profile = VideoResourcePolicy.choose(
                false, 8, 20, 2L * 1024L * MIB, 128L * MIB,
                16L * MIB, 60, 4);
        assertEquals(960, profile.width);
        assertEquals(540, profile.height);
    }

    @Test public void reducesProfileWhenSystemCpuLoadIsHigh() {
        VideoResourcePolicy.Profile profile = VideoResourcePolicy.choose(
                false, 8, 90, 2L * 1024L * MIB, 128L * MIB,
                512L * MIB, 30, 4);
        assertEquals(640, profile.width);
        assertEquals(360, profile.height);
    }

    @Test(expected = IllegalStateException.class)
    public void rejectsVideoWhenThereIsNotEnoughMemory() {
        VideoResourcePolicy.choose(true, 2, 10, 80L * MIB, 8L * MIB,
                128L * MIB, 30, 4);
    }

    @Test(expected = IllegalStateException.class)
    public void rejectsVideoWhenStorageCannotFitEvenTheLightProfile() {
        VideoResourcePolicy.choose(false, 8, 20, 2L * 1024L * MIB, 128L * MIB,
                5L * MIB, 60, 4);
    }
}
