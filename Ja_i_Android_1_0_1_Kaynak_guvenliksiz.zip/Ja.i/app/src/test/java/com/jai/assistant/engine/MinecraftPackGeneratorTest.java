package com.jai.assistant.engine;

import org.junit.Test;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import static org.junit.Assert.*;

public final class MinecraftPackGeneratorTest {
    private Map<String, byte[]> unzip(byte[] bytes) throws Exception {
        Map<String, byte[]> files = new HashMap<>();
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[2048];
                int count;
                while ((count = zip.read(buffer)) != -1) out.write(buffer, 0, count);
                files.put(entry.getName(), out.toByteArray());
            }
        }
        return files;
    }

    @Test public void createsCombinedBedrockAddonWithNestedPacksAnimationsAudioAndScripts() throws Exception {
        MinecraftPackGenerator.Result result = new MinecraftPackGenerator().generate("Minecraft için özel yaratık, gelişmiş animasyon, ses, script ve kaynak/davranış paketi içeren mcaddon yap");
        assertTrue(result.fileName.endsWith(".mcaddon"));
        Map<String, byte[]> outer = unzip(result.archiveBytes);
        assertEquals(3, outer.size());
        assertTrue(outer.containsKey("JAI_PROJE_NOTLARI_TR.md"));
        byte[] resourceBytes = null, behaviorBytes = null;
        for (Map.Entry<String, byte[]> entry : outer.entrySet()) {
            if (entry.getKey().contains("kaynak")) resourceBytes = entry.getValue();
            if (entry.getKey().contains("davranis")) behaviorBytes = entry.getValue();
        }
        assertNotNull(resourceBytes); assertNotNull(behaviorBytes);
        Map<String, byte[]> resource = unzip(resourceBytes);
        Map<String, byte[]> behavior = unzip(behaviorBytes);
        assertTrue(resource.containsKey("manifest.json"));
        assertTrue(behavior.containsKey("manifest.json"));
        assertTrue(behavior.containsKey("entities/jai_companion.json"));
        assertTrue(behavior.containsKey("spawn_rules/jai_companion.json"));
        assertTrue(resource.containsKey("textures/entity/jai_companion.png"));
        assertTrue(resource.containsKey("models/entity/jai_companion.geo.json"));
        assertTrue(behavior.containsKey("items/jai_moon_crystal.json"));
        assertTrue(behavior.containsKey("recipes/jai_moon_crystal.json"));
        assertTrue(behavior.containsKey("blocks/jai_moonstone.json"));
        assertTrue(behavior.containsKey("loot_tables/blocks/jai_moonstone.json"));
        assertTrue(resource.containsKey("textures/terrain_texture.json"));
        assertTrue(resource.containsKey("animations/jai_companion.animation.json"));
        assertTrue(resource.containsKey("animation_controllers/jai_companion.controller.json"));
        assertTrue(resource.containsKey("sounds/sound_definitions.json"));
        assertTrue(resource.containsKey("sounds/mob/jai_companion/attack.ogg"));
        assertTrue(behavior.containsKey("scripts/main.js"));
        String animation = new String(resource.get("animations/jai_companion.animation.json"), java.nio.charset.StandardCharsets.UTF_8);
        for (String name : new String[]{"idle", "walk", "run", "attack", "hurt", "jump", "sit"}) assertTrue(animation.contains("animation.jai_companion." + name));
    }

    @Test public void createsResourceAndBehaviorPacksIndividually() throws Exception {
        MinecraftPackGenerator generator = new MinecraftPackGenerator();
        MinecraftPackGenerator.Result resource = generator.generate("Minecraft kaynak paketi yap");
        MinecraftPackGenerator.Result behavior = generator.generate("Minecraft davranış paketi yap");
        assertTrue(resource.fileName.endsWith(".mcpack"));
        assertTrue(behavior.fileName.endsWith(".mcpack"));
        assertTrue(unzip(resource.archiveBytes).containsKey("manifest.json"));
        Map<String, byte[]> resourceFiles = unzip(resource.archiveBytes);
        Map<String, byte[]> behaviorFiles = unzip(behavior.archiveBytes);
        assertTrue(resourceFiles.containsKey("textures/blocks/dirt.png"));
        assertTrue(resourceFiles.containsKey("animations/jai_companion.animation.json"));
        assertTrue(resourceFiles.containsKey("sounds/mob/jai_companion/idle.ogg"));
        assertTrue(behaviorFiles.containsKey("recipes/jai_golden_apple.json"));
        assertTrue(behaviorFiles.containsKey("entities/jai_companion.json"));
        assertTrue(behaviorFiles.containsKey("blocks/jai_moonstone.json"));
        assertTrue(behaviorFiles.containsKey("scripts/main.js"));
    }

    @Test public void doesNotMistakeMinecraftLikeGameEngineForPackRequest() {
        assertFalse(new MinecraftPackGenerator().isMinecraftPackRequest("3D Minecraft benzeri oyun motoru yap"));
    }

    @Test public void createsMcworldContainerWithLevelAndPacks() throws Exception {
        MinecraftPackGenerator.Result result = new MinecraftPackGenerator().generate("Minecraft için mcworld dünya oluştur");
        assertTrue(result.fileName.endsWith(".mcworld"));
        Map<String, byte[]> files = unzip(result.archiveBytes);
        assertTrue(files.containsKey("level.dat"));
        assertTrue(files.containsKey("levelname.txt"));
        assertTrue(files.containsKey("db/"));
        assertTrue(files.containsKey("world_resource_packs.json"));
        assertTrue(files.containsKey("world_behavior_packs.json"));
        byte[] level = files.get("level.dat");
        assertEquals(10, level[0] & 255);
    }

    @Test public void createsRunnableJavaJarContainer() throws Exception {
        MinecraftPackGenerator.Result result = new MinecraftPackGenerator().generate("Java JAR yap");
        assertTrue(result.fileName.endsWith(".jar"));
        Map<String, byte[]> files = unzip(result.archiveBytes);
        assertTrue(files.containsKey("META-INF/MANIFEST.MF"));
        assertTrue(files.containsKey("Main.class"));
        assertEquals((byte) 0xca, files.get("Main.class")[0]);
        assertEquals((byte) 0xfe, files.get("Main.class")[1]);
    }


    @Test public void honorsBedrock121321ProfileAndSplits999AcrossLegalStacks() throws Exception {
        String request = "Minecraft Bedrock 1.21.132.1 için mod yap; itemler sınırlı tutuluyor ya 999 tutalım.";
        MinecraftPackGenerator.Result result = new MinecraftPackGenerator().generate(request,
                "Resmî kaynak notu: Bedrock manifest ve custom item bileşenleri.");
        assertTrue(result.fileName.endsWith(".mcaddon"));
        Map<String, byte[]> outer = unzip(result.archiveBytes);
        assertTrue(new String(outer.get("JAI_PROJE_NOTLARI_TR.md"), java.nio.charset.StandardCharsets.UTF_8)
                .contains("Resmî kaynak notu"));
        byte[] behaviorBytes = null;
        for (Map.Entry<String, byte[]> entry : outer.entrySet()) if (entry.getKey().endsWith("-davranis.mcpack")) behaviorBytes = entry.getValue();
        assertNotNull(behaviorBytes);
        Map<String, byte[]> behavior = unzip(behaviorBytes);
        String manifest = new String(behavior.get("manifest.json"), java.nio.charset.StandardCharsets.UTF_8);
        assertTrue(manifest.contains("[1, 21, 132]"));
        assertTrue(manifest.contains("\"module_name\": \"@minecraft/server\""));
        assertTrue(manifest.contains("\"version\": \"2.4.0\""));
        String function = new String(behavior.get("functions/jai/give_ozel_esya_999.mcfunction"), java.nio.charset.StandardCharsets.UTF_8);
        int total = 0, lines = 0, max = 0;
        for (String line : function.split("\\R")) if (line.startsWith("give ")) {
            int amount = Integer.parseInt(line.substring(line.lastIndexOf(' ') + 1));
            total += amount; lines++; max = Math.max(max, amount);
        }
        assertEquals(999, total);
        assertEquals(16, lines);
        assertTrue(max <= 64);
        String item = new String(behavior.get("items/ozel_esya.json"), java.nio.charset.StandardCharsets.UTF_8);
        assertTrue(item.contains("\"minecraft:max_stack_size\": 64"));
    }
    @Test public void personalizesCreatureAndItemsFromNaturalLanguageRequest() throws Exception {
        MinecraftPackGenerator.Result result = new MinecraftPackGenerator().generate(
                "Minecraft Bedrock ejderha modu yap; itemler: Parıltı Kristali, Işık Feneri; 999 adet ver.",
                "Araştırma: ejderha kanatları, saldırı animasyonu ve Bedrock item tanımları.");
        Map<String, byte[]> outer = unzip(result.archiveBytes);
        byte[] behaviorBytes = null;
        for (Map.Entry<String, byte[]> entry : outer.entrySet()) if (entry.getKey().endsWith("-davranis.mcpack")) behaviorBytes = entry.getValue();
        assertNotNull(behaviorBytes);
        Map<String, byte[]> behavior = unzip(behaviorBytes);
        assertTrue(behavior.containsKey("entities/jai_dragon.json"));
        assertTrue(behavior.containsKey("items/parilti_kristali.json"));
        assertTrue(behavior.containsKey("items/isik_feneri.json"));
        String script = new String(behavior.get("scripts/main.js"), java.nio.charset.StandardCharsets.UTF_8);
        assertTrue(script.contains("jai:dragon"));
        String manifest = new String(behavior.get("manifest.json"), java.nio.charset.StandardCharsets.UTF_8);
        assertTrue(manifest.contains("\"version\": \"2.4.0\""));
        Map<String, byte[]> resource = null;
        for (Map.Entry<String, byte[]> entry : outer.entrySet()) {
            if (entry.getKey().endsWith("-kaynak.mcpack")) resource = unzip(entry.getValue());
        }
        assertNotNull(resource);
        String geometry = new String(resource.get("models/entity/jai_dragon.geo.json"), java.nio.charset.StandardCharsets.UTF_8);
        String animations = new String(resource.get("animations/jai_dragon.animation.json"), java.nio.charset.StandardCharsets.UTF_8);
        assertTrue(geometry.contains("left_wing"));
        assertTrue(geometry.contains("right_wing"));
        assertTrue(geometry.contains("tail_tip"));
        assertTrue(animations.contains("left_wing"));
        assertTrue(animations.contains("right_wing"));
        String entity = new String(behavior.get("entities/jai_dragon.json"), java.nio.charset.StandardCharsets.UTF_8);
        assertTrue(entity.contains("minecraft:movement.fly"));
        assertTrue(entity.contains("minecraft:navigation.fly"));
        assertTrue(entity.contains("minecraft:behavior.random_fly"));
        assertTrue(entity.contains("\"value\": 200"));
    }

    @Test public void createsWingedDragonGeometryAnimationAndFlightBehavior() throws Exception {
        MinecraftPackGenerator.Result result = new MinecraftPackGenerator().generate(
                "Minecraft Bedrock ejderha modu yap; itemler: Parıltı Kristali, Işık Feneri; 999 adet ver.",
                "Uçuş: movement.fly, navigation.fly, random_fly; kanat kemikleri için animasyon anahtar kareleri.");
        Map<String, byte[]> outer = unzip(result.archiveBytes);
        Map<String, byte[]> resource = null;
        Map<String, byte[]> behavior = null;
        for (Map.Entry<String, byte[]> entry : outer.entrySet()) {
            if (entry.getKey().endsWith("-kaynak.mcpack")) resource = unzip(entry.getValue());
            if (entry.getKey().endsWith("-davranis.mcpack")) behavior = unzip(entry.getValue());
        }
        assertNotNull(resource);
        assertNotNull(behavior);
        String geometry = new String(resource.get("models/entity/jai_dragon.geo.json"), java.nio.charset.StandardCharsets.UTF_8);
        String animations = new String(resource.get("animations/jai_dragon.animation.json"), java.nio.charset.StandardCharsets.UTF_8);
        String entity = new String(behavior.get("entities/jai_dragon.json"), java.nio.charset.StandardCharsets.UTF_8);
        assertTrue(geometry.contains("left_wing"));
        assertTrue(geometry.contains("right_wing"));
        assertTrue(geometry.contains("tail_tip"));
        assertTrue(animations.contains("left_wing"));
        assertTrue(animations.contains("right_wing"));
        assertTrue(entity.contains("minecraft:movement.fly"));
        assertTrue(entity.contains("minecraft:navigation.fly"));
        assertTrue(entity.contains("minecraft:behavior.random_fly"));
    }

    @Test public void rejectsDisallowedEquipmentInItemGeneration() {
        try {
            new MinecraftPackGenerator().generate("Minecraft Bedrock mod yap; itemler: Savaş Kılıcı, Işık Feneri.");
            fail("Kısıtlı içerik sessizce üretilmemeli.");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("dekoratif"));
        } catch (Exception unexpected) {
            fail("Beklenmeyen hata: " + unexpected.getMessage());
        }
    }

}
