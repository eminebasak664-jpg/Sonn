package com.jai.assistant.engine;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public final class VideoScenePlannerTest {
    @Test public void createsSeveralShotsFromOneIdeaAndUsesResearchNotes() {
        List<String> scenes = VideoScenePlanner.plan("Bir ejderha dağların üzerinde uçsun, video yap", "Araştırma: ejderhaların kanat yapısı ve dağ coğrafyası.");
        assertTrue(scenes.size() >= 3);
        assertTrue(scenes.get(0).contains("geniş açı"));
        assertTrue(scenes.get(1).contains("yakın plan"));
        assertTrue(scenes.get(2).contains("dinamik aksiyon"));
        assertTrue(scenes.get(0).contains("Araştırılmış tasarım bilgisi"));
    }

    @Test public void keepsExplicitScenesWhenPromptContainsSceneMarkers() {
        List<String> scenes = VideoScenePlanner.plan("Sahne 1: uzay gemisi kalksın. Sahne 2: gezegene yaklaşsın. Sahne 3: iniş yapsın.", "");
        assertTrue(scenes.size() >= 2);
        assertTrue(scenes.get(0).contains("uzay gemisi"));
        assertTrue(scenes.get(1).contains("gezegene yaklaşsın"));
    }
}
