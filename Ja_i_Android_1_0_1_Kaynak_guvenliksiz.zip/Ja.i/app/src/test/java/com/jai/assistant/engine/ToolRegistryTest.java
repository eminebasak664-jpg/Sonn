package com.jai.assistant.engine;

import org.junit.Test;
import static org.junit.Assert.*;

public final class ToolRegistryTest {
    @Test public void selectsHighestScoringMatchingTool() {
        ToolRegistry registry = new ToolRegistry();
        registry.register("weak", input -> "weak", request -> request.contains("ram") ? 20 : 0, request -> request);
        registry.register("strong", input -> "strong", request -> request.contains("ram") ? 80 : 0, request -> request.trim());
        ToolRegistry.Selection selection = registry.selectBest("ram durumu");
        assertNotNull(selection);
        assertEquals("strong", selection.name);
        assertEquals(80, selection.score);
    }

    @Test public void doesNotSelectToolWithoutMatchingRule() {
        ToolRegistry registry = new ToolRegistry();
        registry.register("calculator", input -> input, request -> request.matches(".*[0-9]+\\s*[+*/-]\\s*[0-9]+.*") ? 100 : 0, request -> request);
        assertNull(registry.selectBest("merhaba"));
    }

    @Test public void executesSelectedTool() throws Exception {
        ToolRegistry registry = new ToolRegistry();
        registry.register("echo", input -> "sonuç:" + input, request -> 10, String::trim);
        assertEquals("sonuç:deneme", registry.execute(registry.selectBest(" deneme ")));
    }
}
