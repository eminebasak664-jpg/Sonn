package com.jai.assistant.server;

import org.junit.Test;
import static org.junit.Assert.*;

public class ServerUrlRulesTest {
    @Test public void acceptsHttpsHostAndPort() throws Exception {
        assertEquals("https://example.com:8443", ServerUrlRules.normalizeBaseUrl("https://example.com:8443"));
    }
    @Test public void rejectsPlainHttp() {
        try { ServerUrlRules.normalizeBaseUrl("http://example.com"); fail("HTTP reddedilmeli"); }
        catch (Exception expected) { assertTrue(expected.getMessage().contains("https")); }
    }
    @Test public void rejectsEmbeddedPath() {
        try { ServerUrlRules.normalizeBaseUrl("https://example.com/api"); fail("Yol ayrı alanda olmalı"); }
        catch (Exception expected) { assertTrue(expected.getMessage().contains("yol")); }
    }
    @Test public void rejectsUserInfoAndQuery() {
        try { ServerUrlRules.normalizeBaseUrl("https://user:pass@example.com"); fail("User info reddedilmeli"); }
        catch (Exception expected) { /* expected */ }
        try { ServerUrlRules.normalizeBaseUrl("https://example.com?token=x"); fail("Query reddedilmeli"); }
        catch (Exception expected) { /* expected */ }
    }
    @Test public void normalizesHealthPath() {
        assertEquals("/health", ServerUrlRules.normalizeHealthPath("health"));
        assertEquals("/custom/wake", ServerUrlRules.normalizeHealthPath("/custom/wake"));
    }
    @Test public void rejectsTraversalAndQueryInPath() {
        try { ServerUrlRules.normalizeHealthPath("/../admin"); fail("Path traversal reddedilmeli"); }
        catch (Exception expected) { /* expected */ }
        try { ServerUrlRules.normalizeHealthPath("/health?x=1"); fail("Query reddedilmeli"); }
        catch (Exception expected) { /* expected */ }
    }
}
