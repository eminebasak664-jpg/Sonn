package com.jai.assistant.engine;

import org.junit.Test;
import java.io.File;
import static org.junit.Assert.*;

public final class VisualLearningEngineTest {
    @Test public void learnsFromLabelledImageAndPersistsWeights() throws Exception {
        File model = File.createTempFile("jai-visual", ".bin");
        assertTrue(model.delete());
        int width = 32, height = 32;
        int[] image = new int[width * height];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                boolean screen = x >= 5 && x < 27 && y >= 4 && y < 23;
                image[y * width + x] = screen ? 0xff1f5e9e : 0xff242832;
                if (y >= 23 && y < 28 && x >= 13 && x < 19) image[y * width + x] = 0xff9a9a9a;
            }
        }
        VisualLearningEngine learner = new VisualLearningEngine(model);
        String report = learner.trainFromImage("televizyon", width, height, image, 3);
        assertTrue(report.contains("Öğrenme tamamlandı"));
        assertTrue(learner.canGenerate("retro TV resmi çiz"));
        int[] generated = learner.generate("televizyon", 64, 64);
        assertEquals(4096, generated.length);
        assertTrue("Ağın renk çıkışı tek tona düşmemeli.", java.util.Arrays.stream(generated).distinct().count() > 2);

        VisualLearningEngine loaded = new VisualLearningEngine(model);
        loaded.load();
        assertTrue(loaded.canGenerate("televizyon resmi yap"));
        assertTrue(loaded.status().contains("eğitildi"));
        assertTrue(model.length() > 100);
        assertTrue(model.delete());
    }

    @Test public void upgradedNetworkHasMoreThanFourTimesTheLegacyParameters() throws Exception {
        VisualLearningEngine learner = new VisualLearningEngine(null);
        assertTrue("Yeni ağ eski 12→32→3 ağından en az dört kat büyük olmalı.", learner.parameterCount() >= 4L * 515L);
        assertEquals(10627L, learner.parameterCount());
    }

    @Test public void refusesToPretendItKnowsAnUntrainedConcept() throws Exception {
        File model = File.createTempFile("jai-visual-empty", ".bin");
        assertTrue(model.delete());
        VisualLearningEngine learner = new VisualLearningEngine(model);
        assertFalse(learner.canGenerate("televizyon çiz"));
        try {
            learner.generate("televizyon çiz", 16, 16);
            fail("Eğitilmemiş kavramı biliyormuş gibi üretmemeli.");
        } catch (IllegalStateException expected) {
            assertTrue(expected.getMessage().contains("eğitilmiş"));
        }
    }
    @Test public void keepsMultipleReferencesAndGeneratesNewRasterPixels() throws Exception {
        File model = File.createTempFile("jai-visual-multi", ".bin");
        assertTrue(model.delete());
        int size = 32;
        int[] first = new int[size * size];
        int[] second = new int[size * size];
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                first[y * size + x] = (x > 10 && x < 20 && y > 3 && y < 28) ? 0xffc58b36 : 0xff6e9a52;
                second[y * size + x] = (x > 12 && x < 22 && y > 2 && y < 27) ? 0xffd59b47 : 0xff789e59;
            }
        }
        VisualLearningEngine learner = new VisualLearningEngine(model);
        learner.trainFromImage("zürafa", size, size, first, 1);
        learner.trainFromImage("zürafa", size, size, second, 1);
        assertEquals(2, learner.referenceSampleCount("zurafa"));
        assertTrue(learner.canGenerate("zürafa resmi üret"));
        int[] generated = learner.generateLearnedImage("zürafa resmi üret", 128, 128, false);
        assertEquals(128 * 128, generated.length);
        assertTrue(java.util.Arrays.stream(generated).distinct().count() > 2);
        assertTrue(learner.status().contains("çoklu referans örneği=2"));
        File sampleDir = new File(model.getParentFile(), "visual_examples");
        if (sampleDir.isDirectory()) {
            File[] files = sampleDir.listFiles();
            if (files != null) for (File file : files) file.delete();
            sampleDir.delete();
        }
        model.delete();
    }

    @Test public void keepsAtMostFiveReferenceImagesPerLabel() throws Exception {
        File model = File.createTempFile("jai-visual-cap", ".bin");
        assertTrue(model.delete());
        VisualLearningEngine learner = new VisualLearningEngine(model);
        int[] pixels = new int[16 * 16];
        for (int i = 0; i < pixels.length; i++) pixels[i] = 0xff123456 + i;
        learner.trainFromImage("uçak", 16, 16, pixels, 1);
        for (int i = 0; i < 6; i++) learner.storeReferenceImage("uçak", 16, 16, pixels);
        assertEquals(5, learner.referenceSampleCount("ucak"));
        File sampleDir = new File(model.getParentFile(), "visual_examples");
        if (sampleDir.isDirectory()) {
            File[] files = sampleDir.listFiles();
            if (files != null) for (File file : files) file.delete();
            sampleDir.delete();
        }
        model.delete();
    }

}
