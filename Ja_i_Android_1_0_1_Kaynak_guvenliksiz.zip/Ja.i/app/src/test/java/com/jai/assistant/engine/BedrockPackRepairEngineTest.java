package com.jai.assistant.engine;

import org.junit.Test;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import static org.junit.Assert.*;

public final class BedrockPackRepairEngineTest {
    @Test public void removesTrailingCommaAndClampsImpossibleStackRequest() throws Exception {
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("manifest.json", ("{\"header\":{\"uuid\":\"11111111-1111-4111-8111-111111111111\",},\"modules\":[{\"uuid\":\"22222222-2222-4222-8222-222222222222\"}],}").getBytes(StandardCharsets.UTF_8));
        files.put("items/test.json", ("{\"minecraft:max_stack_size\":999,}").getBytes(StandardCharsets.UTF_8));
        BedrockPackRepairEngine.Result result = new BedrockPackRepairEngine().validateAndRepair(files);
        String item = new String(result.files.get("items/test.json"), StandardCharsets.UTF_8);
        assertTrue(item.contains("\"minecraft:max_stack_size\":64"));
        assertTrue(result.repairedFiles >= 2);
    }

    @Test public void rejectsPathTraversalInsteadOfHidingIt() throws Exception {
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("manifest.json", "{\"header\":{\"uuid\":\"11111111-1111-4111-8111-111111111111\"},\"modules\":[{\"uuid\":\"22222222-2222-4222-8222-222222222222\"}]}".getBytes(StandardCharsets.UTF_8));
        files.put("../evil.json", "{}".getBytes(StandardCharsets.UTF_8));
        try { new BedrockPackRepairEngine().validateAndRepair(files); fail("Unsafe path must be rejected."); }
        catch (java.io.IOException expected) { assertTrue(expected.getMessage().contains("Güvensiz")); }
    }
}
