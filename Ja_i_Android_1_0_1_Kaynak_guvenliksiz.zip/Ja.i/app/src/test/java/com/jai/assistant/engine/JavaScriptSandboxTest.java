package com.jai.assistant.engine;

import org.junit.Test;
import static org.junit.Assert.*;

public class JavaScriptSandboxTest {
    @Test public void executesAndCapturesOutput() {
        String output = new JavaScriptSandbox().execute("print('Ja.i'); 2 + 3");
        assertTrue(output.contains("Ja.i"));
        assertTrue(output.contains("5"));
    }
    @Test public void oversizedSourceIsRejected() {
        StringBuilder source = new StringBuilder();
        for (int i = 0; i < 80_001; i++) source.append(' ');
        assertTrue(new JavaScriptSandbox().execute(source.toString()).contains("80.000"));
    }
    @Test public void javaBridgeIsNotExposed() {
        String output = new JavaScriptSandbox().execute("Java.type('java.lang.System')");
        assertTrue(output.contains("hatası") || output.contains("Error") || output.contains("ReferenceError"));
    }
}
