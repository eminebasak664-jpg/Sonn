package com.jai.assistant.engine;

import com.jai.assistant.data.MemoryDatabase;
import org.junit.Test;
import java.util.Map;
import static org.junit.Assert.*;

public final class ModelEngineTest {
    @Test public void classificationReturnsKnownIntentAndNormalizedScores() {
        ModelEngine.Classification result = new ModelEngine(new MemoryDatabase()).classifyDetailed("merhaba günaydın nasılsın");
        assertEquals("selam", result.label);
        assertTrue(result.confidence > 0.0 && result.confidence <= 1.0);
        assertTrue(result.margin >= 0.0);
        assertTrue(result.tokenCount > 0);
        assertTrue(result.knownTokenCount > 0);
        assertTrue(result.knownTokenRatio > 0.0 && result.knownTokenRatio <= 1.0);
        assertTrue(result.evidenceStrength > 0.0 && result.evidenceStrength <= 1.0);
        double sum = 0.0;
        for (Map.Entry<String, Double> entry : result.probabilities.entrySet()) sum += entry.getValue();
        assertEquals(1.0, sum, 0.000001);
    }

    @Test public void classifierIncludesResearchFileSummaryAndComparisonIntents() {
        ModelEngine engine = new ModelEngine(new MemoryDatabase());
        assertTrue(engine.knownLabels().contains("arastirma"));
        assertTrue(engine.knownLabels().contains("dosya"));
        assertTrue(engine.knownLabels().contains("ozet"));
        assertTrue(engine.knownLabels().contains("karsilastirma"));
    }

    @Test public void classifiesNaturalLanguageProjectRequestsAsCode() {
        ModelEngine engine = new ModelEngine(new MemoryDatabase());
        assertEquals("kod", engine.classify("görev listesi ve not defteri olan uygulama yap"));
        assertEquals("kod", engine.classify("hafıza kartı eşleştirme oyunu geliştir"));
        assertEquals("kod", engine.classify("çok dosyalı web projesi üret"));
    }

    @Test public void explicitTrainingExampleChangesClassifierDataset() {
        MemoryDatabase database = new MemoryDatabase();
        ModelEngine engine = new ModelEngine(database);
        assertTrue(engine.learnExample("özel deneme komutu", "kod"));
        assertEquals("özel deneme komutu", database.getTrainingExamples().get(0)[0]);
    }
}
