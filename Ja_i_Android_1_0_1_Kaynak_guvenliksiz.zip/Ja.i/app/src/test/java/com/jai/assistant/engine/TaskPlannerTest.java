package com.jai.assistant.engine;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.assertTrue;

public final class TaskPlannerTest {
    private final TaskPlanner planner = new TaskPlanner();

    @Test public void deeperEffortAddsVerificationStep() {
        List<String> steps = planner.createPlan("Java kod projesini araştır ve karşılaştır", "Derin");
        assertTrue(steps.stream().anyMatch(step -> step.contains("çelişki")));
        assertTrue(steps.stream().anyMatch(step -> step.contains("web sonuçlarını")));
    }

    @Test public void quickEffortKeepsPlanShorter() {
        assertTrue(planner.createPlan("Java kodu yaz", "Hızlı").size()
                < planner.createPlan("Java kodu yaz", "Derin").size());
    }
}
