package com.jai.assistant.engine;

import com.jai.assistant.tools.ZipArchiveInspector;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.junit.Assert.assertTrue;

public final class ZipArchiveInspectorTest {
    @Test
    public void readsTextContentInsteadOfOnlyListingArchive() throws Exception {
        String report = new ZipArchiveInspector().inspect(zip("src/Main.java", "class Main { public static void main(String[] args) {} }"));
        assertTrue(report.contains("src/Main.java"));
        assertTrue(report.contains("class Main"));
        assertTrue(report.contains("diske çıkarılmadan"));
    }

    @Test
    public void readsNestedZipEntries() throws Exception {
        byte[] nested = zipBytes("manifest.json", "{\"format_version\":2}");
        String report = new ZipArchiveInspector().inspect(zip("behavior.mcpack", nested));
        assertTrue(report.contains("manifest.json"));
        assertTrue(report.contains("format_version"));
    }

    @Test
    public void readsNestedArchivesBeyondTheOldThreeLevelLimit() throws Exception {
        byte[] nested = zipBytes("deep.txt", "depth-five-content");
        for (int i = 0; i < 6; i++) nested = zipBytes("level" + i + ".zip", nested);
        String report = new ZipArchiveInspector().inspect(new ByteArrayInputStream(nested));
        assertTrue(report.contains("depth-five-content"));
    }


    @Test
    public void readsArchiveWithMoreThanTheOld128MiBTotalExpansion() throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        byte[] binary = new byte[1024 * 1024];
        for (int i = 0; i < binary.length; i++) binary[i] = (byte) ((i % 5) == 0 ? 1 : 'A' + (i % 4));
        try (ZipOutputStream zip = new ZipOutputStream(bytes, StandardCharsets.UTF_8)) {
            for (int i = 0; i < 130; i++) {
                zip.putNextEntry(new ZipEntry("binary/entry-" + i + ".dat"));
                zip.write(binary);
                zip.closeEntry();
            }
        }
        String report = new ZipArchiveInspector().inspect(new ByteArrayInputStream(bytes.toByteArray()));
        assertTrue(report.contains("136314880"));
        assertTrue(report.contains("Okunan açılmış veri toplamı"));
    }

    @Test(expected = IOException.class)
    public void rejectsPathTraversal() throws Exception {
        new ZipArchiveInspector().inspect(zip("../outside.txt", "unsafe"));
    }

    private ByteArrayInputStream zip(String name, String content) throws IOException {
        return new ByteArrayInputStream(zipBytes(name, content.getBytes(StandardCharsets.UTF_8)));
    }

    private ByteArrayInputStream zip(String name, byte[] content) throws IOException {
        return new ByteArrayInputStream(zipBytes(name, content));
    }

    private byte[] zipBytes(String name, String content) throws IOException {
        return zipBytes(name, content.getBytes(StandardCharsets.UTF_8));
    }

    private byte[] zipBytes(String name, byte[] content) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream output = new ZipOutputStream(bytes, StandardCharsets.UTF_8)) {
            output.putNextEntry(new ZipEntry(name));
            output.write(content);
            output.closeEntry();
        }
        return bytes.toByteArray();
    }
}
