package com.jai.assistant.engine;

import org.junit.Test;
import static org.junit.Assert.*;

public final class StructuredProgramCompilerTest {
    private final StructuredProgramCompiler compiler = new StructuredProgramCompiler();

    @Test public void synthesizesVariablesFunctionsAndCallsFromSpecification() {
        StructuredProgramCompiler.Result result = compiler.compile(
                "değişken puan = 0\nfonksiyon ekle(x) = puan + x\nata puan = ekle(3)\nyazdır puan");
        assertTrue(result.recognized);
        assertTrue(result.supported);
        assertTrue(result.source.contains("function ekle(x)"));
        assertTrue(result.source.contains("puan = ekle(3)"));
        assertTrue(result.source.contains("console.log(puan)"));
    }

    @Test public void synthesizesConditionAndLoopStatements() {
        StructuredProgramCompiler.Result result = compiler.compile(
                "değişken skor = 2\neğer skor > 1 ise yazdır skor\ndöngü i başlangıç 1 bitiş 3 yazdır i");
        assertTrue(result.supported);
        assertTrue(result.source.contains("if ((skor > 1))"));
        assertTrue(result.source.contains("for (let i = 1; i <= 3; i++)"));
    }

    @Test public void rejectsInvalidExpressionInsteadOfEmittingBrokenCode() {
        StructuredProgramCompiler.Result result = compiler.compile("değişken skor = 1 +");
        assertTrue(result.recognized);
        assertFalse(result.supported);
        assertEquals("", result.source);
    }

    @Test public void limitsProgramToOneHundredStatements() {
        StringBuilder program = new StringBuilder();
        for (int i = 0; i < 101; i++) program.append("yazdır ").append(i).append("\n");
        StructuredProgramCompiler.Result result = compiler.compile(program.toString());
        assertTrue(result.recognized);
        assertFalse(result.supported);
        assertTrue(result.message.contains("100 komut"));
    }

    @Test public void limitsExpressionTokenCount() {
        StringBuilder expression = new StringBuilder("değişken n = 1");
        for (int i = 0; i < 130; i++) expression.append(" + 1");
        StructuredProgramCompiler.Result result = compiler.compile(expression.toString());
        assertTrue(result.recognized);
        assertFalse(result.supported);
        assertTrue(result.message.contains("256 belirteç"));
    }

    @Test public void leavesUnstructuredNaturalLanguageForOtherGenerators() {
        StructuredProgramCompiler.Result result = compiler.compile("3D Minecraft benzeri bir oyun yap");
        assertFalse(result.recognized);
        assertFalse(result.supported);
    }
}
