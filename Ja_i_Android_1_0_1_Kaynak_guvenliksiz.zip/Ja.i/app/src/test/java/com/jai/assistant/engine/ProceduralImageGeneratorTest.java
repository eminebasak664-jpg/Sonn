package com.jai.assistant.engine;

import org.junit.Test;
import static org.junit.Assert.*;

public final class ProceduralImageGeneratorTest {
    @Test public void generatesARealPngWithoutExternalModel() throws Exception {
        ProceduralImageGenerator.Result result = new ProceduralImageGenerator().generate("mor bir ejderha çiz 128x128");
        assertNotNull(result.pngBytes);
        assertTrue(result.pngBytes.length > 100);
        assertEquals(128, result.width);
        assertEquals(128, result.height);
        assertEquals("ejderha", result.subject);
        assertEquals((byte) 137, result.pngBytes[0]);
        assertEquals('P', result.pngBytes[1]);
        assertEquals('N', result.pngBytes[2]);
        assertEquals('G', result.pngBytes[3]);
    }

    @Test public void mapsSimpleDrawingRequests() {
        ProceduralImageGenerator generator = new ProceduralImageGenerator();
        assertTrue(generator.isImageRequest("kedi çiz"));
        assertTrue(generator.isImageRequest("bir görsel üret"));
        assertFalse(generator.isImageRequest("resimler nedir, anlat"));
        assertFalse(generator.isImageRequest("görev listesi ve not defteri yap"));
        assertTrue(generator.isImageRequest("ev çiz"));
    }

    @Test public void rejectsUnsafeImageDimensions() throws Exception {
        try {
            new ProceduralImageGenerator().generate("test", 2048, 2048);
            fail("Boyut sınırı uygulanmalıydı.");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("1280×720"));
        }
    }

    @Test public void createsLandscape720pImageAndPixelArtUpscale() throws Exception {
        ProceduralImageGenerator generator = new ProceduralImageGenerator();
        ProceduralImageGenerator.Result result = generator.generate("retro televizyon resmi çiz 720p piksel piksel");
        assertEquals(1280, result.width);
        assertEquals(720, result.height);
        assertTrue(result.description.contains("piksel"));
        assertEquals((byte) 137, result.pngBytes[0]);
    }

    @Test public void defaultsTo720pWhenNoDimensionsAreGiven() throws Exception {
        ProceduralImageGenerator.Result result = new ProceduralImageGenerator().generate("bir televizyon resmi yap");
        assertEquals(1280, result.width);
        assertEquals(720, result.height);
    }

    @Test public void supportsPortrait720pDimensions() throws Exception {
        ProceduralImageGenerator.Result result = new ProceduralImageGenerator().generate("kedi çiz 720x1280");
        assertEquals(720, result.width);
        assertEquals(1280, result.height);
    }

    @Test public void refusesUntrainedObjectsInsteadOfDrawingGeometricFallbackInAppMode() throws Exception {
        java.io.File model = java.io.File.createTempFile("jai-visual-research", ".bin");
        assertTrue(model.delete());
        VisualLearningEngine learner = new VisualLearningEngine(model);
        String prompt = "bir teleskop çiz 128x128";
        try {
            new ProceduralImageGenerator().generate(prompt, 128, 128, learner,
                    "Teleskop optik tüp, ön mercek, göz merceği ve üçayak üzerinde dengelenir.");
            fail("Öğrenilmemiş nesne için geometrik şablon kullanılmamalı.");
        } catch (IllegalStateException expected) {
            assertTrue(expected.getMessage().contains("geometrik şablonla çizip"));
        }
        assertFalse(learner.canGenerate(prompt));
        model.delete();
    }
}
