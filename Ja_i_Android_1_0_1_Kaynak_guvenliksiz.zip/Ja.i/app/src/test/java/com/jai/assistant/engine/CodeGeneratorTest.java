package com.jai.assistant.engine;

import org.junit.Test;
import static org.junit.Assert.*;

public class CodeGeneratorTest {
    private final CodeGenerator generator = new CodeGenerator();

    @Test public void mapsCounterPromptToPersistentMultiFileWebProject() {
        CodeGenerator.GeneratedCode code = generator.generate("tıklama sayacı yap");
        assertTrue(code.supported);
        assertTrue(code.project);
        assertFalse(code.runnableInLab);
        assertEquals("HTML", code.language);
        assertTrue(code.projectFiles.get("app.js").contains("counter-plus"));
        assertTrue(code.projectFiles.get("app.js").contains("localStorage"));
    }

    @Test public void mapsHtmlPromptToCompleteMultiFileProject() {
        CodeGenerator.GeneratedCode code = generator.generate("basit HTML web sayfası");
        assertTrue(code.supported);
        assertTrue(code.project);
        assertEquals("HTML", code.language);
        assertTrue(code.source.contains("<!doctype html>"));
        assertTrue(code.projectFiles.containsKey("styles.css"));
        assertTrue(code.projectFiles.containsKey("app.js"));
    }

    @Test public void createsClickableMultiFileGame() {
        CodeGenerator.GeneratedCode code = generator.generate("tıklama oyunu yap");
        assertEquals("generated-web-project", code.templateId);
        assertTrue(code.project);
        assertTrue(code.source.contains("counter-value"));
        assertTrue(code.projectFiles.get("app.js").contains("addEventListener"));
        assertFalse(code.runnableInLab);
    }

    @Test public void createsTicTacToeGame() {
        CodeGenerator.GeneratedCode code = generator.generate("X-O oyunu yap");
        assertEquals("generated-web-project", code.templateId);
        assertTrue(code.projectFiles.get("index.html").contains("xo-board"));
        assertTrue(code.projectFiles.get("app.js").contains("const wins"));
        assertTrue(code.projectFiles.get("app.js").contains("Berabere"));
    }

    @Test public void generatesQuizAndLandingPage() {
        CodeGenerator.GeneratedCode quiz = generator.generate("bilgi yarışması");
        assertTrue(quiz.project);
        assertTrue(quiz.projectFiles.get("index.html").contains("quiz-question"));
        CodeGenerator.GeneratedCode landing = generator.generate("portfolyo tanıtım sitesi");
        assertTrue(landing.project);
        assertTrue(landing.projectFiles.get("index.html").contains("Yerel Web Sayfası"));
    }

    @Test public void supportsStaticLanguageStartersButDoesNotClaimExecution() {
        CodeGenerator.GeneratedCode java = generator.generate("Java programı yaz");
        CodeGenerator.GeneratedCode python = generator.generate("Python başlangıç kodu yaz");
        assertEquals("Java", java.language);
        assertEquals("Python", python.language);
        assertFalse(java.runnableInLab);
        assertFalse(python.runnableInLab);
    }


    @Test public void distinguishesJavaScriptFromJava() {
        CodeGenerator.GeneratedCode code = generator.generate("JavaScript kodu yaz");
        assertEquals("JavaScript", code.language);
        assertTrue(code.runnableInLab);
        assertEquals("js-starter", code.templateId);
    }

    @Test public void synthesizesNewJavaScriptFromStructuredProgramSpec() {
        CodeGenerator.GeneratedCode code = generator.generate(
                "değişken puan = 0\nfonksiyon ekle(x) = puan + x\nata puan = ekle(3)\nyazdır puan");
        assertTrue(code.supported);
        assertTrue(code.runnableInLab);
        assertEquals("structured-js-compiler", code.templateId);
        assertTrue(code.source.contains("function ekle(x)"));
        assertTrue(code.source.contains("puan = ekle(3)"));
    }

    @Test public void rejectsUnsupportedFreeFormGameRequestInsteadOfClaimingGeneration() {
        CodeGenerator.GeneratedCode code = generator.generate("3D Minecraft benzeri oyun motoru yap");
        assertFalse(code.supported);
        assertEquals("", code.source);
    }

    @Test public void unknownPromptIsHonestUnsupportedResult() {
        CodeGenerator.GeneratedCode code = generator.generate("çok karmaşık bir oyun motoru yap");
        assertFalse(code.supported);
        assertEquals("", code.source);
        assertTrue(code.explanation.contains("eşleşmedi"));
    }
    @Test public void producesAnImageArtifactFromAPlainDrawingRequest() {
        CodeGenerator.GeneratedCode image = generator.generate("mor bir ejderha çiz 64x64");
        assertTrue(image.supported);
        assertTrue(image.hasArtifact());
        assertEquals("procedural-png-image", image.templateId);
        assertTrue(image.artifactFileName.endsWith(".png"));
        assertTrue(image.artifactBytes.length > 100);
    }

    @Test public void createsMinecraftBedrockPackArtifact() {
        CodeGenerator.GeneratedCode pack = generator.generate("Minecraft için tam mcaddon oluştur");
        assertTrue(pack.supported);
        assertTrue(pack.hasArtifact());
        assertEquals("minecraft-bedrock-pack", pack.templateId);
        assertTrue(pack.artifactFileName.endsWith(".mcaddon"));
    }

}
