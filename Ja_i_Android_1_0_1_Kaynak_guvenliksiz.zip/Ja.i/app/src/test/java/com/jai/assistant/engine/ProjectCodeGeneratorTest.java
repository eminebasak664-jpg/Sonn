package com.jai.assistant.engine;

import org.junit.Test;
import java.util.Map;
import static org.junit.Assert.*;

public final class ProjectCodeGeneratorTest {
    private final ProjectCodeGenerator generator = new ProjectCodeGenerator();

    @Test public void combinesSeveralRequestedFeaturesIntoSeparateFiles() {
        ProjectCodeGenerator.Project project = generator.generate(
                "Görev listesi ve not defteri olan turkuaz uygulama yap");
        assertNotNull(project);
        assertEquals(4, project.files.size());
        assertTrue(project.files.containsKey("index.html"));
        assertTrue(project.files.containsKey("styles.css"));
        assertTrue(project.files.containsKey("app.js"));
        assertTrue(project.files.containsKey("README.md"));
        assertTrue(project.files.get("index.html").contains("Görev listesi"));
        assertTrue(project.files.get("index.html").contains("Not defteri"));
        assertTrue(project.files.get("styles.css").contains("#2dd4bf"));
        assertTrue(project.files.get("app.js").contains("localStorage"));
        assertTrue(project.files.get("app.js").contains("todo-form"));
    }

    @Test public void generatesMemoryGameWithActualMatchingLogic() {
        ProjectCodeGenerator.Project project = generator.generate("hafıza kartı eşleştirme oyunu yap");
        assertNotNull(project);
        assertTrue(project.files.get("index.html").contains("memory-board"));
        assertTrue(project.files.get("app.js").contains("matched++"));
        assertTrue(project.files.get("app.js").contains("setTimeout"));
    }

    @Test public void generatesSeveralGameMechanicsTogether() {
        ProjectCodeGenerator.Project project = generator.generate("refleks testi ve puan sayacı olan oyun yap");
        assertNotNull(project);
        assertTrue(project.files.get("index.html").contains("reaction-button"));
        assertTrue(project.files.get("index.html").contains("counter-value"));
        assertTrue(project.files.get("app.js").contains("performance.now"));
        assertTrue(project.files.get("app.js").contains("counter-plus"));
    }

    @Test public void escapesCustomProjectTitle() {
        ProjectCodeGenerator.Project project = generator.generate("adı \"<Test>\" olan bir web sitesi yap");
        assertNotNull(project);
        assertTrue(project.files.get("index.html").contains("&lt;Test&gt;"));
        assertFalse(project.files.get("index.html").contains("<title><Test></title>"));
    }

    @Test public void combinesAllExplicitlyRequestedModulesIncludingMemoryCards() {
        ProjectCodeGenerator.Project project = generator.generate(
                "turkuaz temalı puan sayacı, görev listesi, not defteri, hesap makinesi, kronometre, bilgi yarışması, hafıza kartı oyunu, refleks testi ve X-O oyunu olan uygulama yap");
        assertNotNull(project);
        String html = project.files.get("index.html");
        assertTrue(html.contains("counter-value"));
        assertTrue(html.contains("todo-form"));
        assertTrue(html.contains("notes-text"));
        assertTrue(html.contains("calc-run"));
        assertTrue(html.contains("timer-start"));
        assertTrue(html.contains("quiz-options"));
        assertTrue(html.contains("memory-board"));
        assertTrue(html.contains("reaction-button"));
        assertTrue(html.contains("xo-board"));
    }

    @Test public void ignoresNonCreationConversation() {
        assertNull(generator.generate("Bir hafıza oyununun kuralları nelerdir?"));
    }

    @Test public void buildsOfflineResponsiveProjectWithoutRemoteDependencies() {
        ProjectCodeGenerator.Project project = generator.generate("portfolyo web sitesi yap");
        assertNotNull(project);
        for (Map.Entry<String, String> file : project.files.entrySet()) {
            assertFalse(file.getKey(), file.getValue().contains("https://"));
            assertFalse(file.getKey(), file.getValue().contains("http://"));
        }
        assertTrue(project.files.get("index.html").contains("viewport"));
        assertTrue(project.files.get("README.md").contains("İnternet bağlantısı gerekmez"));
    }
}
