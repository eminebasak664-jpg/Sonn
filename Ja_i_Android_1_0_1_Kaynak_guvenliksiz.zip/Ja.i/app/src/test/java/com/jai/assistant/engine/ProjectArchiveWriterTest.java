package com.jai.assistant.engine;

import org.junit.Test;
import java.io.ByteArrayInputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import static org.junit.Assert.*;

public final class ProjectArchiveWriterTest {
    @Test public void writesEveryProjectFileToZip() throws Exception {
        Map<String, String> files = new LinkedHashMap<>();
        files.put("index.html", "<h1>Ja.i</h1>");
        files.put("styles.css", "body{color:white}");
        files.put("app.js", "console.log('ok')");
        byte[] zipBytes = new ProjectArchiveWriter().createZip(files);
        Map<String, String> restored = new LinkedHashMap<>();
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                java.io.ByteArrayOutputStream contents = new java.io.ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int count;
                while ((count = zip.read(buffer)) >= 0) contents.write(buffer, 0, count);
                restored.put(entry.getName(), new String(contents.toByteArray(), java.nio.charset.StandardCharsets.UTF_8));
            }
        }
        assertEquals(files, restored);
    }

    @Test public void rejectsZipSlipPaths() {
        Map<String, String> files = new LinkedHashMap<>();
        files.put("../outside.txt", "bad");
        try {
            new ProjectArchiveWriter().createZip(files);
            fail("Güvensiz yol reddedilmeliydi.");
        } catch (java.io.IOException expected) {
            assertTrue(expected.getMessage().contains("Güvensiz"));
        }
    }
    @Test public void writesBinaryPngBytesWithoutTextConversion() throws Exception {
        Map<String, byte[]> files = new LinkedHashMap<>();
        byte[] png = new byte[]{(byte) 137, 80, 78, 71, 13, 10, 26, 10, 0, 1, (byte) 255};
        files.put("textures/example.png", png);
        byte[] archive = new ProjectArchiveWriter().createZipBinary(files);
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(archive))) {
            assertEquals("textures/example.png", zip.getNextEntry().getName());
            ByteArrayOutputStream restored = new ByteArrayOutputStream();
            byte[] buffer = new byte[32];
            int count;
            while ((count = zip.read(buffer)) != -1) restored.write(buffer, 0, count);
            assertArrayEquals(png, restored.toByteArray());
        }
    }

    @Test public void binaryArchiveRejectsUnsafePaths() {
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("../outside.png", new byte[]{1, 2, 3});
        try {
            new ProjectArchiveWriter().createZipBinary(files);
            fail("Güvensiz yol reddedilmeliydi.");
        } catch (java.io.IOException expected) {
            assertTrue(expected.getMessage().contains("Güvensiz"));
        }
    }

}
