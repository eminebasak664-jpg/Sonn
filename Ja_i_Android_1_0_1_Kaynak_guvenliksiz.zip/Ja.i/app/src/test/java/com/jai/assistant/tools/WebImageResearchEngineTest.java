package com.jai.assistant.tools;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public final class WebImageResearchEngineTest {
    @Test public void parsesImageUrlsAndEscapedTitlesFromSearchResponse() {
        String json = "{\"results\":["
                + "{\"title\":\"Giraffe \\\"adult\\\"\",\"image\":\"https://cdn.example/a.jpg?x=1\\u0026y=2\",\"url\":\"https://source.example/giraffe\"},"
                + "{\"title\":\"Second\",\"image\":\"https://cdn.example/b.webp\",\"url\":\"https://source.example/second\"}]}";
        List<String> urls = WebImageResearchEngine.parseImageUrlsForTest(json);
        assertEquals(2, urls.size());
        assertEquals("https://cdn.example/a.jpg?x=1&y=2", urls.get(0));
        assertEquals("https://cdn.example/b.webp", urls.get(1));
    }

    @Test public void refusesHttpAndLoopbackImageUrls() {
        assertFalse(WebImageResearchEngine.isSafeHttpsUrl("http://1.1.1.1/image.jpg"));
        assertFalse(WebImageResearchEngine.isSafeHttpsUrl("https://127.0.0.1/image.jpg"));
        assertFalse(WebImageResearchEngine.isSafeHttpsUrl("https://localhost/image.jpg"));
        assertTrue(WebImageResearchEngine.isSafeHttpsUrl("https://1.1.1.1/image.jpg"));
    }

    @Test public void onlyAcceptsAndroidRasterImageFormats() {
        assertTrue(WebImageResearchEngine.isSupportedRasterType("image/jpeg; charset=binary"));
        assertTrue(WebImageResearchEngine.isSupportedRasterType("image/png"));
        assertTrue(WebImageResearchEngine.isSupportedRasterType("image/webp"));
        assertFalse(WebImageResearchEngine.isSupportedRasterType("image/svg+xml"));
        assertFalse(WebImageResearchEngine.isSupportedRasterType("text/html"));
    }
}
