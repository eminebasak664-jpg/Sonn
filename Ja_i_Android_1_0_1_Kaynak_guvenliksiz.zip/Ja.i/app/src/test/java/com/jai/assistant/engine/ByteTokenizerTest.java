package com.jai.assistant.engine;

import com.jai.assistant.data.ChatMessage;
import org.junit.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.Assert.*;

public class ByteTokenizerTest {
    @Test public void utf8RoundTripPreservesTurkishCharacters() {
        String text = "Merhaba, Ja.i! Türkçe: ğüşiöç İ ı.";
        int[] ids = ByteTokenizer.encodeText(text);
        java.util.ArrayList<Integer> tokens = new java.util.ArrayList<>();
        for (int id : ids) tokens.add(id);
        assertEquals(text, ByteTokenizer.decodeBytes(tokens));
    }

    @Test public void byteTokensNeverOverlapSpecialTokens() {
        for (int id : ByteTokenizer.encodeText("Türkçe sohbet")) {
            assertTrue(id >= 0 && id <= 255);
        }
        assertEquals(262, ByteTokenizer.VOCAB_SIZE);
        assertEquals(261, ByteTokenizer.SYSTEM);
    }

    @Test public void conversationUsesModelRoleTokensAndEndsWithAssistant() {
        List<ChatMessage> history = Arrays.asList(
                new ChatMessage(1, "user", "Merhaba", 1),
                new ChatMessage(2, "assistant", "Merhaba!", 2)
        );
        int[] tokens = ByteTokenizer.buildConversation(history, "Nasılsın?", "", 512);
        assertEquals(ByteTokenizer.BOS, tokens[0]);
        assertEquals(ByteTokenizer.ASSISTANT, tokens[tokens.length - 1]);
        assertTrue(Arrays.stream(tokens).anyMatch(value -> value == ByteTokenizer.USER));
        assertTrue(Arrays.stream(tokens).anyMatch(value -> value == ByteTokenizer.SYSTEM));
    }

    @Test public void currentPromptAlreadyInHistoryIsNotDuplicated() {
        List<ChatMessage> history = Arrays.asList(
                new ChatMessage(1, "user", "Önceki soru", 1),
                new ChatMessage(2, "assistant", "Önceki yanıt", 2),
                new ChatMessage(3, "user", "Son soru", 3)
        );
        int[] tokens = ByteTokenizer.buildConversation(history, "Son soru", "", 512);
        long userMarkers = Arrays.stream(tokens).filter(value -> value == ByteTokenizer.USER).count();
        assertEquals(2L, userMarkers);
    }

    @Test public void contextWindowRemainsBounded() {
        int[] tokens = ByteTokenizer.buildConversation(null, "x".repeat(5000), "", 128);
        assertTrue(tokens.length <= 128);
        assertEquals(ByteTokenizer.BOS, tokens[0]);
        assertEquals(ByteTokenizer.ASSISTANT, tokens[tokens.length - 1]);
    }
}
