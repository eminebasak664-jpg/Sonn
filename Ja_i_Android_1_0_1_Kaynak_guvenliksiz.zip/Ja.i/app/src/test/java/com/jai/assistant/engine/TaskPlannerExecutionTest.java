package com.jai.assistant.engine;

import org.junit.Test;
import static org.junit.Assert.*;

public final class TaskPlannerExecutionTest {
    @Test public void planIncludesChosenToolAndActionableSteps() {
        ToolRegistry registry = new ToolRegistry();
        registry.register("calculator", input -> input, request -> 100, request -> "2+2");
        ToolRegistry.Selection selection = registry.selectBest("2+2 kaç eder");
        TaskPlanner.ExecutionPlan plan = new TaskPlanner().createExecutionPlan("2+2 kaç eder", "Derin", "matematik", selection);
        assertEquals("calculator", plan.selectedTool);
        assertTrue(plan.retrieveContext);
        assertTrue(plan.verifyOutput);
        assertTrue(plan.steps.stream().anyMatch(step -> step.contains("calculator")));
    }
}
