package com.jai.assistant.engine;

import org.junit.Test;
import static org.junit.Assert.*;

public final class ProjectCodeValidatorTest {
    @Test public void acceptsGeneratedFourFileProject() {
        CodeGenerator.GeneratedCode generated = new CodeGenerator().generate("görev listesi ve not defteri olan uygulama yap");
        assertTrue(generated.project);
        ProjectCodeValidator.Result result = new ProjectCodeValidator().validate(generated.projectFiles);
        assertTrue(result.report, result.valid);
        assertTrue(result.report.contains("HTML temel etiketleri"));
    }

    @Test public void rejectsMissingStylesheetReference() {
        CodeGenerator.GeneratedCode generated = new CodeGenerator().generate("hafıza oyunu yap");
        java.util.Map<String, String> files = new java.util.LinkedHashMap<>(generated.projectFiles);
        files.put("index.html", files.get("index.html").replace("href=\"styles.css\"", "href=\"missing.css\""));
        ProjectCodeValidator.Result result = new ProjectCodeValidator().validate(files);
        assertFalse(result.valid);
        assertTrue(result.report.contains("bağlanmıyor"));
    }
}
