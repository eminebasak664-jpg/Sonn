package com.jai.assistant.engine;

import org.junit.Test;
import static org.junit.Assert.*;

public final class TaskStageEngineTest {
    @Test public void manualOneExecutesTaskDirectly() {
        TaskStageEngine.Plan plan = TaskStageEngine.createPlan("selam", "Hızlı", false, 1);
        assertEquals(1, plan.stages.size());
        assertEquals(TaskStageEngine.Stage.EXECUTE_TASK, plan.stages.get(0));
    }

    @Test public void manualTwoAnalyzesBeforeExecution() {
        TaskStageEngine.Plan plan = TaskStageEngine.createPlan("Java projesini geliştir", "Orta", false, 2);
        assertEquals(2, plan.stages.size());
        assertEquals(TaskStageEngine.Stage.ANALYZE_REQUEST, plan.stages.get(0));
        assertEquals(TaskStageEngine.Stage.EXECUTE_TASK, plan.stages.get(1));
    }

    @Test public void manualThreeRetrievesContextBeforeExecution() {
        TaskStageEngine.Plan plan = TaskStageEngine.createPlan("Java projesini geliştir", "Orta", false, 3);
        assertEquals(3, plan.stages.size());
        assertEquals(TaskStageEngine.Stage.ANALYZE_REQUEST, plan.stages.get(0));
        assertEquals(TaskStageEngine.Stage.RETRIEVE_CONTEXT, plan.stages.get(1));
        assertEquals(TaskStageEngine.Stage.EXECUTE_TASK, plan.stages.get(2));
    }

    @Test public void manualFourPlansBeforeExecution() {
        TaskStageEngine.Plan plan = TaskStageEngine.createPlan("Java projesini geliştir", "Maksimum", false, 4);
        assertEquals(4, plan.stages.size());
        assertEquals(TaskStageEngine.Stage.BUILD_PLAN, plan.stages.get(2));
        assertEquals(TaskStageEngine.Stage.EXECUTE_TASK, plan.stages.get(3));
        assertFalse(plan.stages.contains(TaskStageEngine.Stage.VERIFY_RESULT));
    }

    @Test public void manualFiveVerifiesOnlyAfterExecution() {
        TaskStageEngine.Plan plan = TaskStageEngine.createPlan("Java kodu üret", "Derin", false, 5);
        assertEquals(5, plan.stages.size());
        assertEquals(TaskStageEngine.Stage.EXECUTE_TASK, plan.stages.get(3));
        assertEquals(TaskStageEngine.Stage.VERIFY_RESULT, plan.stages.get(4));
    }

    @Test public void manual115DoesNotInventRepeatedStages() {
        TaskStageEngine.Plan plan = TaskStageEngine.createPlan("Java kodu üret", "Derin", false, 115);
        assertEquals(5, plan.stages.size());
        assertTrue(plan.stopReason.contains("sahte tekrarlar"));
    }

    @Test public void effortChangesAutomaticStageCount() {
        TaskStageEngine.Plan quick = TaskStageEngine.createPlan("Java kodu üret", "Hızlı", true, 8);
        TaskStageEngine.Plan deep = TaskStageEngine.createPlan("Java kodu üret", "Derin", true, 8);
        assertEquals(2, quick.stages.size());
        assertEquals(5, deep.stages.size());
    }
}
