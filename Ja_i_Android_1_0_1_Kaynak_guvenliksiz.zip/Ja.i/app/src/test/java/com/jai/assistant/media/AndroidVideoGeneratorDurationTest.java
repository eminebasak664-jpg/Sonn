package com.jai.assistant.media;

import org.junit.Test;
import static org.junit.Assert.*;

public final class AndroidVideoGeneratorDurationTest {
    @Test public void acceptsOneMinuteAndClampsLongerRequests() {
        assertEquals(60, AndroidVideoGenerator.requestedDurationSeconds("1 dakika video yap"));
        assertEquals(60, AndroidVideoGenerator.requestedDurationSeconds("90 saniyelik video hazırla"));
        assertEquals(10, AndroidVideoGenerator.requestedDurationSeconds("video oluştur"));
    }
}
