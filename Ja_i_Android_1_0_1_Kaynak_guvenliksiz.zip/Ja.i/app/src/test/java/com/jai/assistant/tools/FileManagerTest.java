package com.jai.assistant.tools;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import org.junit.Test;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import static org.junit.Assert.assertTrue;

public class FileManagerTest {
    private static final class NamedUri extends Uri {
        private final String name;
        NamedUri(String name) { this.name = name; }
        @Override public String getLastPathSegment() { return name; }
    }

    private static final class NameCursor implements Cursor {
        private final String name;
        NameCursor(String name) { this.name = name; }
        @Override public boolean moveToFirst() { return true; }
        @Override public int getColumnIndex(String column) { return OpenableColumns.DISPLAY_NAME.equals(column) ? 0 : -1; }
        @Override public String getString(int index) { return index == 0 ? name : null; }
        @Override public void close() { }
    }

    private static final class BytesResolver extends ContentResolver {
        private final String name;
        private final byte[] bytes;
        BytesResolver(String name, byte[] bytes) { this.name = name; this.bytes = bytes; }
        @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String order) {
            return new NameCursor(name);
        }
        @Override public InputStream openInputStream(Uri uri) { return new ByteArrayInputStream(bytes); }
    }

    private static final class BytesContext extends Context {
        private final ContentResolver resolver;
        BytesContext(String name, byte[] bytes) { resolver = new BytesResolver(name, bytes); }
        @Override public ContentResolver getContentResolver() { return resolver; }
    }

    @Test
    public void readsTextEvenWhenExtensionIsUnknown() throws Exception {
        String text = "Bu metin uzantısı bilinmeyen dosyadan okunmalı.";
        FileManager manager = new FileManager();
        String result = manager.readAttachment(new BytesContext("notlar.unknown", text.getBytes(StandardCharsets.UTF_8)),
                new NamedUri("notlar.unknown"));
        assertTrue(result.contains(text));
    }

    @Test
    public void readsTextLargerThanTheOldEightMiBFixedLimit() throws Exception {
        byte[] content = new byte[9 * 1024 * 1024];
        java.util.Arrays.fill(content, (byte) 'A');
        FileManager manager = new FileManager();
        String result = manager.readAttachment(new BytesContext("large.txt", content), new NamedUri("large.txt"));
        assertTrue(result.length() > 8 * 1024 * 1024);
    }

    @Test
    public void exposesSelectedAttachmentTextToTheGenericTool() throws Exception {
        String request = "Bu dosyayı incele\n[Metin eki: notlar.txt]\nİçerik satırı.";
        String result = new FileManager().inspectAttachmentContext(request);
        assertTrue(result.contains("İçerik satırı."));
    }

    @Test
    public void detectsZipBySignatureEvenWhenExtensionIsUnknown() throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(bytes, StandardCharsets.UTF_8)) {
            zip.putNextEntry(new ZipEntry("manifest.json"));
            zip.write("{\"format_version\":2}".getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        }
        FileManager manager = new FileManager();
        String result = manager.readAttachment(new BytesContext("paket.data", bytes.toByteArray()),
                new NamedUri("paket.data"));
        assertTrue(result.contains("format_version"));
    }
}
