package com.jai.assistant.engine;

import org.junit.Test;
import static org.junit.Assert.*;

public final class LocalIntelligenceEngineTest {
    @Test public void detectsComparisonAndAsksForMissingSecondSubject() {
        LocalIntelligenceEngine.Analysis complete = LocalIntelligenceEngine.analyze(
                "Android ile Java arasındaki farkları karşılaştır",
                "karsilastirma", 0.72, 0.61, 3, 5);
        assertEquals(LocalIntelligenceEngine.TaskKind.COMPARISON, complete.taskKind);
        assertFalse(complete.needsClarification);

        LocalIntelligenceEngine.Analysis incomplete = LocalIntelligenceEngine.analyze(
                "bunu karşılaştır", "karsilastirma", 0.51, 0.10, 0, 1);
        assertEquals(LocalIntelligenceEngine.TaskKind.COMPARISON, incomplete.taskKind);
        assertTrue(incomplete.needsClarification);
        assertTrue(incomplete.clarificationQuestion.contains("hangi iki"));
    }

    @Test public void detectsFreshInformationAndRequestComplexity() {
        LocalIntelligenceEngine.Analysis analysis = LocalIntelligenceEngine.analyze(
                "2026 güncel Android sürümünü ve son güvenlik gelişmelerini araştır",
                "arastirma", 0.65, 0.70, 4, 7);
        assertEquals(LocalIntelligenceEngine.TaskKind.RESEARCH, analysis.taskKind);
        assertTrue(analysis.requiresFreshInformation);
        assertTrue(analysis.complexity >= 2);
    }

    @Test public void attachedTextPreventsFalseSummaryClarification() {
        LocalIntelligenceEngine.Analysis analysis = LocalIntelligenceEngine.analyze(
                "özetle\n[Metin eki: not.txt]\nBu dosyanın uzun metin içeriği.",
                "ozet", 0.5, 0.5, 1, 1);
        assertEquals(LocalIntelligenceEngine.TaskKind.SUMMARY, analysis.taskKind);
        assertFalse(analysis.needsClarification);
    }

    @Test public void twoAttachmentsSatisfyComparisonInputRequirement() {
        LocalIntelligenceEngine.Analysis analysis = LocalIntelligenceEngine.analyze(
                "bunu karşılaştır\n[Metin eki: a.txt]\nBirinci metin\n[Dosya eki: b.pdf]\nİkinci metin",
                "karsilastirma", 0.5, 0.2, 0, 1);
        assertEquals(LocalIntelligenceEngine.TaskKind.COMPARISON, analysis.taskKind);
        assertFalse(analysis.needsClarification);
    }

    @Test public void reportsNoTrainingEvidenceForUnknownVocabulary() {
        LocalIntelligenceEngine.Analysis analysis = LocalIntelligenceEngine.analyze(
                "qzxv plmokn ttrr", "genel", 0.80, 0.0, 0, 3);
        assertEquals(0, analysis.knownTokenCount);
        assertEquals(0.0, analysis.evidenceStrength, 0.000001);
    }
}
