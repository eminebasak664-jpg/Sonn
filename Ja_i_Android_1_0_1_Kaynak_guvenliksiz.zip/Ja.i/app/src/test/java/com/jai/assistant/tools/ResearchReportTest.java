package com.jai.assistant.tools;

import org.junit.Test;
import java.util.Arrays;
import static org.junit.Assert.*;

public class ResearchReportTest {
    @Test
    public void countsReadPagesAndDistinctDomainsSeparately() {
        ResearchReport report = new ResearchReport("Java Android", 1000L, true, Arrays.asList(
                new ResearchSource("Android docs", "https://developer.android.com/guide", "developer.android.com", "A sufficiently long excerpt for the test.", true),
                new ResearchSource("Android blog", "https://developer.android.com/blog", "developer.android.com", "Another sufficiently long excerpt for the test.", false),
                new ResearchSource("Java docs", "https://docs.oracle.com/java", "docs.oracle.com", "A third sufficiently long excerpt for the test.", true)
        ), "test");

        assertEquals(2, report.getReadPageCount());
        assertEquals(2, report.getDistinctDomainCount());
    }

    @Test
    public void displaysPublishedDateWhenExtractedFromPage() {
        ResearchReport report = new ResearchReport("test", 1000L, true,
                Arrays.asList(new ResearchSource("Example", "https://example.com", "example.com",
                        "Example excerpt long enough.", true, "2026-11-03")), "");
        assertTrue(report.toDisplayText().contains("2026-11-03"));
    }

    @Test
    public void reportDoesNotClaimSourceTruthWasVerified() {
        ResearchReport report = new ResearchReport("test", 1000L, true,
                Arrays.asList(new ResearchSource("Example", "https://example.com", "example.com", "Example excerpt long enough.", true)), "");
        String text = report.toDisplayText().toLowerCase();
        assertTrue(text.contains("kanıtlamaz"));
        assertTrue(text.contains("kesin doğrulanmış"));
    }
}
