package com.jai.assistant.engine;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class TurkishTextProcessorTest {
    @Test public void normalizesTurkishCharacters() {
        assertEquals("cagri ve fotograf", TurkishTextProcessor.normalize("Çağrı ve Fotoğraf"));
    }
    @Test public void stripsCommonTurkishSuffixes() {
        assertEquals("fotograf", TurkishTextProcessor.stem("fotoğraflar"));
        assertEquals("ogrenme", TurkishTextProcessor.stem("öğrenmesi"));
    }
    @Test public void removesCommonStopWords() {
        List<String> tokens = TurkishTextProcessor.tokens("bana bunu nasıl anlatırsın?");
        assertFalse(tokens.contains("bana"));
        assertFalse(tokens.contains("nasil"));
    }
    @Test public void expandsUsefulSearchSynonyms() {
        List<String> terms = TurkishTextProcessor.searchTerms("web sitesi");
        assertTrue(terms.contains("web"));
        assertTrue(terms.contains("site"));
        assertTrue(terms.contains("html"));
    }
    @Test public void keepsMeaningfulWords() {
        assertTrue(TurkishTextProcessor.tokens("Java uygulamasında hata ayıkla").contains("java"));
    }
    @Test public void stemsPossessiveAndFindsSynonyms() {
        List<String> terms = TurkishTextProcessor.searchTerms("uygulaması");
        assertTrue(terms.contains("uygulama"));
        assertTrue(terms.contains("program"));
    }
}
