package com.jai.assistant.tools;

import org.junit.Test;
import java.lang.reflect.Method;
import static org.junit.Assert.*;

public class WebResearchEngineTest {
    @Test
    public void emptyQueryDoesNotAttemptNetworkSearch() {
        ResearchReport report = new WebResearchEngine().researchDetailed("   ", 5);
        assertFalse(report.searchCompleted);
        assertTrue(report.getSources().isEmpty());
        assertTrue(report.note.contains("boş"));
    }

    @Test
    public void initialSearchUrlContainsExactlyOneQueryParameter() throws Exception {
        WebResearchEngine engine = new WebResearchEngine();
        Method method = WebResearchEngine.class.getDeclaredMethod("buildInitialSearchUrl", String.class);
        method.setAccessible(true);
        String url = (String) method.invoke(engine, "ja%20ai");
        assertTrue(url.contains("/html/?q=ja%20ai&kl=tr-tr"));
        assertFalse(url.contains("q=q="));
    }

    @Test
    public void extractsDuckDuckGoContinuationTokenForPaginatedSearch() throws Exception {
        WebResearchEngine engine = new WebResearchEngine();
        Method method = WebResearchEngine.class.getDeclaredMethod("extractVqd", String.class);
        method.setAccessible(true);
        String html = "<form><input type=\"hidden\" name=\"vqd\" value=\"token-123\"></form>";
        assertEquals("token-123", method.invoke(engine, html));
    }
}
