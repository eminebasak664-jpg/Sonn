package com.jai.assistant.tools;

import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.nio.ByteOrder;
import static org.junit.Assert.assertTrue;

public final class NbtInspectorTest {
    @Test
    public void readsJavaBigEndianNbtString() throws Exception {
        String report = new NbtInspector().inspect(sample(ByteOrder.BIG_ENDIAN), false);
        assertTrue(report.contains("hello"));
        assertTrue(report.contains("value"));
    }

    @Test
    public void readsBedrockLittleEndianNbtString() throws Exception {
        String report = new NbtInspector().inspect(sample(ByteOrder.LITTLE_ENDIAN), true);
        assertTrue(report.contains("hello"));
        assertTrue(report.contains("value"));
    }

    private byte[] sample(ByteOrder order) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeByte(10); writeShort(out, 4, order); out.writeBytes("root");
        out.writeByte(8); writeShort(out, 5, order); out.writeBytes("hello");
        writeShort(out, 5, order); out.writeBytes("value");
        out.writeByte(0);
        return bytes.toByteArray();
    }

    private void writeShort(DataOutputStream out, int value, ByteOrder order) throws Exception {
        if (order == ByteOrder.BIG_ENDIAN) out.writeShort(value);
        else { out.writeByte(value & 0xff); out.writeByte((value >>> 8) & 0xff); }
    }
}
