package com.jai.assistant.tools;

import org.junit.Test;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import static org.junit.Assert.assertTrue;

public final class TarArchiveInspectorTest {
    @Test
    public void readsTextFromTarWithoutExtracting() throws Exception {
        byte[] content = "TAR_SAMPLE_CONTENT".getBytes(StandardCharsets.UTF_8);
        byte[] archive = tar("notes.txt", content);
        String report = new TarArchiveInspector().inspect(new ByteArrayInputStream(archive));
        assertTrue(report.contains("notes.txt"));
        assertTrue(report.contains("TAR_SAMPLE_CONTENT"));
    }

    private byte[] tar(String name, byte[] content) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] header = new byte[512];
        byte[] nameBytes = name.getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(nameBytes, 0, header, 0, nameBytes.length);
        octal(header, 100, 8, 0644);
        octal(header, 108, 8, 0);
        octal(header, 116, 8, 0);
        octal(header, 124, 12, content.length);
        octal(header, 136, 12, 0);
        for (int i = 148; i < 156; i++) header[i] = 32;
        header[156] = '0';
        byte[] magic = "ustar".getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(magic, 0, header, 257, magic.length);
        int checksum = 0;
        for (byte value : header) checksum += value & 0xff;
        String sum = String.format(java.util.Locale.ROOT, "%06o", checksum);
        System.arraycopy(sum.getBytes(StandardCharsets.US_ASCII), 0, header, 148, 6);
        header[154] = 0; header[155] = 32;
        out.write(header); out.write(content);
        int padding = (512 - (content.length % 512)) % 512;
        out.write(new byte[padding]); out.write(new byte[1024]);
        return out.toByteArray();
    }

    private void octal(byte[] target, int offset, int length, long value) {
        String raw = String.format(java.util.Locale.ROOT, "%0" + (length - 1) + "o", value);
        byte[] bytes = raw.getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(bytes, 0, target, offset, Math.min(bytes.length, length - 1));
        target[offset + length - 1] = 0;
    }
}
