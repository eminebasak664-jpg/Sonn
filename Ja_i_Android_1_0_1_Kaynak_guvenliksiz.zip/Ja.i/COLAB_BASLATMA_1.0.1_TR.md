# Ja.i 1.0.1 — Colab eğitimini başlatma

1. Google Colab'ı Android tarayıcısında aç.
2. `colab/Ja.i_1.0.1_Sifirdan_Sohbet_Modeli_Egitimi.ipynb` dosyasını Colab'a yükle.
3. Çalışma zamanı ayarlarından GPU varsa GPU seç; yoksa CPU ile çalışabilir ancak eğitim çok daha yavaş olur.
4. Notebook hücrelerini sırayla çalıştır. İlk hücre gerekli Python paketlerini kurar.
5. Veri indirme ve temizleme tamamlanınca örnek denetim tablosunu dikkatle oku.
6. Veriyi uygun bulursan ayarlar hücresinde `APPROVE_DATA_AFTER_REVIEW = True` yap ve onay hücresini tekrar çalıştır.
7. Smoke test geçerse eğitim hücresini çalıştır. GPU belleği yetmezse `BATCH_SIZE = 8` yapıp eğitim hücresini tekrar çalıştır; yeni eğitim başlatılmadan eski checkpointler temizlenir.
8. Eğitim tamamlanınca ONNX/PyTorch karşılaştırması, test loss ve ZIP kontrolü otomatik yapılır. Son hücre `jai-chat-model.zip` dosyasını indirir.
9. APK içinden **Zekâ ayarı → Colab modelini yükle** yoluyla ZIP'i seç.

## Model sözleşmesi

Notebook hazır model veya hazır ağırlık indirmez. GRU rastgele ağırlıklarla sıfırdan eğitilir; haricî sohbet AI API'si çağrılmaz. Android uyumu için `jai-gru-byte-v1`, UTF-8 byte tokenizer, özel token kimlikleri, 384 gizil boyut, 3 GRU katmanı, 512 token bağlamı, ONNX giriş/çıkış adları ve üç üyeli model ZIP biçimi korunur.

## Dikkat

Tam eğitim burada yapılmadı. Notebook'un eğitim ve ONNX adımlarını kendi Colab oturumunda çalıştırmalısın. Loss değerleri modelin genel doğruluğunu veya insan seviyesinde zekâsını kanıtlamaz; test cevaplarını ayrıca oku. Colab oturumu sıfırlanırsa `/content` içindeki checkpointler silinebilir.
