package org.gradle.wrapper;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Small source-included Gradle bootstrap used by this project when the official
 * Gradle wrapper JAR cannot be supplied by the build environment. It reads the
 * project's distributionUrl, downloads the distribution when needed, safely
 * extracts it, and forwards all command-line arguments to Gradle.
 *
 * This is a minimal bootstrap implementation, not the official Gradle wrapper.
 */
public final class GradleWrapperMain {
    private GradleWrapperMain() { }

    public static void main(String[] args) {
        try {
            Path projectDir = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
            Path propertiesPath = projectDir.resolve("gradle/wrapper/gradle-wrapper.properties");
            if (!Files.isRegularFile(propertiesPath)) {
                throw new IOException("gradle/wrapper/gradle-wrapper.properties bulunamadı. Proje kökünden çalıştır.");
            }
            Properties properties = new Properties();
            try (InputStream input = Files.newInputStream(propertiesPath)) {
                properties.load(input);
            }
            String distributionUrl = properties.getProperty("distributionUrl", "").trim();
            if (!distributionUrl.startsWith("https://") && !distributionUrl.startsWith("http://")) {
                throw new IOException("Geçerli bir Gradle distributionUrl ayarlı değil.");
            }
            Path gradleExecutable = ensureGradle(distributionUrl);
            int exitCode = runGradle(gradleExecutable, args);
            System.exit(exitCode);
        } catch (Exception exception) {
            System.err.println("Ja.i Gradle başlatıcısı: " + safeMessage(exception));
            System.exit(1);
        }
    }

    private static Path ensureGradle(String distributionUrl) throws IOException {
        String fileName = distributionUrl.substring(distributionUrl.lastIndexOf('/') + 1);
        String distributionName = fileName.endsWith(".zip") ? fileName.substring(0, fileName.length() - 4) : "gradle-custom";
        String distributionDirName = distributionName.replace("-bin", "").replace("-all", "");
        String versionKey = distributionName.replaceAll("[^A-Za-z0-9._-]", "_");
        String home = System.getenv("GRADLE_USER_HOME");
        if (home == null || home.trim().isEmpty()) home = Paths.get(System.getProperty("user.home"), ".gradle").toString();
        Path cache = Paths.get(home).resolve("wrapper/dists").resolve(versionKey).resolve("jai-bootstrap");
        Files.createDirectories(cache);
        Path existing = findGradleExecutable(cache, distributionDirName);
        if (existing != null) return existing;

        Path zipPath = cache.resolve(fileName);
        if (!Files.isRegularFile(zipPath) || Files.size(zipPath) == 0) download(distributionUrl, zipPath);
        extractSafely(zipPath, cache);
        existing = findGradleExecutable(cache, distributionDirName);
        if (existing == null) throw new IOException("Gradle ZIP'i indirildi fakat gradle yürütülebilir dosyası bulunamadı.");
        return existing;
    }

    private static void download(String urlText, Path destination) throws IOException {
        System.err.println("Gradle dağıtımı indiriliyor. Bu işlem internet ve depolama alanı gerektirir.");
        HttpURLConnection connection = (HttpURLConnection) new URL(urlText).openConnection();
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(60000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", "Ja.i-build-bootstrap/0.1");
        try {
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new IOException("Gradle indirme sunucusu HTTP " + status + " yanıtı verdi.");
            Path temporary = destination.resolveSibling(destination.getFileName().toString() + ".part");
            try (InputStream input = connection.getInputStream(); OutputStream output = Files.newOutputStream(temporary)) {
                byte[] buffer = new byte[16384];
                int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            }
            Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            connection.disconnect();
        }
    }

    private static void extractSafely(Path zipPath, Path destination) throws IOException {
        Path root = destination.toAbsolutePath().normalize();
        try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(zipPath))) {
            ZipEntry entry;
            byte[] buffer = new byte[16384];
            while ((entry = zip.getNextEntry()) != null) {
                Path target = root.resolve(entry.getName()).normalize();
                if (!target.startsWith(root)) throw new IOException("Gradle arşivinde güvenli olmayan dosya yolu tespit edildi.");
                if (entry.isDirectory()) {
                    Files.createDirectories(target);
                } else {
                    Path parent = target.getParent();
                    if (parent != null) Files.createDirectories(parent);
                    try (OutputStream output = Files.newOutputStream(target)) {
                        int count;
                        while ((count = zip.read(buffer)) != -1) output.write(buffer, 0, count);
                    }
                }
                zip.closeEntry();
            }
        }
    }

    private static Path findGradleExecutable(Path cache, String distributionDirName) {
        String executable = isWindows() ? "gradle.bat" : "gradle";
        Path first = cache.resolve(distributionDirName).resolve("bin").resolve(executable);
        if (Files.isRegularFile(first)) return first;
        try (java.util.stream.Stream<Path> paths = Files.walk(cache, 5)) {
            return paths.filter(path -> path.getFileName() != null && path.getFileName().toString().equals(executable)
                    && path.getParent() != null && path.getParent().getFileName().toString().equals("bin"))
                    .findFirst().orElse(null);
        } catch (IOException ignored) {
            return null;
        }
    }

    private static int runGradle(Path executable, String[] args) throws IOException, InterruptedException {
        List<String> command = new ArrayList<>();
        if (isWindows()) {
            command.add("cmd.exe");
            command.add("/c");
            command.add(executable.toString());
        } else {
            try {
                executable.toFile().setExecutable(true, true);
            } catch (SecurityException ignored) {
                // Gradle will emit the actual execution error if permissions cannot be changed.
            }
            command.add(executable.toString());
        }
        for (String arg : args) command.add(arg);
        return new ProcessBuilder(command).inheritIO().start().waitFor();
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }

    private static String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.trim().isEmpty() ? exception.getClass().getSimpleName() : message;
    }
}
