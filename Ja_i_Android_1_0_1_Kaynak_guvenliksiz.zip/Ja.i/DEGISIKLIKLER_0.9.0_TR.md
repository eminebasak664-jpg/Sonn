# Ja.i 0.9.0 — Değişiklikler

Bu sürüm yalnızca dosya ve web araçlarını geliştirir; temel arayüz yeniden tasarlanmadı ve APK üretimi bu çalışmanın hedefi değildir.

## Dosya okuyucu
- Dosya seçici `*/*` türündeki dosyaları kabul eder; çoklu seçimde sabit 5 dosya sınırı kaldırıldı.
- Uzantı listesine bağlı kalmadan UTF-8/UTF-16 metin içeriği algılanır.
- ZIP/JAR/APK/AAB/MCPACK/MCADDON/MCWORLD, Office Open XML, OpenDocument, EPUB ve CBZ gibi ZIP tabanlı paketlerin metin/XML girdileri okunur; iç içe ZIP desteği eklendi.
- Minecraft `.nbt` ve `.mcstructure` dosyaları için big-endian/little-endian NBT ayrıştırıcısı eklendi.
- TAR, GZIP ve TGZ desteği eklendi.
- PDF/fotoğraf işlemleri mevcut PDFBox Android ve cihaz içi ML Kit hattını kullanmaya devam eder.
- Ses/video meta verileri okunur; transkripsiyon yapılmaz. Bilinmeyen ikili dosyalarda okunabilir metin dizeleri çıkarılır.
- RAR/7z açılmaz; JAR `.class` dosyaları Java kaynak koduna geri çevrilmez. Bu sınırlar raporda açıkça belirtilir.

## Uyarlanabilir web araştırması
- Ana sohbet ve WorkManager öğrenme görevi sabit sonuç adedi yerine `researchAdaptive` metodunu çağırır.
- Başlangıç sorguları Think çabasına göre genişler. Yeni kaynak başlıkları ve Derin/Maksimum modlarında içerik terimleri takip sorguları üretir.
- Sabit 5 sorgu sınırı kaldırıldı. Sayfalama yeni URL geldikçe sürer; 2 ardışık sorguda yeni kaynak gelmezse kuyruk sonlandırılır.
- DuckDuckGo başlangıç GET adresindeki sorgu parametresi ve sonraki sayfa isteğinin `vqd` içeren POST formu ayrı oluşturulur; URL kurucu testi eklendi.
- HTTPS/yerel ağ hedefi denetimi korunur; yayın tarihi meta alanları okunmaya çalışılır.

## Güvenlik ve telefon kaynakları
- Arşivler diske çıkarılmaz; mutlak yol ve `..` yol geçişleri reddedilir.
- Arşiv başına 10.000 girdi, girdi başına 16 MiB, toplam açılmış veri için 128 MiB, iç içe arşiv derinliği 3 ve rapor çıktısı için 8 MiB güvenlik sınırları vardır.
- Normal metin dosyası 8 MiB, sohbet mesajına birleşik ek içeriği 8 MiB ile sınırlıdır. Sınırı aşan dosya için durum mesajı verilir.
- Bu limitler uzantı kısıtlaması değil, bellek/CPU ve arşiv bombası korumasıdır. Her ikili dosya biçiminin tam çözümlenmesi iddia edilmez.

## Test durumu
- `ZipArchiveInspector`, `NbtInspector`, `TarArchiveInspector`, `ResearchReport` ve `WebResearchEngine` için 14 JUnit uyumlu test metodu geçti; uzantısı bilinmeyen metin ve ZIP imzalı dosya için FileManager testleri de eklendi.
- Saf Java motor sınıfları JDK 17 ile derlendi. `FileManager`, geçici Android API uyumlu stub sınıflarıyla sözdizimi/bağlantı kontrolünden geçti.
- Tam Gradle test paketi, Android SDK derlemesi ve cihaz üstünde UI testi bu ortamda çalıştırılmadı. Canlı DuckDuckGo POST/pagination ve gerçek dosya sağlayıcısı entegrasyonu da cihaz üzerinde doğrulanmadı.
