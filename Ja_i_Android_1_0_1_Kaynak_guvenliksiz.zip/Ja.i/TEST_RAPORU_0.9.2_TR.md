# Ja.i 0.9.2 — Test raporu

## Eklenen regresyon testleri
- Önceki üç seviye sınırını aşan altı katmanlı iç içe ZIP içeriğinin okunması.
- Toplam açılmış verisi 130 MiB'ı aşan (136.314.880 bayt) ZIP'in sabit 128 MiB toplam kotası olmadan taranması.
- Önceki sabit 8 MiB metin dosyası kotasını aşan 9 MiB metnin okunması.
- Ekli metnin `FileManager.inspectAttachmentContext` üzerinden genel araç girdisi olarak alınması.
- Önceki ZIP yol geçişi reddi ve dosya imzası algılama testleri korunur.

## Bu ortamda doğrulama durumu
- `ResourceAwareBudget`, `NbtInspector`, `ZipArchiveInspector`, `TarArchiveInspector` ve `FileManager`, geçici Android API arayüzleriyle OpenJDK 21 üzerinde `javac` üzerinden derlendi.
- Geçici JVM düzeneğinde `ZipArchiveInspectorTest` ve `FileManagerTest` içindeki dokuz test, Android/JUnit API'lerinin hafif geçici stub'larıyla derlenip çalıştırıldı; dokuzunun tamamı `PASS`. Buna 9 MiB metin, altı katmanlı ZIP, 136.314.880 bayt toplam açılmış verili ZIP, dosya eki aracı, ZIP imza tanıma ve yol geçişi reddi dahil.
- Ayrı akış testinde normal TAR ve TGZ içerikleri de `PASS` verdi.
- `ResearchSource`, `ResearchReport` ve `WebResearchEngine` de OpenJDK 21 ile derlendi. Canlı web isteği çalıştırılmadı.
- `FileManager` Android API stub'larıyla derlendi; bu gerçek Android SDK derlemesi değildir. `BrainEngine` ve `MainActivity` için tam Android derlemesi yapılmadı.
- Gerçek Gradle/JUnit çalıştırması ve APK derlemesi henüz başarıyla tamamlanmadı.
- Android SDK/Gradle dağıtımı erişilebilir değilse testler yerel ortamda tamamlanamayabilir.
- Gerçek cihaz testi yapılmadan büyük arşivlerin her telefonda tamamen okunacağı iddia edilmez; dinamik heap bütçesi cihazın belleğine göre işlem kesebilir.

## Cihazda test planı
1. 9 MiB üzeri düz metin dosyası ekle ve içeriğe dair soru sor.
2. En az 5 katmanlı ZIP içeren ZIP paketi ekle; en içteki metnin raporda göründüğünü denetle.
3. 128 MiB üzeri toplam açılmış içerik içeren ve çok sayıda küçük dosyaya bölünmüş test ZIP/TAR arşivini dene; toplam açılımın 128 MiB nedeniyle kesilmediğini, ekrandaki raporun yalnızca kullanılabilir RAM kadar gösterilebildiğini doğrula.
4. Ara açıkken güncel bir konu sor; cevapta araştırma öncesinde toplanan kaynak linklerinin yer aldığını doğrula.
5. Ara kapalıyken aynı soruyu sor; ağ isteği yapılmadığını doğrula.
6. Think modunda Ara açık araştırma yap; görev duraklatılıp devam ettirildiğinde `supplemental_context` verisinin korunduğunu denetle.
