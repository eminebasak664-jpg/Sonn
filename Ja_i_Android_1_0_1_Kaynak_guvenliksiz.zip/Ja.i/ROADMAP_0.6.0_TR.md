# Ja.i 0.7.0 — Özellik ve dürüstlük durumu

| Alan | 0.7.0 durumu | Gerçek sınır |
|---|---|---|
| PDF | Kısmen çalışır kod eklendi | İlk 20 sayfada metin; taranmış PDF için ilk 5 sayfada OCR. Android derlemesi/cihaz testi bekliyor. |
| Fotoğraf | Kısmen çalışır kod eklendi | OCR + en fazla 8 görsel etiketi. Genel görsel muhakeme değil. Derleme/cihaz testi bekliyor. |
| Kod üretimi | Sınırlı | 6 yerel şablon ve açıklamalı fallback. Herhangi bir metin isteğini genel şekilde kodlamaz. |
| Kod çalıştırma | JavaScript sınırlı sandbox | Rhino, 80.000 karakter üst sınırı, varsayılan 1,5 saniye zaman sınırı (üst sınır 5 saniye), 12.000 karakter çıktı. Java/Python/HTML çalıştırılmaz. |
| Uzun görev | Kod ve kalıcı kuyruk eklendi | WorkManager adım adım araştırma-kaydetme-özetleme yapar. Android güç yönetimi geciktirebilir; gerçek cihazda test bekliyor. |
| Yerel dil | Geliştirildi ama sınırlı | Hafıza arama, kelime puanlama ve cümle seçme; genel LLM değil. |
| Gerçek mesajlaşma | Sunucu + Android istemci kaynak kodu | İki hesap, HTTPS ve backend dağıtımı gerekir. Sunucu canlıya dağıtılmadı; push ve uçtan uca şifreleme yok. |
| Sunucu uyandırma | İstemci kodu mevcut | Uygulama açıldığında bir istek. Sunucu sağlayıcısının bu istekle uyanması platform desteğine bağlı. |

## Henüz tamamlanmayan doğrulamalar

- Android Gradle derlemesi ve Android 8+ gerçek cihaz testi.
- ML Kit OCR/etiketleyici ve PDFBox akışının telefonda bellek/performans testi.
- Rhino sandbox birim testlerinin Android/Gradle üzerinde yürütülmesi.
- WorkManager uygulama kapatma, ağ kaybı, Ara kapatma ve tekrar devam senaryoları testi.
- Backend'in HTTPS üzerinde gerçek bulut dağıtımı ve iki ayrı Android cihazla uçtan uca testi.
- Üretim güvenliği: uçtan uca şifreleme, rate limiting/abuse önleme, hesap kurtarma, kullanıcı engelleme ve gizlilik politikası.

Bu sürümde APK oluşturulmamıştır. `build_apk` girişi kapalıyken GitHub Actions sadece doğrulama ve test çalıştırır. Ana APK yalnızca tüm özellikler ve testler tamamlandığında açıkça istenerek üretilecektir.


## 0.7.0 geliştirme güncellemesi
- Yerel Türkçe metin normalleştirme, sınırlı kök/ek çözümleme ve sinonim genişletme eklendi.
- Hafıza cümleleri anahtar sözcük puanlarıyla sıralanıyor; kaynak URL'leri yanıtla birlikte gösteriliyor.
- Kod üretimi daha geniş tarif kataloğuna, sayısal parametrelere ve `supported/runnableInLab` durumuna kavuştu.
- Bilinmeyen kod talepleri artık sahte bir kod örneğiyle doldurulmuyor.
- GitHub Actions iş akışında `build_apk` anahtarı kaldırıldı; yeni versioned kaynak ZIP'i push edilince APK otomatik derleniyor.
- Yerel Android SDK/Gradle dağıtımı bulunmadığı için gerçek APK build'i bu ortamda doğrulanamadı. GitHub deposu entegrasyonu dosya yazma isteğini 403 ile reddetti; iş akışı dosyası ve yeni kaynak ZIP'i bu teslimatta hazırlandı, uzak depoya otomatik commit edilmedi.
