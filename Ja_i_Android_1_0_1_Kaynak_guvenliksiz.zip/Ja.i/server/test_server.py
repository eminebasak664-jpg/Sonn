import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient
import main as backend


class MessagingFlowTests(unittest.TestCase):
    def setUp(self):
        backend._RATE_BUCKETS.clear()
        self.temp_dir = tempfile.TemporaryDirectory()
        backend.DB_PATH = Path(self.temp_dir.name) / "test.sqlite3"
        backend.init_db()
        self.client = TestClient(backend.app)

    def tearDown(self):
        self.client.close()
        self.temp_dir.cleanup()

    def test_real_delivery_and_read_receipts(self):
        a = self.client.post("/v1/register", json={"username": "alpha_user", "password": "safe-passphrase-001"})
        b = self.client.post("/v1/register", json={"username": "beta_user", "password": "safe-passphrase-002"})
        self.assertEqual(a.status_code, 200)
        self.assertEqual(b.status_code, 200)
        token_a = a.json()["token"]
        token_b = b.json()["token"]

        sent = self.client.post("/v1/messages", headers={"Authorization": "Bearer " + token_a},
                                json={"recipient": "beta_user", "text": "Merhaba Ja.i"})
        self.assertEqual(sent.status_code, 200)
        message_id = sent.json()["id"]

        before = self.client.get(f"/v1/messages/{message_id}/status", headers={"Authorization": "Bearer " + token_a})
        self.assertEqual(before.json()["status"], "sent")

        inbox = self.client.get("/v1/messages", headers={"Authorization": "Bearer " + token_b})
        self.assertEqual(inbox.status_code, 200)
        self.assertEqual(inbox.json()["messages"][0]["text"], "Merhaba Ja.i")

        delivered = self.client.get(f"/v1/messages/{message_id}/status", headers={"Authorization": "Bearer " + token_a})
        self.assertEqual(delivered.json()["status"], "delivered")

        read = self.client.post(f"/v1/messages/{message_id}/read", headers={"Authorization": "Bearer " + token_b})
        self.assertEqual(read.status_code, 200)
        after_read = self.client.get(f"/v1/messages/{message_id}/status", headers={"Authorization": "Bearer " + token_a})
        self.assertEqual(after_read.json()["status"], "read")

    def test_recipient_must_exist(self):
        a = self.client.post("/v1/register", json={"username": "alpha_user", "password": "safe-passphrase-003"})
        token = a.json()["token"]
        result = self.client.post("/v1/messages", headers={"Authorization": "Bearer " + token},
                                  json={"recipient": "missing_user", "text": "test"})
        self.assertEqual(result.status_code, 404)

    def test_duplicate_account_is_rejected(self):
        first = self.client.post("/v1/register", json={"username": "same_user", "password": "safe-passphrase-004"})
        second = self.client.post("/v1/register", json={"username": "same_user", "password": "safe-passphrase-005"})
        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 409)

    def test_message_endpoints_require_login(self):
        response = self.client.get("/v1/messages")
        self.assertEqual(response.status_code, 401)

    def test_login_route_has_basic_ip_rate_limit(self):
        for _ in range(6):
            response = self.client.post("/v1/login", json={"username": "unknown_user", "password": "safe-passphrase-006"})
            self.assertEqual(response.status_code, 401)
        limited = self.client.post("/v1/login", json={"username": "unknown_user", "password": "safe-passphrase-006"})
        self.assertEqual(limited.status_code, 429)


if __name__ == "__main__":
    unittest.main()
