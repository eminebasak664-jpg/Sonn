"""Ja.i minimal real messaging backend.
Run with: uvicorn main:app --host 0.0.0.0 --port 8000
Use only behind an HTTPS reverse proxy in any public deployment.
Messages are stored as plaintext in this MVP; do not send sensitive information.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import time
from threading import Lock
from pathlib import Path
from typing import Optional
from contextlib import contextmanager

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("JAI_DATA_DIR", str(APP_DIR / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "jai_messages.sqlite3"
TOKEN_TTL_SECONDS = 60 * 60 * 24 * 30
PASSWORD_ITERATIONS = 310_000
bearer = HTTPBearer(auto_error=False)
app = FastAPI(title="Ja.i Message Server", version="0.6.0")
_RATE_LOCK = Lock()
_RATE_BUCKETS: dict[tuple[str, str], list[float]] = {}


class Credentials(BaseModel):
    username: str = Field(min_length=3, max_length=24)
    password: str = Field(min_length=10, max_length=128)


class SendMessage(BaseModel):
    recipient: str = Field(min_length=3, max_length=24)
    text: str = Field(min_length=1, max_length=4000)


def connect() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH, timeout=15)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA journal_mode=WAL")
    return connection


@contextmanager
def db_session():
    db = connect()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def init_db() -> None:
    with db_session() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            salt BLOB NOT NULL,
            password_hash BLOB NOT NULL,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            token_hash BLOB NOT NULL UNIQUE,
            expires_at INTEGER NOT NULL,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_id INTEGER NOT NULL REFERENCES users(id),
            recipient_id INTEGER NOT NULL REFERENCES users(id),
            text TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            delivered_at INTEGER,
            read_at INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_messages_inbox ON messages(recipient_id, id);
        CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id, id);
        CREATE INDEX IF NOT EXISTS idx_tokens_hash ON tokens(token_hash);
        """)


@app.on_event("startup")
def on_startup() -> None:
    init_db()


@app.middleware("http")
async def public_https_guard(request, call_next):
    forwarded = request.headers.get("x-forwarded-proto", "").split(",")[0].strip().lower()
    secure = request.url.scheme == "https" or forwarded == "https"
    client_host = request.client.host if request.client else "unknown"
    local = client_host in {"127.0.0.1", "::1", "testclient"}
    if os.environ.get("JAI_ALLOW_INSECURE_LOCAL", "0") != "1" and not secure and not local:
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=400, content={"detail": "HTTPS is required for public access."})

    # Tek işlemci örneği için temel IP hız sınırı. Dağıtık/çoklu worker koruması değildir.
    path = request.url.path
    limit = 6 if path in {"/v1/login", "/v1/register"} else 120
    now = time.monotonic()
    key = (client_host, path if limit == 6 else "general")
    with _RATE_LOCK:
        recent = [stamp for stamp in _RATE_BUCKETS.get(key, []) if now - stamp < 60.0]
        if len(recent) >= limit:
            from fastapi.responses import JSONResponse
            return JSONResponse(status_code=429, headers={"Retry-After": "60"},
                                 content={"detail": "Çok fazla istek gönderildi. Bir dakika sonra tekrar dene."})
        recent.append(now)
        _RATE_BUCKETS[key] = recent
    return await call_next(request)


def normalize_username(value: str) -> str:
    username = (value or "").strip().lower()
    if not re.fullmatch(r"[a-z0-9_]{3,24}", username):
        raise HTTPException(status_code=422, detail="Kullanıcı adı 3-24 karakter olmalı; harf, rakam ve alt çizgi kullan.")
    return username


def password_hash(password: str, salt: bytes) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS, dklen=32)


def new_token(db: sqlite3.Connection, user_id: int) -> str:
    raw = secrets.token_urlsafe(36)
    digest = hashlib.sha256(raw.encode("utf-8")).digest()
    now = int(time.time())
    db.execute("INSERT INTO tokens(user_id,token_hash,expires_at,created_at) VALUES(?,?,?,?)",
               (user_id, digest, now + TOKEN_TTL_SECONDS, now))
    return raw


def current_user(credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer)) -> sqlite3.Row:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(status_code=401, detail="Bearer oturumu gerekli.")
    digest = hashlib.sha256(credentials.credentials.encode("utf-8")).digest()
    now = int(time.time())
    with db_session() as db:
        row = db.execute("""SELECT users.id, users.username FROM tokens
                            JOIN users ON users.id=tokens.user_id
                            WHERE tokens.token_hash=? AND tokens.expires_at>? LIMIT 1""",
                         (digest, now)).fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="Oturum geçersiz veya süresi dolmuş.")
    return row


@app.get("/health")
def health():
    with db_session() as db:
        db.execute("SELECT 1").fetchone()
    return {"status": "ok", "service": "jai-message-server", "version": "0.6.0"}


@app.post("/v1/register")
def register(payload: Credentials):
    username = normalize_username(payload.username)
    salt = secrets.token_bytes(16)
    digest = password_hash(payload.password, salt)
    now = int(time.time())
    try:
        with db_session() as db:
            cursor = db.execute("INSERT INTO users(username,salt,password_hash,created_at) VALUES(?,?,?,?)",
                                (username, salt, digest, now))
            user_id = int(cursor.lastrowid)
            token = new_token(db, user_id)
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="Bu kullanıcı adı zaten kullanılıyor.")
    return {"username": username, "token": token, "expires_in": TOKEN_TTL_SECONDS}


@app.post("/v1/login")
def login(payload: Credentials):
    username = normalize_username(payload.username)
    with db_session() as db:
        row = db.execute("SELECT id,salt,password_hash FROM users WHERE username=?", (username,)).fetchone()
        if row is None or not hmac.compare_digest(password_hash(payload.password, row["salt"]), row["password_hash"]):
            raise HTTPException(status_code=401, detail="Kullanıcı adı veya parola hatalı.")
        token = new_token(db, int(row["id"]))
    return {"username": username, "token": token, "expires_in": TOKEN_TTL_SECONDS}


@app.get("/v1/users/exists")
def user_exists(username: str = Query(min_length=3, max_length=24), user=Depends(current_user)):
    target = normalize_username(username)
    with db_session() as db:
        row = db.execute("SELECT 1 FROM users WHERE username=?", (target,)).fetchone()
    return {"username": target, "exists": row is not None}


@app.post("/v1/messages")
def send_message(payload: SendMessage, user=Depends(current_user)):
    recipient = normalize_username(payload.recipient)
    text = payload.text.strip()
    if not text:
        raise HTTPException(status_code=422, detail="Mesaj boş olamaz.")
    if user["username"] == recipient:
        raise HTTPException(status_code=400, detail="Kendine mesaj göndermek desteklenmiyor.")
    now = int(time.time())
    with db_session() as db:
        target = db.execute("SELECT id FROM users WHERE username=?", (recipient,)).fetchone()
        if target is None:
            raise HTTPException(status_code=404, detail="Alıcı hesabı bulunamadı.")
        cursor = db.execute("INSERT INTO messages(sender_id,recipient_id,text,created_at) VALUES(?,?,?,?)",
                             (int(user["id"]), int(target["id"]), text, now))
        message_id = int(cursor.lastrowid)
    return {"id": message_id, "status": "sent", "created_at": now,
            "note": "Sunucu mesajı kabul edip alıcının gelen kutusuna koydu; teslim/okundu durumu ayrı sorgulanır."}


@app.get("/v1/messages")
def inbox(after_id: int = Query(default=0, ge=0), limit: int = Query(default=50, ge=1, le=100), user=Depends(current_user)):
    now = int(time.time())
    with db_session() as db:
        rows = db.execute("""SELECT messages.id, sender.username AS sender, recipient.username AS recipient,
                                    messages.text, messages.created_at, messages.delivered_at, messages.read_at
                             FROM messages JOIN users AS sender ON sender.id=messages.sender_id
                             JOIN users AS recipient ON recipient.id=messages.recipient_id
                             WHERE messages.recipient_id=? AND messages.id>? ORDER BY messages.id ASC LIMIT ?""",
                          (int(user["id"]), after_id, limit)).fetchall()
        ids = [int(row["id"]) for row in rows]
        if ids:
            placeholders = ",".join("?" for _ in ids)
            db.execute(f"UPDATE messages SET delivered_at=COALESCE(delivered_at,?) WHERE id IN ({placeholders})",
                       [now] + ids)
        messages = [{"id": int(row["id"]), "sender": row["sender"], "recipient": row["recipient"],
                     "text": row["text"], "created_at": int(row["created_at"]),
                     "delivered_at": int(row["delivered_at"] or now), "read_at": row["read_at"]}
                    for row in rows]
    return {"messages": messages, "count": len(messages)}


@app.post("/v1/messages/{message_id}/read")
def mark_read(message_id: int, user=Depends(current_user)):
    now = int(time.time())
    with db_session() as db:
        updated = db.execute("UPDATE messages SET delivered_at=COALESCE(delivered_at,?), read_at=COALESCE(read_at,?) WHERE id=? AND recipient_id=?",
                             (now, now, message_id, int(user["id"]))).rowcount
    if not updated:
        raise HTTPException(status_code=404, detail="Mesaj bulunamadı veya bu hesaba ait değil.")
    return {"id": message_id, "status": "read", "read_at": now}


@app.get("/v1/messages/{message_id}/status")
def message_status(message_id: int, user=Depends(current_user)):
    with db_session() as db:
        row = db.execute("""SELECT id,sender_id,recipient_id,created_at,delivered_at,read_at FROM messages
                            WHERE id=? AND (sender_id=? OR recipient_id=?)""",
                         (message_id, int(user["id"]), int(user["id"]))).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Mesaj bulunamadı.")
    status = "read" if row["read_at"] else "delivered" if row["delivered_at"] else "sent"
    return {"id": int(row["id"]), "status": status, "created_at": int(row["created_at"]),
            "delivered_at": row["delivered_at"], "read_at": row["read_at"]}


@app.post("/v1/logout")
def logout(credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer)):
    if credentials is None:
        return {"ok": True}
    digest = hashlib.sha256(credentials.credentials.encode("utf-8")).digest()
    with db_session() as db:
        db.execute("DELETE FROM tokens WHERE token_hash=?", (digest,))
    return {"ok": True}
