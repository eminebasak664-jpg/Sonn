#!/usr/bin/env sh
set -eu
APP_HOME=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$APP_HOME"
if ! command -v java >/dev/null 2>&1; then
  echo "HATA: JDK 21 bulunamadı. Bu paketin Gradle başlatıcısı JDK 21 gerektirir." >&2
  exit 1
fi
JAVA_VERSION=$(java -version 2>&1 | sed -n '1s/.*version "\([0-9]*\).*/\1/p')
if [ -z "$JAVA_VERSION" ] || [ "$JAVA_VERSION" -lt 21 ]; then
  echo "HATA: JDK 21 veya üzeri gerekli; bulunan ana sürüm: ${JAVA_VERSION:-belirsiz}." >&2
  exit 1
fi
printf '%s\n' 'Ja.i kaynak doğrulaması, birim testleri ve debug APK derlemesi başlatılıyor...'
chmod +x ./gradlew
./gradlew --no-daemon validateAndroidResources testDebugUnitTest assembleDebug
APK="$APP_HOME/app/build/outputs/apk/debug/app-debug.apk"
if [ -s "$APK" ]; then
  printf '\n%s\n' 'BAŞARILI: APK oluşturuldu:' "$APK"
else
  printf '\n%s\n' 'Derleme komutu tamamlandı ancak geçerli APK bulunamadı.' >&2
  exit 2
fi
