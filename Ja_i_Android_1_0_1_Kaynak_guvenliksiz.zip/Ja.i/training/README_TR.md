# Ja.i 1.0.0 — Colab sohbet modeli eğitimi

## Dosyalar

- `../colab/Ja.i_1.0.0_Sifirdan_Sohbet_Modeli_Egitimi.ipynb`: Google Colab'da açılacak ana notebook.
- `train_jai_from_scratch.py`: Rastgele ağırlıklardan GRU dil modeli eğitir, ONNX dışa aktarır ve doğrular.
- `ORNEK_KONUSMA_VERISI.jsonl`: Kullanıcının kendi JSONL konuşmalarını hazırlaması için örnek biçim.
- `test_train_jai.py`: Tokenizer, mesaj serileştirme, asistan hedef maskesi, kayıt ayrımı ve GRU şekil testleri.

## Kullanılan metin verileri

1. **Turkish Daily Dialogues 5K** — 5.000 sentetik, çok turlu Türkçe günlük konuşma; CC BY 4.0. Kaynak kartı: https://huggingface.co/datasets/3nesdeniz/turkish-daily-dialogues-5k
2. **TFLai Turkish-Alpaca** — yaklaşık 51.900 tek turlu talimat-cevap örneği; Apache-2.0. Kaynak kartı: https://huggingface.co/datasets/TFLai/Turkish-Alpaca

Bunlar hazır yapay zekâ modelleri veya hazır model ağırlıkları değildir; yalnızca metin eğitim verisidir. İkinci veri kümesi hatalı/eskimiş yanıtlar içerebilir. Notebook basit ve korumacı bir içerik filtresi uygular, ancak tüm sorunları bulamaz. Çıktıların doğruluğunu ayrıca kontrol et.

## Telefonda Colab eğitimi

1. Kaynak ZIP'i telefonda çıkar.
2. `colab/Ja.i_1.0.0_Sifirdan_Sohbet_Modeli_Egitimi.ipynb` dosyasını Google Colab'da aç.
3. Runtime türünü mümkünse GPU yap. Ücretsiz GPU ve oturum süresi garanti değildir.
4. Hücreleri sırayla çalıştır. Açık veri kaynakları varsayılan olarak açık; istersen notebook'taki seçeneklerden kapatıp yalnızca kendi kullanım hakkın olan JSONL verini kullanabilirsin.
5. Eğitim tamamlanınca ONNX tek-token ve değişken uzunluklu giriş testleri çalışır; başarılıysa `jai-chat-model.zip` indirilir.
6. Ja.i uygulamasında **Zekâ ayarı → Colab modelini yükle** yoluyla ZIP'i seç.

## Model mimarisi ve sınırlamalar

- GRU ağı rastgele ağırlıklarla başlar. Hazır LLM ağırlığı, haricî AI sohbet API'si veya internet üzerinden çıkarım servisi kullanılmaz.
- Tokenizer UTF-8 byte tabanlıdır: 0–255 baytlar, 256–261 kontrol işaretleridir. Bu yaklaşım basittir ama Türkçe metni alt sözcük tokenizer'ı kadar verimli kodlamaz.
- Her asistan cevabı EOS ile biter. Eğitim kaybı yalnızca asistan yanıtı baytlarını ve cevap sonu işaretini hedefler; kullanıcı metni bağlamdır, taklit edilecek hedef değildir.
- Kayıtlar konuşma/talimat örneği düzeyinde train/validation/test olarak ayrılır. Eğitim raporu kaynak atfını, örnek sayılarını, adımları ve kayıp değerlerini içerir.
- 6.000 adım, 384 gizil boyut ve 3 katman küçük prototip varsayılanıdır. Modelin genel bilgi, uzun akıl yürütme, doğruluk veya doğal sohbet kalitesi garanti edilmez. Bu veri ölçeği insan seviyesinde veya büyük ticari LLM düzeyi bir model oluşturmaz.
- ONNX modeli Android'de değişken uzunluklu bağlamı tek çağrıda işleyip sonraki üretilen baytları tek tek üretir. Gerçek hız cihazın CPU/RAM'ine bağlıdır.
- Colab GPU, RAM, süre ve kota dinamik olarak değişebilir. Oturum kesilirse eğitim çıktısı oluşmayabilir; Colab kaynakları garanti etmez.

## Veri güvenliği ve lisans

Yalnızca kullanma ve eğitim hakkına sahip olduğun verileri yükle. Özel sohbetler, kişisel kimlik/iletişim bilgileri, sağlık bilgileri veya başkasına ait gizli içerikleri ekleme. Açık veri kaynaklarının lisans/atıf koşullarını koru. Otomatik filtre güvenlik ya da doğruluk sertifikası değildir.

Atıflar:
- Enes Deniz, *Turkish Daily Dialogues 5K*, 2026, CC BY 4.0, https://huggingface.co/datasets/3nesdeniz/turkish-daily-dialogues-5k
- TFLai, *Turkish-Alpaca*, Apache-2.0, https://huggingface.co/datasets/TFLai/Turkish-Alpaca

## Yerel Android uygulaması

Android uygulaması `jai-chat-model.zip` paketinden `jai-chat-model.onnx`, `model_config.json` ve isteğe bağlı `training_report.json` dosyalarını doğrular. Model cihazın özel uygulama depolamasında tutulur ve ONNX Runtime ile CPU üzerinde çalışır. Model yoksa uygulama bunu açıkça bildirir; eğitilmiş model varmış gibi davranmaz. Web araştırması yalnızca `Ara` açık olduğunda yapılır.
