#!/usr/bin/env python3
"""Ja.i 1.0.0 tiny GRU language model trainer (from random initialization; no pretrained model)."""
from __future__ import annotations

import argparse
import json
import math
import os
import random
import zipfile
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader, random_split

PAD, BOS, USER, ASSISTANT, EOS, SYSTEM = 256, 257, 258, 259, 260, 261
VOCAB_SIZE = 262
SCHEMA = "jai-gru-byte-v1"
SYSTEM_PROMPT = (
    "Sen Ja.i'sin. Türkçe konuş. Yardımcı, açık ve dürüst ol. "
    "Bilmediğin bilgiyi uydurma.\n"
)

# Bu küçük özgün örnekler yalnızca eğitim hattının çalıştığını sınamak içindir.
# Bunlarla genel amaçlı veya akıcı bir sohbet zekâsı oluşmaz.
STARTER_PAIRS = [
    ("Merhaba!", "Merhaba! Nasılsın? Bugün ne hakkında konuşalım?"),
    ("Nasılsın?", "İyiyim, teşekkür ederim. Sen nasılsın?"),
    ("Bugün ne yapabiliriz?", "Bir konu öğrenebilir, bir fikir geliştirebilir veya küçük bir proje planlayabiliriz."),
    ("Bir konuyu nasıl öğrenirim?", "Önce temel kavramları öğren. Sonra küçük örnekler üzerinde çalış ve öğrendiklerini kendi cümlelerinle açıkla."),
    ("Bana motivasyon ver.", "Küçük ama düzenli adımlar büyük ilerleme sağlar. Bugün yalnızca bir sonraki adımı tamamlamaya odaklan."),
    ("Fikir üretmeme yardım et.", "Önce hedefini belirleyelim. Ardından birkaç farklı yaklaşım üretip en uygulanabilir olanı seçebiliriz."),
    ("Bir şeyi bilmiyorsan ne yaparsın?", "Bilmediğimi açıkça söylerim. Gerekirse güvenilir kaynakları araştırır, bulduğum bilgiyi kaynaklarıyla ayırırım."),
    ("Teşekkür ederim.", "Rica ederim! Başka bir konuda yardımcı olmamı ister misin?"),
    ("Kısa cevap ver.", "Elbette. Gereksiz ayrıntıya girmeden doğrudan cevap vereceğim."),
    ("Daha ayrıntılı anlat.", "Tabii. Konuyu adım adım açıklayıp örneklerle destekleyeceğim."),
    ("Python nedir?", "Python, okunabilir sözdizimiyle bilinen genel amaçlı bir programlama dilidir. Otomasyon, veri işleme ve uygulama geliştirmede kullanılır."),
    ("HTML ne işe yarar?", "HTML, web sayfasının yapısını tanımlar. Başlık, paragraf, bağlantı, görsel ve form gibi öğeleri oluşturur."),
    ("Java nedir?", "Java, nesne yönelimli bir programlama dilidir. Android uygulamalarında ve sunucu yazılımlarında kullanılabilir."),
    ("Bir oyun fikri ver.", "Oyuncunun küçük görevleri tamamlayarak puan topladığı, giderek zorlaşan bir bulmaca oyunu tasarlanabilir."),
    ("Bir projeye nasıl başlanır?", "Hedefi ve başarı ölçütünü yaz. Gereken özellikleri sırala. Önce en küçük çalışan sürümü yap ve test et."),
    ("Hata bulunca ne yapmalıyım?", "Hata mesajını oku, sorunu tekrar oluştur, ilgili kodu daralt ve tek değişiklik yaparak yeniden test et."),
    ("Dostça konuşabilir misin?", "Elbette. Saygılı, doğal ve anlaşılır bir dille konuşabilirim."),
    ("Bana bir bilmece sor.", "Bir odada dört köşe var ve her köşede bir kedi oturuyor. Odada kaç kedi vardır?"),
    ("Cevap dört mü?", "Evet, doğru. Her köşede bir kedi olduğuna göre toplam dört kedi var."),
    ("Plan yapmama yardım et.", "Hedefini, bitiş tarihini ve günlük ayırabileceğin zamanı belirleyelim. Sonra işi küçük görevlere bölelim."),
    ("İnternet olmadan çalışabilir misin?", "Cihazda yüklü yerel model ve kayıtlı bilgilerle çalışabilirim. Güncel web araştırması için bağlantı ve Ara seçeneği gerekir."),
    ("Ara kapalıysa ne olur?", "Ara kapalıyken web isteği başlatmam. Yerel model, hafıza ve cihazdaki araçlarla devam ederim."),
    ("Hafıza ne işe yarar?", "Hafıza, daha sonra arayabilmek için seçtiğin notları cihazda saklar. Not kaydetmek tek başına dil modelini yeniden eğitmez."),
    ("Güvenilir kaynak nasıl anlaşılır?", "Yayınlayan kurumu, tarihi, yöntemi ve başka bağımsız kaynakların aynı bilgiyi destekleyip desteklemediğini kontrol et."),
    ("Tarih çalışmak istiyorum.", "Önce dönemin zaman çizelgesini çıkar. Sonra nedenleri, önemli gelişmeleri ve sonuçları ayrı başlıklarda incele."),
    ("Bilimsel bir konuyu açıkla.", "Konunun temel kavramlarını tanımlayıp mekanizmayı adım adım anlatabilir, ardından günlük hayattan örnek verebilirim."),
    ("Bir yazıyı düzeltir misin?", "Metni gönder. Anlamını koruyarak yazım, dil bilgisi ve anlatım akışını kontrol edebilirim."),
    ("Fikrime karşı çıkabilir misin?", "Evet. Önce fikrini doğru anladığımı özetler, ardından kanıta ve mantığa dayalı karşı görüş sunarım."),
    ("Kendimi geliştirmek istiyorum.", "Tek bir alan seç, ölçülebilir küçük hedef koy ve düzenli geri bildirim al. Aynı anda çok fazla hedef belirleme."),
    ("İyi geceler.", "İyi geceler! Dinlenmek de verimli çalışmanın bir parçasıdır."),
]


def byte_encode(text: str) -> list[int]:
    return list(text.encode("utf-8", errors="replace"))


def serialize_messages(messages: list[dict[str, str]]) -> list[int]:
    ids = [BOS, SYSTEM] + byte_encode(SYSTEM_PROMPT)
    for msg in messages:
        role = str(msg.get("role", "")).lower()
        content = str(msg.get("content", ""))
        if role == "system":
            ids.append(SYSTEM)
        elif role in ("user", "human"):
            ids.append(USER)
        elif role in ("assistant", "bot", "gpt"):
            ids.append(ASSISTANT)
        else:
            continue
        ids.extend(byte_encode(content))
        if role in ("assistant", "bot", "gpt"):
            # Her asistan cevabını ayrı bitir; model bir sonraki kullanıcı turunu üretmesin.
            ids.append(EOS)
    return ids


def assistant_only_targets(tokens: list[int]) -> list[int]:
    """Sadece asistan metnini ve cevap sonu EOS işaretini hedef yapar."""
    targets = [PAD] * max(0, len(tokens) - 1)
    in_assistant_turn = False
    for target_index in range(1, len(tokens)):
        token = tokens[target_index]
        if token == ASSISTANT:
            in_assistant_turn = True
            continue
        if token in (BOS, USER, SYSTEM):
            in_assistant_turn = False
            continue
        if in_assistant_turn:
            targets[target_index - 1] = token
            if token == EOS:
                in_assistant_turn = False
    return targets


def load_records(paths: list[Path]) -> list[list[int]]:
    records: list[list[int]] = []
    for path in paths:
        if not path.exists() or path.suffix.lower() != ".jsonl":
            continue
        with path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    item: Any = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"{path.name}:{line_number} JSONL hatası: {exc}") from exc
                if isinstance(item, dict) and isinstance(item.get("messages"), list):
                    messages = item["messages"]
                    valid = [m for m in messages if isinstance(m, dict) and m.get("role") in ("user", "assistant", "system") and isinstance(m.get("content"), str)]
                    has_user = any(m["role"] == "user" for m in valid)
                    has_assistant = any(m["role"] == "assistant" for m in valid)
                    if has_user and has_assistant:
                        ids = serialize_messages(valid)
                        if len(ids) > 8:
                            records.append(ids)
                elif isinstance(item, dict) and isinstance(item.get("prompt"), str) and isinstance(item.get("response"), str):
                    ids = serialize_messages([
                        {"role": "user", "content": item["prompt"]},
                        {"role": "assistant", "content": item["response"]},
                    ])
                    if len(ids) > 8:
                        records.append(ids)
    return records


class ConversationChunks(Dataset):
    def __init__(self, records: list[list[int]], seq_len: int):
        self.items: list[tuple[list[int], list[int]]] = []
        for tokens in records:
            target_stream = assistant_only_targets(tokens)
            # Uzun konuşmalar sabit uzunluklu, örtüşmesiz pencerelere ayrılır.
            for start in range(0, max(1, len(tokens) - 1), seq_len):
                x = tokens[start:start + seq_len]
                y = target_stream[start:start + seq_len]
                if not x or not y or not any(token != PAD for token in y):
                    continue
                x = x[:seq_len]
                y = y[:seq_len]
                x += [PAD] * (seq_len - len(x))
                y += [PAD] * (seq_len - len(y))
                self.items.append((x, y))

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, index: int):
        x, y = self.items[index]
        return torch.tensor(x, dtype=torch.long), torch.tensor(y, dtype=torch.long)


class JaIRecurrentLanguageModel(nn.Module):
    def __init__(self, vocab_size: int = VOCAB_SIZE, hidden_size: int = 384, num_layers: int = 3):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, hidden_size, padding_idx=PAD)
        self.gru = nn.GRU(hidden_size, hidden_size, num_layers=num_layers, batch_first=True)
        self.norm = nn.LayerNorm(hidden_size)
        self.head = nn.Linear(hidden_size, vocab_size)
        self.hidden_size = hidden_size
        self.num_layers = num_layers

    def forward(self, input_ids: torch.Tensor, hidden_in: torch.Tensor):
        embedded = self.embedding(input_ids)
        output, hidden_out = self.gru(embedded, hidden_in)
        logits = self.head(self.norm(output))
        return logits, hidden_out


def make_examples_from_pairs(pairs: list[tuple[str, str]]) -> list[list[int]]:
    out = []
    for prompt, response in pairs:
        out.append(serialize_messages([
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": response},
        ]))
    return out


def evaluate(model, loader, device, num_layers, hidden_size) -> float:
    model.eval()
    loss_fn = nn.CrossEntropyLoss(ignore_index=PAD)
    losses = []
    with torch.no_grad():
        for input_ids, targets in loader:
            input_ids = input_ids.to(device)
            targets = targets.to(device)
            hidden = torch.zeros(num_layers, input_ids.size(0), hidden_size, device=device)
            logits, _ = model(input_ids, hidden)
            loss = loss_fn(logits.reshape(-1, VOCAB_SIZE), targets.reshape(-1))
            if torch.isfinite(loss):
                losses.append(float(loss.item()))
    return float(np.mean(losses)) if losses else math.inf


def split_conversations(records: list[list[int]], seed: int):
    """Konuşmaları bölmeden ayırır; aynı konuşma eğitim ve doğrulamaya sızmaz."""
    if len(records) < 2:
        raise RuntimeError("Eğitim/doğrulama ayrımı için en az iki konuşma örneği gerekli.")
    shuffled = list(records)
    random.Random(seed).shuffle(shuffled)
    validation_count = max(1, int(len(shuffled) * 0.10))
    validation_count = min(validation_count, len(shuffled) - 1)
    return shuffled[validation_count:], shuffled[:validation_count]


def train_and_export(args):
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.set_num_threads(max(1, min(4, os.cpu_count() or 2)))

    paths = [Path(value) for value in args.data]
    records = load_records(paths)
    used_starter = False
    if len(records) == 0:
        records = make_examples_from_pairs(STARTER_PAIRS)
        used_starter = True
        print("UYARI: JSONL veri bulunamadı. Yalnızca teknik hat kontrolü için küçük demo veri kümesi kullanılacak.")
    if len(records) < 1000:
        print(f"UYARI: {len(records)} konuşma örneği var. Bu ölçek genel amaçlı sohbet kalitesi için yetersizdir.")
        print("Daha iyi sonuç için izinli, temiz, çeşitli ve yeterince büyük Türkçe diyalog verisi gerekir.")

    validation_paths = [Path(value) for value in args.validation_data]
    test_paths = [Path(value) for value in args.test_data]
    if validation_paths:
        validation_records = load_records(validation_paths)
        train_records = records
        if not validation_records:
            raise RuntimeError("--validation-data verildi ama içinden geçerli konuşma çıkmadı.")
    else:
        train_records, validation_records = split_conversations(records, args.seed)
    test_records = load_records(test_paths) if test_paths else []

    seq_len = args.sequence_length
    dataset = ConversationChunks(train_records, seq_len)
    val_data = ConversationChunks(validation_records, seq_len)
    test_data = ConversationChunks(test_records, seq_len) if test_records else None
    if len(dataset) < 2 or len(val_data) < 1:
        raise RuntimeError("Eğitim/doğrulama parçaları oluşturulamadı; JSONL içeriğini kontrol et.")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    batch_size = args.batch_size if device.type == "cuda" else max(1, min(args.batch_size, 4))
    train_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=False)
    val_loader = DataLoader(val_data, batch_size=batch_size, shuffle=False, drop_last=False)

    model = JaIRecurrentLanguageModel(hidden_size=args.hidden_size, num_layers=args.num_layers).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=0.01)
    loss_fn = nn.CrossEntropyLoss(ignore_index=PAD)
    scaler = torch.amp.GradScaler("cuda", enabled=(device.type == "cuda" and args.use_amp))
    model.train()
    step = 0
    running = []
    while step < args.steps:
        for input_ids, targets in train_loader:
            input_ids = input_ids.to(device)
            targets = targets.to(device)
            hidden = torch.zeros(args.num_layers, input_ids.size(0), args.hidden_size, device=device)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=(device.type == "cuda" and args.use_amp)):
                logits, _ = model(input_ids, hidden)
                loss = loss_fn(logits.reshape(-1, VOCAB_SIZE), targets.reshape(-1))
            if not torch.isfinite(loss):
                raise RuntimeError("Eğitim kaybı NaN/Inf oldu; veri veya öğrenme oranını kontrol et.")
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(optimizer)
            scaler.update()
            running.append(float(loss.item()))
            step += 1
            if step == 1 or step % 50 == 0 or step == args.steps:
                average = float(np.mean(running[-50:]))
                print(f"Adım {step}/{args.steps} · eğitim kaybı {average:.4f}")
            if step >= args.steps:
                break

    val_loss = evaluate(model, val_loader, device, args.num_layers, args.hidden_size)
    print(f"Doğrulama kaybı: {val_loss:.4f}")
    test_loss = None
    if test_data is not None and len(test_data) > 0:
        test_loader = DataLoader(test_data, batch_size=batch_size, shuffle=False, drop_last=False)
        test_loss = evaluate(model, test_loader, device, args.num_layers, args.hidden_size)
        print(f"Ayrı test kümesi kaybı: {test_loss:.4f}")
    if args.skip_export:
        print("SMOKE TEST: Eğitim döngüsü tamamlandı; --skip-export nedeniyle ONNX/ZIP oluşturulmadı.")
        return
    model = model.to("cpu").eval()

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    onnx_path = out_dir / "jai-chat-model.onnx"
    config_path = out_dir / "model_config.json"
    report_path = out_dir / "training_report.json"

    dummy_ids = torch.tensor([[BOS]], dtype=torch.long)
    dummy_hidden = torch.zeros(args.num_layers, 1, args.hidden_size, dtype=torch.float32)
    torch.onnx.export(
        model,
        (dummy_ids, dummy_hidden),
        str(onnx_path),
        input_names=["input_ids", "hidden_in"],
        output_names=["logits", "hidden_out"],
        opset_version=17,
        do_constant_folding=True,
        dynamic_axes={
            "input_ids": {1: "sequence_length"},
            "logits": {1: "sequence_length"},
        },
        dynamo=False,
    )

    config = {
        "schema": SCHEMA,
        "model_name": "Ja.i GRU Byte Language Model",
        "trained_from_scratch": True,
        "pretrained_weights_used": False,
        "external_ai_api_used": False,
        "vocab_size": VOCAB_SIZE,
        "pad_id": PAD,
        "bos_id": BOS,
        "user_id": USER,
        "assistant_id": ASSISTANT,
        "eos_id": EOS,
        "system_id": SYSTEM,
        "hidden_size": args.hidden_size,
        "num_layers": args.num_layers,
        "max_context_tokens": args.max_context_tokens,
        "training_examples": len(train_records),
        "validation_examples": len(validation_records),
        "test_examples": len(test_records),
        "training_chunks": len(dataset),
        "validation_chunks": len(val_data),
        "training_steps": step,
        "validation_loss": val_loss,
        "test_loss": test_loss,
        "demo_seed_only": used_starter,
        "data_attribution": args.data_attribution,
        "tokenizer": "UTF-8 byte tokenizer with Ja.i special tokens",
    }
    config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    report = {
        "status": "exported",
        "device": str(device),
        "parameters": sum(p.numel() for p in model.parameters()),
        "training_examples": len(train_records),
        "validation_examples": len(validation_records),
        "test_examples": len(test_records),
        "validation_loss": val_loss,
        "test_loss": test_loss,
        "data_attribution": args.data_attribution,
        "warning": "A low validation loss does not establish general intelligence or factual reliability.",
        "demo_seed_only": used_starter,
    }
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    # ONNX dosyasını bağımsız biçimde doğrula.
    import onnx
    onnx_model = onnx.load(str(onnx_path))
    onnx.checker.check_model(onnx_model)
    try:
        import onnxruntime as ort
        session = ort.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
        test_hidden_in = np.zeros((args.num_layers, 1, args.hidden_size), dtype=np.float32)
        test_logits, test_hidden = session.run(
            ["logits", "hidden_out"],
            {"input_ids": np.array([[BOS]], dtype=np.int64), "hidden_in": test_hidden_in},
        )
        if test_logits.shape != (1, 1, VOCAB_SIZE) or test_hidden.shape != (args.num_layers, 1, args.hidden_size):
            raise RuntimeError(f"ONNX tek-token şekil doğrulaması başarısız: {test_logits.shape}, {test_hidden.shape}")
        prompt_logits, prompt_hidden = session.run(
            ["logits", "hidden_out"],
            {"input_ids": np.array([[BOS, SYSTEM, 77, USER, 77, ASSISTANT, 78]], dtype=np.int64), "hidden_in": test_hidden_in},
        )
        if prompt_logits.shape != (1, 7, VOCAB_SIZE) or prompt_hidden.shape != (args.num_layers, 1, args.hidden_size):
            raise RuntimeError(f"ONNX değişken dizi doğrulaması başarısız: {prompt_logits.shape}, {prompt_hidden.shape}")
        print("ONNX Runtime CPU testleri geçti (tek token + değişken uzunluklu sohbet bağlamı).")
    except ImportError:
        print("ONNX Runtime Python kurulu değil; ONNX şema kontrolü geçti.")

    zip_path = out_dir / "jai-chat-model.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.write(onnx_path, arcname="jai-chat-model.onnx")
        archive.write(config_path, arcname="model_config.json")
        archive.write(report_path, arcname="training_report.json")
    print(f"Model paketi hazır: {zip_path}")
    print("Not: demo_seed_only=true ise bu yalnızca teknik denemedir; genel sohbet kalitesi beklenmemelidir.")


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", nargs="*", default=[], help="JSONL training files")
    parser.add_argument("--validation-data", nargs="*", default=[], help="JSONL validation files")
    parser.add_argument("--test-data", nargs="*", default=[], help="JSONL held-out test files")
    parser.add_argument("--data-attribution", default="User-provided training data", help="Dataset attribution recorded in the model report")
    parser.add_argument("--output-dir", default="/content/jai_output")
    parser.add_argument("--steps", type=int, default=1200)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--sequence-length", type=int, default=512)
    parser.add_argument("--hidden-size", type=int, default=384)
    parser.add_argument("--num-layers", type=int, default=3)
    parser.add_argument("--max-context-tokens", type=int, default=512)
    parser.add_argument("--learning-rate", type=float, default=2e-4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--use-amp", action="store_true")
    parser.add_argument("--skip-export", action="store_true", help="Local smoke test only; train but do not export ONNX")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    if args.steps < 1 or args.steps > 20000:
        raise SystemExit("--steps 1..20000 aralığında olmalı.")
    if args.hidden_size < 64 or args.hidden_size > 512:
        raise SystemExit("--hidden-size 64..512 aralığında olmalı.")
    if args.num_layers < 1 or args.num_layers > 4:
        raise SystemExit("--num-layers 1..4 aralığında olmalı.")
    if args.sequence_length < 64 or args.sequence_length > 2048:
        raise SystemExit("--sequence-length 64..2048 aralığında olmalı.")
    train_and_export(args)
