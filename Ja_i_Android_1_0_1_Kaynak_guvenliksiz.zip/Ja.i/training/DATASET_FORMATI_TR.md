# Ja.i konuşma verisi biçimi

Colab notebook'u yalnızca kullanıcının seçtiği `.jsonl` dosyalarını okur. Her satır tek bir JSON nesnesidir.

## Tek kullanıcı/yanıt çifti

```json
{"prompt":"Merhaba","response":"Merhaba, nasılsın?"}
```

## Çok turlu konuşma

```json
{"messages":[{"role":"user","content":"Bugün nasılsın?"},{"role":"assistant","content":"İyiyim, teşekkür ederim. Sen nasılsın?"},{"role":"user","content":"Ben de iyiyim."},{"role":"assistant","content":"Güzel! Bugün ne yapmak istersin?"}]}
```

## Veri kalitesi

- Sadece kullanma hakkına sahip olduğun metinleri kullan.
- Özel bilgiler, şifreler, kimlik numaraları, kişisel adresler ve başkalarına ait gizli konuşmaları ekleme.
- Yanlış bilgi, tekrar, bozuk kodlama, spam ve anlamsız satırları ayıkla.
- Sadece selamlaşma değil; açıklama, soru-cevap, günlük konuşma, öğretici diyalog, yazma, özetleme ve farklı uzunluklarda konuşmalar ekle.
- Birden fazla konu ve farklı ifade biçimleri kullan.
- Veri kümesini eğitim/doğrulama/test kümelerine ayırmak en iyisidir. Notebook basit bir doğrulama bölümü ayırır; bağımsız test seti ayrıca hazırlanmalıdır.
- 20-100 örnek yalnızca denemedir. Genel sohbet için binlerce değil, çok daha fazla, temiz ve çeşitli konuşma gerekir. Modelin küçük boyutu nedeniyle veri artsa da insan seviyesinde genel zekâ beklenmemelidir.
