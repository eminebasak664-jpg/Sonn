import json
import tempfile
import unittest
from pathlib import Path

import torch

try:
    from .train_jai_from_scratch import (
        ASSISTANT,
        BOS,
        EOS,
        PAD,
        SYSTEM,
        USER,
        ConversationChunks,
        JaIRecurrentLanguageModel,
        assistant_only_targets,
        byte_encode,
        load_records,
        serialize_messages,
        split_conversations,
    )
except ImportError:
    from train_jai_from_scratch import (
        ASSISTANT,
        BOS,
        EOS,
        PAD,
        SYSTEM,
        USER,
        ConversationChunks,
        JaIRecurrentLanguageModel,
        assistant_only_targets,
        byte_encode,
        load_records,
        serialize_messages,
        split_conversations,
    )


class TrainingPipelineTests(unittest.TestCase):
    def test_utf8_encoder_keeps_turkish_bytes(self):
        encoded = byte_encode("Türkçe ğüşiöç")
        self.assertTrue(encoded)
        self.assertTrue(all(0 <= token <= 255 for token in encoded))

    def test_serialization_uses_same_special_token_ids(self):
        encoded = serialize_messages([
            {"role": "user", "content": "Merhaba"},
            {"role": "assistant", "content": "Selam"},
            {"role": "user", "content": "Nasılsın?"},
            {"role": "assistant", "content": "İyiyim."},
        ])
        self.assertEqual(BOS, encoded[0])
        self.assertIn(SYSTEM, encoded)
        self.assertIn(USER, encoded)
        self.assertIn(ASSISTANT, encoded)
        self.assertEqual(2, encoded.count(EOS), "Her asistan turu EOS ile bitmeli")

    def test_only_assistant_tokens_are_training_targets(self):
        tokens = [BOS, SYSTEM, 65, USER, 66, ASSISTANT, 67, EOS, USER, 68, ASSISTANT, 69, EOS]
        targets = assistant_only_targets(tokens)
        self.assertEqual(PAD, targets[2])  # SYSTEM metni tahmin hedefi değil
        self.assertEqual(PAD, targets[3])  # USER işareti hedef değil
        self.assertEqual(PAD, targets[4])  # Kullanıcı metni hedef değil
        self.assertEqual(67, targets[5])   # Asistan yanıtı hedef
        self.assertEqual(EOS, targets[6])  # Yanıt bitişi hedef
        self.assertEqual(69, targets[10])  # İkinci asistan yanıtı hedef
        self.assertEqual(EOS, targets[11])

    def test_conversation_split_has_no_overlap(self):
        source = [[BOS, SYSTEM, i, USER, i, ASSISTANT, i] for i in range(40)]
        train, validation = split_conversations(source, seed=123)
        self.assertEqual(len(source), len(train) + len(validation))
        self.assertTrue(set(map(tuple, train)).isdisjoint(set(map(tuple, validation))))

    def test_conversation_chunks_have_fixed_length(self):
        tokens = [BOS, SYSTEM] + [65] * 70 + [USER] + [66] * 20 + [ASSISTANT] + [67] * 130 + [EOS]
        dataset = ConversationChunks([tokens], seq_len=64)
        self.assertGreaterEqual(len(dataset), 2)
        inputs, targets = dataset[0]
        self.assertEqual((64,), tuple(inputs.shape))
        self.assertEqual((64,), tuple(targets.shape))
        self.assertEqual(torch.long, inputs.dtype)

    def test_jsonl_loader_reads_multiturn_records(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / "train.jsonl"
            source.write_text(json.dumps({"messages": [
                {"role": "user", "content": "Bir fikrim var."},
                {"role": "assistant", "content": "Anlat, birlikte değerlendirelim."},
                {"role": "user", "content": "Bir oyun yapmak istiyorum."},
                {"role": "assistant", "content": "Önce küçük bir oyun taslağı hazırlayabiliriz."},
            ]}, ensure_ascii=False) + "\n", encoding="utf-8")
            records = load_records([source])
            self.assertEqual(1, len(records))
            self.assertEqual(BOS, records[0][0])

    def test_gru_forward_shape_and_finite_loss(self):
        model = JaIRecurrentLanguageModel(hidden_size=64, num_layers=1)
        input_ids = torch.randint(0, 262, (2, 12), dtype=torch.long)
        hidden = torch.zeros(1, 2, 64)
        logits, hidden_out = model(input_ids, hidden)
        self.assertEqual((2, 12, 262), tuple(logits.shape))
        self.assertEqual((1, 2, 64), tuple(hidden_out.shape))
        self.assertTrue(torch.isfinite(logits).all().item())


if __name__ == "__main__":
    unittest.main(verbosity=2)
