# Ja.i 1.0.1 — Test raporu

## Geçen kontroller

- Kaynak arşivi açıldı ve dosya bütünlük kontrolü yapıldı.
- `training/test_train_jai.py`: 7/7 test geçti.
- `server/test_server.py`: 5/5 test geçti. FastAPI'nin eski `on_event` başlangıç kancası için iki uyarı verdi; testler başarısız olmadı.
- `VideoResourcePolicy.java`: saf Java derlemesi ve 7 kaynak profili senaryosu geçti (yüksek/orta/hafif profil, CPU yükü, depolama düşüşü ve yetersiz kaynak reddi).
- Colab 2.1 notebook JSON yapısı ve normal Python hücrelerinin sözdizimi kontrol edildi.
- Colab eğitim betiği ayrı Python dosyası olarak derlendi; küçük sentetik kayıtlarla JSONL metadata, konuşma pencereleri ve `WeightedRandomSampler` smoke testleri geçti.
- ONNX model sözleşmesi (özel token kimlikleri, GRU boyutları, ONNX giriş/çıkış adları ve ZIP dosya adları) önceki Android yükleyicisiyle eşleşecek şekilde korundu.

## Bu ortamda tamamlanamayan doğrulamalar

- Android Gradle derlemesi başlatılmak istendi; Gradle dağıtımı ağ/DNS erişimi olmadığı için indirilemedi. Bu nedenle APK derlendiği iddia edilmiyor.
- Gerçek Android cihazda `MediaCodec` H.264 üretimi, MP4 oynatma, bellek tepe kullanımı ve depolama profili düşüşü henüz test edilmedi.
- Colab'da tam veri indirimi, model eğitimi ve ONNX dışa aktarma çalıştırılmadı. Notebook bu işlemleri Colab oturumunda yapacak.

## Önerilen cihaz testleri

1. 10 saniyelik MP4 oluştur ve Dosyalar uygulamasına kaydet.
2. 60 saniyelik MP4 oluştur; üretim sırasında Ja.i'nin CPU/RAM durumunu gözlemle.
3. Kullanılabilir cache alanı azaldığında profilin 540p/360p'ye indiğini veya açık hata verdiğini doğrula.
4. Kaydedilen MP4'ü Android video oynatıcısında aç.
5. Colab'dan alınan sohbet ZIP'ini uygulamaya aktar ve internet kapalıyken test et.
