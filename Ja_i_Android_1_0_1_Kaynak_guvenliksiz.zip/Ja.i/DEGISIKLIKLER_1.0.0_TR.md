# Ja.i 1.0.0 — Değişiklikler

## Sohbet zekâsı
- `ByteTokenizer`: eğitim ve Android'de ortak UTF-8 byte tokenizer; geçmiş serileştirme; asistan cevaplarının EOS işaretiyle sonlandırılması.
- `LocalOnnxLanguageModel`: Colab'da rastgele ağırlıklardan eğitilmiş ONNX GRU modelini içe alır ve çevrimdışı çalıştırır.
- Model ZIP içe aktarmada dosya adı/yol, giriş sayısı, tekrarlanan kayıt ve dosya boyutu sınırları denetlenir; geçersiz modelde eski model geri yüklenir.
- Zekâ ayarı ekranına model durumu ve **Colab modelini yükle** seçeneği eklendi.
- Model yüklenmemişse uygulama durumu dürüstçe bildirir ve mevcut yerel yardımcı motoruna geri döner.
- Bağlamın tamamı değişken uzunluklu ONNX dizisi olarak tek çağrıda işlenir; yeni üretilen baytlar sonraki çağrılarla sürdürülür.
- Eğitilmiş sohbet modeli yüklüyse web araştırması ve dosya inceleme bağlamları da modele verilir; model yoksa eski yerel bağlam yanıtlayıcısı yedek olarak kalır.
- Mevcut model arka plan iş parçacığında yüklenir; ONNX session açılmadan önce gerçek giriş/çıkış tensör şekilleri tek-token denemesiyle doğrulanır; kapanıştan önce native oturum kapatılır.

## Colab eğitim hattı
- `colab/Ja.i_1.0.0_Sifirdan_Sohbet_Modeli_Egitimi.ipynb` eklendi.
- `training/train_jai_from_scratch.py` sıfırdan GRU modeli eğitir; ONNX dışa aktarır, ONNX checker ve Python ONNX Runtime tek/çok token şekil testlerini çalıştırır; model ZIP'i oluşturur.
- 5.000 çok turlu Türkçe diyalog verisi (CC BY 4.0) ve yaklaşık 51.900 talimat-cevap örneği (Apache-2.0) seçenekleri eklendi; korumacı örnek filtresi var.
- Kendi JSONL dosyalarını ekleme ve eğitim/doğrulama/test ayrımlarını ayrı tutma desteği eklendi.
- Her asistan turu EOS ile biter. Loss maskesi yalnızca asistan yanıtı ve EOS tokenlerini eğitir.
- 30 satırlık demo veri yalnızca teknik smoke testidir; genel sohbet modeli değildir.

## Güvenlik ve veri
- İstek ve oluşturulan yanıt için yerel güvenlik kontrolü.
- Veri kaynaklarının atıf/lisans ve doğruluk sınırları belgelenir. Kullanıcıya özel/hassas veriyi eğitim için yüklememe uyarısı eklenir.

## Android
- compileSdk/targetSdk 36; AGP 8.13.2; Gradle 8.13; uygulama Java kaynak hedefi 17.
- Paket içindeki özel Gradle başlatıcı JDK 21 bytecode'u içerdiğinden GitHub Actions JDK 21 ile çalışır.
- Android 15/16 edge-to-edge sistem çubuğu inset yönetimi eklendi.
- CI, Android API 36 / Build Tools 36.0.0, kaynak doğrulama, birim testleri ve debug APK derlemesi çalıştırır.

## Bu sürümde doğrulanmayanlar
- Colab'ın gerçek GPU eğitimi; bu oturumda Hugging Face veri indirme/Colab çalıştırma yapılmadı.
- ONNX dosyasının Colab'da dışa aktarımı ve Android'de native runtime ile açılması; gerekli Python ONNX paketleri ve Android SDK bu çalışma ortamında yok.
- Gerçek cihaz APK derlemesi/kurulumu.
