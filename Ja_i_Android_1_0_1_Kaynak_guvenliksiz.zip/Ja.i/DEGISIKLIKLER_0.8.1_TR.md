# Ja.i 0.8.1 — Değişiklikler

Bu paket, 0.8.0 kaynaklarının üzerine Think görev aşaması entegrasyonunu ekler.

## Eklendi
- `TaskStageEngine`: Akıllı/Manuel aşama planı.
- Gerçek yerel aşamalar: istek analizi, puanlanmış yerel bağlam, plan, görev/araç çalıştırma ve çıktı doğrulama.
- Aşama ilerlemesi ana ekrandaki işlem göstergesine bağlandı.
- Think modunda kod çıktısı için statik ön kontrol.
- TaskStageEngine (5), StructuredProgramCompiler (6) ve CodeGenerator (10) testleri; toplam 21 yerel Java test metodu geçti.
- `StructuredProgramCompiler`: kullanıcının yapılandırılmış program tanımından yeni JavaScript kaynak kodu sentezi.
- Sentezleyici; değişken, fonksiyon, ifade, koşul, döngü, atama ve çıktı ifadelerini ayrıştırır. Desteklemediği satırları sessizce kod diye üretmez.
- CodeGenerator önce bu sentezleyiciyi çalıştırır, ardından mevcut başlangıç tariflerine geçer. İki entegrasyon regresyon testi eklendi.

## Bilerek yapılmayanlar
- Eğitilmiş yerel LLM veya model çıkarımı varmış gibi gösterilmez.
- 115 aşama seçildiğinde aynı iş 115 kez tekrarlanmaz; bağımsız yerel aşamalar bitince motor durur.
- Yapılandırılmış mini dil derleyicisi genel amaçlı doğal dil kod üreticisi diye adlandırılmaz; karmaşık 3D oyun/proje üretimi hâlâ desteklenmiyor.

## Paketleme durumu
Bu dosya bir Android kaynak projesi paketidir. Bu geliştirme oturumunda Gradle dağıtımı indirilemediği ve Android SDK bulunmadığı için APK derlenemedi. Ayrıntılar `TEST_RAPORU_0.8.1_TR.md` içindedir.
