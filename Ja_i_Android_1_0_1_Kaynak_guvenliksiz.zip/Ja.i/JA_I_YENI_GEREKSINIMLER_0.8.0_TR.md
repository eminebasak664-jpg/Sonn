# Ja.i — Kullanıcı tarafından istenen yeni zekâ ve kod üretim gereksinimleri

Bu belge, konuşmada istenen özelliklerin proje gereksinimi olarak kaydıdır. Gereksinimin belgelenmesi, özelliğin tamamlandığı anlamına gelmez. Durumlar aşağıda ayrı gösterilmiştir.

## 1. Yerel dil modeli eğitimi

- Ja.i için haricî LLM API'si kullanmadan, Colab/PyTorch gibi bir ortamda eğitilecek yerel bir dil modeli hedefleniyor.
- İlk deneysel hedef: yaklaşık 65 milyon parametreli küçük model. Daha önce konuşulan 10 Transformer katmanı, 576 gizli boyut ve 8 dikkat kafası bir başlangıç hipotezidir; eğitimden önce bellek/parametre hesabı ve gerçek donanım sınırları doğrulanmalıdır.
- Eğitim hedefi, sonraki token tahmini ve daha sonra talimat/veri kalitesi iyileştirmesidir. Wikipedia tek başına sohbet ve kodlama yeteneği kazandırmaz; lisansı ve kalitesi uygun çeşitli veri kümeleri gerekir.
- Model boyutu, eğitim süresi ve INT8 çıktı boyutu garanti değildir. 65M parametrenin ham INT8 ağırlıkları yaklaşık 65 MB olsa da tokenizer, meta veri ve çalışma belleği ayrıca hesaplanır.
- Android tarafı için özel `model_int8.bin` dosyası ve `PtqReader.java` varsayımı henüz doğrulanmış bir dağıtım biçimi değildir. Önce PyTorch modelinin Android'de gerçekten çalıştırılabileceği bir çıkarım biçimi/runtime seçilmeli ve aynı model çıktısıyla test edilmelidir.

**Durum (0.8.0):** Henüz eğitilmiş model, tokenizer dosyaları, Android çıkarım motoru veya Colab eğitim defteri bu kaynak paketine eklenmedi.

## 2. Özgün kod üretimi — hazır tarif karşıtlığı

- Kullanıcı hazır kod listesi, örnek seçme veya tarif birleştirme istemiyor.
- Örnek hedef istekler: 3D oyun, Android uygulaması, web sitesi, mevcut projedeki hataları bulup düzeltme ve yeni oyun motoru.
- Hedef davranış: isteği anlama → gereksinimleri çıkarma → plan → proje/dosya yapısı → yeni kod üretimi → statik kontrol → gerçek derleme/çalıştırma testleri → hata düzeltme → teslim.
- Üretilen kaynak, hazır kod kataloğundan seçilmiş gibi sunulmamalı. Gerekirse dış sınırlar açıkça belirtilmeli; çalıştırılmayan/derlenmeyen kod için test edildi denmemeli.
- Şablonlar yalnızca açıkça başlangıç örneği veya iskelet istendiğinde kullanılabilir; genel kod üretiminin yerine geçemez.

**Durum (geliştirme paketi):** Henüz tamamlanmadı. `CodeGenerator` hâlâ şablon/anahtar sözcük eşleştirmesi yapıyor. Think doğrulama adımı üretilmiş kodu yalnızca statik ön kontrolden geçirir; derleme/çalıştırma değildir.

## 3. Çok aşamalı çalışma ayarı

- Ja.i ayarlarında iki mod olmalı:
  - **Akıllı (otomatik):** Motor, görev için gerekli aşama sayısını kendisi belirler ve yeterli sonuca ulaştığında durur.
  - **Manuel:** Kullanıcı tek sayı girer. İstenen aralık 1–115'tir; örneğin 2, 8 veya 115.
- Aynı modelin ağırlıkları aşamalar arasında yeniden kullanılabilir. İki kez 65M parametreli modeli çalıştırmak, onu 130M parametreli tek modele dönüştürmez.
- Aşamalar aynı cevabı tekrar etmemeli; her tur önceki sonucu değerlendirmeli ve yeni katkı üretmelidir.
- Otomatik modda durma koşulu, yalnızca aşama sayısına değil yeni katkı, doğrulama sonucu, testler ve hata kalmaması gibi ölçütlere dayanmalıdır.
- İşlemci yükü, RAM, depolama, işlem süresi ve kullanıcı iptali sınırları bulunmalıdır. 115 aşama varsayılan olmamalı; kullanıcı manuel seçerse dahi kaynak sınırları uygulanmalıdır.
- Kullanıcıya gerçek ilerleme gösterilmeli: tamamlanan aşamalar, toplam/üst sınır, o anki iş, durma nedeni ve varsa başarısız doğrulamalar.

**Durum (geliştirme paketi):** Akıllı/Manuel ayarı artık Think işlem hattına bağlı. Beş bağımsız yerel adım vardır: istek analizi, yerel bağlam taraması, plan oluşturma, görevi/araçları çalıştırma ve çıktı doğrulama. Manuel sayı bu görev için çalıştırılacak bağımsız adımların üst sınırıdır; 115 seçilirse mevcut görevde bulunmayan aşamalar veya sahte model turları oluşturulmaz. Eğitilmiş model hâlâ olmadığından bu aşamalar model çıkarımı değildir.

## 4. İlerleme çubuğu

- İlerleme göstergesi gerçek iş aşamalarından beslenmelidir.
- 0.8.0'da gösterilen çubuk yerel yanıt hazırlama, isteğe bağlı web araştırması ve sohbet kaydı sürecini izler; modelin 115 tur çalıştığını göstermez.
- Gelecekteki model aşamaları bağlanınca her gerçek aşama tamamlandığında ilerleme güncellenmeli ve iş yeterli olduğunda tamamlandı bildirimi verilmelidir.

**Durum (geliştirme paketi):** Ana ekrandaki çubuk Think işlem hattından aşama tamamlandıkça gerçek ilerleme alır; sonrasında web araştırması ve kayıt adımlarıyla devam eder. Bu, model yineleme sayacı değildir.

## 5. Öncelik ve tamamlanma ölçütü

1. Model eğitim verisi ve eğitim denemesi.
2. Android'de gerçek model çıkarımı ve küçük cihazlarda işlemci/RAM/depolama ölçümü.
3. Şablon bağımlılığını kaldıran özgün kod üretim mimarisi.
4. Manuel/akıllı aşama ayarlarını gerçek model döngüsüne bağlama.
5. Aşama bazlı test/doğrulama, durma koşulu ve gerçek ilerleme raporu.

Hiçbir özellik, yalnızca ekranda göründüğü için tamamlandı sayılmaz. APK derlemesi ve cihaz testi yapılmadıysa yapılmış gibi belirtilmez.


## 0.8.1 ek notu — kaynak sentezi sınırı

0.8.1 sürümünde `StructuredProgramCompiler`, belgelenmiş yapılandırılmış program satırlarını yeni JavaScript kaynak metnine çevirebilir. Değişken, fonksiyon, ifade, koşul, döngü, atama ve yazdırma komutlarını destekler. Bu, serbest doğal dilde genel amaçlı kod üretimi veya 3D oyun motoru üretimi değildir. Daha geniş kod üretimi için kendi yerel modelimizin eğitilmesi ve ara kod temsili/derleme-doğrulama hattının geliştirilmesi gerekir.
