# Ja.i 1.0.1 — Kaynak uyumlu video üretimi

## Video kaynak yönetimi
- İşlemci mantıksal çekirdek sayısı, /proc/stat üzerinden kısa CPU yük örneklemi (okunabiliyorsa), Android düşük-RAM cihaz işareti, kullanılabilir sistem RAM'i, uygulama heap'i ve cache depolaması birlikte değerlendirilir.
- Üç MP4 profili vardır: 1280×720/24 FPS/1.8 Mbit/s, 960×540/20 FPS/1.2 Mbit/s ve 640×360/15 FPS/650 kbit/s. Kaynaklar düştükçe daha hafif profil seçilir.
- En hafif profilin bellek/depolama ihtiyacı karşılanmıyorsa üretim başlamadan açıklayıcı hata döner; talep edilen klip süresi sessizce kısaltılmaz.
- Sahne bitmap'leri işlem tamamlanınca geri bırakılır; kare başına Matrix tekrar kullanılır ve parçacık sayısı kalite profiline göre ayarlanır.

## Dosya/heap yönetimi
- MP4 çıktısı cache içinde dosya olarak tutulur; tüm MP4 byte[] olarak belleğe yüklenmez.
- Kod Laboratuvarı dışa aktarması 64 KiB akış tamponuyla yapılır; büyük videolarda tam dosya kopyası uygulama heap'inde tutulmaz.
- Yedi günden eski Ja.i geçici video dosyaları yeni üretim öncesinde temizlenir.
- Kaynak durumu ekranına CPU çekirdek sayısı ve düşük-RAM cihaz bilgisi eklendi.

## Diğer düzeltmeler
- ZIP/TAR sınır mesajları işlemci yükü ve bellek kullanımını açıklar.
- Eğitim örneği JSONL dosyasının bozuk Türkçe dosya adı ASCII adla değiştirildi; veri içeriği aynı kaldı.
- Mesajlaşma sunucusunun mimarisi ve veri saklama davranışı değiştirilmedi.

## Test kapsamı
- Video kaynak profili seçimleri için 7 JUnit testi eklendi.
- Gerçek MediaCodec MP4 üretimi ve gerçek cihaz RAM/depolama ölçümü fiziksel Android cihazda ayrıca yapılmalıdır.
