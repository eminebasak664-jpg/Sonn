# DEVAM NOTU — Ja.i 0.9.7

## Mevcut kararlar
- Ana zekâ Ja.i'nin yerel Java mimarisidir. Haricî AI API'si/modeli yoktur.
- Ara açıksa web araştırması üretimden önce yapılır; kaynak notları yerel hafızaya yazılır. Ara kapalıysa CodeLab araştırması yapılmaz.
- Görsel ağ 16→128→64→3; 10.627 parametre. Eski 12→32→3 model dosyası için göç yolu vardır.
- Video 720p/24fps, 1–60 saniye; dört yerel sahne ve geçişlerle MP4.
- Minecraft Bedrock profili 1.21.132.1; min_engine_version 1.21.132; `@minecraft/server` 2.4.0.
- 999 miktarı bir yığın değil, 64 veya daha az yığınların komut dizisiyle üretilir.

## Son doğrulananlar
- Saf Java üretim çekirdeği derlendi.
- 999 öğe toplamı 16 yığında doğru bölündü; hiçbir yığın 64'ü aşmadı.
- Örnek Minecraft Add-on'un 25 JSON dosyası ayrıştırıldı; ejderha kanat/kuyruk modeli, yedi animasyon durumu ve uçuş bileşenleri ayrıca kontrol edildi.
- 10.627 parametreli ağda eğitim/kaydet/yükle testi geçti.
- 1280×720 PNG üretildi.
- Video sahne planı ve 60 saniye süre ayrıştırması test edildi.
- JSON son virgül ve max stack otomatik onarım testi geçti.

## Açık işler
1. Android Gradle ile APK derlemesi (SDK/`android.jar` ve Gradle dağıtımı gereken ortam).
2. Gerçek Android cihazda 60 saniye MP4 kodlama; işlemci, RAM ve depolama kullanımını ölç.
3. Bedrock 1.21.132.1'de gerçek içe aktarma ve dünya içi test.
4. Üretilmiş Minecraft animasyon, item ve scriptlerinin oyun içi semantik testi.
5. MLP'nin daha büyük görsel veri kümesiyle eğitimi ve daha güçlü kompozisyon üretimi.

## Değişen ana dosyalar
- `app/src/main/java/com/jai/assistant/engine/VisualLearningEngine.java`
- `app/src/main/java/com/jai/assistant/engine/ProceduralImageGenerator.java`
- `app/src/main/java/com/jai/assistant/engine/VideoScenePlanner.java` (yeni)
- `app/src/main/java/com/jai/assistant/media/AndroidVideoGenerator.java`
- `app/src/main/java/com/jai/assistant/engine/MinecraftPackGenerator.java`
- `app/src/main/java/com/jai/assistant/engine/BedrockPackRepairEngine.java`
- `app/src/main/java/com/jai/assistant/engine/CodeGenerator.java`
- `app/src/main/java/com/jai/assistant/MainActivity.java`
- `app/src/test/java/com/jai/assistant/engine/VideoScenePlannerTest.java` (yeni)
- `app/src/test/java/com/jai/assistant/media/AndroidVideoGeneratorDurationTest.java`
- `app/build.gradle` (`versionCode 19`, `versionName 0.9.7`)
