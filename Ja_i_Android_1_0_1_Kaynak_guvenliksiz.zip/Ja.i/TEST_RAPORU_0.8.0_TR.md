# Ja.i 0.8.0 — Değişiklik ve kontrol raporu

## Yapılan değişiklikler
- `SettingsManager`: Akıllı/Manuel aşama modu ve 1–115 arası manuel sayı cihaz ayarlarında saklanır.
- `MainActivity`: Zekâ ayarları dialogu eklendi; sayı doğrulaması ve kayıt eklendi.
- `activity_main.xml`: Zekâ ayarları düğmesi ve işlem ilerleme çubuğu eklendi.
- `MainActivity`: Yerel yanıt hazırlama, isteğe bağlı web araştırması ve kayıt aşamalarında ilerleme güncellenir.
- `JA_I_YENI_GEREKSINIMLER_0.8.0_TR.md`: Eğitim, özgün kod üretimi ve gerçek çok aşamalı model çalışması için gereksinimler ve eksik durumlar kaydedildi.

## Kontroller
- Android `src/main` altındaki 5 XML dosyası Python XML ayrıştırıcısıyla başarıyla ayrıştırıldı.
- Gradle doğrulama/test komutu denendi: `./gradlew validateAndroidResources testDebugUnitTest`.
- Gradle başlatıcısı Gradle dağıtımını `services.gradle.org` adresinden indirmeye ihtiyaç duydu; bu çalışma ortamında indirme başarısız oldu. Dolayısıyla Gradle doğrulama, Java birim testleri ve APK derlemesi tamamlanamadı.

## Henüz tamamlanmayanlar
- Eğitilmiş 65M parametreli model, tokenizer ve Android çıkarım motoru yok.
- Ayarlardaki aşama sayısı henüz model çağrı döngüsünü yönetmiyor; yalnızca saklanıyor.
- İlerleme çubuğu gerçek uygulama görev aşamalarını gösterir; modelin kaç kez çalıştığını göstermez.
- `CodeGenerator` hâlâ anahtar sözcük/şablon tabanlıdır. Özgün genel kod üretimi tamamlanmadı.
- APK ve gerçek Android cihaz testi yapılmadı.


## Geliştirme oturumu — Think işlem hattı

- `TaskStageEngine` eklendi: otomatik/manuel aşama planı üretir; iş çalıştırma aşamasını atlamaz.
- `BrainEngine` Think modunda analiz, ilgili yerel bağlam taraması, plan, gerçek yerel görev çalıştırması ve çıktı kontrolünü ayrı aşamalar olarak yürütür.
- `MainActivity` aşama ilerlemesini gerçek tamamlanan aşamalardan günceller.
- Manuel 1–115 değeri görev için üst sınırdır; 5'ten fazla bağımsız yerel adım mevcut değilse açık durma nedeni raporlanır. Bu, 115 model çıkarımı anlamına gelmez.
- `TaskStageEngineTest` eklendi: manuel 1, manuel 4, manuel 115 ve Hızlı/Derin otomatik farkı sınanır.

**Henüz çalıştırılmayan kontroller:** Gradle dağıtımının ve Android SDK'nın bu ortamda bulunup bulunmadığı henüz doğrulanmadı; bu nedenle APK derlemesi ve Android cihaz testi yapılmış sayılmaz. Birim testleri sonraki doğrulama adımında çalıştırılacaktır.
