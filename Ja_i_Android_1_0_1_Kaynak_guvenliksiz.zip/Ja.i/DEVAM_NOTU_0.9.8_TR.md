# DEVAM NOTU — Ja.i 0.9.8

## Hedef
Ara açıkken görsel örneklerini web'den alıp yerel görsel öğrenme altyapısına eklemek; üretilmiş kendi çizimini eğitim kaynağı olarak kullanmamak; raster PNG üretimini yerel örnekler ve ağla sürdürmek.

## Mimari kararlar
- Haricî AI API'si veya indirilmiş hazır AI modeli yok.
- Görsel web araması yalnızca kullanıcı `Ara`yı açtığında çalışır.
- En çok 4 görsel, her biri en çok 1,5 MB; 256 px'e kadar küçültülüp `.jaimg` örneği olarak saklanır.
- Etiket başına en çok 5 referans örneği saklanır.
- Geçerli ama eğitilmemiş kavramlarda uygulama eski geometrik çiziciye sessizce düşmez.
- MLP 16→128→64→3 ve örnek pikseli karışımı mevcut ilk aşama yaklaşımıdır; gelişmiş üretken görsel zekâ değildir.

## Son doğrulananlar
- Saf Java motor sınıfları `javac -Xlint:all` ile derlendi.
- Hedefli smoke testi JSON ayrıştırma, URL güvenliği, 5 örnek sınırı, model kaydet/yükle, raster PNG ve eğitilmemiş konu reddini geçti.

## Açık işler
1. Android telefonda `Ara` açıkken zürafa/başka nesne görsel aramasının çalıştığını doğrula.
2. Gerçek indirilmiş görsellerin etiket doğruluğunu denetle; hatalı arama sonuçlarını eğitim dışı bırakacak kullanıcı onay adımı ekle.
3. Çok daha güçlü, yerel ve sıfırdan eğitilebilir görsel üretim mimarisi tasarla; küçük MLP'yi tek başına yüksek kaliteli üretim gibi sunma.
4. Android SDK bulunan ortamda `testDebugUnitTest` ve APK derlemesini yap.
5. Gerçek cihazda işlemci yükü, RAM, depolama kullanımı ve eğitim süresini ölç.

## Ana değişen dosyalar
- `app/src/main/java/com/jai/assistant/tools/WebImageResearchEngine.java`
- `app/src/main/java/com/jai/assistant/engine/VisualLearningEngine.java`
- `app/src/main/java/com/jai/assistant/engine/ProceduralImageGenerator.java`
- `app/src/main/java/com/jai/assistant/MainActivity.java`
- `app/src/test/java/com/jai/assistant/tools/WebImageResearchEngineTest.java`
- `app/build.gradle`
