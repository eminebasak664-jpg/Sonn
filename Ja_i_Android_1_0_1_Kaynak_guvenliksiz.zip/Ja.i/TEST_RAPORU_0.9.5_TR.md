# Ja.i 0.9.5 test raporu

## Çalıştırılan testler
- Yeni görsel, paket, ikili ZIP ve mevcut üretici çekirdeğinin Java kaynakları JDK 21 ile derlendi.
- Doğrudan üretim harness'i PNG, resource `.mcpack`, behavior `.mcpack` ve combined `.mcaddon` üretti. Regresyon kontrolünde eski çok dosyalı web proje üretimi ve yapılandırılmış JavaScript sentezi de tekrar çalıştırıldı.
- Görsel PNG, Pillow ile açıldı: 128×128, RGBA.
- Üretilen üç Minecraft paketi açıldı; JSON dosyalarının tamamı Python `json` ile ayrıştırıldı. Son combined pakette 24 dosya üretildi.
- Combined pakette kaynak ve davranış manifesti; yaratık entity/spawn/loot, geometri ve texture; özel blok, eşya, tarif, loot ve terrain texture dosyaları bulundu.
- Görsel ve paket üretim kodları haricî ağ/API/model çağrısı yapmadan çalıştı.

## Bu ortamda yapılamayan testler
- JUnit/Gradle test görevi çalıştırılmadı; Gradle 8.9 dağıtımı önbellekte yok ve Android SDK/android.jar bulunmuyor.
- MainActivity'nin tam Android derlemesi, emulator/telefon testi, SAF kaydetme UI akışı ve Minecraft oyun içi import/oynanış testi yapılmadı.
- Bedrock paketi şemaları hedeflenen sürüm şablonlarına göre üretildi; oyun içi tam uyumluluk kesinleştirilmiş değildir.

## Manuel test planı (Android)
1. `Kod Laboratuvarı` aç.
2. `mor bir ejderha çiz 128x128` yazıp `Üret` seç; PNG önizlemesini gör ve `Üretilen dosyayı kaydet` ile PNG'yi kaydet.
3. `Minecraft kaynak paketi yap` yaz; `.mcpack` kaydet ve Bedrock içe aktarmayı dene.
4. `Minecraft davranış paketi yap` yaz; `.mcpack` kaydet ve dünya ayarlarında etkinleştir.
5. `Minecraft için özel yaratık ve kaynak/davranış paketini mcaddon olarak yap` yaz; `.mcaddon` kaydet, Minecraft'ta içe aktar ve dünya ayarlarında iki paketi etkinleştir.
6. Içe aktarma sonrası özel blok/eşya tariflerini ve yaratığın spawn/düşürme davranışını test et. Hata varsa Minecraft sürümü ve içerik günlüğünü paylaş.
