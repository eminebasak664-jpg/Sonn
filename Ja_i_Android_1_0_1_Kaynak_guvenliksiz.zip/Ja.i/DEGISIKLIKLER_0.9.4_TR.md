# Ja.i 0.9.4 — Çok dosyalı yerel kod üretimi

## Yeni üretim hattı
- `ProjectCodeGenerator.java`: desteklenen Türkçe proje tariflerinden bileşen seçer ve ayrı HTML/CSS/JavaScript/README dosyaları sentezler.
- Desteklenen birleştirilebilir modüller: puan sayacı, görev listesi, yerel not defteri, dört işlem hesap makinesi, kronometre.
- Desteklenen oyun mekanikleri: tıklama oyunu, hafıza kartı eşleştirme, refleks testi, bilgi yarışması ve iki kişilik X-O.
- Tarif içinden proje adı ve vurgu rengi çıkarılabilir. HTML metinleri kaçırılır; form girdileri DOM `textContent` ile gösterilir.
- Projeler vanilla HTML/CSS/JS ile hazırlanır; CDN, uzak API veya internet bağımlılığı yoktur. Kalıcı görev/not/sayaç kayıtları tarayıcının `localStorage` alanındadır.

## Proje denetimi ve dışa aktarma
- `ProjectCodeValidator.java`: dosya varlığı/bağlantısı, temel HTML etiketleri ve CSS/JS ayraç kontrolleri.
- `ProjectArchiveWriter.java`: proje dosyalarını UTF-8 ZIP'e yazar; yol geçişi reddedilir, 64 dosya ve 2 MiB kaynak toplamı sınırları uygulanır.
- `FileManager.writeBytes`: üretilen ZIP'i Android Storage Access Framework hedefine kaydeder.
- Kod Laboratuvarı: çok dosyalı proje üretiminde `index.html` önizleme metni gösterilir; ayrı düğmeyle ZIP kaydedilir. Projeler Kod Laboratuvarı DOM sandbox'ında çalıştırılmaz; dışa aktarılıp tarayıcıda açılır.
- Sohbet tarafındaki açık kod üretme isteği, dosya listesi ve her dosyanın kaynak kodunu döndürür.

## Sınıflandırma
- `ModelEngine` için Türkçe web uygulaması, oyun geliştirme ve çok dosyalı proje istekleri eğitim örnekleri eklendi.

## Test/kanıt sınırı
- Android'in Java 17 hedefiyle uyum için saf Java çekirdek sınıfları `javac --release 17` ile derlendi.
- Geçici JUnit uyumlu test çalıştırıcısı ve `MemoryDatabase` test stub'ı kullanılarak 8 test sınıfındaki 42 test geçti. Bu, Gradle/JUnit Android proje testi değildir.
- 10 doğal dil isteğiyle proje matrisi üretildi; her projede dört kaynak dosyası, statik proje doğrulaması ve ZIP bütünlüğü kontrol edildi.
- 10 üretilmiş `app.js` dosyasının tamamı Node.js 22 `node --check` denetiminden geçti.
- MainActivity, BrainEngine, CodeGenerator, yeni proje sınıfları, FileManager ve ModelEngine üzerinde statik ayraç kontrolü geçti.
- Gerçek Chrome/Android tarayıcı etkileşim testi bu ortamda tamamlanamadı; headless Chromium süreçleri ortamda zaman aşımına uğradı. Bu nedenle butonların gerçek tarayıcı davranışı doğrulanmış sayılmaz.
- Android SDK/Gradle derlemesi ve APK üretimi bu ortamda yapılmadı.

## Bilinçli sınırlar
- Bu üretici genel amaçlı LLM değildir. Desteklenen işlevlerin yerel ayrıştırılması ve kaynak birleştirmesidir.
- Özel Java/Android uygulaması, APK, 3D oyun motoru, keyfî Python/Java proje ve istekten bağımsız karmaşık tasarımlar hâlâ kapsam dışıdır.
- HTML projeleri ZIP olarak dışa aktarılır; telefon tarayıcısında kullanıcı tarafından açılır.
- Haricî AI API'si, indirilen model veya uzak kod üretim servisi kullanılmaz.
