# Ja.i 1.0.0 — APK oluşturma

Bu dosya eski sürüm kılavuzlarının yerine bırakılmış kısa yönlendirmedir. Güncel adımlar için **`APK_OLUSTUR_TELEFON_1.0.0_TR.md`** dosyasını kullan.

- Güncel kaynak ZIP: `Ja.i_Android_1.0.0_Tam_Kaynak_Colab.zip`
- GitHub Actions: `.github/workflows/android.yml`
- Colab eğitimi: `colab/Ja.i_1.0.0_Sifirdan_Sohbet_Modeli_Egitimi.ipynb`
- Colab modeli uygulamaya aktarma: Ja.i → Zekâ ayarı → Colab modelini yükle.

Arşiv bir kaynak paketidir, hazır APK değildir. Gerçek APK, GitHub Actions veya Android SDK bulunan bir derleme ortamında üretilmelidir.
