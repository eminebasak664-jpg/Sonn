# Ja.i 0.9.6 — Devam Notu

## Bu sürümde eklenenler
- Varsayılan 1280×720 PNG, dikey 720×1280, pixel-art ızgara ve nearest-neighbor upscale.
- Yerel 12→32→3 MLP; kullanıcı görselleriyle backpropagation, yerel model saklama ve örnek görsel belleği.
- Kullanıcının arşivde bulunan Altın Ağ Küresi Amblemi 256×256 örneği başlangıç eğitim verisi yapıldı; model ağırlığı `app/src/main/assets/visual-model-jaiv.bin` içinde.
- Android MediaCodec/H.264 720p MP4 yolu (24 FPS, 4 saniye, pan/zoom/partikül; cihaz testi yok).
- Minecraft Bedrock resource/behavior `.mcpack`, iç paketli `.mcaddon`, `.mcworld` kapsayıcısı, 7 animasyon, ses OGG'leri, Script API ve özel blok/eşya tarifleri.
- Genel amaçlı runnable Java 8 `.jar` üretimi.

## Doğrulama
- 13 üretim/öğrenme/paket testi geçti (yerel JUnit-uyumlu adaptör; Gradle test görevi değil).
- Saf Java çekirdek derlemesi geçti; 720p PNG çıktı açıldı; MLP örneğiyle 720p render görseli açıldı.
- Add-on iç arşivleri, JSON'lar, CRC, manifestler, OGG başlıkları, animasyon adları ve script sözdizimi kontrol edildi.
- JAR `java -jar` ile çalıştı.
- Android tam APK ve gerçek cihaz / Minecraft oyun testi yapılmadı.

## Bilinen gerçek sınırlar
- MLP genel amaçlı diffusion/text-to-image modeli değil; bir başlangıç örneği ve kullanıcı etiketli görsel örnekleriyle öğrenir. Yeni türler için yeni örnek gerekir.
- 720p MP4 kodu var; gerçek Android MediaCodec doğrulaması yok ve video kısa pan/zoom animasyonudur, tam metinden video üretimi değildir.
- `.mcworld` arşivinde LevelDB `db/` henüz boş; tam oynanabilir dünya garantisi yok.
- JAR genel çalıştırılabilir Java JAR'ıdır; Fabric/Forge modu değil.
- Minecraft'ta paket import/runtime uyumluluğu doğrulanmadı.

## Bir sonraki işler
1. Android SDK bulunan GitHub Actions ortamında `validateAndroidResources testDebugUnitTest assembleDebug` çalıştır ve derleme hatalarını gider.
2. Gerçek telefonda 720p MP4 MediaCodec, bellek kullanımı ve dosya kaydetme testlerini yap.
3. Minecraft Bedrock sürümünde Add-on import, script, animasyon, ses, özel eşya/blok ve world testlerini yap.
4. Oyun içinde gerçek dünya oluşturmak için Bedrock LevelDB üretim/başlangıç veritabanı uyumluluğunu araştır ve test et.
5. Görsel MLP'nin birden fazla örnek/etiketle doğruluğunu ölç; kapasiteyi ancak telefon RAM/CPU ölçümleriyle artır.
