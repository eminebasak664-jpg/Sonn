@echo off
setlocal
set APP_HOME=%~dp0
cd /d "%APP_HOME%"
where java >nul 2>nul
if not %ERRORLEVEL% EQU 0 (
  echo Java bulunamadi. JDK 17 veya uyumlu Java kurulumu gerekiyor.
  exit /b 1
)
java %JAVA_OPTS% %GRADLE_OPTS% -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
