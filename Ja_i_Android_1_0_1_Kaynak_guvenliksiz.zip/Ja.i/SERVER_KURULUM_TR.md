# Ja.i mesaj sunucusu kurulumu (0.6.0)

Bu klasörde `server/main.py`, `requirements.txt` ve `Dockerfile` bulunur. Sunucu uygulaması Android APK'sından ayrıdır. Android tarafında **Sunucu** bölümüne girilecek HTTPS temel adresi bu hizmetin dağıtım adresidir.

## Sunucunun sunduğu API

- `GET /health` — sağlık kontrolü.
- `POST /v1/register` — hesap açma (kullanıcı adı 3-24 karakter, parola en az 10 karakter).
- `POST /v1/login` — giriş ve 30 günlük erişim belirteci.
- `POST /v1/messages` — kullanıcı adına mesaj gönderme.
- `GET /v1/messages?after_id=0` — gelen kutusunu eşitleme; bu işlem mesajları teslim edildi olarak işaretler.
- `POST /v1/messages/{id}/read` — kullanıcının açıkça seçtiği mesajı okundu işaretleme.
- `GET /v1/messages/{id}/status` — gönderildi/teslim edildi/okundu durumunu sorgulama.
- `POST /v1/logout` — sunucu oturum belirtecini iptal etme.

Kimlik doğrulaması gereken uç noktalara `Authorization: Bearer <token>` başlığı gönderilir. Android istemcisi HTTPS dışında bağlantı kurmaz.

## Docker ile yerel deneme

JDK/Android aracı gerekmez; Python 3.12 ve Docker yeterlidir.

```sh
cd server
docker build -t jai-message-server .
docker run --name jai-message-server -p 8000:8000 -v jai-data:/data jai-message-server
```

Yerel sağlık testi: `http://127.0.0.1:8000/health`. Bu adres yalnızca aynı cihaz/yerel test içindir; Android dış ağdan bu adrese erişemez. İnternete açılacak gerçek dağıtımda HTTPS ters proxy/platform TLS, kalıcı `/data` hacmi ve güvenlik duvarı gerekir. Uygulama HTTP adresini kabul etmez.

## Bulut barındırma

Python 3.12 veya Docker destekleyen bir barındırma hizmeti seç. Repodaki `server/` klasörünü servis kaynağı olarak bağla; Dockerfile kullan veya şu komutu çalıştır:

```sh
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

Platformun verdiği HTTPS adresini Ja.i → Sunucu bölümüne gir. Kalıcı disk/volume özelliği varsa `/data` yoluna bağla. Kalıcı disk yoksa ücretsiz servis yeniden başlatıldığında SQLite veritabanı silinebilir. Uykuya geçen barındırma hizmetlerinde uygulamanın açılışında tek `/health` isteği servisi uyandırabilir; bu yalnızca platformun isteğe bağlı uyandırma desteği varsa geçerlidir.

Ücretsiz planlar zamanla değişebilir. Kredi/banka kartı gerekip gerekmediğini, uykuya geçme politikasını, depolama kalıcılığını, ücretsiz kullanım kotalarını ve hizmetin 7/24 çalışmaya izin verip vermediğini kayıt olmadan önce sağlayıcının güncel koşullarından kontrol et. Ja.i belirli bir ücretsiz sunucu sağlayıcısına bağlı değildir ve ücretsiz 7/24 çalışma garantisi vermez.

## İki cihazda deneme

1. Sunucu internette HTTPS ile çalışıyor ve `/health` yanıt veriyor olmalı.
2. Her iki Ja.i kurulumunda aynı HTTPS temel adresini Sunucu ayarına kaydet.
3. İlk cihazda Mesajlaşma → Kayıt ile bir kullanıcı oluştur.
4. İkinci cihazda farklı kullanıcı adıyla kayıt oluştur.
5. Birinci cihazdan ikinci kullanıcının adını yazarak mesaj gönder.
6. İkinci cihaz Gelen kutusu düğmesine dokunarak mesajı eşitlesin. Sunucu mesajı bu aşamada **teslim edildi** olarak işaretler.
7. İkinci cihaz mesaj numarasını girip **Seçilen mesajı okundu işaretle** düğmesine basarsa durum **okundu** olur.
8. Birinci cihaz son gönderdiği mesajın durumunu sunucudan sorgulayabilir.

Gelen kutusu eşitlemesi elle yapılır; push bildirimi yoktur. Sunucuya gönderilen mesaj metni SQLite'da okunabilir olarak saklanır. Uçtan uca şifreleme bu sürümde yoktur. Gerçek kişisel veya gizli bilgiler göndermeyin.

## Güvenlik uyarıları

- Sunucuyu herkese açık yayınlamadan önce güncel TLS/HTTPS, kalıcı depolama, yedekleme ve erişim izleme ayarlarını yap.
- SQLite veritabanı ve mesaj gövdeleri sunucu işletmecisi tarafından okunabilir.
- Parolalar PBKDF2-HMAC-SHA256 ile özetlenir; oturum belirteçlerinin ham değeri sunucu veritabanında saklanmaz.
- Sunucuda tek süreç için IP başına temel hız sınırı vardır (kayıt/giriş yolları dakikada 6, genel istekler dakikada 120). Bu dağıtık/çoklu worker koruması değildir. Uçtan uca şifreleme, yönetici paneli, hesap kurtarma, kötüye kullanım raporlama ve üretim seviyesi abuse önleme henüz yoktur. Herkese açık, güvenilmeyen kullanıcıların olduğu geniş bir servis olarak kullanma.
- Hesap parolanı veya erişim belirtecini sohbet içinde kimseyle paylaşma.
