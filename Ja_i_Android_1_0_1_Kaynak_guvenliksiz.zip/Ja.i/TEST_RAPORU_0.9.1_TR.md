# Ja.i 0.9.1 — Zekâ altyapısı test raporu

## Kontrol edilen değişiklikler
- BrainEngine Think pipeline ve SQLite checkpoint/resume akışı.
- ToolRegistry puanlı araç seçimi.
- TaskPlanner.ExecutionPlan.
- ModelEngine göreli sınıflandırma puanları.
- Yerel bağlamın yanıt seçimine aktarılması.
- Think aşama sıralaması.

## Test sonuçları

### 15 çekirdek test geçti
1. TaskPlanner derin efor planı.
2. TaskPlanner hızlı/derin plan uzunluğu.
3. Manuel 1 aşamada yürütme.
4. Manuel 2 aşamada analiz sonra yürütme.
5. Manuel 3 aşamada bağlam araması sonra yürütme.
6. Manuel 4 aşamada planlamanın yürütmeden önce olması.
7. Manuel 5 aşamada doğrulamanın yürütmeden sonra olması.
8. 115 isteğinde tekrar aşaması uydurulmaması.
9. Akıllı Hızlı ve Derin aşama sayısı farkı.
10. ToolRegistry'nin en yüksek puanlı eşleşmeyi seçmesi.
11. Eşleşme yokken araç seçilmemesi.
12. Seçilen aracın doğru girdiyi çalıştırması.
13. ExecutionPlan içinde seçilen araç ve işlem adımları bulunması.
14. ModelEngine'in bilinen niyeti sınıflandırması ve puan dağılımının 1'e toplamı.
15. Öğretilen örneğin sınıflandırıcı eğitim kümesine eklenmesi.

Bu testler geçici JUnit uyumlu test adaptörüyle JDK 21 üzerinde çalıştırıldı. Gradle JUnit çalışma zamanı değildir.

### 6 BrainEngine entegrasyon simülasyonu geçti
- Kullanıcı notu kaydedildi ve Think bağlam aramasıyla yanıt içeriğine aktarıldı.
- “4+5 kaç eder” isteğinde calculator aracı otomatik seçildi ve sonucu üretti.
- Think görevi `brain` türüyle görev tablosuna kaydedildi ve her aşamadan sonra kontrol noktası güncellendi.
- Birinci aşamadan sonra simüle edilen kesintinin ardından `görev devam: ID` ilk tamamlanmamış aşamadan devam etti ve görevi tamamladı.
- Özgün kullanıcı girdisinin ayrı payload alanında bulunduğu ve checkpoint JSON içinde yinelenmediği kontrol edildi.
- `görevleri göster` çıktısının Think ve öğrenme görevlerini birlikte listelediği doğrulandı.

Bu entegrasyon denemesinde gerçek Android `Context`, gerçek Android SQLite veya Android `org.json` yerine geçici test adaptörleri kullanıldı. Bu nedenle SQLite transaction ve v2→v3 migration gerçek Android veritabanında henüz cihaz üzerinde doğrulanmış değildir. Sonuçlar gerçek cihaz testinin yerine geçmez.

### 2 SQLite şema/payload simülasyonu geçti
- Eski v2 şemasından `brain_task_payloads` tablosunu oluşturan geçiş SQL'i SQLite test veritabanında çalıştırıldı; mevcut hafıza satırının korunduğu görüldü.
- Görev checkpoint JSON'u güncellenirken özgün promptun ayrı payload tablosunda kaldığı doğrulandı.
- Bu test Python SQLite ile SQL davranışını doğrular; Android `SQLiteOpenHelper` çalışma zamanının cihaz üzerinde testi değildir.

## Derleme ve doğrulama sınırları
- `./gradlew testDebugUnitTest --no-daemon` denendi; proje başlatıcısı Gradle 8.9 dağıtımını indiremediği için başarısız oldu.
- Ortamda Android SDK ve `android.jar` bulunmadığından tam Android derlemesi yapılamadı.
- Gerçek Android SQLite transaction/checkpoint/resume, MainActivity ekran ilerlemesi ve cihaz yeniden başlatma testi yapılmadı. `MemoryDatabase.java` JDK 21 üzerinde geçici Android SQLite API sınıflarıyla sözdizimi/çağrı uyumluluğu için derlendi; bu Android derlemesinin yerine geçmez.
- Canlı web araması ve dosya araçlarının bu sürümde yeniden testi yapılmadı; 0.9.0 dosya/web kaynakları korundu.

## Doğrulanmış olmayan iddialar
- Bu paket ChatGPT seviyesinde bir genel dil modeli eklemez.
- Naive Bayes'in göreli puanı kalibre edilmiş güven değeri değildir.
- Statik kod ön kontrolü kod derlemesi/çalıştırması değildir.
- Think aşamaları gerçek yerel işlemlerdir; ardışık LLM çıkarımı değildir.
